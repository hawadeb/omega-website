﻿using System;
using HarmonyLib;

namespace untitled.Core.Patches
{
	// Token: 0x0200002B RID: 43
	[HarmonyPatch(typeof(VRRig), "OnDisable", 0)]
	public class RigPatch
	{
		// Token: 0x0600019C RID: 412 RVA: 0x00019BC4 File Offset: 0x00017DC4
		public static bool Prefix(VRRig __instance)
		{
			return !(__instance == GorillaTagger.Instance.offlineVRRig);
		}
	}
}
