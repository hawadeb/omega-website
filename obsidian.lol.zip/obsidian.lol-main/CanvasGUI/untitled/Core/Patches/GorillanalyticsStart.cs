﻿using System;
using HarmonyLib;
using UnityEngine;

namespace untitled.Core.Patches
{
	// Token: 0x0200001A RID: 26
	[HarmonyPatch(typeof(Gorillanalytics), "Start", 5)]
	public class GorillanalyticsStart : MonoBehaviour
	{
		// Token: 0x0600017A RID: 378 RVA: 0x00019988 File Offset: 0x00017B88
		private static bool Prefix()
		{
			return false;
		}
	}
}
