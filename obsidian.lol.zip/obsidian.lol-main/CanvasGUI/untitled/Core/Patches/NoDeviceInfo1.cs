﻿using System;
using HarmonyLib;
using PlayFab;

namespace untitled.Core.Patches
{
	// Token: 0x02000020 RID: 32
	[HarmonyPatch(typeof(PlayFabClientAPI), "ReportDeviceInfo")]
	internal class NoDeviceInfo1
	{
		// Token: 0x06000186 RID: 390 RVA: 0x00019A90 File Offset: 0x00017C90
		private static bool Prefix()
		{
			return false;
		}
	}
}
