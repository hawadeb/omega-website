﻿using System;
using HarmonyLib;

namespace untitled.Core.Patches
{
	// Token: 0x02000024 RID: 36
	[HarmonyPatch(typeof(GorillaNetworkPublicTestsJoin))]
	[HarmonyPatch("GracePeriod", 5)]
	public class NoGracePeriod
	{
		// Token: 0x0600018E RID: 398 RVA: 0x00019B00 File Offset: 0x00017D00
		public static bool Prefix()
		{
			return false;
		}
	}
}
