﻿using System;
using HarmonyLib;

namespace untitled.Core.Patches
{
	// Token: 0x02000025 RID: 37
	[HarmonyPatch(typeof(GorillaNetworkPublicTestJoin2))]
	[HarmonyPatch("LateUpdate", 0)]
	public class NoGracePeriod2
	{
		// Token: 0x06000190 RID: 400 RVA: 0x00019B1C File Offset: 0x00017D1C
		public static bool Prefix()
		{
			return false;
		}
	}
}
