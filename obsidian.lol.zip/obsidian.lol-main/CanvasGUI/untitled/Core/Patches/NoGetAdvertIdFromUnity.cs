﻿using System;
using HarmonyLib;
using PlayFab.Internal;

namespace untitled.Core.Patches
{
	// Token: 0x02000023 RID: 35
	[HarmonyPatch(typeof(PlayFabDeviceUtil), "GetAdvertIdFromUnity")]
	internal class NoGetAdvertIdFromUnity
	{
		// Token: 0x0600018C RID: 396 RVA: 0x00019AE4 File Offset: 0x00017CE4
		private static bool Prefix()
		{
			return false;
		}
	}
}
