﻿using System;
using HarmonyLib;
using PlayFab.Internal;

namespace untitled.Core.Patches
{
	// Token: 0x0200001F RID: 31
	[HarmonyPatch(typeof(PlayFabDeviceUtil), "SendDeviceInfoToPlayFab")]
	internal class NoDeviceInfo
	{
		// Token: 0x06000184 RID: 388 RVA: 0x00019A74 File Offset: 0x00017C74
		private static bool Prefix()
		{
			return false;
		}
	}
}
