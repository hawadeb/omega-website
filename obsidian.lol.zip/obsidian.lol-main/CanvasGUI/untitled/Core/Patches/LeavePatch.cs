﻿using System;
using HarmonyLib;
using Photon.Pun;
using Photon.Realtime;

namespace untitled.Core.Patches
{
	// Token: 0x0200001C RID: 28
	[HarmonyPatch(typeof(MonoBehaviourPunCallbacks), "OnPlayerLeftRoom")]
	public class LeavePatch
	{
		// Token: 0x0600017E RID: 382 RVA: 0x000199F0 File Offset: 0x00017BF0
		public static void Prefix(Player newPlayer)
		{
			bool flag = newPlayer != LeavePatch.lastPlayerLeft;
			bool flag2 = flag;
			if (flag2)
			{
				Notifications.SendNotification("<color=grey>[</color><color=red>LEFT</color><color=grey>] </color><color=white>Name: " + newPlayer.NickName + "</color>");
				LeavePatch.lastPlayerLeft = newPlayer;
			}
		}

		// Token: 0x0400016F RID: 367
		private static Player lastPlayerLeft;
	}
}
