﻿using System;
using System.Collections.Generic;
using HarmonyLib;
using PlayFab;
using PlayFab.ClientModels;

namespace untitled.Core.Patches
{
	// Token: 0x02000029 RID: 41
	[HarmonyPatch(typeof(PlayFabClientInstanceAPI), "ReportPlayer", 0)]
	public class NoReportPlayer
	{
		// Token: 0x06000198 RID: 408 RVA: 0x00019B8C File Offset: 0x00017D8C
		private static bool Prefix(ReportPlayerClientRequest request, Action<ReportPlayerClientResult> resultCallback, Action<PlayFabError> errorCallback, object customData = null, Dictionary<string, string> extraHeaders = null)
		{
			return false;
		}
	}
}
