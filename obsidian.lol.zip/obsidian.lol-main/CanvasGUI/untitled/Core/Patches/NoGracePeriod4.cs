﻿using System;
using HarmonyLib;

namespace untitled.Core.Patches
{
	// Token: 0x02000027 RID: 39
	[HarmonyPatch(typeof(GorillaNetworkPublicTestsJoin))]
	[HarmonyPatch("LateUpdate", 0)]
	public class NoGracePeriod4
	{
		// Token: 0x06000194 RID: 404 RVA: 0x00019B54 File Offset: 0x00017D54
		public static bool Prefix()
		{
			return false;
		}
	}
}
