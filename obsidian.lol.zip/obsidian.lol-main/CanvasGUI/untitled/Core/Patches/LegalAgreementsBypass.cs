﻿using System;
using HarmonyLib;

namespace untitled.Core.Patches
{
	// Token: 0x0200001D RID: 29
	[HarmonyPatch(typeof(LegalAgreements), "Awake", 0)]
	internal class LegalAgreementsBypass
	{
		// Token: 0x06000180 RID: 384 RVA: 0x00019A3C File Offset: 0x00017C3C
		private static bool Prefix()
		{
			return false;
		}
	}
}
