﻿using System;
using HarmonyLib;

namespace untitled.Core.Patches
{
	// Token: 0x02000026 RID: 38
	[HarmonyPatch(typeof(GorillaNetworkPublicTestJoin2))]
	[HarmonyPatch("GracePeriod", 5)]
	public class NoGracePeriod3
	{
		// Token: 0x06000192 RID: 402 RVA: 0x00019B38 File Offset: 0x00017D38
		public static bool Prefix()
		{
			return false;
		}
	}
}
