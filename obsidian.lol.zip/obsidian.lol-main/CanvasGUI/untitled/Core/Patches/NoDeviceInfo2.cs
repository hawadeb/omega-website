﻿using System;
using HarmonyLib;
using PlayFab;

namespace untitled.Core.Patches
{
	// Token: 0x02000021 RID: 33
	[HarmonyPatch(typeof(PlayFabClientInstanceAPI), "ReportDeviceInfo")]
	internal class NoDeviceInfo2
	{
		// Token: 0x06000188 RID: 392 RVA: 0x00019AAC File Offset: 0x00017CAC
		private static bool Prefix()
		{
			return false;
		}
	}
}
