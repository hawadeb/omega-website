﻿using System;
using HarmonyLib;
using UnityEngine;

namespace untitled.Core.Patches
{
	// Token: 0x02000018 RID: 24
	[HarmonyPatch(typeof(Gorillanalytics), "UploadGorillanalytics", 0)]
	public class AnalyticsPatch : MonoBehaviour
	{
		// Token: 0x06000176 RID: 374 RVA: 0x00019910 File Offset: 0x00017B10
		private static bool Prefix()
		{
			return false;
		}
	}
}
