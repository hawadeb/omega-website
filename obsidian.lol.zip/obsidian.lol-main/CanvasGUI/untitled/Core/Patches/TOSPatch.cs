﻿using System;
using HarmonyLib;

namespace untitled.Core.Patches
{
	// Token: 0x0200002C RID: 44
	[HarmonyPatch(typeof(LegalAgreements))]
	[HarmonyPatch("PostUpdate", 0)]
	internal class TOSPatch
	{
		// Token: 0x0600019E RID: 414 RVA: 0x00019BF4 File Offset: 0x00017DF4
		private static bool Prefix(LegalAgreements __instance)
		{
			bool flag = TOSPatch.turnedthefuckon;
			bool flag2 = flag;
			bool flag3;
			if (flag2)
			{
				Traverse.Create(__instance).Field("controllerBehaviour").Field("buttonDown")
					.SetValue(true);
				Traverse.Create(__instance).Field("holdTime").SetValue(0.1f);
				flag3 = false;
			}
			else
			{
				flag3 = true;
			}
			return flag3;
		}

		// Token: 0x04000170 RID: 368
		public static bool turnedthefuckon;
	}
}
