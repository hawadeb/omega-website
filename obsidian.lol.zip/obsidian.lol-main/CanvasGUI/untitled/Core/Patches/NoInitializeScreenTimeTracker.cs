﻿using System;
using HarmonyLib;
using PlayFab.Internal;

namespace untitled.Core.Patches
{
	// Token: 0x02000028 RID: 40
	[HarmonyPatch(typeof(PlayFabHttp), "InitializeScreenTimeTracker")]
	internal class NoInitializeScreenTimeTracker
	{
		// Token: 0x06000196 RID: 406 RVA: 0x00019B70 File Offset: 0x00017D70
		private static bool Prefix()
		{
			return false;
		}
	}
}
