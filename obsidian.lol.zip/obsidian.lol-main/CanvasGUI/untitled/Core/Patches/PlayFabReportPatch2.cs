﻿using System;
using System.Collections.Generic;
using HarmonyLib;
using PlayFab;
using PlayFab.ClientModels;

namespace untitled.Core.Patches
{
	// Token: 0x0200002A RID: 42
	[HarmonyPatch(typeof(PlayFabClientAPI), "ReportPlayer", 0)]
	public class PlayFabReportPatch2
	{
		// Token: 0x0600019A RID: 410 RVA: 0x00019BA8 File Offset: 0x00017DA8
		private static bool Prefix(ReportPlayerClientRequest request, Action<ReportPlayerClientResult> resultCallback, Action<PlayFabError> errorCallback, object customData = null, Dictionary<string, string> extraHeaders = null)
		{
			return false;
		}
	}
}
