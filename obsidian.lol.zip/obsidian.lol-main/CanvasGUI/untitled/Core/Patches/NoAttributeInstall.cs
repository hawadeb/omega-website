﻿using System;
using HarmonyLib;
using PlayFab;

namespace untitled.Core.Patches
{
	// Token: 0x0200001E RID: 30
	[HarmonyPatch(typeof(PlayFabClientAPI), "AttributeInstall")]
	internal class NoAttributeInstall
	{
		// Token: 0x06000182 RID: 386 RVA: 0x00019A58 File Offset: 0x00017C58
		private static bool Prefix()
		{
			return false;
		}
	}
}
