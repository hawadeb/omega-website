﻿using System;
using HarmonyLib;
using PlayFab.Internal;

namespace untitled.Core.Patches
{
	// Token: 0x02000022 RID: 34
	[HarmonyPatch(typeof(PlayFabDeviceUtil), "DoAttributeInstall")]
	internal class NoDoAttributeInstall
	{
		// Token: 0x0600018A RID: 394 RVA: 0x00019AC8 File Offset: 0x00017CC8
		private static bool Prefix()
		{
			return false;
		}
	}
}
