﻿using System;
using HarmonyLib;
using UnityEngine;

namespace untitled.Core.Patches
{
	// Token: 0x02000019 RID: 25
	[HarmonyPatch(typeof(GameObject), "CreatePrimitive", 0)]
	public class GameObjectPatch
	{
		// Token: 0x06000178 RID: 376 RVA: 0x0001992C File Offset: 0x00017B2C
		public static void Postfix(GameObject __result)
		{
			bool flag = __result.GetComponent<Renderer>() != null;
			bool flag2 = flag;
			if (flag2)
			{
				__result.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
				__result.GetComponent<Renderer>().material.color = Color.black;
			}
		}
	}
}
