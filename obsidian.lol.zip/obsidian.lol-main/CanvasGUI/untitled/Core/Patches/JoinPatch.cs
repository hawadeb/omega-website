﻿using System;
using HarmonyLib;
using Photon.Pun;
using Photon.Realtime;

namespace untitled.Core.Patches
{
	// Token: 0x0200001B RID: 27
	[HarmonyPatch(typeof(MonoBehaviourPunCallbacks), "OnPlayerEnteredRoom")]
	public class JoinPatch
	{
		// Token: 0x0600017C RID: 380 RVA: 0x000199A4 File Offset: 0x00017BA4
		public static void Prefix(Player newPlayer)
		{
			bool flag = newPlayer != JoinPatch.lastPlayerLeft;
			bool flag2 = flag;
			if (flag2)
			{
				Notifications.SendNotification("<color=grey>[</color><color=green>JOIN</color><color=grey>] </color><color=white>Name: " + newPlayer.NickName + "</color>");
				JoinPatch.lastPlayerLeft = newPlayer;
			}
		}

		// Token: 0x0400016E RID: 366
		private static Player lastPlayerLeft;
	}
}
