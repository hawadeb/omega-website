﻿using System;
using BepInEx;
using HarmonyLib;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;

namespace StupidTemplate.Classes
{
	// Token: 0x02000007 RID: 7
	internal class RigManager : BaseUnityPlugin
	{
		// Token: 0x06000065 RID: 101 RVA: 0x00005C18 File Offset: 0x00003E18
		public static VRRig GetVRRigFromPlayer(Player p)
		{
			return GorillaGameManager.instance.FindPlayerVRRig(p);
		}

		// Token: 0x06000066 RID: 102 RVA: 0x00005C3C File Offset: 0x00003E3C
		public static VRRig GetRandomVRRig(bool includeSelf)
		{
			VRRig vrrig = GorillaParent.instance.vrrigs[global::UnityEngine.Random.Range(0, GorillaParent.instance.vrrigs.Count - 1)];
			VRRig vrrig2;
			if (includeSelf)
			{
				vrrig2 = vrrig;
			}
			else
			{
				bool flag = vrrig != GorillaTagger.Instance.offlineVRRig;
				if (flag)
				{
					vrrig2 = vrrig;
				}
				else
				{
					vrrig2 = RigManager.GetRandomVRRig(includeSelf);
				}
			}
			return vrrig2;
		}

		// Token: 0x06000067 RID: 103 RVA: 0x00005CA4 File Offset: 0x00003EA4
		public static VRRig GetClosestVRRig()
		{
			float num = float.MaxValue;
			VRRig vrrig = null;
			foreach (VRRig vrrig2 in GorillaParent.instance.vrrigs)
			{
				bool flag = Vector3.Distance(GorillaTagger.Instance.bodyCollider.transform.position, vrrig2.transform.position) < num;
				if (flag)
				{
					num = Vector3.Distance(GorillaTagger.Instance.bodyCollider.transform.position, vrrig2.transform.position);
					vrrig = vrrig2;
				}
			}
			return vrrig;
		}

		// Token: 0x06000068 RID: 104 RVA: 0x00005D60 File Offset: 0x00003F60
		public static PhotonView GetPhotonViewFromVRRig(VRRig p)
		{
			return (PhotonView)Traverse.Create(p).Field("photonView").GetValue();
		}

		// Token: 0x06000069 RID: 105 RVA: 0x00005D8C File Offset: 0x00003F8C
		public static Player GetRandomPlayer(bool includeSelf)
		{
			Player player;
			if (includeSelf)
			{
				player = PhotonNetwork.PlayerList[global::UnityEngine.Random.Range(0, PhotonNetwork.PlayerList.Length - 1)];
			}
			else
			{
				player = PhotonNetwork.PlayerListOthers[global::UnityEngine.Random.Range(0, PhotonNetwork.PlayerListOthers.Length - 1)];
			}
			return player;
		}

		// Token: 0x0600006A RID: 106 RVA: 0x00005DD4 File Offset: 0x00003FD4
		public static Player GetPlayerFromVRRig(VRRig p)
		{
			return RigManager.GetPhotonViewFromVRRig(p).Owner;
		}

		// Token: 0x0600006B RID: 107 RVA: 0x00005DF4 File Offset: 0x00003FF4
		public static Player GetPlayerFromID(string id)
		{
			Player player = null;
			foreach (Player player2 in PhotonNetwork.PlayerList)
			{
				bool flag = player2.UserId == id;
				if (flag)
				{
					player = player2;
					break;
				}
			}
			return player;
		}
	}
}
