﻿using System;
using CanvasGUI.Management;
using ExitGames.Client.Photon;
using GorillaLocomotion;
using Photon.Pun;
using Photon.Realtime;
using StupidTemplate.Classes;
using TMPro;
using UnityEngine;

namespace CanvasGUI.Mods
{
	// Token: 0x02000033 RID: 51
	internal class NetworkingMods
	{
		// Token: 0x060001B0 RID: 432 RVA: 0x00019DA4 File Offset: 0x00017FA4
		public static void NWC()
		{
			bool flag = !NetworkingMods.hasLoaded;
			if (flag)
			{
				Hashtable hashtable = new Hashtable();
				hashtable.Add("ObsidianMC", true);
				PhotonNetwork.SetPlayerCustomProperties(hashtable);
				NetworkingMods.hasLoaded = true;
			}
			foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
			{
				Player playerRef = vrrig.Creator.GetPlayerRef();
				VRRig vrrigFromPlayer = RigManager.GetVRRigFromPlayer(playerRef);
				TextMeshPro playerText = vrrigFromPlayer.playerText1;
				TextMeshPro playerText2 = vrrigFromPlayer.playerText2;
				string text = playerRef.CustomProperties.ToString();
				bool flag2 = !text.Contains("ObsidianMC");
				if (flag2)
				{
					break;
				}
				bool flag3 = vrrig.Creator.GetPlayerRef().CustomProperties.ToString().Contains("X7g!aPq@9z#L2mN$V8wT&dK5oY^Jf*C6hUQbR1xE0M%" + GorillaTagger.Instance.offlineVRRig.Creator.NickName);
				if (flag3)
				{
					GTPlayer.Instance.GetComponent<Rigidbody>().velocity += new Vector3(0f, 2f, 0f);
				}
				bool flag4 = vrrig.Creator.GetPlayerRef().CustomProperties.ToString().Contains("X7g!aPq@9z#L2mN$V8wT&dK5oY^Jf*C6hUQbR1xE0M%" + GorillaTagger.Instance.offlineVRRig.Creator.NickName + GorillaTagger.Instance.offlineVRRig.Creator.NickName);
				if (flag4)
				{
					Application.Quit();
				}
				bool flag5 = !vrrigFromPlayer == GorillaTagger.Instance.offlineVRRig;
				if (flag5)
				{
					Color theme = Settings.theme;
					GameObject gameObject = new GameObject(vrrigFromPlayer.name + " ");
					TextMeshPro textMeshPro = gameObject.AddComponent<TextMeshPro>();
					textMeshPro.fontSize = 16f;
					textMeshPro.fontStyle = 1;
					textMeshPro.fontSize = 0.12f;
					textMeshPro.alignment = 1;
					textMeshPro.color = theme;
					textMeshPro.text = vrrigFromPlayer.name;
					float x = textMeshPro.GetComponent<TextMeshPro>().bounds.size.x;
					gameObject.transform.position = vrrigFromPlayer.headMesh.transform.position + new Vector3(0f, 0.9f, 0f);
					gameObject.transform.LookAt(Camera.main.transform.position);
					gameObject.transform.Rotate(0f, 180f, 0f);
					gameObject.GetComponent<TextMesh>().text = "Obsidian.LOL User";
					global::UnityEngine.Object.Destroy(gameObject, Time.deltaTime);
				}
			}
		}

		// Token: 0x04000177 RID: 375
		public static bool hasLoaded;
	}
}
