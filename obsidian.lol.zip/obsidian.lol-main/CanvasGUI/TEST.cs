﻿using System;

// Token: 0x02000004 RID: 4
internal class TEST
{
}
