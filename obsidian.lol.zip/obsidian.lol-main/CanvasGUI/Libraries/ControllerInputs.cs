﻿using System;
using UnityEngine;
using UnityEngine.XR;
using Valve.VR;

namespace CanvasGUI.Libraries
{
	// Token: 0x02000038 RID: 56
	public class ControllerInputs
	{
		// Token: 0x060001D6 RID: 470 RVA: 0x0001ED04 File Offset: 0x0001CF04
		public static bool leftStick()
		{
			bool flag = GameObject.Find("[SteamVR]") != null;
			bool state;
			if (flag)
			{
				state = SteamVR_Actions.gorillaTag_LeftJoystickClick.GetState(1);
			}
			else
			{
				InputDevices.GetDeviceAtXRNode(4).TryGetFeatureValue(CommonUsages.primary2DAxisClick, ref state);
			}
			return state;
		}

		// Token: 0x060001D7 RID: 471 RVA: 0x0001ED50 File Offset: 0x0001CF50
		public static bool leftGrip()
		{
			return ControllerInputPoller.instance.leftGrab;
		}

		// Token: 0x060001D8 RID: 472 RVA: 0x0001ED70 File Offset: 0x0001CF70
		public static bool leftTrigger()
		{
			return ControllerInputPoller.instance.leftControllerIndexFloat > 0.5f;
		}

		// Token: 0x060001D9 RID: 473 RVA: 0x0001ED98 File Offset: 0x0001CF98
		public static bool leftPrimary()
		{
			return ControllerInputPoller.instance.leftControllerPrimaryButton;
		}

		// Token: 0x060001DA RID: 474 RVA: 0x0001EDB8 File Offset: 0x0001CFB8
		public static bool leftSecondary()
		{
			return ControllerInputPoller.instance.leftControllerSecondaryButton;
		}

		// Token: 0x060001DB RID: 475 RVA: 0x0001EDD8 File Offset: 0x0001CFD8
		public static bool rightStick()
		{
			bool flag = GameObject.Find("[SteamVR]") != null;
			bool state;
			if (flag)
			{
				state = SteamVR_Actions.gorillaTag_RightJoystickClick.GetState(2);
			}
			else
			{
				InputDevices.GetDeviceAtXRNode(5).TryGetFeatureValue(CommonUsages.primary2DAxisClick, ref state);
			}
			return state;
		}

		// Token: 0x060001DC RID: 476 RVA: 0x0001EE24 File Offset: 0x0001D024
		public static bool rightGrip()
		{
			return ControllerInputPoller.instance.rightGrab;
		}

		// Token: 0x060001DD RID: 477 RVA: 0x0001EE44 File Offset: 0x0001D044
		public static bool rightTrigger()
		{
			return ControllerInputPoller.instance.rightControllerIndexFloat > 0.5f;
		}

		// Token: 0x060001DE RID: 478 RVA: 0x0001EE6C File Offset: 0x0001D06C
		public static bool rightPrimary()
		{
			return ControllerInputPoller.instance.rightControllerPrimaryButton;
		}

		// Token: 0x060001DF RID: 479 RVA: 0x0001EE8C File Offset: 0x0001D08C
		public static bool rightSecondary()
		{
			return ControllerInputPoller.instance.rightControllerSecondaryButton;
		}
	}
}
