﻿using System;
using System.Linq;
using BepInEx;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000003 RID: 3
[BepInPlugin("org.gorillatag.lars.notifications2", "NotificationLibrary", "1.0.5")]
public class Notifications : BaseUnityPlugin
{
	// Token: 0x0600000E RID: 14 RVA: 0x000038BC File Offset: 0x00001ABC
	private void Awake()
	{
		base.Logger.LogInfo("Plugin NotificationLibrary is loaded!");
	}

	// Token: 0x0600000F RID: 15 RVA: 0x000038D0 File Offset: 0x00001AD0
	private void Init()
	{
		this.MainCamera = GameObject.Find("Main Camera");
		this.HUDObj = new GameObject();
		this.HUDObj2 = new GameObject();
		this.HUDObj2.name = "NOTIFICATIONLIB_HUD_OBJ";
		this.HUDObj.name = "NOTIFICATIONLIB_HUD_OBJ";
		this.HUDObj.AddComponent<Canvas>();
		this.HUDObj.AddComponent<CanvasScaler>();
		this.HUDObj.AddComponent<GraphicRaycaster>();
		this.HUDObj.GetComponent<Canvas>().enabled = true;
		this.HUDObj.GetComponent<Canvas>().renderMode = 2;
		this.HUDObj.GetComponent<Canvas>().worldCamera = this.MainCamera.GetComponent<Camera>();
		this.HUDObj.GetComponent<RectTransform>().sizeDelta = new Vector2(5f, 5f);
		this.HUDObj.GetComponent<RectTransform>().position = new Vector3(this.MainCamera.transform.position.x, this.MainCamera.transform.position.y, this.MainCamera.transform.position.z);
		this.HUDObj2.transform.position = new Vector3(this.MainCamera.transform.position.x, this.MainCamera.transform.position.y, this.MainCamera.transform.position.z - 4.6f);
		this.HUDObj.transform.parent = this.HUDObj2.transform;
		this.HUDObj.GetComponent<RectTransform>().localPosition = new Vector3(0f, 0f, 1.6f);
		Vector3 eulerAngles = this.HUDObj.GetComponent<RectTransform>().rotation.eulerAngles;
		eulerAngles.y = -270f;
		this.HUDObj.transform.localScale = new Vector3(1f, 1f, 1f);
		this.HUDObj.GetComponent<RectTransform>().rotation = Quaternion.Euler(eulerAngles);
		this.Testtext = new GameObject
		{
			transform = 
			{
				parent = this.HUDObj.transform
			}
		}.AddComponent<Text>();
		this.Testtext.text = "";
		this.Testtext.fontSize = 30;
		this.Testtext.font = Resources.GetBuiltinResource(typeof(Font), "Arial.ttf") as Font;
		this.Testtext.rectTransform.sizeDelta = new Vector2(450f, 210f);
		this.Testtext.alignment = 2;
		this.Testtext.rectTransform.localScale = new Vector3(0.0016666667f, 0.0016666667f, 0.16666667f);
		this.Testtext.rectTransform.localPosition = new Vector3(1f, 2f, -0.5f);
		this.Testtext.material = this.AlertText;
		Notifications.NotifiText = this.Testtext;
	}

	// Token: 0x06000010 RID: 16 RVA: 0x00003BFC File Offset: 0x00001DFC
	private void FixedUpdate()
	{
		bool flag = !this.HasInit && GameObject.Find("Main Camera") != null;
		bool flag2 = flag;
		if (flag2)
		{
			this.Init();
			this.HasInit = true;
		}
		this.HUDObj2.transform.position = new Vector3(this.MainCamera.transform.position.x, this.MainCamera.transform.position.y, this.MainCamera.transform.position.z);
		this.HUDObj2.transform.rotation = this.MainCamera.transform.rotation;
		bool flag3 = this.Testtext.text != "";
		if (flag3)
		{
			this.NotificationDecayTimeCounter++;
			bool flag4 = this.NotificationDecayTimeCounter > this.NotificationDecayTime;
			if (flag4)
			{
				this.Notifilines = null;
				this.newtext = "";
				this.NotificationDecayTimeCounter = 0;
				this.Notifilines = this.Testtext.text.Split(Environment.NewLine.ToCharArray()).Skip(1).ToArray<string>();
				foreach (string text in this.Notifilines)
				{
					bool flag5 = text != "";
					if (flag5)
					{
						this.newtext = this.newtext + text + "\n";
					}
				}
				this.Testtext.text = this.newtext;
			}
		}
		else
		{
			this.NotificationDecayTimeCounter = 0;
		}
	}

	// Token: 0x06000011 RID: 17 RVA: 0x00003DA8 File Offset: 0x00001FA8
	public static void SendNotification(string NotificationText)
	{
		try
		{
			bool flag = Notifications.IsEnabled && Notifications.PreviousNotifi != NotificationText;
			if (flag)
			{
				bool flag2 = !NotificationText.Contains(Environment.NewLine);
				if (flag2)
				{
					NotificationText += Environment.NewLine;
				}
				Notifications.NotifiText.text = Notifications.NotifiText.text + NotificationText;
				Notifications.NotifiText.supportRichText = true;
				Notifications.PreviousNotifi = NotificationText;
			}
		}
		catch
		{
			Debug.LogError("Notification failed, object probably nil due to third person ; " + NotificationText);
		}
	}

	// Token: 0x06000012 RID: 18 RVA: 0x00003E4C File Offset: 0x0000204C
	public static void ClearAllNotifications()
	{
		Notifications.NotifiText.text = "";
	}

	// Token: 0x06000013 RID: 19 RVA: 0x00003E60 File Offset: 0x00002060
	public static void ClearPastNotifications(int amount)
	{
		string text = "";
		foreach (string text2 in Notifications.NotifiText.text.Split(Environment.NewLine.ToCharArray()).Skip(amount).ToArray<string>())
		{
			bool flag = text2 != "";
			if (flag)
			{
				text = text + text2 + "\n";
			}
		}
		Notifications.NotifiText.text = text;
	}

	// Token: 0x04000009 RID: 9
	private GameObject HUDObj;

	// Token: 0x0400000A RID: 10
	private GameObject HUDObj2;

	// Token: 0x0400000B RID: 11
	private GameObject MainCamera;

	// Token: 0x0400000C RID: 12
	private Text Testtext;

	// Token: 0x0400000D RID: 13
	private Material AlertText = new Material(Shader.Find("GUI/Text Shader"));

	// Token: 0x0400000E RID: 14
	private int NotificationDecayTime = 144;

	// Token: 0x0400000F RID: 15
	private int NotificationDecayTimeCounter;

	// Token: 0x04000010 RID: 16
	public static int NoticationThreshold = 30;

	// Token: 0x04000011 RID: 17
	private string[] Notifilines;

	// Token: 0x04000012 RID: 18
	private string newtext;

	// Token: 0x04000013 RID: 19
	public static string PreviousNotifi;

	// Token: 0x04000014 RID: 20
	private bool HasInit;

	// Token: 0x04000015 RID: 21
	private static Text NotifiText;

	// Token: 0x04000016 RID: 22
	public static bool IsEnabled = true;
}
