﻿using System;
using GorillaTagScripts;
using HarmonyLib;

namespace CanvasGUI
{
	// Token: 0x02000030 RID: 48
	[HarmonyPatch(typeof(FriendshipGroupDetection), "VerifyPartyMember")]
	internal class VerifyPartyMemberPatch : HarmonyPatch
	{
		// Token: 0x060001A8 RID: 424 RVA: 0x00019D54 File Offset: 0x00017F54
		[HarmonyPrefix]
		private static bool Prefix()
		{
			return true;
		}
	}
}
