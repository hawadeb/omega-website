﻿using System;
using GorillaTagScripts;
using HarmonyLib;

namespace CanvasGUI
{
	// Token: 0x0200002F RID: 47
	[HarmonyPatch(typeof(FriendshipGroupDetection), "PartyMemberIsAboutToGroupJoin")]
	internal class SafePartyJoinPatch : HarmonyPatch
	{
		// Token: 0x060001A6 RID: 422 RVA: 0x00019D38 File Offset: 0x00017F38
		[HarmonyPrefix]
		private static bool Prefix()
		{
			return true;
		}
	}
}
