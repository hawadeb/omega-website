﻿using System;

namespace CanvasGUI
{
	// Token: 0x02000032 RID: 50
	public class PluginInfo
	{
		// Token: 0x04000174 RID: 372
		public const string GUID = "com.obs.gorillatag.lol";

		// Token: 0x04000175 RID: 373
		public const string Name = "Obsidian.LOL";

		// Token: 0x04000176 RID: 374
		public const string Version = "1.5.0";
	}
}
