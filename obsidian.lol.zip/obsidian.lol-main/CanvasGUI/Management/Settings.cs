﻿using System;
using Abyss.Mods;
using CanvasGUI.Libraries;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace CanvasGUI.Management
{
	// Token: 0x02000037 RID: 55
	public class Settings
	{
		// Token: 0x17000029 RID: 41
		// (get) Token: 0x060001D0 RID: 464 RVA: 0x0001E2C7 File Offset: 0x0001C4C7
		public static bool toggleButton
		{
			get
			{
				return ControllerInputs.leftPrimary();
			}
		}

		// Token: 0x060001D1 RID: 465 RVA: 0x0001E2D0 File Offset: 0x0001C4D0
		public static void ChangeTheme()
		{
			Settings.CurrentTheme++;
			bool flag = Settings.CurrentTheme == 0;
			if (flag)
			{
				Settings.col1 = Settings.org1;
				Settings.col2 = Settings.org2;
				Settings.theme = Settings.orgTheme;
				Settings.UpdateColors();
			}
			else
			{
				bool flag2 = Settings.CurrentTheme == 1;
				if (flag2)
				{
					Settings.ColorSet(Color.black, Color.white, Visuals.DarkGrey);
				}
				else
				{
					bool flag3 = Settings.CurrentTheme == 2;
					if (flag3)
					{
						Settings.ColorSet(Color.black, Color.red, Visuals.DarkRed);
					}
					else
					{
						bool flag4 = Settings.CurrentTheme == 3;
						if (flag4)
						{
							Settings.ColorSet(Visuals.DarkDodgerBlue, Visuals.DarkBlue, Visuals.DarkBlue);
						}
						else
						{
							bool flag5 = Settings.CurrentTheme == 4;
							if (flag5)
							{
								Settings.ColorSet(Color.green, Visuals.Lime, Visuals.DarkGreen);
							}
							else
							{
								bool flag6 = Settings.CurrentTheme == 5;
								if (flag6)
								{
									Settings.ColorSet(new Color(44f, 83f, 100f, 255f), new Color(15f, 32f, 39f, 255f), new Color(32f, 58f, 67f, 255f));
								}
								else
								{
									bool flag7 = Settings.CurrentTheme == 6;
									if (flag7)
									{
										Settings.ColorSet(Visuals.Magenta, Visuals.Purple, Visuals.PurpleTransparent);
									}
									else
									{
										bool flag8 = Settings.CurrentTheme == 7;
										if (flag8)
										{
											Settings.ColorSet(new Color(0.17254902f, 0.24313726f, 0.3137255f), new Color(0.29803923f, 0.6313726f, 0.6862745f), new Color(0.17254902f, 0.24313726f, 0.3137255f));
										}
										else
										{
											bool flag9 = Settings.CurrentTheme == 8;
											if (flag9)
											{
												Settings.ColorSet(new Color(0.3764706f, 0.21960784f, 0.07450981f), new Color(0.69803923f, 0.62352943f, 0.5803922f), new Color(0.69803923f, 0.62352943f, 0.5803922f));
											}
											else
											{
												bool flag10 = Settings.CurrentTheme == 9;
												if (flag10)
												{
													Settings.ColorSet(new Color(0.43529412f, 0.69411767f, 0.9882353f), new Color(0.2627451f, 0.39215687f, 0.96862745f), new Color(0f, 0.32156864f, 0.83137256f));
												}
												else
												{
													bool flag11 = Settings.CurrentTheme == 10;
													if (flag11)
													{
														Settings.ColorSet(new Color(0.9843137f, 0.78039217f, 0.83137256f), new Color(0.5921569f, 0.5882353f, 0.9411765f), new Color(0.5921569f, 0.5882353f, 0.9411765f));
													}
													else
													{
														bool flag12 = Settings.CurrentTheme == 11;
														if (flag12)
														{
															Settings.ColorSet(new Color(1f, 0.34509805f, 0.34509805f), new Color(0.972549f, 0.34117648f, 0.6509804f), new Color(1f, 0.34509805f, 0.34509805f));
														}
														else
														{
															bool flag13 = Settings.CurrentTheme == 12;
															if (flag13)
															{
																Settings.ColorSet(new Color(0.16470589f, 0.03137255f, 0.27058825f), new Color(0.39215687f, 0.25490198f, 0.64705884f), new Color(0.16470589f, 0.03137255f, 0.27058825f));
															}
															else
															{
																bool flag14 = Settings.CurrentTheme == 13;
																if (flag14)
																{
																	Settings.ColorSet(new Color(0.6509804f, 0.69411767f, 1f, 0.295f), new Color(0.6901961f, 0.5647059f, 0.99215686f, 0.855f), new Color(0.6901961f, 0.5647059f, 0.99215686f, 0.855f));
																}
																else
																{
																	bool flag15 = Settings.CurrentTheme == 14;
																	if (flag15)
																	{
																		Settings.ColorSet(new Color(0.47058824f, 1f, 0.8392157f), new Color(0f, 0.4745098f, 0.5686275f), new Color(0f, 0.4745098f, 0.5686275f));
																	}
																	else
																	{
																		Settings.CurrentTheme = 0;
																		Settings.ColorSet(new Color(0.074f, 0.415f, 0.541f, 1f), new Color(0.074f, 0.415f, 0.541f, 1f), new Color(0.074f, 0.415f, 0.541f, 1f));
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

		// Token: 0x060001D2 RID: 466 RVA: 0x0001E7A8 File Offset: 0x0001C9A8
		public static void ColorSet(Color col11, Color col22, Color mainTheme)
		{
			Settings.col1 = new Color(Mathf.Clamp01(col11.r * 1.2f), Mathf.Clamp01(col11.g * 1.2f), Mathf.Clamp01(col11.b * 1.2f), 1f);
			Settings.col2 = new Color(Mathf.Clamp01(col22.r * 1.2f), Mathf.Clamp01(col22.g * 1.2f), Mathf.Clamp01(col22.b * 1.2f), 1f);
			Settings.theme = new Color(Mathf.Clamp01(mainTheme.r * 0.8333333f), Mathf.Clamp01(mainTheme.g * 0.8333333f), Mathf.Clamp01(mainTheme.b * 0.8333333f), 1f);
			Settings.UpdateColors();
		}

		// Token: 0x060001D3 RID: 467 RVA: 0x0001E884 File Offset: 0x0001CA84
		public static void UpdateColors()
		{
			Menu.GenerateGradient(Menu.menu.transform.Find("Canvas/Visual/Tabs").GetComponent<Image>(), Settings.col1, Settings.col2);
			Menu.GenerateGradient(Menu.menu.transform.Find("Canvas/Visual/Divider").GetComponent<Image>(), Settings.col1, Settings.col2);
			GameObject gameObject = Menu.menu.transform.Find("Canvas/Tab Scrolling/Tabs").gameObject;
			for (int i = 0; i < gameObject.transform.childCount; i++)
			{
				GameObject gameObject2 = gameObject.transform.GetChild(i).gameObject;
				bool activeSelf = gameObject2.activeSelf;
				if (activeSelf)
				{
					Menu.GenerateGradient(gameObject2.GetComponent<Image>(), Settings.col1, Settings.col2);
				}
			}
			for (int j = 0; j < Menu.categories.Count; j++)
			{
				GameObject gameObject3 = Menu.menu.transform.Find("Canvas/Tab Scrolling/Tabs").gameObject;
				GameObject gameObject4 = gameObject3.transform.Find("Tab").gameObject;
				GameObject gameObject5 = global::UnityEngine.Object.Instantiate<GameObject>(gameObject4, gameObject3.transform);
				gameObject5.SetActive(true);
				gameObject5.name = Menu.categories[j].name;
				bool flag = gameObject5.name != "HIDDEN";
				if (flag)
				{
					int index = j;
					gameObject5.GetComponent<Button>().onClick.AddListener(delegate
					{
						Menu.UpdateCurrentPage(index);
					});
					gameObject5.GetComponentInChildren<TextMeshProUGUI>().text = Menu.categories[j].name;
					Menu.GenerateGradient(gameObject5.GetComponent<Image>(), Settings.col1, Settings.col2);
				}
				else
				{
					gameObject5.SetActive(false);
					gameObject5.GetComponent<Button>().onClick.RemoveAllListeners();
				}
			}
			GameObject gameObject6 = Menu.menu.transform.Find("Canvas/Module Scrolling/Modules").gameObject;
			GameObject gameObject7 = gameObject6.transform.Find("Module").gameObject;
			for (int k = 0; k < Menu.categories[Menu.page_index].buttons.Length; k++)
			{
				GameObject gameObject8 = gameObject6.transform.GetChild(k).gameObject;
				Transform transform = gameObject8.transform.Find("Backround");
				bool flag2 = transform != null;
				if (flag2)
				{
					Image component = transform.GetComponent<Image>();
					Menu.GenerateGradient(component, Settings.col1, Settings.col2);
				}
			}
			GameObject gameObject9 = Menu.menu.transform.Find("Canvas/Visual/Background").gameObject;
			gameObject9.GetComponent<Outline>().effectColor = Settings.theme;
			Menu.GenerateGradient(Menu.menu.transform.Find("Canvas/UpTab").GetComponent<Image>(), Settings.col1, Settings.col2);
			Menu.GenerateGradient(Menu.menu.transform.Find("Canvas/DownTab").GetComponent<Image>(), Settings.col1, Settings.col2);
			Menu.GenerateGradient(Menu.menu.transform.Find("Canvas/UpModules").GetComponent<Image>(), Settings.col1, Settings.col2);
			Menu.GenerateGradient(Menu.menu.transform.Find("Canvas/DownModules").GetComponent<Image>(), Settings.col1, Settings.col2);
			GUIMain.g.CycleTheme();
			Menu.UpdateCurrentPage(Menu.page_index);
		}

		// Token: 0x04000187 RID: 391
		public static string title = "Obsidian.LOL";

		// Token: 0x04000188 RID: 392
		public static Color[] buttons = new Color[]
		{
			Color.green,
			Color.red,
			Color.grey
		};

		// Token: 0x04000189 RID: 393
		public static Color theme = new Color(0.074f, 0.415f, 0.541f, 1f);

		// Token: 0x0400018A RID: 394
		public static Color org1 = Settings.col1;

		// Token: 0x0400018B RID: 395
		public static Color org2 = Settings.col2;

		// Token: 0x0400018C RID: 396
		public static Color orgTheme = Settings.theme;

		// Token: 0x0400018D RID: 397
		public static Color col1 = new Color(Mathf.Clamp01(0.088800006f), Mathf.Clamp01(0.498f), Mathf.Clamp01(0.6492f), 1f);

		// Token: 0x0400018E RID: 398
		public static Color col2 = new Color(Mathf.Clamp01(0.17880002f), Mathf.Clamp01(0.56520003f), Mathf.Clamp01(0.5316f), 1f);

		// Token: 0x0400018F RID: 399
		public static int CurrentTheme = 0;
	}
}
