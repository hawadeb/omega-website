﻿using System;

namespace CanvasGUI.Management
{
	// Token: 0x02000034 RID: 52
	public class Module
	{
		// Token: 0x17000020 RID: 32
		// (get) Token: 0x060001B2 RID: 434 RVA: 0x0001A0A1 File Offset: 0x000182A1
		// (set) Token: 0x060001B3 RID: 435 RVA: 0x0001A0A9 File Offset: 0x000182A9
		public string title { get; set; }

		// Token: 0x17000021 RID: 33
		// (get) Token: 0x060001B4 RID: 436 RVA: 0x0001A0B2 File Offset: 0x000182B2
		// (set) Token: 0x060001B5 RID: 437 RVA: 0x0001A0BA File Offset: 0x000182BA
		public string tooltip { get; set; }

		// Token: 0x17000022 RID: 34
		// (get) Token: 0x060001B6 RID: 438 RVA: 0x0001A0C3 File Offset: 0x000182C3
		// (set) Token: 0x060001B7 RID: 439 RVA: 0x0001A0CB File Offset: 0x000182CB
		public string[] options { get; set; }

		// Token: 0x17000023 RID: 35
		// (get) Token: 0x060001B8 RID: 440 RVA: 0x0001A0D4 File Offset: 0x000182D4
		// (set) Token: 0x060001B9 RID: 441 RVA: 0x0001A0DC File Offset: 0x000182DC
		public bool toggled { get; set; }

		// Token: 0x17000024 RID: 36
		// (get) Token: 0x060001BA RID: 442 RVA: 0x0001A0E5 File Offset: 0x000182E5
		// (set) Token: 0x060001BB RID: 443 RVA: 0x0001A0ED File Offset: 0x000182ED
		public bool toggleable { get; set; }

		// Token: 0x17000025 RID: 37
		// (get) Token: 0x060001BC RID: 444 RVA: 0x0001A0F6 File Offset: 0x000182F6
		// (set) Token: 0x060001BD RID: 445 RVA: 0x0001A0FE File Offset: 0x000182FE
		public Action action { get; set; }

		// Token: 0x17000026 RID: 38
		// (get) Token: 0x060001BE RID: 446 RVA: 0x0001A107 File Offset: 0x00018307
		// (set) Token: 0x060001BF RID: 447 RVA: 0x0001A10F File Offset: 0x0001830F
		public Action disableAction { get; set; }
	}
}
