﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using Abyss.Mods;
using CanvasGUI.Components;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace CanvasGUI.Management
{
	// Token: 0x02000036 RID: 54
	public class Menu
	{
		// Token: 0x060001C6 RID: 454 RVA: 0x0001A160 File Offset: 0x00018360
		private static AssetBundle LoadAssetBundle(string path)
		{
			Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream(path);
			AssetBundle assetBundle = AssetBundle.LoadFromStream(manifestResourceStream);
			manifestResourceStream.Close();
			return assetBundle;
		}

		// Token: 0x060001C7 RID: 455 RVA: 0x0001A190 File Offset: 0x00018390
		public static void Toggle(bool toggle)
		{
			if (toggle)
			{
				Menu.menu.transform.position = GorillaTagger.Instance.headCollider.transform.position + GorillaTagger.Instance.headCollider.transform.forward * 0.8f - GorillaTagger.Instance.headCollider.transform.right * 0.4f - GorillaTagger.Instance.headCollider.transform.up * 0.25f;
				Menu.menu.transform.rotation = GorillaTagger.Instance.headCollider.transform.rotation;
			}
			Menu.menu.SetActive(toggle);
		}

		// Token: 0x060001C8 RID: 456 RVA: 0x0001A268 File Offset: 0x00018468
		public static void UpdateCurrentPage(int page)
		{
			ScrollInteractor.scroll = 0f;
			bool flag = page >= 0;
			if (flag)
			{
				bool flag2 = page < Menu.categories.Count;
				if (flag2)
				{
					Menu.page_index = page;
				}
			}
			foreach (GameObject gameObject in Menu.buttons)
			{
				global::UnityEngine.Object.Destroy(gameObject);
			}
			Menu.buttons.Clear();
			Menu.Buttons();
			RectTransform component = Menu.menu.transform.Find("Canvas/Module Scrolling/Modules").GetComponent<RectTransform>();
			component.anchoredPosition = new Vector2(component.anchoredPosition.x, -98.4f);
		}

		// Token: 0x060001C9 RID: 457 RVA: 0x0001A334 File Offset: 0x00018534
		public static void Buttons()
		{
			GameObject gameObject = Menu.menu.transform.Find("Canvas/Module Scrolling/Modules").gameObject;
			GameObject gameObject2 = gameObject.transform.Find("Module").gameObject;
			for (int i = 0; i < Menu.categories[Menu.page_index].buttons.Length; i++)
			{
				GameObject gameObject3 = global::UnityEngine.Object.Instantiate<GameObject>(gameObject2, gameObject.transform);
				Menu.buttons.Add(gameObject3);
				gameObject3.SetActive(true);
				gameObject3.GetComponentInChildren<TextMeshProUGUI>().text = Menu.categories[Menu.page_index].buttons[i].title;
				gameObject3.transform.Find("Description").GetComponent<TextMeshProUGUI>().text = Menu.categories[Menu.page_index].buttons[i].tooltip;
				gameObject3.transform.Find("Description").GetComponent<TextMeshProUGUI>().fontSize = 2f;
				Button indicator = gameObject3.GetComponentInChildren<Button>();
				indicator.image.color = (Menu.categories[Menu.page_index].buttons[i].toggleable ? (Menu.categories[Menu.page_index].buttons[i].toggled ? Settings.buttons[0] : Settings.buttons[1]) : Settings.buttons[2]);
				Transform transform = gameObject3.transform.Find("Backround");
				bool flag = transform != null;
				if (flag)
				{
					Image component = transform.GetComponent<Image>();
					Menu.GenerateGradient(component, Settings.col1, Settings.col2);
				}
				int index = i;
				indicator.onClick.AddListener(delegate
				{
					Module module = Menu.categories[Menu.page_index].buttons[index];
					module.toggled = !module.toggled;
					bool flag2 = !module.toggled && module.disableAction != null;
					if (flag2)
					{
						module.disableAction();
					}
					bool toggleable = module.toggleable;
					if (toggleable)
					{
						indicator.image.color = (module.toggled ? Settings.buttons[0] : Settings.buttons[1]);
					}
					else
					{
						bool flag3 = module.action != null;
						if (flag3)
						{
							module.action();
						}
					}
				});
			}
		}

		// Token: 0x060001CA RID: 458 RVA: 0x0001A52C File Offset: 0x0001872C
		public static void Cateories()
		{
			List<Category> list = Menu.categories;
			string text = "Settings";
			Module[] array = new Module[16];
			int num = 0;
			Module module = new Module();
			module.title = "Change Theme";
			module.tooltip = "Changes the theme of the menu.";
			module.toggleable = false;
			module.action = delegate
			{
				Settings.ChangeTheme();
			};
			array[num] = module;
			int num2 = 1;
			Module module2 = new Module();
			module2.title = "Change Button Sound";
			module2.tooltip = "Changes the Button Sound.";
			module2.toggleable = false;
			module2.toggled = false;
			module2.action = delegate
			{
				Visuals.ChangeButtonSound();
			};
			array[num2] = module2;
			int num3 = 2;
			Module module3 = new Module();
			module3.title = "+1 Buttton Volume";
			module3.tooltip = "Changes the Button Volume by 1.";
			module3.toggleable = false;
			module3.action = delegate
			{
				Visuals.ClickMore();
			};
			array[num3] = module3;
			int num4 = 3;
			Module module4 = new Module();
			module4.title = "-1 Button Volume";
			module4.tooltip = "Changes the Button Volume by -1.";
			module4.toggleable = false;
			module4.action = delegate
			{
				Visuals.ClickLess();
			};
			array[num4] = module4;
			int num5 = 4;
			Module module5 = new Module();
			module5.title = "Turn Off Ghost Visualizer";
			module5.tooltip = "Turns off the Ghost Preview.";
			module5.toggleable = true;
			module5.action = delegate
			{
				Visuals.canGhost = false;
			};
			module5.disableAction = delegate
			{
				Visuals.canGhost = true;
			};
			array[num5] = module5;
			int num6 = 5;
			Module module6 = new Module();
			module6.title = "Gun Preview";
			module6.tooltip = "Allows you to preview the current GunLib.";
			module6.toggleable = true;
			module6.action = delegate
			{
				GunLib.lockShoot();
			};
			array[num6] = module6;
			int num7 = 6;
			Module module7 = new Module();
			module7.title = "More Wavy Gun Line";
			module7.tooltip = "Makes the GunLib more wavy.";
			module7.toggleable = false;
			module7.action = delegate
			{
				GunLib.Wavy += 20;
			};
			array[num7] = module7;
			int num8 = 7;
			Module module8 = new Module();
			module8.title = "Less Wavy Gun Line";
			module8.tooltip = "Makes the GunLib less wavy.";
			module8.toggleable = false;
			module8.action = delegate
			{
				GunLib.Wavy -= 20;
			};
			array[num8] = module8;
			int num9 = 8;
			Module module9 = new Module();
			module9.title = "More Gun Frequency";
			module9.tooltip = "Adds more waves to the GunLib.";
			module9.toggleable = false;
			module9.action = delegate
			{
				GunLib.Freq += 1f;
			};
			array[num9] = module9;
			int num10 = 9;
			Module module10 = new Module();
			module10.title = "Less Gun Frequency";
			module10.tooltip = "Adds less waves to the GunLib.";
			module10.toggleable = false;
			module10.action = delegate
			{
				GunLib.Freq -= 1f;
			};
			array[num10] = module10;
			int num11 = 10;
			Module module11 = new Module();
			module11.title = "Reset Gun line";
			module11.tooltip = "Resets the GunLib.";
			module11.toggleable = false;
			module11.action = delegate
			{
				Visuals.ResetGun();
			};
			array[num11] = module11;
			int num12 = 11;
			Module module12 = new Module();
			module12.title = "Un-Smooth Gun";
			module12.tooltip = "Makes the GunLib Non-Wavy.";
			module12.toggleable = false;
			module12.action = delegate
			{
				GunLib.Wavy = 20;
			};
			array[num12] = module12;
			int num13 = 12;
			Module module13 = new Module();
			module13.title = "Criss Cross GunLib";
			module13.tooltip = "Makes the GunLib have a criss-cross effect.";
			module13.toggleable = false;
			module13.action = delegate
			{
				Visuals.StupidGunLib();
			};
			array[num13] = module13;
			int num14 = 13;
			Module module14 = new Module();
			module14.title = "No Line GunLib";
			module14.tooltip = "Makes the GunLib only have a pointer.";
			module14.toggleable = false;
			module14.action = delegate
			{
				Visuals.SetWthenF(0, 0);
			};
			array[num14] = module14;
			int num15 = 14;
			Module module15 = new Module();
			module15.title = "Normal Line GunLib";
			module15.tooltip = "Makes the GunLib straight.";
			module15.toggleable = false;
			module15.action = delegate
			{
				Visuals.SetWthenF(2, 2);
			};
			array[num15] = module15;
			int num16 = 15;
			Module module16 = new Module();
			module16.title = "Wiggly GunLib";
			module16.tooltip = "Makes the GunLib Wiggly (Wavy but less frequency).";
			module16.toggleable = false;
			module16.action = delegate
			{
				Visuals.SetWthenF(20, 4);
			};
			array[num16] = module16;
			list.Add(new Category(text, array));
			List<Category> list2 = Menu.categories;
			string text2 = "Room";
			Module[] array2 = new Module[6];
			int num17 = 0;
			Module module17 = new Module();
			module17.title = "Anti Report";
			module17.tooltip = "When someone tries to report you, you disconnect.";
			module17.toggled = true;
			module17.toggleable = true;
			module17.action = delegate
			{
				OP.AntiReport();
			};
			array2[num17] = module17;
			int num18 = 1;
			Module module18 = new Module();
			module18.title = "Anti Ban";
			module18.tooltip = "Prevents you from getting banned from our mods.";
			module18.toggleable = true;
			module18.toggled = true;
			module18.action = delegate
			{
				OP.AntiBan();
			};
			array2[num18] = module18;
			int num19 = 2;
			Module module19 = new Module();
			module19.title = "Quit Game";
			module19.tooltip = "Quits your app.";
			module19.toggleable = false;
			module19.action = delegate
			{
				Room.QuitGTAG();
			};
			array2[num19] = module19;
			int num20 = 3;
			Module module20 = new Module();
			module20.title = "Join Random";
			module20.tooltip = "Makes you join a random lobby.";
			module20.toggleable = false;
			module20.action = delegate
			{
				Room.JoinRandomPublic();
			};
			array2[num20] = module20;
			int num21 = 4;
			Module module21 = new Module();
			module21.title = "Disconnect";
			module21.tooltip = "Makes you leave the lobby.";
			module21.toggleable = false;
			module21.action = delegate
			{
				Room.Disconnect();
			};
			array2[num21] = module21;
			int num22 = 5;
			Module module22 = new Module();
			module22.title = "Primary Disconnect";
			module22.tooltip = "When you click your primary, you disconnect.";
			module22.toggleable = true;
			module22.action = delegate
			{
				Room.PrimaryDisconnect();
			};
			array2[num22] = module22;
			list2.Add(new Category(text2, array2));
			List<Category> list3 = Menu.categories;
			string text3 = "Movement";
			Module[] array3 = new Module[12];
			int num23 = 0;
			Module module23 = new Module();
			module23.title = "WASD";
			module23.tooltip = "Allows you to move with WASD on your keyboard.";
			module23.toggleable = true;
			module23.action = delegate
			{
				Move.PcMovemeent();
			};
			array3[num23] = module23;
			int num24 = 1;
			Module module24 = new Module();
			module24.title = "Platforms";
			module24.tooltip = "Puts platforms/boxes under your hands by holding your grips.";
			module24.toggleable = true;
			module24.action = delegate
			{
				Move.PlatformsMod();
			};
			array3[num24] = module24;
			int num25 = 2;
			Module module25 = new Module();
			module25.title = "No-Clip (RT)";
			module25.tooltip = "Allows you to passthrough walls.";
			module25.toggleable = true;
			module25.toggled = false;
			module25.action = delegate
			{
				Move.Noclip();
			};
			array3[num25] = module25;
			int num26 = 3;
			Module module26 = new Module();
			module26.title = "Walk-Walk (RG)";
			module26.tooltip = "Pulls you towards the wall you last hit.";
			module26.toggleable = true;
			module26.toggled = false;
			module26.action = delegate
			{
				Move.WallWalk();
			};
			array3[num26] = module26;
			int num27 = 4;
			Module module27 = new Module();
			module27.title = "Frozone";
			module27.tooltip = "Puts ice platforms under your hands by holding your grips.";
			module27.toggleable = true;
			module27.toggled = false;
			module27.action = delegate
			{
				Rig.Frozone();
			};
			array3[num27] = module27;
			int num28 = 5;
			Module module28 = new Module();
			module28.title = "Iron-Man";
			module28.tooltip = "Makes you like Iron-Man, spawning fire underneath you.";
			module28.toggleable = true;
			module28.toggled = false;
			module28.action = delegate
			{
				Move.iron();
			};
			array3[num28] = module28;
			int num29 = 6;
			Module module29 = new Module();
			module29.title = "Fly";
			module29.tooltip = "Adds velocity to you while holding your right primary.";
			module29.toggleable = true;
			module29.toggled = false;
			module29.action = delegate
			{
				Move.Fly();
			};
			array3[num29] = module29;
			int num30 = 7;
			Module module30 = new Module();
			module30.title = "Bark Fly";
			module30.tooltip = "Allows you to fly with Joysticks.";
			module30.toggleable = true;
			module30.toggled = false;
			module30.action = delegate
			{
				Rig.BarkFly();
			};
			array3[num30] = module30;
			int num31 = 8;
			Module module31 = new Module();
			module31.title = "Speedboost (LG)";
			module31.tooltip = "Makes you slightly faster while holding Left-Grip";
			module31.toggleable = true;
			module31.action = delegate
			{
				OP.SpeedBoost();
			};
			array3[num31] = module31;
			int num32 = 9;
			Module module32 = new Module();
			module32.title = "TP Gun";
			module32.tooltip = "Teleports you wherever you shoot.";
			module32.toggleable = true;
			module32.action = delegate
			{
				Move.TPGun();
			};
			array3[num32] = module32;
			int num33 = 10;
			Module module33 = new Module();
			module33.title = "Airstrike Gun";
			module33.tooltip = "Teleports you 100 feet higher wherever you shoot.";
			module33.toggleable = true;
			module33.action = delegate
			{
				Move.AirStrikeGun();
			};
			array3[num33] = module33;
			int num34 = 11;
			Module module34 = new Module();
			module34.title = "Punch Mod";
			module34.tooltip = "Allows others to punch you.";
			module34.toggleable = true;
			module34.action = delegate
			{
				Move.PunchMod();
			};
			array3[num34] = module34;
			list3.Add(new Category(text3, array3));
			List<Category> list4 = Menu.categories;
			string text4 = "Rig";
			Module[] array4 = new Module[10];
			int num35 = 0;
			Module module35 = new Module();
			module35.title = "Invis Monke";
			module35.tooltip = "Makes you invisible.";
			module35.toggleable = true;
			module35.action = delegate
			{
				Move.Invis();
			};
			array4[num35] = module35;
			int num36 = 1;
			Module module36 = new Module();
			module36.title = "Ghost Monke";
			module36.tooltip = "Makes you a ghost, where you can move around with people seeing your rig frozen.";
			module36.toggleable = true;
			module36.toggled = false;
			module36.action = delegate
			{
				Move.Ghost();
			};
			array4[num36] = module36;
			int num37 = 2;
			Module module37 = new Module();
			module37.title = "Grab Rig (Grips)";
			module37.tooltip = "Allows you to Grab Your Rig.";
			module37.toggleable = true;
			module37.toggled = false;
			module37.action = delegate
			{
				Rig.GrabRig();
			};
			array4[num37] = module37;
			int num38 = 3;
			Module module38 = new Module();
			module38.title = "Rig Gun";
			module38.tooltip = "Allows others to punch you.";
			module38.toggleable = true;
			module38.toggled = false;
			module38.action = delegate
			{
				Rig.RigGun();
			};
			array4[num38] = module38;
			int num39 = 4;
			Module module39 = new Module();
			module39.title = "Spin Head (X)";
			module39.tooltip = "Spins your head in the X Rotation.";
			module39.toggleable = true;
			module39.toggled = false;
			module39.action = delegate
			{
				Rig.SpinHead(new Vector3(1f, 0f, 0f));
			};
			module39.disableAction = delegate
			{
				Rig.FixHead();
			};
			array4[num39] = module39;
			int num40 = 5;
			Module module40 = new Module();
			module40.title = "Spin Head (Y)";
			module40.tooltip = "Spins your head in the Y Rotation.";
			module40.toggleable = true;
			module40.toggled = false;
			module40.action = delegate
			{
				Rig.SpinHead(new Vector3(0f, 1f, 0f));
			};
			module40.disableAction = delegate
			{
				Rig.FixHead();
			};
			array4[num40] = module40;
			int num41 = 6;
			Module module41 = new Module();
			module41.title = "Spin Head (Z)";
			module41.tooltip = "Spins your head in the Z Rotation.";
			module41.toggleable = true;
			module41.toggled = false;
			module41.action = delegate
			{
				Rig.SpinHead(new Vector3(0f, 0f, 1f));
			};
			module41.disableAction = delegate
			{
				Rig.FixHead();
			};
			array4[num41] = module41;
			int num42 = 7;
			Module module42 = new Module();
			module42.title = "Spaz Head";
			module42.tooltip = "Spins your head in the X, Y and Z Rotation.";
			module42.toggleable = true;
			module42.toggled = false;
			module42.action = delegate
			{
				Rig.SpinHead(new Vector3(1f, 1f, 1f));
			};
			module42.disableAction = delegate
			{
				Rig.FixHead();
			};
			array4[num42] = module42;
			int num43 = 8;
			Module module43 = new Module();
			module43.title = "Spaz Rig (A)";
			module43.tooltip = "Twists your rig in all Rotations.";
			module43.toggleable = true;
			module43.toggled = false;
			module43.action = delegate
			{
				Rig.SpazRig();
			};
			module43.disableAction = delegate
			{
				Rig.FixRig();
			};
			array4[num43] = module43;
			int num44 = 9;
			Module module44 = new Module();
			module44.title = "Freeze Rig (A)";
			module44.tooltip = "Freezes your rigs Rotation.";
			module44.toggleable = true;
			module44.toggled = false;
			module44.action = delegate
			{
				Rig.SpazHands();
			};
			array4[num44] = module44;
			list4.Add(new Category(text4, array4));
			List<Category> list5 = Menu.categories;
			string text5 = "Projectiles";
			Module[] array5 = new Module[19];
			int num45 = 0;
			Module module45 = new Module();
			module45.title = "SnowBall Gun";
			module45.tooltip = "Shoots a Snowball.";
			module45.toggleable = true;
			module45.action = delegate
			{
				Projectiles.SnowBallGun();
			};
			array5[num45] = module45;
			int num46 = 1;
			Module module46 = new Module();
			module46.title = "SnowBall Spam";
			module46.tooltip = "Spams a Snowball. ";
			module46.toggleable = true;
			module46.action = delegate
			{
				Projectiles.SnowBallSpam();
			};
			array5[num46] = module46;
			int num47 = 2;
			Module module47 = new Module();
			module47.title = "Vote Rock Gun";
			module47.tooltip = "Shoots a Vote Rock. ";
			module47.toggleable = true;
			module47.action = delegate
			{
				Projectiles.VoteRockGun();
			};
			array5[num47] = module47;
			int num48 = 3;
			Module module48 = new Module();
			module48.title = "Vote Rock Spam";
			module48.tooltip = "Spams a Vote Rock. ";
			module48.toggleable = true;
			module48.action = delegate
			{
				Projectiles.VoteRockSpam();
			};
			array5[num48] = module48;
			int num49 = 4;
			Module module49 = new Module();
			module49.title = "Water Balloon Gun";
			module49.tooltip = "Shoots a Water Balloon. ";
			module49.toggleable = true;
			module49.action = delegate
			{
				Projectiles.WaterBalloonGun();
			};
			array5[num49] = module49;
			int num50 = 5;
			Module module50 = new Module();
			module50.title = "Water Balloon Spam";
			module50.tooltip = "Spams a Water Balloon. ";
			module50.toggleable = true;
			module50.action = delegate
			{
				Projectiles.WaterBalloonSpam();
			};
			array5[num50] = module50;
			int num51 = 6;
			Module module51 = new Module();
			module51.title = "Mentos Gun";
			module51.tooltip = "Shoots a Mento. ";
			module51.toggleable = true;
			module51.action = delegate
			{
				Projectiles.MentoGun();
			};
			array5[num51] = module51;
			int num52 = 7;
			Module module52 = new Module();
			module52.title = "Mentos Spam";
			module52.tooltip = "Spams a Mento. ";
			module52.toggleable = true;
			module52.action = delegate
			{
				Projectiles.MentoSpam();
			};
			array5[num52] = module52;
			int num53 = 8;
			Module module53 = new Module();
			module53.title = "Halloween Gun";
			module53.tooltip = "Shoots a Halloween Projectile. ";
			module53.toggleable = true;
			module53.action = delegate
			{
				Projectiles.HalloweenCandyGun();
			};
			array5[num53] = module53;
			int num54 = 9;
			Module module54 = new Module();
			module54.title = "Halloween Spam";
			module54.tooltip = "Spams a Halloween Projectile. ";
			module54.toggleable = true;
			module54.action = delegate
			{
				Projectiles.HalloweenCandySpam();
			};
			array5[num54] = module54;
			int num55 = 10;
			Module module55 = new Module();
			module55.title = "Gift Gun";
			module55.tooltip = "Shoots a Gift. ";
			module55.toggleable = true;
			module55.action = delegate
			{
				Projectiles.GiftGun();
			};
			array5[num55] = module55;
			int num56 = 11;
			Module module56 = new Module();
			module56.title = "Gift Spam";
			module56.tooltip = "Spams a Gift. ";
			module56.toggleable = true;
			module56.action = delegate
			{
				Projectiles.GiftSpam();
			};
			array5[num56] = module56;
			int num57 = 12;
			Module module57 = new Module();
			module57.title = "Fish Food Gun";
			module57.tooltip = "Shoots a Fish Food. ";
			module57.toggleable = true;
			module57.action = delegate
			{
				Projectiles.FishFoodGun();
			};
			array5[num57] = module57;
			int num58 = 13;
			Module module58 = new Module();
			module58.title = "Fish Food Spam";
			module58.tooltip = "Spams a Fish Food. ";
			module58.toggleable = true;
			module58.action = delegate
			{
				Projectiles.FishFoodSpam();
			};
			array5[num58] = module58;
			int num59 = 14;
			Module module59 = new Module();
			module59.title = "Apple Gun";
			module59.tooltip = "Shoots a Apple.";
			module59.toggleable = true;
			module59.action = delegate
			{
				Projectiles.AppleGun();
			};
			array5[num59] = module59;
			int num60 = 15;
			Module module60 = new Module();
			module60.title = "Apple Spam";
			module60.tooltip = "Spams a Apple.";
			module60.toggleable = true;
			module60.action = delegate
			{
				Projectiles.AppleSpam();
			};
			array5[num60] = module60;
			int num61 = 16;
			Module module61 = new Module();
			module61.title = "Piss";
			module61.tooltip = "Spams a Snowball out of you. ";
			module61.toggleable = true;
			module61.action = delegate
			{
				Projectiles.Urine();
			};
			array5[num61] = module61;
			int num62 = 17;
			Module module62 = new Module();
			module62.title = "Poop";
			module62.tooltip = "Spams a Fish Food underneath you. ";
			module62.toggleable = true;
			module62.action = delegate
			{
				Projectiles.Feces();
			};
			array5[num62] = module62;
			int num63 = 18;
			Module module63 = new Module();
			module63.title = "Bust";
			module63.tooltip = "Allows you to bust everywhere.";
			module63.toggleable = true;
			module63.action = delegate
			{
				Projectiles.Bust();
			};
			array5[num63] = module63;
			list5.Add(new Category(text5, array5));
			List<Category> list6 = Menu.categories;
			string text6 = "Visuals";
			Module[] array6 = new Module[49];
			int num64 = 0;
			Module module64 = new Module();
			module64.title = "Morning Time";
			module64.tooltip = "Sets the time to Morning.";
			module64.toggleable = false;
			module64.action = delegate
			{
				Visuals.SetTime("morning");
			};
			array6[num64] = module64;
			int num65 = 1;
			Module module65 = new Module();
			module65.title = "Day Time";
			module65.tooltip = "Sets the time to Day.";
			module65.toggleable = false;
			module65.action = delegate
			{
				Visuals.SetTime("day");
			};
			array6[num65] = module65;
			int num66 = 2;
			Module module66 = new Module();
			module66.title = "Evening Time";
			module66.tooltip = "Sets the time to Evening.";
			module66.toggleable = false;
			module66.action = delegate
			{
				Visuals.SetTime("evening");
			};
			array6[num66] = module66;
			int num67 = 3;
			Module module67 = new Module();
			module67.title = "Night Time";
			module67.tooltip = "Sets the time to Night.";
			module67.toggleable = false;
			module67.action = delegate
			{
				Visuals.SetTime("night");
			};
			array6[num67] = module67;
			int num68 = 4;
			Module module68 = new Module();
			module68.title = "Small Grenade";
			module68.tooltip = "Spawns a Grenade at your hand. (based on size)";
			module68.toggleable = true;
			module68.action = delegate
			{
				Visuals.Grenade(0.05f);
			};
			array6[num68] = module68;
			int num69 = 5;
			Module module69 = new Module();
			module69.title = "Grenade";
			module69.tooltip = "Spawns a Grenade at your hand. (based on size)";
			module69.toggleable = true;
			module69.action = delegate
			{
				Visuals.Grenade(0.1f);
			};
			array6[num69] = module69;
			int num70 = 6;
			Module module70 = new Module();
			module70.title = "Big Grenade";
			module70.tooltip = "Spawns a Grenade at your hand. (based on size)";
			module70.toggleable = true;
			module70.action = delegate
			{
				Visuals.Grenade(0.2f);
			};
			array6[num70] = module70;
			int num71 = 7;
			Module module71 = new Module();
			module71.title = "Bigger Grenade";
			module71.tooltip = "Spawns a Grenade at your hand. (based on size)";
			module71.toggleable = true;
			module71.action = delegate
			{
				Visuals.Grenade(0.5f);
			};
			array6[num71] = module71;
			int num72 = 8;
			Module module72 = new Module();
			module72.title = "HUGE Grenade";
			module72.tooltip = "Spawns a Grenade at your hand. (based on size)";
			module72.toggleable = true;
			module72.action = delegate
			{
				Visuals.Grenade(1f);
			};
			array6[num72] = module72;
			int num73 = 9;
			Module module73 = new Module();
			module73.title = "Grenade Minigun";
			module73.tooltip = "Shoots a Grenade out of your hand. (based on size)";
			module73.toggleable = true;
			module73.action = delegate
			{
				Visuals.GrenadeMinigun();
			};
			array6[num73] = module73;
			int num74 = 10;
			Module module74 = new Module();
			module74.title = "Explode Gun";
			module74.tooltip = "Plays an Explosion Effect wherever you shoot.";
			module74.toggleable = true;
			module74.action = delegate
			{
				Visuals.ExplodeGun();
			};
			array6[num74] = module74;
			int num75 = 11;
			Module module75 = new Module();
			module75.title = "Rainbow Lightning";
			module75.tooltip = "Makes all Lightning Rainbow.";
			module75.toggleable = true;
			module75.disableAction = delegate
			{
				Visuals.Rainbow(false);
			};
			module75.action = delegate
			{
				Visuals.Rainbow(true);
			};
			array6[num75] = module75;
			int num76 = 12;
			Module module76 = new Module();
			module76.title = "Lightning Strike (G)";
			module76.tooltip = "Shoots Lightning out your hand.";
			module76.toggleable = true;
			module76.action = delegate
			{
				Visuals.CastLightningBolt();
			};
			array6[num76] = module76;
			int num77 = 13;
			Module module77 = new Module();
			module77.title = "Lightning Strike Gun";
			module77.tooltip = "Spawns Lightning wherever you shoot.";
			module77.toggleable = true;
			module77.action = delegate
			{
				Visuals.CastLightningBoltGun();
			};
			array6[num77] = module77;
			int num78 = 14;
			Module module78 = new Module();
			module78.title = "Lightning Strike Aura (G)";
			module78.tooltip = "Spawns Lightning around you.";
			module78.toggleable = true;
			module78.action = delegate
			{
				Visuals.LightningAura();
			};
			array6[num78] = module78;
			int num79 = 15;
			Module module79 = new Module();
			module79.title = "Growing Blackhole (FOREST)";
			module79.tooltip = "Spawns a Growing Blackhole in Forest.";
			module79.toggleable = true;
			module79.action = delegate
			{
				Visuals.CreateBlackHole(0.0001f, true);
			};
			module79.disableAction = delegate
			{
				Visuals.StopSound();
			};
			array6[num79] = module79;
			int num80 = 16;
			Module module80 = new Module();
			module80.title = "Very Small Blackhole (FOREST)";
			module80.tooltip = "Spawns a Blackhole in Forest. (based on size)";
			module80.toggleable = true;
			module80.action = delegate
			{
				Visuals.CreateBlackHole(0.1f, false);
			};
			module80.disableAction = delegate
			{
				Visuals.StopSound();
			};
			array6[num80] = module80;
			int num81 = 17;
			Module module81 = new Module();
			module81.title = "Small Blackhole (FOREST)";
			module81.tooltip = "Spawns a Blackhole in Forest. (based on size)";
			module81.toggleable = true;
			module81.action = delegate
			{
				Visuals.CreateBlackHole(0.5f, false);
			};
			module81.disableAction = delegate
			{
				Visuals.StopSound();
			};
			array6[num81] = module81;
			int num82 = 18;
			Module module82 = new Module();
			module82.title = "Medium Blackhole (FOREST)";
			module82.tooltip = "Spawns a Blackhole in Forest. (based on size)";
			module82.toggleable = true;
			module82.action = delegate
			{
				Visuals.CreateBlackHole(1f, false);
			};
			module82.disableAction = delegate
			{
				Visuals.StopSound();
			};
			array6[num82] = module82;
			int num83 = 19;
			Module module83 = new Module();
			module83.title = "Large Blackhole (FOREST)";
			module83.tooltip = "Spawns a Blackhole in Forest. (based on size)";
			module83.toggleable = true;
			module83.action = delegate
			{
				Visuals.CreateBlackHole(3f, false);
			};
			module83.disableAction = delegate
			{
				Visuals.StopSound();
			};
			array6[num83] = module83;
			int num84 = 20;
			Module module84 = new Module();
			module84.title = "Massive Blackhole";
			module84.tooltip = "Spawns a Blackhole in Forest. (based on size)";
			module84.toggleable = true;
			module84.action = delegate
			{
				Visuals.CreateBlackHole(6f, false);
			};
			module84.disableAction = delegate
			{
				Visuals.StopSound();
			};
			array6[num84] = module84;
			int num85 = 21;
			Module module85 = new Module();
			module85.title = "SUPERMASSIVE Blackhole";
			module85.tooltip = "Spawns a Blackhole in Forest. (based on size)";
			module85.toggleable = true;
			module85.action = delegate
			{
				Visuals.CreateBlackHole(18f, false);
			};
			module85.disableAction = delegate
			{
				Visuals.StopSound();
			};
			array6[num85] = module85;
			int num86 = 22;
			Module module86 = new Module();
			module86.title = "Move Blackhole Gun";
			module86.tooltip = "Moves the Blackhole to wherever you shoot.";
			module86.toggleable = true;
			module86.action = delegate
			{
				Visuals.BlackHoleGun();
			};
			array6[num86] = module86;
			int num87 = 23;
			Module module87 = new Module();
			module87.title = "Draw";
			module87.tooltip = "Creates Particles at your Hands.";
			module87.toggleable = true;
			module87.action = delegate
			{
				Visuals.Draw();
			};
			array6[num87] = module87;
			int num88 = 24;
			Module module88 = new Module();
			module88.title = "Draw Gun";
			module88.tooltip = "Creates Particles wherever you shoot.";
			module88.toggleable = true;
			module88.action = delegate
			{
				Visuals.DrawGun();
			};
			array6[num88] = module88;
			int num89 = 25;
			Module module89 = new Module();
			module89.title = "NameTags";
			module89.tooltip = "Puts a Text above everyone showing their name and FPS.";
			module89.toggleable = true;
			module89.action = delegate
			{
				Visuals.NameTagESP();
			};
			array6[num89] = module89;
			int num90 = 26;
			Module module90 = new Module();
			module90.title = "WireFrame ESP";
			module90.tooltip = "Creates a wireframe box around everyone.";
			module90.toggleable = true;
			module90.action = delegate
			{
				Visuals.WireFrame();
			};
			array6[num90] = module90;
			int num91 = 27;
			Module module91 = new Module();
			module91.title = "Bone ESP";
			module91.tooltip = "Allows you to see the bones of everyone.";
			module91.toggleable = true;
			module91.action = delegate
			{
				Visuals.BoneESP();
			};
			array6[num91] = module91;
			int num92 = 28;
			Module module92 = new Module();
			module92.title = "Box Esp";
			module92.tooltip = "Creates a box around everyone.";
			module92.toggleable = true;
			module92.action = delegate
			{
				Visuals.BoxESP();
			};
			array6[num92] = module92;
			int num93 = 29;
			Module module93 = new Module();
			module93.title = "Trail All";
			module93.tooltip = "Creates a trail on everyone.";
			module93.toggleable = true;
			module93.toggled = false;
			module93.action = delegate
			{
				Visuals.Trails();
			};
			array6[num93] = module93;
			int num94 = 30;
			Module module94 = new Module();
			module94.title = "Thick Tracers";
			module94.tooltip = "Creates a Line going to everyone in the lobby.";
			module94.toggleable = true;
			module94.toggled = false;
			module94.action = delegate
			{
				Visuals.ThickAdvTracers();
			};
			array6[num94] = module94;
			int num95 = 31;
			Module module95 = new Module();
			module95.title = "Thin Tracers";
			module95.tooltip = "Creates a Line going to everyone in the lobby.";
			module95.toggleable = true;
			module95.action = delegate
			{
				Visuals.ThinAdvTracers();
			};
			array6[num95] = module95;
			int num96 = 32;
			Module module96 = new Module();
			module96.title = "Rainbow Projectiles (CS)";
			module96.tooltip = "Makes all projectiles Rainbow.";
			module96.toggleable = true;
			module96.action = delegate
			{
				Visuals.RainbowProj();
			};
			array6[num96] = module96;
			int num97 = 33;
			Module module97 = new Module();
			module97.title = "Cube Minigun (CS)";
			module97.tooltip = "Shoots the desired shape.";
			module97.toggleable = true;
			module97.action = delegate
			{
				Visuals.CubeSpam(new Vector3(0.1f, 0.1f, 0.1f), Visuals.Black);
			};
			array6[num97] = module97;
			int num98 = 34;
			Module module98 = new Module();
			module98.title = "Big Cube Minigun (CS)";
			module98.tooltip = "Shoots the desired shape.";
			module98.toggleable = true;
			module98.action = delegate
			{
				Visuals.CubeSpam(new Vector3(0.2f, 0.2f, 0.2f), Visuals.Black);
			};
			array6[num98] = module98;
			int num99 = 35;
			Module module99 = new Module();
			module99.title = "Bigger Cube Minigun (CS)";
			module99.tooltip = "Shoots the desired shape.";
			module99.toggleable = true;
			module99.action = delegate
			{
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
			};
			array6[num99] = module99;
			int num100 = 36;
			Module module100 = new Module();
			module100.title = "Cube Gun (CS)";
			module100.tooltip = "Spawns the desired shape wherever you shoot.";
			module100.toggleable = true;
			module100.action = delegate
			{
				Visuals.CubeGun(new Vector3(0.1f, 0.1f, 0.1f), Visuals.Black);
			};
			array6[num100] = module100;
			int num101 = 37;
			Module module101 = new Module();
			module101.title = "Sphere Minigun (CS)";
			module101.tooltip = "Shoots the desired shape.";
			module101.toggleable = true;
			module101.action = delegate
			{
				Visuals.SphereSpam(new Vector3(0.1f, 0.1f, 0.1f), Visuals.Black);
			};
			array6[num101] = module101;
			int num102 = 38;
			Module module102 = new Module();
			module102.title = "Big Sphere Minigun (CS)";
			module102.tooltip = "Shoots the desired shape.";
			module102.toggleable = true;
			module102.action = delegate
			{
				Visuals.SphereSpam(new Vector3(0.2f, 0.2f, 0.2f), Visuals.Black);
			};
			array6[num102] = module102;
			int num103 = 39;
			Module module103 = new Module();
			module103.title = "Bigger Sphere Minigun (CS)";
			module103.tooltip = "Shoots the desired shape.";
			module103.toggleable = true;
			module103.action = delegate
			{
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
			};
			array6[num103] = module103;
			int num104 = 40;
			Module module104 = new Module();
			module104.title = "Sphere Gun (CS)";
			module104.tooltip = "Spawns the desired shape wherever you shoot.";
			module104.toggleable = true;
			module104.action = delegate
			{
				Visuals.SphereGun(new Vector3(0.1f, 0.1f, 0.1f), Visuals.Black);
			};
			array6[num104] = module104;
			int num105 = 41;
			Module module105 = new Module();
			module105.title = "Projectile Blaster (INSANE)";
			module105.tooltip = "Spawns a LOT of projectiles.";
			module105.toggleable = true;
			module105.action = delegate
			{
				Visuals.Miniguun();
			};
			array6[num105] = module105;
			int num106 = 42;
			Module module106 = new Module();
			module106.title = "Grab Projectiles (CS)";
			module106.tooltip = "Allows you to Grab the Projectiles";
			module106.toggleable = true;
			module106.action = delegate
			{
				Visuals.GrabProjectiles();
			};
			array6[num106] = module106;
			int num107 = 43;
			Module module107 = new Module();
			module107.title = "Launch Projectile Gun";
			module107.tooltip = "Launches the projectiles selected.";
			module107.toggleable = true;
			module107.action = delegate
			{
				Visuals.FPP();
			};
			array6[num107] = module107;
			int num108 = 44;
			Module module108 = new Module();
			module108.title = "Launch All Projectile";
			module108.tooltip = "Launches the projectiles selected.";
			module108.toggleable = true;
			module108.action = delegate
			{
				Visuals.FPPAll();
			};
			array6[num108] = module108;
			int num109 = 45;
			Module module109 = new Module();
			module109.title = "Launch Projectile Aura";
			module109.tooltip = "Launches the projectiles selected.";
			module109.toggleable = true;
			module109.action = delegate
			{
				Visuals.FPPAura();
			};
			array6[num109] = module109;
			int num110 = 46;
			Module module110 = new Module();
			module110.title = "Bring Projectile Gun";
			module110.tooltip = "Brings the projectiles selected.";
			module110.toggleable = true;
			module110.action = delegate
			{
				Visuals.BP();
			};
			array6[num110] = module110;
			int num111 = 47;
			Module module111 = new Module();
			module111.title = "Bring All Projectile";
			module111.tooltip = "Brings the projectiles selected.";
			module111.toggleable = true;
			module111.action = delegate
			{
				Visuals.BPA();
			};
			array6[num111] = module111;
			int num112 = 48;
			Module module112 = new Module();
			module112.title = "Delete Projectiles";
			module112.tooltip = "Deletes all Projectiles.";
			module112.toggleable = false;
			module112.action = delegate
			{
				Visuals.DelProj();
			};
			array6[num112] = module112;
			list6.Add(new Category(text6, array6));
			List<Category> list7 = Menu.categories;
			string text7 = "Advantage";
			Module[] array7 = new Module[10];
			int num113 = 0;
			Module module113 = new Module();
			module113.title = "Flick Tag Gun";
			module113.tooltip = "'Flick Tags' the player.";
			module113.toggleable = true;
			module113.toggled = false;
			module113.action = delegate
			{
				Advantage.FlickTagGun();
			};
			array7[num113] = module113;
			int num114 = 1;
			Module module114 = new Module();
			module114.title = "Flick Tag Aura";
			module114.tooltip = "'Flick Tags' the people around you.";
			module114.toggleable = true;
			module114.toggled = false;
			module114.action = delegate
			{
				Advantage.FlickTagAura();
			};
			array7[num114] = module114;
			int num115 = 2;
			Module module115 = new Module();
			module115.title = "Tag All";
			module115.tooltip = "Tags everyone in the lobby.";
			module115.toggleable = true;
			module115.action = delegate
			{
				Advantage.TagAll();
			};
			array7[num115] = module115;
			int num116 = 3;
			Module module116 = new Module();
			module116.title = "Tag Self";
			module116.tooltip = "Tags your VRRig.";
			module116.toggleable = true;
			module116.action = delegate
			{
				Advantage.TagSelf();
			};
			array7[num116] = module116;
			int num117 = 4;
			Module module117 = new Module();
			module117.title = "Tag Gun";
			module117.tooltip = "Tags the person selected.";
			module117.toggleable = true;
			module117.toggled = false;
			module117.action = delegate
			{
				Advantage.TagGun();
			};
			array7[num117] = module117;
			int num118 = 5;
			Module module118 = new Module();
			module118.title = "Grab All (GUARDIAN)";
			module118.tooltip = "Grabs everyone.";
			module118.toggleable = true;
			module118.toggled = false;
			module118.action = delegate
			{
				Advantage.GrabAll();
			};
			array7[num118] = module118;
			int num119 = 6;
			Module module119 = new Module();
			module119.title = "Grab Gun (GUARDIAN)";
			module119.tooltip = "Grabs the person selected.";
			module119.toggleable = true;
			module119.toggled = false;
			module119.action = delegate
			{
				Advantage.GrabGun();
			};
			array7[num119] = module119;
			int num120 = 7;
			Module module120 = new Module();
			module120.title = "Invis All (GUARDIAN)";
			module120.tooltip = "Makes everyone Invisible.";
			module120.toggleable = true;
			module120.toggled = false;
			module120.action = delegate
			{
				Advantage.crash();
			};
			array7[num120] = module120;
			int num121 = 8;
			Module module121 = new Module();
			module121.title = "Invis Gun (GUARDIAN)";
			module121.tooltip = "Makes the person Invisible.";
			module121.toggleable = true;
			module121.toggled = false;
			module121.action = delegate
			{
				Advantage.crashgun2();
			};
			array7[num121] = module121;
			int num122 = 9;
			Module module122 = new Module();
			module122.title = "Auto Guardian";
			module122.tooltip = "Makes you Guardian each round.";
			module122.toggleable = true;
			module122.toggled = false;
			module122.action = delegate
			{
				Advantage.AutoGuardian();
			};
			array7[num122] = module122;
			list7.Add(new Category(text7, array7));
			List<Category> list8 = Menu.categories;
			string text8 = "Exploits";
			Module[] array8 = new Module[15];
			array8[0] = new Module
			{
				title = "Kick All (STUMP) (PRIVATE)",
				tooltip = "Kicks everyone in Stump.",
				toggleable = false,
				action = new Action(OP.KickAll)
			};
			array8[1] = new Module
			{
				title = "Crash Gun",
				tooltip = "Crashes the person selected.",
				toggleable = true,
				action = new Action(OP.FreezeGun)
			};
			array8[2] = new Module
			{
				title = "Crash All",
				tooltip = "Crashes everyone.",
				toggleable = true,
				action = new Action(OP.FreezeAll)
			};
			array8[3] = new Module
			{
				title = "Crash Aura",
				tooltip = "Crashes everyone around you.",
				toggleable = true,
				action = new Action(OP.FreezeAura)
			};
			array8[4] = new Module
			{
				title = "Crash On Touch",
				tooltip = "Crashes anyone you touch.",
				toggleable = true,
				action = new Action(OP.FreezeOnTouch)
			};
			int num123 = 5;
			Module module123 = new Module();
			module123.title = "Stutter Gun";
			module123.tooltip = "Strong Lags the person selected.";
			module123.toggleable = true;
			module123.action = delegate
			{
				OP.LagSpikeGun();
			};
			array8[num123] = module123;
			int num124 = 6;
			Module module124 = new Module();
			module124.title = "Stutter All";
			module124.tooltip = "Strong Lags everyone.";
			module124.toggleable = true;
			module124.action = delegate
			{
				OP.LagSpikeAll();
			};
			array8[num124] = module124;
			int num125 = 7;
			Module module125 = new Module();
			module125.title = "Stutter Aura";
			module125.tooltip = "Strong Lags everyone around you.";
			module125.toggleable = true;
			module125.action = delegate
			{
				OP.LagSpikeAura();
			};
			array8[num125] = module125;
			int num126 = 8;
			Module module126 = new Module();
			module126.title = "Stutter On Touch";
			module126.tooltip = "Strong Lags anyone you touch.";
			module126.toggleable = true;
			module126.action = delegate
			{
				OP.LagSpikeOnTouch();
			};
			array8[num126] = module126;
			int num127 = 9;
			Module module127 = new Module();
			module127.title = "Lag Gun";
			module127.tooltip = "Lags the person selected.";
			module127.toggleable = true;
			module127.action = delegate
			{
				OP.LagGun();
			};
			array8[num127] = module127;
			int num128 = 10;
			Module module128 = new Module();
			module128.title = "Lag All";
			module128.tooltip = "Lags everyone";
			module128.toggleable = true;
			module128.action = delegate
			{
				OP.LagAll();
			};
			array8[num128] = module128;
			int num129 = 11;
			Module module129 = new Module();
			module129.title = "Lag Aura";
			module129.tooltip = "Lags everyone around you.";
			module129.toggleable = true;
			module129.action = delegate
			{
				OP.LagAura(false);
			};
			array8[num129] = module129;
			int num130 = 12;
			Module module130 = new Module();
			module130.title = "Lag On Touch";
			module130.tooltip = "Lags anyone you touch.";
			module130.toggleable = true;
			module130.action = delegate
			{
				OP.LagOnTouch();
			};
			array8[num130] = module130;
			int num131 = 13;
			Module module131 = new Module();
			module131.title = "Destroy Gun (REJOIN)";
			module131.tooltip = "The people who join can't see the Destroyed Person.";
			module131.toggleable = true;
			module131.action = delegate
			{
				OP.DestroyGun();
			};
			array8[num131] = module131;
			int num132 = 14;
			Module module132 = new Module();
			module132.title = "Destroy All (REJOIN)";
			module132.tooltip = "The people who join can't see everyone else.";
			module132.toggleable = true;
			module132.action = delegate
			{
				OP.DestroyAll();
			};
			array8[num132] = module132;
			list8.Add(new Category(text8, array8));
			List<Category> list9 = Menu.categories;
			string text9 = "ServerSide";
			Module[] array9 = new Module[18];
			int num133 = 0;
			Module module133 = new Module();
			module133.title = "Earrape Gun (M) (CRITTER MAP)";
			module133.tooltip = "Spams a Noise wherever you desire.";
			module133.toggleable = true;
			module133.action = delegate
			{
				OP.MEarrapeGun();
			};
			array9[num133] = module133;
			int num134 = 1;
			Module module134 = new Module();
			module134.title = "Earrape All (M) (CRITTER MAP)";
			module134.tooltip = "Spams a Noise wherever you desire.";
			module134.toggleable = true;
			module134.action = delegate
			{
				OP.MEarrapeAll();
			};
			array9[num134] = module134;
			int num135 = 2;
			Module module135 = new Module();
			module135.title = "Noise Pop Spammer (M) (CRITTER MAP)";
			module135.tooltip = "Spams a Noise wherever you desire.";
			module135.toggleable = true;
			module135.action = delegate
			{
				OP.MNoiseMaker();
			};
			array9[num135] = module135;
			int num136 = 3;
			Module module136 = new Module();
			module136.title = "Noise Pop Gun (M) (CRITTER MAP)";
			module136.tooltip = "Spams a Noise wherever you desire.";
			module136.toggleable = true;
			module136.action = delegate
			{
				OP.MNoiseMakerGun();
			};
			array9[num136] = module136;
			int num137 = 4;
			Module module137 = new Module();
			module137.title = "Noise Pop Aura (M) (CRITTER MAP)";
			module137.tooltip = "Spams a Noise wherever you desire.";
			module137.toggleable = true;
			module137.action = delegate
			{
				OP.MNoiseMakerAura();
			};
			array9[num137] = module137;
			int num138 = 5;
			Module module138 = new Module();
			module138.title = "Noise Pop Halo (M) (CRITTER MAP)";
			module138.tooltip = "Spams a Noise wherever you desire.";
			module138.toggleable = true;
			module138.action = delegate
			{
				OP.MHalo();
			};
			array9[num138] = module138;
			int num139 = 6;
			Module module139 = new Module();
			module139.title = "Hoverboard Spawn Gun";
			module139.tooltip = "Spawns HoverBoards wherever you shoot.";
			module139.toggleable = true;
			module139.toggled = false;
			module139.action = delegate
			{
				Serversided.HoverboardGun();
			};
			array9[num139] = module139;
			int num140 = 7;
			Module module140 = new Module();
			module140.title = "Hoverboard Spam";
			module140.tooltip = "Spams a HoverBoard.";
			module140.toggleable = true;
			module140.toggled = false;
			module140.action = delegate
			{
				Serversided.HoverboardSpam(Serversided.hoverBoardDelay);
			};
			array9[num140] = module140;
			int num141 = 8;
			Module module141 = new Module();
			module141.title = "Hoverboard Shoot";
			module141.tooltip = "Shoots a HoverBoard. (based on speed)";
			module141.toggleable = true;
			module141.toggled = false;
			module141.action = delegate
			{
				Serversided.HoverboardShoot(2f);
			};
			array9[num141] = module141;
			int num142 = 9;
			Module module142 = new Module();
			module142.title = "Hoverboard MiniGun";
			module142.tooltip = "Shoots a HoverBoard. (based on speed)";
			module142.toggleable = true;
			module142.toggled = false;
			module142.action = delegate
			{
				Serversided.HoverboardShoot(6f);
			};
			array9[num142] = module142;
			int num143 = 10;
			Module module143 = new Module();
			module143.title = "Hoverboard Sniper";
			module143.tooltip = "Shoots a HoverBoard. (based on speed)";
			module143.toggleable = true;
			module143.toggled = false;
			module143.action = delegate
			{
				Serversided.HoverboardShoot(9f);
			};
			array9[num143] = module143;
			int num144 = 11;
			Module module144 = new Module();
			module144.title = "Hoverboard Laser";
			module144.tooltip = "Shoots a HoverBoard. (based on speed)";
			module144.toggleable = true;
			module144.toggled = false;
			module144.action = delegate
			{
				Serversided.HoverboardShoot(14f);
			};
			array9[num144] = module144;
			int num145 = 12;
			Module module145 = new Module();
			module145.title = "Hoverboard Halo";
			module145.tooltip = "Makes hoverboards halo around you.";
			module145.toggleable = true;
			module145.toggled = false;
			module145.action = delegate
			{
				Serversided.HoverboardHalo();
			};
			array9[num145] = module145;
			int num146 = 13;
			Module module146 = new Module();
			module146.title = "Pee Hoverboard";
			module146.tooltip = "Makes you pee a hoverboard.";
			module146.toggleable = true;
			module146.toggled = false;
			module146.action = delegate
			{
				Serversided.PeeHoverboard();
			};
			array9[num146] = module146;
			int num147 = 14;
			Module module147 = new Module();
			module147.title = "Poop Hoverboard";
			module147.tooltip = "Makes you poop a hoverboard.";
			module147.toggleable = true;
			module147.toggled = false;
			module147.action = delegate
			{
				Serversided.PoopHoverboard();
			};
			array9[num147] = module147;
			int num148 = 15;
			Module module148 = new Module();
			module148.title = "SS Hoverboard";
			module148.tooltip = "Allows you to grab a hoverboard.";
			module148.toggleable = true;
			module148.toggled = false;
			module148.action = delegate
			{
				Hoverboards.GetHoverboard();
			};
			array9[num148] = module148;
			int num149 = 16;
			Module module149 = new Module();
			module149.title = "VFX Spammer (STUMP)";
			module149.tooltip = "Spams the Virtual Stump Effect in Stump.";
			module149.toggleable = true;
			module149.toggled = false;
			module149.action = delegate
			{
				Visuals.VFX();
			};
			array9[num149] = module149;
			int num150 = 17;
			Module module150 = new Module();
			module150.title = "VFX Spammer Only For Person Gun (STUMP)";
			module150.tooltip = "VFX Spams for only one target.";
			module150.toggleable = true;
			module150.toggled = false;
			module150.action = delegate
			{
				Visuals.VFXG();
			};
			array9[num150] = module150;
			list9.Add(new Category(text9, array9));
			List<Category> list10 = Menu.categories;
			string text10 = "<color=green>TEST</color>";
			Module[] array10 = new Module[10];
			array10[0] = new Module
			{
				title = "READ ME",
				tooltip = "Anything you use in this category might lead to you getting banned.",
				toggleable = false,
				toggled = false
			};
			int num151 = 1;
			Module module151 = new Module();
			module151.title = "Red Gun (M)";
			module151.toggleable = true;
			module151.toggled = false;
			module151.action = delegate
			{
				OP.SetColorGun("red");
			};
			array10[num151] = module151;
			int num152 = 2;
			Module module152 = new Module();
			module152.title = "Blue Gun (M)";
			module152.toggleable = true;
			module152.toggled = false;
			module152.action = delegate
			{
				OP.SetColorGun("blue");
			};
			array10[num152] = module152;
			array10[3] = new Module
			{
				title = "Fire Spam",
				toggleable = true,
				toggled = false,
				action = new Action(Projectiles.FirecrackerSpam)
			};
			array10[4] = new Module
			{
				title = "Bomb Spam",
				toggleable = true,
				toggled = false,
				action = new Action(Projectiles.BombSpam)
			};
			array10[5] = new Module
			{
				title = "Stun Shoot",
				toggleable = true,
				toggled = false,
				action = new Action(OP.StunBombMinigun)
			};
			array10[6] = new Module
			{
				title = "Container Critter Spam",
				toggleable = true,
				toggled = false,
				action = new Action(OP.ContainerSpam)
			};
			array10[7] = new Module
			{
				title = "Critter Spam",
				toggleable = true,
				toggled = false,
				action = new Action(OP.PetSpam)
			};
			array10[8] = new Module
			{
				title = "Critter Minigun",
				toggleable = true,
				toggled = false,
				action = new Action(OP.PetMinigun)
			};
			array10[9] = new Module
			{
				title = "Camera Spammer (NW!!)",
				toggleable = true,
				toggled = false,
				action = new Action(OP.CameraSpammer)
			};
			list10.Add(new Category(text10, array10));
			List<Category> list11 = Menu.categories;
			string text11 = "HIDDEN";
			Module[] array11 = new Module[4];
			int num153 = 0;
			Module module153 = new Module();
			module153.title = "Rainbow HOVERBOARDS";
			module153.toggleable = true;
			module153.toggled = true;
			module153.action = delegate
			{
				Serversided.RGB();
			};
			array11[num153] = module153;
			int num154 = 1;
			Module module154 = new Module();
			module154.title = "Board Text";
			module154.toggleable = true;
			module154.toggled = true;
			module154.action = delegate
			{
				Loader.AlsoAwake();
			};
			array11[num154] = module154;
			int num155 = 2;
			Module module155 = new Module();
			module155.title = "Stump Menu Text";
			module155.toggleable = true;
			module155.toggled = true;
			module155.action = delegate
			{
				Visuals.Display();
			};
			array11[num155] = module155;
			int num156 = 3;
			Module module156 = new Module();
			module156.title = "Menu Handler";
			module156.toggleable = true;
			module156.toggled = true;
			module156.action = delegate
			{
				Visuals.r();
			};
			array11[num156] = module156;
			list11.Add(new Category(text11, array11));
		}

		// Token: 0x060001CB RID: 459 RVA: 0x0001DC70 File Offset: 0x0001BE70
		public static void Start()
		{
			try
			{
				Menu.Cateories();
				AssetBundle assetBundle = Menu.LoadAssetBundle("CanvasGUI.Resources.menu");
				GameObject gameObject = assetBundle.LoadAsset<GameObject>("Menu");
				Menu.menu = global::UnityEngine.Object.Instantiate<GameObject>(gameObject);
				global::UnityEngine.Object.DontDestroyOnLoad(Menu.menu);
				Menu.menu.name = Settings.title + " - Menu";
				Menu.menu.GetComponentInChildren<Canvas>().worldCamera = Camera.main;
				Menu.menu.AddComponent<ButtonInteractor>();
				Menu.menu.AddComponent<ScrollInteractor>();
				GameObject gameObject2 = Menu.menu.transform.Find("Canvas/Visual/Background").gameObject;
				try
				{
					gameObject2.GetComponent<Outline>().effectColor = Settings.theme;
					Menu.GenerateGradient(Menu.menu.transform.Find("Canvas/Visual/Tabs").GetComponent<Image>(), Settings.col1, Settings.col2);
					Menu.GenerateGradient(Menu.menu.transform.Find("Canvas/Visual/Divider").GetComponent<Image>(), Settings.col1, Settings.col2);
					GameObject gameObject3 = Menu.menu.transform.Find("Canvas/Tab Scrolling/Tabs").gameObject;
					for (int i = 0; i < gameObject3.transform.childCount; i++)
					{
						GameObject gameObject4 = gameObject3.transform.GetChild(i).gameObject;
						bool activeSelf = gameObject4.activeSelf;
						if (activeSelf)
						{
							Menu.GenerateGradient(gameObject4.GetComponent<Image>(), Settings.col1, Settings.col2);
						}
					}
				}
				catch
				{
				}
				Menu.menu.transform.Find("Canvas/Visual/Watermark").GetComponent<TextMeshProUGUI>().text = Settings.title + " - 1.5.0";
				Menu.menu.transform.Find("Canvas/Visual/Close").GetComponent<Button>().onClick.AddListener(delegate
				{
					Menu.Toggle(false);
				});
				Menu.menu.transform.Find("Canvas/Visual/Disconnect").GetComponent<Button>().onClick.AddListener(delegate
				{
					NetworkSystem.Instance.ReturnToSinglePlayer();
				});
				for (int j = 0; j < Menu.categories.Count; j++)
				{
					GameObject gameObject5 = Menu.menu.transform.Find("Canvas/Tab Scrolling/Tabs").gameObject;
					GameObject gameObject6 = gameObject5.transform.Find("Tab").gameObject;
					GameObject gameObject7 = global::UnityEngine.Object.Instantiate<GameObject>(gameObject6, gameObject5.transform);
					gameObject7.SetActive(true);
					gameObject7.name = Menu.categories[j].name;
					bool flag = gameObject7.name != "HIDDEN";
					if (flag)
					{
						int index = j;
						gameObject7.GetComponent<Button>().onClick.AddListener(delegate
						{
							Menu.UpdateCurrentPage(index);
						});
						gameObject7.GetComponentInChildren<TextMeshProUGUI>().text = Menu.categories[j].name;
						Menu.GenerateGradient(gameObject7.GetComponent<Image>(), Settings.col1, Settings.col2);
					}
					else
					{
						gameObject7.SetActive(false);
						gameObject7.GetComponent<Button>().onClick.RemoveAllListeners();
					}
				}
				Menu.Buttons();
				Menu.Toggle(false);
			}
			catch
			{
			}
		}

		// Token: 0x060001CC RID: 460 RVA: 0x0001E018 File Offset: 0x0001C218
		public static void GenerateGradient(Image rawImage, Color col1, Color col2)
		{
			try
			{
				RectTransform rectTransform = rawImage.rectTransform;
				int num = Mathf.RoundToInt(rectTransform.rect.width);
				int num2 = Mathf.RoundToInt(rectTransform.rect.height);
				Texture2D texture2D = new Texture2D(1, num);
				for (int i = 0; i < num; i++)
				{
					float num3 = (float)i / (float)(num - 1);
					Color color = Color.Lerp(col1, col2, num3);
					texture2D.SetPixel(0, i, color);
				}
				texture2D.Apply();
				Sprite sprite = Sprite.Create(texture2D, new Rect(0f, 0f, (float)texture2D.width, (float)texture2D.height), new Vector2(0.5f, 0.5f));
				rawImage.sprite = sprite;
			}
			catch (Exception ex)
			{
				GUIUtility.systemCopyBuffer = ex.Message;
			}
		}

		// Token: 0x060001CD RID: 461 RVA: 0x0001E104 File Offset: 0x0001C304
		public static void Update()
		{
			try
			{
				bool flag = !GorillaTagger.hasInstance;
				if (!flag)
				{
					bool toggleButton = Settings.toggleButton;
					if (toggleButton)
					{
						bool flag2 = !Menu.menu.activeSelf && Menu.canOpen;
						if (flag2)
						{
							Menu.Toggle(true);
						}
						else
						{
							bool flag3 = Menu.canClose;
							if (flag3)
							{
								Menu.Toggle(false);
							}
						}
						Menu.canClose = false;
					}
					else
					{
						bool activeSelf = Menu.menu.activeSelf;
						if (activeSelf)
						{
							Menu.canClose = true;
							Menu.canOpen = false;
						}
						else
						{
							Menu.canClose = false;
							Menu.canOpen = true;
						}
					}
					foreach (Category category in Menu.categories)
					{
						foreach (Module module in category.buttons.Where((Module m) => m.toggleable && m.toggled && m.action != null))
						{
							module.action();
						}
					}
				}
			}
			catch (Exception ex)
			{
				GUIUtility.systemCopyBuffer = ex.Message;
			}
		}

		// Token: 0x04000181 RID: 385
		public static GameObject menu = null;

		// Token: 0x04000182 RID: 386
		public static List<Category> categories = new List<Category>();

		// Token: 0x04000183 RID: 387
		public static List<GameObject> buttons = new List<GameObject>();

		// Token: 0x04000184 RID: 388
		public static int page_index = 0;

		// Token: 0x04000185 RID: 389
		public static bool canClose = false;

		// Token: 0x04000186 RID: 390
		public static bool canOpen = true;
	}
}
