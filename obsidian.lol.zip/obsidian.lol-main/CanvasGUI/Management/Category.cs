﻿using System;

namespace CanvasGUI.Management
{
	// Token: 0x02000035 RID: 53
	public class Category
	{
		// Token: 0x17000027 RID: 39
		// (get) Token: 0x060001C1 RID: 449 RVA: 0x0001A121 File Offset: 0x00018321
		// (set) Token: 0x060001C2 RID: 450 RVA: 0x0001A129 File Offset: 0x00018329
		public string name { get; set; }

		// Token: 0x17000028 RID: 40
		// (get) Token: 0x060001C3 RID: 451 RVA: 0x0001A132 File Offset: 0x00018332
		// (set) Token: 0x060001C4 RID: 452 RVA: 0x0001A13A File Offset: 0x0001833A
		public Module[] buttons { get; set; }

		// Token: 0x060001C5 RID: 453 RVA: 0x0001A143 File Offset: 0x00018343
		public Category(string name, Module[] buttons)
		{
			this.name = name;
			this.buttons = buttons;
		}
	}
}
