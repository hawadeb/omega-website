﻿using System;
using GorillaLocomotion;
using Photon.Pun;
using UnityEngine;

namespace Abyss.Mods
{
	// Token: 0x02000014 RID: 20
	public class Serversided
	{
		// Token: 0x0600012E RID: 302 RVA: 0x0000E884 File Offset: 0x0000CA84
		public static void HoverboardGun()
		{
			Rig.RigGun();
			GunLib.Waver waver = GunLib.nolockshoot();
			bool flag = waver != null;
			if (flag)
			{
				bool flag2 = waver.shooting && waver.triggered;
				if (flag2)
				{
					bool flag3 = Time.time > Serversided.ina;
					bool flag4 = flag3;
					if (flag4)
					{
						Serversided.ina = Time.time + Serversided.hoverBoardDelay;
						Serversided.SpawnHoverboard(waver.pointerPos, Quaternion.identity, Vector3.zero, Color.HSVToRGB(Serversided.hue, 1f, 1f), 0);
					}
				}
			}
		}

		// Token: 0x0600012F RID: 303 RVA: 0x0000E914 File Offset: 0x0000CB14
		public static void RGB()
		{
			Serversided.hue += Time.deltaTime * 0.5f;
			bool flag = Serversided.hue > 1f;
			if (flag)
			{
				Serversided.hue = 0f;
			}
		}

		// Token: 0x06000130 RID: 304 RVA: 0x0000E954 File Offset: 0x0000CB54
		public static void HoverboardShoot(float speed)
		{
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			if (rightGrab)
			{
				bool flag = Time.time > Serversided.ina;
				bool flag2 = flag;
				if (flag2)
				{
					Serversided.ina = Time.time + 0.9f / speed;
					Serversided.SpawnHoverboard(GorillaTagger.Instance.rightHandTransform.transform.position, GorillaTagger.Instance.rightHandTransform.rotation, GorillaTagger.Instance.rightHandTransform.forward * 10f * speed, Color.HSVToRGB(Serversided.hue, 1f, 1f), 0);
				}
			}
			bool leftGrab = ControllerInputPoller.instance.leftGrab;
			if (leftGrab)
			{
				bool flag3 = Time.time > Serversided.ina;
				bool flag4 = flag3;
				if (flag4)
				{
					Serversided.ina = Time.time + 0.9f / speed;
					Serversided.SpawnHoverboard(GorillaTagger.Instance.leftHandTransform.transform.position, GorillaTagger.Instance.leftHandTransform.rotation, GorillaTagger.Instance.leftHandTransform.forward * 10f * speed, Color.HSVToRGB(Serversided.hue, 1f, 1f), 0);
				}
			}
		}

		// Token: 0x06000131 RID: 305 RVA: 0x0000EA98 File Offset: 0x0000CC98
		public static void RainbowHoverboard()
		{
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			if (rightGrab)
			{
				GTPlayer.Instance.GrabPersonalHoverboard(false, Vector3.zero, GorillaTagger.Instance.rightHandTransform.transform.rotation * Quaternion.Euler(0f, 180f, 0f), Color.HSVToRGB(Serversided.hue, 1f, 1f));
			}
		}

		// Token: 0x06000132 RID: 306 RVA: 0x0000EB0C File Offset: 0x0000CD0C
		public static void HoverboardSpam(float delay)
		{
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			if (rightGrab)
			{
				bool flag = Time.time > Serversided.ina;
				bool flag2 = flag;
				if (flag2)
				{
					Serversided.ina = Time.time + delay;
					Serversided.SpawnHoverboard(GorillaTagger.Instance.rightHandTransform.transform.position, GorillaTagger.Instance.rightHandTransform.rotation, Vector3.zero, Color.HSVToRGB(Serversided.hue, 1f, 1f), 0);
				}
			}
			bool leftGrab = ControllerInputPoller.instance.leftGrab;
			if (leftGrab)
			{
				bool flag3 = Time.time > Serversided.ina;
				bool flag4 = flag3;
				if (flag4)
				{
					Serversided.ina = Time.time + Serversided.hoverBoardDelay;
					Serversided.SpawnHoverboard(GorillaTagger.Instance.leftHandTransform.transform.position, GorillaTagger.Instance.leftHandTransform.rotation, Vector3.zero, Color.HSVToRGB(Serversided.hue, 1f, 1f), 0);
				}
			}
		}

		// Token: 0x06000133 RID: 307 RVA: 0x0000EC10 File Offset: 0x0000CE10
		public static void PeeHoverboard()
		{
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			if (rightGrab)
			{
				bool flag = Time.time > Serversided.ina;
				if (flag)
				{
					Serversided.ina = Time.time + Serversided.hoverBoardDelay;
					Vector3 vector = GorillaTagger.Instance.offlineVRRig.transform.forward.normalized * 10f;
					Serversided.SpawnHoverboard(GorillaTagger.Instance.offlineVRRig.transform.position - new Vector3(0f, 0.3f, 0f), Quaternion.identity, GorillaTagger.Instance.offlineVRRig.transform.forward.normalized * 10f, Color.yellow, 0);
				}
			}
		}

		// Token: 0x06000134 RID: 308 RVA: 0x0000ECE4 File Offset: 0x0000CEE4
		public static void HoverboardHalo()
		{
			Serversided.angle += 8f * Time.deltaTime;
			float num = GorillaTagger.Instance.offlineVRRig.transform.position.x + 0.7f * Mathf.Cos(Serversided.angle);
			float num2 = GorillaTagger.Instance.offlineVRRig.transform.position.y + 1.5f;
			float num3 = GorillaTagger.Instance.offlineVRRig.transform.position.z + 0.7f * Mathf.Sin(Serversided.angle);
			Vector3 vector = new Vector3(num, num2, num3);
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			if (rightGrab)
			{
				bool flag = Time.time > Serversided.ina;
				bool flag2 = flag;
				if (flag2)
				{
					Serversided.ina = Time.time + 0.1f;
					Serversided.SpawnHoverboard(vector, Quaternion.identity, Vector3.zero, Color.HSVToRGB(Serversided.hue, 1f, 1f), 0);
				}
			}
		}

		// Token: 0x06000135 RID: 309 RVA: 0x0000EDEC File Offset: 0x0000CFEC
		public static void PoopHoverboard()
		{
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			if (rightGrab)
			{
				bool flag = Time.time > Serversided.ina;
				if (flag)
				{
					Serversided.ina = Time.time + Serversided.hoverBoardDelay;
					Serversided.SpawnHoverboard(GorillaTagger.Instance.offlineVRRig.transform.position - new Vector3(0f, Serversided.hoverBoardDelay, 0f), Quaternion.Euler(90f, 0f, 0f), GorillaTagger.Instance.offlineVRRig.transform.up * -1f, Color.clear, 0);
				}
			}
		}

		// Token: 0x06000136 RID: 310 RVA: 0x0000EE9C File Offset: 0x0000D09C
		public static void SpawnHoverboard(Vector3 position, Quaternion rotation, Vector3 velocity, Color col, RpcTarget rpc)
		{
			bool flag = Serversided.whip;
			if (flag)
			{
				FreeHoverboardManager.instance.photonView.RPC("DropBoard_RPC", rpc, new object[]
				{
					true,
					BitPackUtils.PackWorldPosForNetwork(position),
					BitPackUtils.PackQuaternionForNetwork(rotation),
					BitPackUtils.PackWorldPosForNetwork(velocity),
					BitPackUtils.PackWorldPosForNetwork(Vector3.zero),
					BitPackUtils.PackColorForNetwork(col)
				});
				Serversided.whip = false;
			}
			else
			{
				FreeHoverboardManager.instance.photonView.RPC("DropBoard_RPC", rpc, new object[]
				{
					false,
					BitPackUtils.PackWorldPosForNetwork(position),
					BitPackUtils.PackQuaternionForNetwork(rotation),
					BitPackUtils.PackWorldPosForNetwork(velocity),
					BitPackUtils.PackWorldPosForNetwork(Vector3.zero),
					BitPackUtils.PackColorForNetwork(col)
				});
				Serversided.whip = true;
			}
		}

		// Token: 0x040000AB RID: 171
		public static float hue = 0f;

		// Token: 0x040000AC RID: 172
		public static float hoverBoardDelay = 0.35f;

		// Token: 0x040000AD RID: 173
		public static float ina;

		// Token: 0x040000AE RID: 174
		public static float angle = 0f;

		// Token: 0x040000AF RID: 175
		public static bool whip = true;
	}
}
