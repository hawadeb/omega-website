﻿using System;
using System.Collections.Generic;
using BepInEx;
using GorillaNetworking;
using Photon.Pun;
using UnityEngine;

namespace Abyss.Mods
{
	// Token: 0x02000013 RID: 19
	public class Room : MonoBehaviourPunCallbacks
	{
		// Token: 0x06000125 RID: 293 RVA: 0x0000E588 File Offset: 0x0000C788
		public static void QuitGTAG()
		{
			Application.Quit();
		}

		// Token: 0x06000126 RID: 294 RVA: 0x0000E591 File Offset: 0x0000C791
		public static void Disconnect()
		{
			PhotonNetwork.Disconnect();
		}

		// Token: 0x06000127 RID: 295 RVA: 0x0000E59C File Offset: 0x0000C79C
		public static string DetectCurrentMap()
		{
			foreach (KeyValuePair<string, string> keyValuePair in Room.gameModePaths)
			{
				bool flag = GameObject.Find(keyValuePair.Value) != null;
				if (flag)
				{
					return keyValuePair.Key;
				}
			}
			return null;
		}

		// Token: 0x06000128 RID: 296 RVA: 0x0000E614 File Offset: 0x0000C814
		public static string GetPathForGameMode(string gameMode)
		{
			string text;
			Room.gameModePaths.TryGetValue(gameMode.ToLower(), out text);
			return text;
		}

		// Token: 0x06000129 RID: 297 RVA: 0x0000E63C File Offset: 0x0000C83C
		public static void JoinRandomPublic()
		{
			bool inRoom = PhotonNetwork.InRoom;
			if (inRoom)
			{
				Debug.LogWarning("<color=blue>Photon</color> : Already connected to a room.");
			}
			else
			{
				string text = Room.DetectCurrentMap();
				bool flag = text == null;
				if (flag)
				{
					Debug.LogError("<color=blue>Photon</color> : Unable to detect the current map.");
				}
				else
				{
					string pathForGameMode = Room.GetPathForGameMode(text);
					bool flag2 = pathForGameMode == null;
					if (flag2)
					{
						Debug.LogError("<color=blue>Photon</color> : No valid path found for map: " + text + ".");
					}
					else
					{
						GameObject gameObject = GameObject.Find(pathForGameMode);
						GorillaNetworkJoinTrigger gorillaNetworkJoinTrigger = ((gameObject != null) ? gameObject.GetComponent<GorillaNetworkJoinTrigger>() : null);
						bool flag3 = gorillaNetworkJoinTrigger == null;
						if (flag3)
						{
							Debug.LogError("<color=blue>Photon</color> : Join trigger not found for path: " + pathForGameMode + ".");
						}
						else
						{
							PhotonNetworkController.Instance.AttemptToJoinPublicRoom(gorillaNetworkJoinTrigger, 0);
						}
					}
				}
			}
		}

		// Token: 0x0600012A RID: 298 RVA: 0x0000E6F4 File Offset: 0x0000C8F4
		public override void OnJoinRoomFailed(short returnCode, string message)
		{
			bool flag = returnCode == 32765;
			if (flag)
			{
				Debug.LogWarning("OnJoinRoomFailed : Failed to join room '" + Room.roomCode + "'. Reason: Is Full.");
			}
			else
			{
				Debug.LogWarning(string.Concat(new string[]
				{
					"OnJoinRoomFailed: Failed to join room '",
					Room.roomCode,
					"'. Reason: ",
					message,
					"."
				}));
			}
		}

		// Token: 0x0600012B RID: 299 RVA: 0x0000E764 File Offset: 0x0000C964
		public static void PrimaryDisconnect()
		{
			bool flag = ControllerInputPoller.instance.rightControllerPrimaryButton | UnityInput.Current.GetKey(KeyCode.F);
			if (flag)
			{
				PhotonNetwork.Disconnect();
			}
		}

		// Token: 0x040000A9 RID: 169
		public static string roomCode;

		// Token: 0x040000AA RID: 170
		public static readonly Dictionary<string, string> gameModePaths = new Dictionary<string, string>
		{
			{ "forest", "Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Forest, Tree Exit" },
			{ "city", "Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - City Front" },
			{ "canyons", "Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Canyon" },
			{ "mountains", "Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Mountain For Computer" },
			{ "beach", "Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Beach from Forest" },
			{ "sky", "Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Clouds" },
			{ "basement", "Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Basement For Computer" },
			{ "metro", "Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Metropolis from Computer" },
			{ "arcade", "Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - City frm Arcade" },
			{ "rotating", "Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Rotating Map" },
			{ "bayou", "Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - BayouComputer2" },
			{ "caves", "Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Cave" }
		};
	}
}
