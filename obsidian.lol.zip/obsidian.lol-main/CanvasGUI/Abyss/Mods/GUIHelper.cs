﻿using System;
using UnityEngine;

namespace Abyss.Mods
{
	// Token: 0x02000009 RID: 9
	public class GUIHelper
	{
		// Token: 0x0600007A RID: 122 RVA: 0x00006B94 File Offset: 0x00004D94
		public static Texture2D MakeTex(int width, int height, Color col)
		{
			Color[] array = new Color[width * height];
			for (int i = 0; i < array.Length; i++)
			{
				array[i] = col;
			}
			Texture2D texture2D = new Texture2D(width, height);
			texture2D.SetPixels(array);
			texture2D.Apply();
			texture2D.filterMode = FilterMode.Bilinear;
			texture2D.wrapMode = TextureWrapMode.Clamp;
			return texture2D;
		}

		// Token: 0x0600007B RID: 123 RVA: 0x00006BF4 File Offset: 0x00004DF4
		public static Texture2D MakeRoundedRectTexture(int width, int height, Color col, int roundPixels)
		{
			Texture2D texture2D = new Texture2D(width, height, TextureFormat.ARGB32, false);
			Color color = new Color(0f, 0f, 0f, 0f);
			for (int i = 0; i < height; i++)
			{
				for (int j = 0; j < width; j++)
				{
					bool flag = true;
					bool flag2 = j < roundPixels && i < roundPixels;
					if (flag2)
					{
						float num = (float)(roundPixels - j);
						float num2 = (float)(roundPixels - i);
						flag = num * num + num2 * num2 <= (float)(roundPixels * roundPixels);
					}
					else
					{
						bool flag3 = j >= width - roundPixels && i < roundPixels;
						if (flag3)
						{
							float num3 = (float)(j - (width - roundPixels));
							float num4 = (float)(roundPixels - i);
							flag = num3 * num3 + num4 * num4 <= (float)(roundPixels * roundPixels);
						}
						else
						{
							bool flag4 = j < roundPixels && i >= height - roundPixels;
							if (flag4)
							{
								float num5 = (float)(roundPixels - j);
								float num6 = (float)(i - (height - roundPixels));
								flag = num5 * num5 + num6 * num6 <= (float)(roundPixels * roundPixels);
							}
							else
							{
								bool flag5 = j >= width - roundPixels && i >= height - roundPixels;
								if (flag5)
								{
									float num7 = (float)(j - (width - roundPixels));
									float num8 = (float)(i - (height - roundPixels));
									flag = num7 * num7 + num8 * num8 <= (float)(roundPixels * roundPixels);
								}
							}
						}
					}
					texture2D.SetPixel(j, i, flag ? col : color);
				}
			}
			texture2D.Apply();
			texture2D.filterMode = FilterMode.Bilinear;
			texture2D.wrapMode = TextureWrapMode.Clamp;
			return texture2D;
		}

		// Token: 0x0600007C RID: 124 RVA: 0x00006D80 File Offset: 0x00004F80
		public static bool DrawButton(float windowWidth, ref float currentY, string text, Action onClick)
		{
			float num = windowWidth - 2f * GUIHelper.horizontalPadding;
			Rect rect = new Rect(GUIHelper.horizontalPadding, currentY, num, GUIHelper.buttonHeight);
			bool flag = GUI.Button(rect, text, GUIHelper.buttonStyle);
			bool flag2 = flag && onClick != null;
			if (flag2)
			{
				onClick();
			}
			currentY += GUIHelper.buttonHeight + GUIHelper.controlSpacing;
			return flag;
		}

		// Token: 0x0600007D RID: 125 RVA: 0x00006DEC File Offset: 0x00004FEC
		public static void DrawLabel(float windowWidth, ref float currentY, string text)
		{
			float num = windowWidth - 2f * GUIHelper.horizontalPadding;
			Rect rect = new Rect(GUIHelper.horizontalPadding, currentY, num, GUIHelper.buttonHeight);
			GUI.Label(rect, text, GUIHelper.labelStyle);
			currentY += GUIHelper.buttonHeight + GUIHelper.controlSpacing;
		}

		// Token: 0x0600007E RID: 126 RVA: 0x00006E3C File Offset: 0x0000503C
		public static void DrawLabelTextField(float windowWidth, ref float currentY, string labelText, ref string text, int maxLength, float labelWidthFactor = 0.4f)
		{
			float num = windowWidth - 2f * GUIHelper.horizontalPadding;
			float num2 = num * labelWidthFactor;
			float num3 = num - num2 - GUIHelper.controlSpacing;
			Rect rect = new Rect(GUIHelper.horizontalPadding, currentY, num2, GUIHelper.buttonHeight);
			GUI.Label(rect, labelText, GUIHelper.labelStyle);
			Rect rect2 = new Rect(GUIHelper.horizontalPadding + num2 + GUIHelper.controlSpacing, currentY, num3, GUIHelper.buttonHeight);
			text = GUI.TextField(rect2, text, maxLength, GUIHelper.textFieldStyle);
			currentY += GUIHelper.buttonHeight + GUIHelper.controlSpacing;
		}

		// Token: 0x0600007F RID: 127 RVA: 0x00006EC8 File Offset: 0x000050C8
		public static void DrawToggle(float windowWidth, ref float currentY, string label, ref bool value, Action<bool> onToggle)
		{
			float num = windowWidth - 2f * GUIHelper.horizontalPadding;
			Rect rect = new Rect(GUIHelper.horizontalPadding, currentY, num, GUIHelper.buttonHeight);
			GUIStyle guistyle = new GUIStyle(GUIHelper.buttonStyle);
			bool flag = value;
			if (flag)
			{
				Color backgroundColor = GUI.backgroundColor;
				GUI.backgroundColor = Color.green;
				bool flag2 = GUI.Button(rect, label + " [ON]", guistyle);
				GUI.backgroundColor = backgroundColor;
				bool flag3 = flag2;
				if (flag3)
				{
					value = !value;
					if (onToggle != null)
					{
						onToggle(value);
					}
				}
			}
			else
			{
				bool flag4 = GUI.Button(rect, label + " [OFF]", guistyle);
				bool flag5 = flag4;
				if (flag5)
				{
					value = !value;
					if (onToggle != null)
					{
						onToggle(value);
					}
				}
			}
			currentY += GUIHelper.buttonHeight + GUIHelper.controlSpacing;
		}

		// Token: 0x06000080 RID: 128 RVA: 0x00006FA4 File Offset: 0x000051A4
		public static void DrawSeparator(float windowWidth, ref float currentY, float height = 2f)
		{
			Rect rect = new Rect(GUIHelper.horizontalPadding, currentY, windowWidth - 2f * GUIHelper.horizontalPadding, height);
			Color backgroundColor = GUI.backgroundColor;
			GUI.backgroundColor = new Color(0.5f, 0.5f, 0.5f, 0.5f);
			GUI.Box(rect, "");
			GUI.backgroundColor = backgroundColor;
			currentY += height + GUIHelper.controlSpacing;
		}

		// Token: 0x06000081 RID: 129 RVA: 0x00007014 File Offset: 0x00005214
		public static bool DrawColoredButton(float windowWidth, ref float currentY, string text, Color color, Action onClick)
		{
			float num = windowWidth - 2f * GUIHelper.horizontalPadding;
			Rect rect = new Rect(GUIHelper.horizontalPadding, currentY, num, GUIHelper.buttonHeight);
			Color backgroundColor = GUI.backgroundColor;
			GUI.backgroundColor = color;
			bool flag = GUI.Button(rect, text, GUIHelper.buttonStyle);
			GUI.backgroundColor = backgroundColor;
			bool flag2 = flag && onClick != null;
			if (flag2)
			{
				onClick();
			}
			currentY += GUIHelper.buttonHeight + GUIHelper.controlSpacing;
			return flag;
		}

		// Token: 0x04000054 RID: 84
		public static GUIStyle buttonStyle;

		// Token: 0x04000055 RID: 85
		public static GUIStyle labelStyle;

		// Token: 0x04000056 RID: 86
		public static GUIStyle textFieldStyle;

		// Token: 0x04000057 RID: 87
		private static float controlSpacing = 10f;

		// Token: 0x04000058 RID: 88
		private static float horizontalPadding = 10f;

		// Token: 0x04000059 RID: 89
		private static float verticalPadding = 10f;

		// Token: 0x0400005A RID: 90
		public static float buttonHeight = 30f;

		// Token: 0x0400005B RID: 91
		public static int cornerRadius = 8;
	}
}
