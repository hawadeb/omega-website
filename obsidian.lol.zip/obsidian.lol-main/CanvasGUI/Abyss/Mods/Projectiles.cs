﻿using System;
using System.Linq;
using System.Reflection;
using BepInEx;
using ExitGames.Client.Photon;
using HarmonyLib;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;

namespace Abyss.Mods
{
	// Token: 0x02000011 RID: 17
	public class Projectiles
	{
		// Token: 0x060000FC RID: 252 RVA: 0x0000C24C File Offset: 0x0000A44C
		public static void RPCProtection()
		{
			GorillaNot.instance.rpcErrorMax = int.MaxValue;
			GorillaNot.instance.rpcCallLimit = int.MaxValue;
			GorillaNot.instance.logErrorMax = int.MaxValue;
			PhotonNetwork.MaxResendsBeforeDisconnect = int.MaxValue;
			PhotonNetwork.QuickResends = int.MaxValue;
			PhotonNetwork.OpCleanActorRpcBuffer(PhotonNetwork.LocalPlayer.ActorNumber);
			PhotonNetwork.SendAllOutgoingCommands();
			GorillaNot.instance.OnPlayerLeftRoom(PhotonNetwork.LocalPlayer);
			PhotonNetwork.RemoveRPCs(PhotonNetwork.LocalPlayer);
			PhotonNetwork.RemoveRPCsInGroup(99999999);
			PhotonNetwork.RemoveBufferedRPCs(99999999, null, null);
		}

		// Token: 0x060000FD RID: 253 RVA: 0x0000C2F4 File Offset: 0x0000A4F4
		public static void LaunchSnowBallProjectile(string Path, string Name, Vector3 velocity, Vector3 position, Quaternion rotation, Color color, bool RGB)
		{
			bool flag = !Projectiles.ObjMade;
			if (flag)
			{
				Projectiles.gorillaVelocityEstimatorCustome = new GameObject("GorillaVelocityEstimator (J0kerMenu)");
				Projectiles.scriptedGorillaVelEst = Projectiles.gorillaVelocityEstimatorCustome.AddComponent<GorillaVelocityEstimator>();
				Projectiles.ObjMade = true;
			}
			SnowballThrowable component = GameObject.Find(Path + "/").transform.Find(Name).GetComponent<SnowballThrowable>();
			bool flag2 = !component.gameObject.activeSelf;
			if (flag2)
			{
				component.SetSnowballActiveLocal(true);
				if (RGB)
				{
					component.randomizeColor = true;
				}
				else
				{
					component.randomizeColor = false;
				}
				component.velocityEstimator = Projectiles.scriptedGorillaVelEst;
				component.transform.position = position;
				component.transform.rotation = rotation;
			}
			bool flag3 = Time.time > Projectiles.projectileDelay;
			if (flag3)
			{
				Projectiles.projectileDelay = Time.time + 0.1f;
				Rigidbody component2 = GorillaTagger.Instance.GetComponent<Rigidbody>();
				Vector3 velocity2 = component2.velocity;
				Vector3 position2 = component.transform.position;
				component2.velocity = velocity;
				GorillaTagger.Instance.offlineVRRig.SetThrowableProjectileColor(true, color);
				MethodInfo method = typeof(SnowballThrowable).GetMethod("PerformSnowballThrowAuthority", BindingFlags.Instance | BindingFlags.NonPublic);
				method.Invoke(component, null);
				component2.velocity = velocity2;
				component.transform.position = position2;
				Projectiles.RPCProtection();
			}
			bool flag4 = !ControllerInputPoller.instance.rightGrab || UnityInput.Current.GetKeyUp(KeyCode.G);
			if (flag4)
			{
				component.SetSnowballActiveLocal(false);
			}
		}

		// Token: 0x060000FE RID: 254 RVA: 0x0000C488 File Offset: 0x0000A688
		public static void LaunchGrowingSnowBallProjectile(string Path, string Name, Vector3 velocity, Vector3 position, Quaternion rotation, int Size, bool onGun, bool shouldFling)
		{
			bool flag = !Projectiles.ObjMade;
			if (flag)
			{
				Projectiles.gorillaVelocityEstimatorCustome = new GameObject("GorillaVelocityEstimator");
				Projectiles.scriptedGorillaVelEst = Projectiles.gorillaVelocityEstimatorCustome.AddComponent<GorillaVelocityEstimator>();
				Projectiles.ObjMade = true;
			}
			GrowingSnowballThrowable component = GameObject.Find(Path + "/").transform.Find(Name).GetComponent<GrowingSnowballThrowable>();
			bool flag2 = !component.gameObject.activeSelf;
			if (flag2)
			{
				component.SetSnowballActiveLocal(true);
				component.velocityEstimator = Projectiles.scriptedGorillaVelEst;
				component.transform.position = position;
				component.transform.rotation = rotation;
				component.transform.localRotation = rotation;
				component.IncreaseSize(5);
			}
			bool flag3 = Time.time > Projectiles.projectileDelay;
			if (flag3)
			{
				Projectiles.projectileDelay = Time.time + 0.1f;
				Rigidbody component2 = GorillaTagger.Instance.GetComponent<Rigidbody>();
				Vector3 velocity2 = component2.velocity;
				Vector3 position2 = component.transform.position;
				component2.velocity = velocity;
				GorillaTagger.Instance.offlineVRRig.SetThrowableProjectileColor(true, Color.white);
				MethodInfo method = typeof(GrowingSnowballThrowable).GetMethod("PerformSnowballThrowAuthority", BindingFlags.Instance | BindingFlags.NonPublic);
				method.Invoke(component, null);
				component2.velocity = velocity2;
				component.transform.position = position2;
				Projectiles.RPCProtection();
			}
			bool flag4 = !onGun;
			if (flag4)
			{
				bool flag5 = !ControllerInputPoller.instance.rightGrab || UnityInput.Current.GetKeyUp(KeyCode.G);
				if (flag5)
				{
					component.SetSnowballActiveLocal(false);
				}
			}
			if (shouldFling)
			{
				PhotonEvent value = Traverse.Create(component).Field("snowballThrowEvent").GetValue<PhotonEvent>();
				object[] array = new object[]
				{
					position,
					new Vector3(0f, -9999f, 0f),
					5f
				};
				value.RaiseOthers(array);
			}
		}

		// Token: 0x060000FF RID: 255 RVA: 0x0000C68C File Offset: 0x0000A88C
		public static void EnableAllProjs()
		{
			string[] array = new string[] { "Player Objects/Local VRRig/Local Gorilla Player/Holdables/GrowingSnowballRightAnchor(Clone)/LMACF. RIGHT.", "Player Objects/Local VRRig/Local Gorilla Player/Holdables/WaterBalloonRightAnchor(Clone)/LMAEY. RIGHT.", "Player Objects/Local VRRig/Local Gorilla Player/Holdables/TrickTreatFunctionalAnchorRIGHT Variant(Clone)/LMAMO. RIGHT.", "Player Objects/Local VRRig/Local Gorilla Player/Holdables/AppleRightAnchor(Clone)/LMAMV.", "Player Objects/Local VRRig/Local Gorilla Player/Holdables/ScienceCandyRightAnchor(Clone)/LMAIF. RIGHT.", "Player Objects/Local VRRig/Local Gorilla Player/Holdables/BucketGiftFunctionalAnchor_Right(Clone)/LMAHR. RIGHT.", "Player Objects/Local VRRig/Local Gorilla Player/Holdables/VotingRockAnchor_RIGHT(Clone)/LMAMT. RIGHT.", "Player Objects/Local VRRig/Local Gorilla Player/Holdables/FishFoodRightAnchor(Clone)/LMAIP. RIGHT." };
			string[] array2 = new string[] { "Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R/palm.01.R/TransferrableItemRightHand/GrowingSnowballRightAnchor(Clone)/LMACF. RIGHT.", "Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R/palm.01.R/TransferrableItemRightHand/WaterBalloonRightAnchor(Clone)/LMAEY. RIGHT.", "Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R/palm.01.R/TransferrableItemRightHand/TrickTreatFunctionalAnchorRIGHT Variant(Clone)/LMAMO. RIGHT.", "Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R/palm.01.R/TransferrableItemRightHand/AppleRightAnchor(Clone)/LMAMV.", "Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R/palm.01.R/TransferrableItemRightHand/ScienceCandyRightAnchor(Clone)/LMAIF. RIGHT.", "Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R/palm.01.R/TransferrableItemRightHand/BucketGiftFunctionalAnchor_Right(Clone)/LMAHR. RIGHT.", "Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R/palm.01.R/TransferrableItemRightHand/VotingRockAnchor_RIGHT(Clone)/LMAMT. RIGHT.", "Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R/palm.01.R/TransferrableItemRightHand/FishFoodRightAnchor(Clone)/LMAIP. RIGHT." };
			foreach (string text in array)
			{
				GameObject gameObject = GameObject.Find(text);
				bool flag = gameObject != null;
				if (flag)
				{
					gameObject.SetActive(true);
				}
			}
			foreach (string text2 in array2)
			{
				GameObject gameObject2 = GameObject.Find(text2);
				bool flag2 = gameObject2 != null;
				if (flag2)
				{
					gameObject2.SetActive(false);
				}
			}
			Projectiles.projModsEnabled = true;
		}

		// Token: 0x06000100 RID: 256 RVA: 0x0000C7A8 File Offset: 0x0000A9A8
		public static void SpawnHoldableThrowable(Vector3 pos, Vector3 vel, int type, string path, float delay)
		{
			bool flag = Time.time > delay;
			if (flag)
			{
				GorillaTagger.Instance.offlineVRRig.SetActiveTransferrableObjectIndex(1, type);
				GameObject gameObject = GorillaTagger.Instance.offlineVRRig.myBodyDockPositions.allObjects[type].gameObject;
				gameObject.SetActive(true);
				GorillaTagger.Instance.offlineVRRig.myBodyDockPositions.allObjects[type].storedZone = 2;
				GorillaTagger.Instance.offlineVRRig.myBodyDockPositions.allObjects[type].currentState = 2;
				object[] array = new object[]
				{
					pos,
					Quaternion.identity,
					vel,
					1f
				};
				RubberDuckEvents component = GameObject.Find(path).GetComponent<RubberDuckEvents>();
				int num = StaticHash.Compute(string.Format("{0}.{1}", component.PlayerId, "Activate"));
				object[] array2 = array.Prepend(num).ToArray<object>();
				PhotonNetwork.RaiseEvent(176, array2, new RaiseEventOptions
				{
					Receivers = ReceiverGroup.All
				}, SendOptions.SendReliable);
				delay = Time.time + 0.3f;
			}
		}

		// Token: 0x06000101 RID: 257 RVA: 0x0000C8D8 File Offset: 0x0000AAD8
		public static void BombSpam()
		{
			bool flag = ControllerInputPoller.instance.rightGrab || UnityInput.Current.GetMouseButton(1);
			if (flag)
			{
				Projectiles.SpawnHoldableThrowable(GorillaTagger.Instance.leftHandTransform.position, Vector3.zero, 600, "Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/shoulder.R/upper_arm.R/forearm.R/Right Arm Item Anchor/DropZoneAnchor/SmokeBomb_Anchor Variant(Clone)/LMAOM.", 0f);
			}
		}

		// Token: 0x06000102 RID: 258 RVA: 0x0000C934 File Offset: 0x0000AB34
		public static void FirecrackerSpam()
		{
			bool flag = ControllerInputPoller.instance.rightGrab || UnityInput.Current.GetMouseButton(1);
			if (flag)
			{
				Projectiles.SpawnHoldableThrowable(GorillaTagger.Instance.rightHandTransform.position, Vector3.zero, 587, "Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/shoulder.R/upper_arm.R/forearm.R/Right Arm Item Anchor/DropZoneAnchor/FireCrackersAnchor(Clone)/LMANZ.", 0f);
			}
		}

		// Token: 0x06000103 RID: 259 RVA: 0x0000C990 File Offset: 0x0000AB90
		public static void SnowBallGun()
		{
			bool flag = ControllerInputPoller.instance.rightControllerGripFloat > 0.1f || UnityInput.Current.GetKey(KeyCode.G);
			if (flag)
			{
				bool flag2 = Projectiles.projModsEnabled;
				if (flag2)
				{
					Vector3 vector = GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -20f;
					Vector3 position = GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position;
					Quaternion rotation = GorillaTagger.Instance.offlineVRRig.rightHandTransform.rotation;
					Projectiles.LaunchGrowingSnowBallProjectile("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R/palm.01.R/TransferrableItemRightHand/GrowingSnowballRightAnchor(Clone)", "LMACF. RIGHT.", vector, position, rotation, 999, false, false);
				}
				else
				{
					Projectiles.EnableAllProjs();
				}
			}
		}

		// Token: 0x06000104 RID: 260 RVA: 0x0000CA50 File Offset: 0x0000AC50
		public static void Bust()
		{
			bool flag = ControllerInputPoller.instance.rightControllerGripFloat > 0.499f || UnityInput.Current.GetKey(KeyCode.G);
			if (flag)
			{
				bool flag2 = Projectiles.projModsEnabled;
				if (flag2)
				{
					Vector3 vector = GorillaTagger.Instance.offlineVRRig.transform.forward.normalized * -20f;
					Vector3 vector2 = GorillaTagger.Instance.offlineVRRig.transform.position - new Vector3(0f, 0.3f, 0f);
					Quaternion rotation = GorillaTagger.Instance.offlineVRRig.rightHandTransform.rotation;
					Projectiles.LaunchGrowingSnowBallProjectile("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R/palm.01.R/TransferrableItemRightHand/GrowingSnowballRightAnchor(Clone)", "LMACF. RIGHT.", vector, vector2, rotation, 999, false, false);
				}
				else
				{
					Projectiles.EnableAllProjs();
				}
			}
		}

		// Token: 0x06000105 RID: 261 RVA: 0x0000CB28 File Offset: 0x0000AD28
		public static void Urine()
		{
			bool flag = ControllerInputPoller.instance.rightControllerGripFloat > 0.499f || UnityInput.Current.GetKey(KeyCode.G);
			if (flag)
			{
				bool flag2 = Projectiles.projModsEnabled;
				if (flag2)
				{
					Vector3 vector = GorillaTagger.Instance.offlineVRRig.transform.forward.normalized * -10f;
					Vector3 vector2 = GorillaTagger.Instance.offlineVRRig.transform.position - new Vector3(0f, 0.3f, 0f);
					Quaternion rotation = GorillaTagger.Instance.offlineVRRig.rightHandTransform.rotation;
					Projectiles.LaunchSnowBallProjectile("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R/palm.01.R/TransferrableItemRightHand/GrowingSnowballRightAnchor(Clone)", "LMACF. RIGHT.", vector, vector2, rotation, Color.yellow, false);
				}
				else
				{
					Projectiles.EnableAllProjs();
				}
			}
		}

		// Token: 0x06000106 RID: 262 RVA: 0x0000CC00 File Offset: 0x0000AE00
		public static void SnowBallSpam()
		{
			bool flag = ControllerInputPoller.instance.rightControllerGripFloat > 0.499f || UnityInput.Current.GetKey(KeyCode.G);
			if (flag)
			{
				bool flag2 = Projectiles.projModsEnabled;
				if (flag2)
				{
					Vector3 vector = -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * 0f;
					Vector3 position = GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position;
					Quaternion rotation = GorillaTagger.Instance.offlineVRRig.rightHandTransform.rotation;
					Projectiles.LaunchGrowingSnowBallProjectile("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R/palm.01.R/TransferrableItemRightHand/GrowingSnowballRightAnchor(Clone)", "LMACF. RIGHT.", vector, position, rotation, 999, false, false);
				}
				else
				{
					Projectiles.EnableAllProjs();
				}
			}
		}

		// Token: 0x06000107 RID: 263 RVA: 0x0000CCC4 File Offset: 0x0000AEC4
		public static void WaterBalloonGun()
		{
			bool flag = ControllerInputPoller.instance.rightControllerGripFloat > 0.1f || UnityInput.Current.GetKey(KeyCode.G);
			if (flag)
			{
				bool flag2 = Projectiles.projModsEnabled;
				if (flag2)
				{
					Vector3 vector = -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * 15.33f;
					Vector3 position = GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position;
					Quaternion rotation = GorillaTagger.Instance.offlineVRRig.rightHandTransform.rotation;
					Projectiles.LaunchSnowBallProjectile("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R/palm.01.R/TransferrableItemRightHand/WaterBalloonRightAnchor(Clone)", "LMAEY. RIGHT.", vector, position, rotation, Color.white, true);
				}
				else
				{
					Projectiles.EnableAllProjs();
				}
			}
		}

		// Token: 0x06000108 RID: 264 RVA: 0x0000CD88 File Offset: 0x0000AF88
		public static void WaterBalloonSpam()
		{
			bool flag = ControllerInputPoller.instance.rightControllerGripFloat > 0.1f || UnityInput.Current.GetKey(KeyCode.G);
			if (flag)
			{
				bool flag2 = Projectiles.projModsEnabled;
				if (flag2)
				{
					Vector3 vector = -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * 0f;
					Vector3 position = GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position;
					Quaternion rotation = GorillaTagger.Instance.offlineVRRig.rightHandTransform.rotation;
					Projectiles.LaunchSnowBallProjectile("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R/palm.01.R/TransferrableItemRightHand/WaterBalloonRightAnchor(Clone)", "LMAEY. RIGHT.", vector, position, rotation, Color.white, true);
				}
				else
				{
					Projectiles.EnableAllProjs();
				}
			}
		}

		// Token: 0x06000109 RID: 265 RVA: 0x0000CE4C File Offset: 0x0000B04C
		public static void LavaRockGun()
		{
			bool flag = ControllerInputPoller.instance.rightControllerGripFloat > 0.1f || UnityInput.Current.GetKey(KeyCode.G);
			if (flag)
			{
				bool flag2 = Projectiles.projModsEnabled;
				if (flag2)
				{
					Vector3 vector = -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * 15.33f;
					Vector3 position = GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position;
					Quaternion rotation = GorillaTagger.Instance.offlineVRRig.rightHandTransform.rotation;
					Projectiles.LaunchSnowBallProjectile("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R/palm.01.R/TransferrableItemRightHand/LavaRockAnchor(Clone)", "LMAGE. RIGHT.", vector, position, rotation, Color.white, true);
				}
				else
				{
					Projectiles.EnableAllProjs();
				}
			}
		}

		// Token: 0x0600010A RID: 266 RVA: 0x0000CF10 File Offset: 0x0000B110
		public static void VoteRockGun()
		{
			bool flag = ControllerInputPoller.instance.rightControllerGripFloat > 0.1f || UnityInput.Current.GetKey(KeyCode.G);
			if (flag)
			{
				bool flag2 = Projectiles.projModsEnabled;
				if (flag2)
				{
					Vector3 vector = -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * 15.33f;
					Vector3 position = GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position;
					Quaternion rotation = GorillaTagger.Instance.offlineVRRig.rightHandTransform.rotation;
					Projectiles.LaunchSnowBallProjectile("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R/palm.01.R/TransferrableItemRightHand/VotingRockAnchor_RIGHT(Clone)", "LMAMT. RIGHT.", vector, position, rotation, Color.white, true);
				}
				else
				{
					Projectiles.EnableAllProjs();
				}
			}
		}

		// Token: 0x0600010B RID: 267 RVA: 0x0000CFD4 File Offset: 0x0000B1D4
		public static void VoteRockSpam()
		{
			bool flag = ControllerInputPoller.instance.rightControllerGripFloat > 0.1f || UnityInput.Current.GetKey(KeyCode.G);
			if (flag)
			{
				bool flag2 = Projectiles.projModsEnabled;
				if (flag2)
				{
					Vector3 vector = -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * 0f;
					Vector3 position = GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position;
					Quaternion rotation = GorillaTagger.Instance.offlineVRRig.rightHandTransform.rotation;
					Projectiles.LaunchSnowBallProjectile("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R/palm.01.R/TransferrableItemRightHand/VotingRockAnchor_RIGHT(Clone)", "LMAMT. RIGHT.", vector, position, rotation, Color.white, true);
				}
				else
				{
					Projectiles.EnableAllProjs();
				}
			}
		}

		// Token: 0x0600010C RID: 268 RVA: 0x0000D098 File Offset: 0x0000B298
		public static void HalloweenCandyGun()
		{
			bool flag = ControllerInputPoller.instance.rightControllerGripFloat > 0.1f || UnityInput.Current.GetKey(KeyCode.G);
			if (flag)
			{
				bool flag2 = Projectiles.projModsEnabled;
				if (flag2)
				{
					Vector3 vector = -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * 15.33f;
					Vector3 position = GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position;
					Quaternion rotation = GorillaTagger.Instance.offlineVRRig.rightHandTransform.rotation;
					Projectiles.LaunchSnowBallProjectile("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R/palm.01.R/TransferrableItemRightHand/TrickTreatFunctionalAnchorRIGHT Variant(Clone)", "LMAMO. RIGHT.", vector, position, rotation, Color.white, false);
				}
				else
				{
					Projectiles.EnableAllProjs();
				}
			}
		}

		// Token: 0x0600010D RID: 269 RVA: 0x0000D15C File Offset: 0x0000B35C
		public static void HalloweenCandySpam()
		{
			bool flag = ControllerInputPoller.instance.rightControllerGripFloat > 0.1f || UnityInput.Current.GetKey(KeyCode.G);
			if (flag)
			{
				bool flag2 = Projectiles.projModsEnabled;
				if (flag2)
				{
					Vector3 vector = -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * 0f;
					Vector3 position = GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position;
					Quaternion rotation = GorillaTagger.Instance.offlineVRRig.rightHandTransform.rotation;
					Projectiles.LaunchSnowBallProjectile("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R/palm.01.R/TransferrableItemRightHand/TrickTreatFunctionalAnchorRIGHT Variant(Clone)", "LMAMO. RIGHT.", vector, position, rotation, Color.white, false);
				}
				else
				{
					Projectiles.EnableAllProjs();
				}
			}
		}

		// Token: 0x0600010E RID: 270 RVA: 0x0000D220 File Offset: 0x0000B420
		public static void AppleGun()
		{
			bool flag = ControllerInputPoller.instance.rightControllerGripFloat > 0.1f || UnityInput.Current.GetKey(KeyCode.G);
			if (flag)
			{
				bool flag2 = Projectiles.projModsEnabled;
				if (flag2)
				{
					Vector3 vector = -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * 15.33f;
					Vector3 position = GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position;
					Quaternion rotation = GorillaTagger.Instance.offlineVRRig.rightHandTransform.rotation;
					Projectiles.LaunchSnowBallProjectile("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R/palm.01.R/TransferrableItemRightHand/AppleRightAnchor(Clone)", "LMAMV.", vector, position, rotation, Color.white, true);
				}
				else
				{
					Projectiles.EnableAllProjs();
				}
			}
		}

		// Token: 0x0600010F RID: 271 RVA: 0x0000D2E4 File Offset: 0x0000B4E4
		public static void AppleSpam()
		{
			bool flag = ControllerInputPoller.instance.rightControllerGripFloat > 0.1f || UnityInput.Current.GetKey(KeyCode.G);
			if (flag)
			{
				bool flag2 = Projectiles.projModsEnabled;
				if (flag2)
				{
					Vector3 vector = -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * 0f;
					Vector3 position = GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position;
					Quaternion rotation = GorillaTagger.Instance.offlineVRRig.rightHandTransform.rotation;
					Projectiles.LaunchSnowBallProjectile("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R/palm.01.R/TransferrableItemRightHand/AppleRightAnchor(Clone)", "LMAMV.", vector, position, rotation, Color.white, true);
				}
				else
				{
					Projectiles.EnableAllProjs();
				}
			}
		}

		// Token: 0x06000110 RID: 272 RVA: 0x0000D3A8 File Offset: 0x0000B5A8
		public static void MentoGun()
		{
			bool flag = ControllerInputPoller.instance.rightControllerGripFloat > 0.1f || UnityInput.Current.GetKey(KeyCode.G);
			if (flag)
			{
				bool flag2 = Projectiles.projModsEnabled;
				if (flag2)
				{
					Vector3 vector = -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * 15.33f;
					Vector3 position = GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position;
					Quaternion rotation = GorillaTagger.Instance.offlineVRRig.rightHandTransform.rotation;
					Projectiles.LaunchSnowBallProjectile("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R/palm.01.R/TransferrableItemRightHand/ScienceCandyRightAnchor(Clone)", "LMAIF. RIGHT.", vector, position, rotation, Color.white, true);
				}
				else
				{
					Projectiles.EnableAllProjs();
				}
			}
		}

		// Token: 0x06000111 RID: 273 RVA: 0x0000D46C File Offset: 0x0000B66C
		public static void MentoSpam()
		{
			bool flag = ControllerInputPoller.instance.rightControllerGripFloat > 0.1f || UnityInput.Current.GetKey(KeyCode.G);
			if (flag)
			{
				bool flag2 = Projectiles.projModsEnabled;
				if (flag2)
				{
					Vector3 vector = -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * 0f;
					Vector3 position = GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position;
					Quaternion rotation = GorillaTagger.Instance.offlineVRRig.rightHandTransform.rotation;
					Projectiles.LaunchSnowBallProjectile("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R/palm.01.R/TransferrableItemRightHand/ScienceCandyRightAnchor(Clone)", "LMAIF. RIGHT.", vector, position, rotation, Color.white, true);
				}
				else
				{
					Projectiles.EnableAllProjs();
				}
			}
		}

		// Token: 0x06000112 RID: 274 RVA: 0x0000D530 File Offset: 0x0000B730
		public static void GiftGun()
		{
			bool flag = ControllerInputPoller.instance.rightControllerGripFloat > 0.1f || UnityInput.Current.GetKey(KeyCode.G);
			if (flag)
			{
				bool flag2 = Projectiles.projModsEnabled;
				if (flag2)
				{
					Vector3 vector = -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * 15.33f;
					Vector3 position = GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position;
					Quaternion rotation = GorillaTagger.Instance.offlineVRRig.rightHandTransform.rotation;
					Projectiles.LaunchSnowBallProjectile("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R/palm.01.R/TransferrableItemRightHand/BucketGiftFunctionalAnchor_Right(Clone)", "LMAHR. RIGHT.", vector, position, rotation, Color.white, true);
				}
				else
				{
					Projectiles.EnableAllProjs();
				}
			}
		}

		// Token: 0x06000113 RID: 275 RVA: 0x0000D5F4 File Offset: 0x0000B7F4
		public static void GiftSpam()
		{
			bool flag = ControllerInputPoller.instance.rightControllerGripFloat > 0.1f || UnityInput.Current.GetKey(KeyCode.G);
			if (flag)
			{
				bool flag2 = Projectiles.projModsEnabled;
				if (flag2)
				{
					Vector3 vector = -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * 0f;
					Vector3 position = GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position;
					Quaternion rotation = GorillaTagger.Instance.offlineVRRig.rightHandTransform.rotation;
					Projectiles.LaunchSnowBallProjectile("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R/palm.01.R/TransferrableItemRightHand/BucketGiftFunctionalAnchor_Right(Clone)", "LMAHR. RIGHT.", vector, position, rotation, Color.white, true);
				}
				else
				{
					Projectiles.EnableAllProjs();
				}
			}
		}

		// Token: 0x06000114 RID: 276 RVA: 0x0000D6B8 File Offset: 0x0000B8B8
		public static void FishFoodGun()
		{
			bool flag = ControllerInputPoller.instance.rightControllerGripFloat > 0.1f || UnityInput.Current.GetKey(KeyCode.G);
			if (flag)
			{
				bool flag2 = Projectiles.projModsEnabled;
				if (flag2)
				{
					Vector3 vector = -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * 15.33f;
					Vector3 position = GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position;
					Quaternion rotation = GorillaTagger.Instance.offlineVRRig.rightHandTransform.rotation;
					Projectiles.LaunchSnowBallProjectile("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R/palm.01.R/TransferrableItemRightHand/FishFoodRightAnchor(Clone)", "LMAIP. RIGHT.", vector, position, rotation, Color.white, true);
				}
				else
				{
					Projectiles.EnableAllProjs();
				}
			}
		}

		// Token: 0x06000115 RID: 277 RVA: 0x0000D77C File Offset: 0x0000B97C
		public static void Feces()
		{
			bool flag = ControllerInputPoller.instance.rightControllerGripFloat > 0.1f || UnityInput.Current.GetKey(KeyCode.G);
			if (flag)
			{
				bool flag2 = Projectiles.projModsEnabled;
				if (flag2)
				{
					Vector3 zero = Vector3.zero;
					Vector3 position = GorillaTagger.Instance.offlineVRRig.transform.position;
					Quaternion identity = Quaternion.identity;
					Projectiles.LaunchSnowBallProjectile("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R/palm.01.R/TransferrableItemRightHand/FishFoodRightAnchor(Clone)", "LMAIP. RIGHT.", zero, position, identity, Color.HSVToRGB(101f, 67f, 33f), false);
				}
				else
				{
					Projectiles.EnableAllProjs();
				}
			}
		}

		// Token: 0x06000116 RID: 278 RVA: 0x0000D814 File Offset: 0x0000BA14
		public static void FishFoodSpam()
		{
			bool flag = ControllerInputPoller.instance.rightControllerGripFloat > 0.1f || UnityInput.Current.GetKey(KeyCode.G);
			if (flag)
			{
				bool flag2 = Projectiles.projModsEnabled;
				if (flag2)
				{
					Vector3 vector = -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * 0f;
					Vector3 position = GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position;
					Quaternion rotation = GorillaTagger.Instance.offlineVRRig.rightHandTransform.rotation;
					Projectiles.LaunchSnowBallProjectile("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R/palm.01.R/TransferrableItemRightHand/FishFoodRightAnchor(Clone)", "LMAIP. RIGHT.", vector, position, rotation, Color.white, true);
				}
				else
				{
					Projectiles.EnableAllProjs();
				}
			}
		}

		// Token: 0x06000117 RID: 279 RVA: 0x0000D8D5 File Offset: 0x0000BAD5
		public static void BigSnowBalls()
		{
			Projectiles.changeSnowBall = (Projectiles.changeSnowBall + 1) % 6;
		}

		// Token: 0x04000097 RID: 151
		private static GameObject gorillaVelocityEstimatorCustome;

		// Token: 0x04000098 RID: 152
		private static GorillaVelocityEstimator scriptedGorillaVelEst;

		// Token: 0x04000099 RID: 153
		private PhotonEvent snowballThrowEvent;

		// Token: 0x0400009A RID: 154
		private static bool ObjMade;

		// Token: 0x0400009B RID: 155
		private static float projectileDelay;

		// Token: 0x0400009C RID: 156
		public static bool projModsEnabled;

		// Token: 0x0400009D RID: 157
		private static int changeSnowBall;
	}
}
