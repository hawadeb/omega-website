﻿using System;
using UnityEngine;

namespace Abyss.Mods
{
	// Token: 0x02000015 RID: 21
	public class eoc : MonoBehaviour
	{
		// Token: 0x06000139 RID: 313 RVA: 0x0000EFD4 File Offset: 0x0000D1D4
		public void Update()
		{
			base.gameObject.GetComponent<Renderer>().material.color = Color.red;
		}

		// Token: 0x0600013A RID: 314 RVA: 0x0000EFF4 File Offset: 0x0000D1F4
		private void OnCollisionEnter(Collision collision)
		{
			ParticleSystem particleSystem = this.CreateExplosionEffect();
			particleSystem.transform.position = base.transform.position;
			particleSystem.Play();
			global::UnityEngine.Object.Destroy(base.gameObject);
			global::UnityEngine.Object.Destroy(particleSystem.gameObject, particleSystem.main.duration);
		}

		// Token: 0x0600013B RID: 315 RVA: 0x0000F050 File Offset: 0x0000D250
		private ParticleSystem CreateExplosionEffect()
		{
			GameObject gameObject = new GameObject("Explosion");
			ParticleSystem particleSystem = gameObject.AddComponent<ParticleSystem>();
			ParticleSystem.MainModule main = particleSystem.main;
			main.startSize = new ParticleSystem.MinMaxCurve(0.4f * Visuals.size, 1f * Visuals.size);
			main.startLifetime = new ParticleSystem.MinMaxCurve(0.3f * Visuals.size, 0.6f * Visuals.size);
			main.startSpeed = new ParticleSystem.MinMaxCurve(1f * Visuals.size, 3f * Visuals.size);
			main.startColor = new ParticleSystem.MinMaxGradient(Color.red, Color.gray);
			main.simulationSpace = 1;
			main.gravityModifier = -0.05f;
			main.loop = false;
			ParticleSystem.EmissionModule emission = particleSystem.emission;
			emission.rateOverTime = 0f;
			emission.SetBursts(new ParticleSystem.Burst[]
			{
				new ParticleSystem.Burst(0f, 80f * Visuals.size)
			});
			ParticleSystem.ShapeModule shape = particleSystem.shape;
			shape.shapeType = 0;
			shape.radius = 0.2f * Visuals.size;
			ParticleSystemRenderer component = particleSystem.GetComponent<ParticleSystemRenderer>();
			component.material = new Material(Shader.Find("Particles/Standard Unlit"));
			GameObject gameObject2 = new GameObject("Shockwave");
			ParticleSystem particleSystem2 = gameObject2.AddComponent<ParticleSystem>();
			ParticleSystem.MainModule main2 = particleSystem2.main;
			main2.startSize = new ParticleSystem.MinMaxCurve(0.3f, 2f);
			main2.startLifetime = 0.3f * Visuals.size;
			main2.startSpeed = 0f;
			main2.startColor = new Color(1f, 1f, 1f, 0.4f);
			main2.loop = false;
			ParticleSystem.EmissionModule emission2 = particleSystem2.emission;
			emission2.rateOverTime = 0f;
			emission2.SetBursts(new ParticleSystem.Burst[]
			{
				new ParticleSystem.Burst(0f, 1f * Visuals.size)
			});
			ParticleSystem.ShapeModule shape2 = particleSystem2.shape;
			shape2.shapeType = 17;
			shape2.radius = 0.4f * Visuals.size;
			ParticleSystemRenderer component2 = particleSystem2.GetComponent<ParticleSystemRenderer>();
			component2.material = new Material(Shader.Find("Particles/Standard Unlit"));
			GameObject gameObject3 = new GameObject("Sparks");
			ParticleSystem particleSystem3 = gameObject3.AddComponent<ParticleSystem>();
			ParticleSystem.MainModule main3 = particleSystem3.main;
			main3.startSize = new ParticleSystem.MinMaxCurve(0.05f * Visuals.size, 0.2f * Visuals.size);
			main3.startLifetime = new ParticleSystem.MinMaxCurve(0.2f * Visuals.size, 0.5f * Visuals.size);
			main3.startSpeed = new ParticleSystem.MinMaxCurve(2f * Visuals.size, 4f * Visuals.size);
			main3.startColor = Color.red;
			main3.loop = false;
			ParticleSystem.EmissionModule emission3 = particleSystem3.emission;
			emission3.rateOverTime = 0f;
			emission3.SetBursts(new ParticleSystem.Burst[]
			{
				new ParticleSystem.Burst(0f, 100f * Visuals.size)
			});
			ParticleSystem.ShapeModule shape3 = particleSystem3.shape;
			shape3.shapeType = 0;
			shape3.radius = 0.1f;
			ParticleSystemRenderer component3 = particleSystem3.GetComponent<ParticleSystemRenderer>();
			component3.material = new Material(Shader.Find("Particles/Standard Unlit"));
			GameObject gameObject4 = new GameObject("ExplosionLight");
			Light light = gameObject4.AddComponent<Light>();
			light.intensity = 4f * Visuals.size;
			light.range = 3f * Visuals.size;
			light.color = Color.red;
			particleSystem.Play();
			particleSystem2.Play();
			particleSystem3.Play();
			global::UnityEngine.Object.Destroy(gameObject, 3f);
			global::UnityEngine.Object.Destroy(gameObject2, 0.5f);
			global::UnityEngine.Object.Destroy(gameObject3, 0.5f);
			global::UnityEngine.Object.Destroy(gameObject4, 0.2f);
			return particleSystem;
		}
	}
}
