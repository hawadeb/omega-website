﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using BepInEx;
using CanvasGUI.Components;
using CanvasGUI.Libraries;
using CanvasGUI.Management;
using GorillaLocomotion;
using Photon.Pun;
using UnityEngine;

namespace Abyss.Mods
{
	// Token: 0x0200000F RID: 15
	public class Move : MonoBehaviourPunCallbacks
	{
		// Token: 0x1700001E RID: 30
		// (get) Token: 0x0600009E RID: 158 RVA: 0x000080FF File Offset: 0x000062FF
		public static bool RightPrimary
		{
			get
			{
				return ControllerInputPoller.instance.rightControllerPrimaryButton;
			}
		}

		// Token: 0x0600009F RID: 159 RVA: 0x00008110 File Offset: 0x00006310
		public static void Body()
		{
			try
			{
				bool flag = !GorillaTagger.Instance.offlineVRRig.enabled;
				if (flag)
				{
					Move.player = GTPlayer.Instance;
					bool flag2 = Move.GhostRig == null;
					if (flag2)
					{
						VRRig offlineVRRig = GorillaTagger.Instance.offlineVRRig;
						offlineVRRig.enabled = false;
						Move.GhostRig = global::UnityEngine.Object.Instantiate<VRRig>(GorillaTagger.Instance.offlineVRRig, GTPlayer.Instance.transform.position, GTPlayer.Instance.transform.rotation);
						Move.GhostRig.headConstraint.transform.SetPositionAndRotation(Move.player.headCollider.transform.position, Move.player.headCollider.transform.rotation);
						Move.GhostRig.leftHandTransform.SetPositionAndRotation(Move.player.leftControllerTransform.position, Move.player.leftControllerTransform.rotation);
						Move.GhostRig.rightHandTransform.SetPositionAndRotation(Move.player.rightControllerTransform.position, Move.player.rightControllerTransform.rotation);
						Move.GhostRig.name = "GT";
						Move.GhostRig.headBodyOffset = Vector3.zero;
						Move.GhostRig.enabled = true;
						Move.GhostRig.transform.Find("VR Constraints/LeftArm/Left Arm IK/SlideAudio").gameObject.SetActive(false);
						Move.GhostRig.transform.Find("VR Constraints/RightArm/Right Arm IK/SlideAudio").gameObject.SetActive(false);
						bool flag3 = (Move.delays.ContainsKey(Move.GhostRig) && Time.time > Move.delays[Move.GhostRig]) || !Move.delays.ContainsKey(Move.GhostRig);
						if (flag3)
						{
							bool flag4 = Move.delays.ContainsKey(Move.GhostRig);
							if (flag4)
							{
								Move.delays[Move.GhostRig] = Time.time + 5f;
							}
							else
							{
								Move.delays.Add(Move.GhostRig, Time.time + 5f);
							}
							Move.GhostRig.mainSkin.sharedMesh.colors32 = Enumerable.Repeat<Color32>(Color.Lerp(Settings.col2, Settings.col1, Mathf.PingPong(Time.time, 1f)), Move.GhostRig.mainSkin.sharedMesh.colors32.Length).ToArray<Color32>();
							Move.GhostRig.mainSkin.sharedMesh.colors = Enumerable.Repeat<Color>(Color.Lerp(Settings.col2, Settings.col1, Mathf.PingPong(Time.time, 1f)), Move.GhostRig.mainSkin.sharedMesh.colors.Length).ToArray<Color>();
						}
					}
					Move.mat = new Material(Shader.Find("GUI/Text Shader"));
					Move.GhostRig.mainSkin.sharedMesh.colors32 = Enumerable.Repeat<Color32>(Color.Lerp(Settings.col2, Settings.col1, Mathf.PingPong(Time.time, 1f)), Move.GhostRig.mainSkin.sharedMesh.colors32.Length).ToArray<Color32>();
					Move.GhostRig.mainSkin.sharedMesh.colors = Enumerable.Repeat<Color>(Color.Lerp(Settings.col2, Settings.col1, Mathf.PingPong(Time.time, 1f)), Move.GhostRig.mainSkin.sharedMesh.colors.Length).ToArray<Color>();
					Move.ghostColor = Color.Lerp(Settings.col2, Settings.col1, Mathf.PingPong(Time.time, 1f));
					Move.ghostColor.a = 0.1f;
					Move.mat.color = Move.ghostColor;
					Move.GhostRig.mainSkin.material = Move.mat;
					Move.GhostRig.headConstraint.transform.SetPositionAndRotation(Move.player.headCollider.transform.position, Move.player.headCollider.transform.rotation);
					Move.GhostRig.leftHandTransform.SetPositionAndRotation(Move.player.leftControllerTransform.position, Move.player.leftControllerTransform.rotation);
					Move.GhostRig.rightHandTransform.SetPositionAndRotation(Move.player.rightControllerTransform.position, Move.player.rightControllerTransform.rotation);
					Move.GhostRig.transform.SetPositionAndRotation(Move.player.transform.position, Move.player.transform.rotation);
				}
				else
				{
					bool flag5 = Move.GhostRig != null;
					if (flag5)
					{
						global::UnityEngine.Object.Destroy(Move.GhostRig.gameObject);
						Move.player = null;
						Move.GhostRig = null;
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x060000A0 RID: 160 RVA: 0x00008614 File Offset: 0x00006814
		public static void Ghost()
		{
			bool rightPrimary = Move.RightPrimary;
			if (rightPrimary)
			{
				bool flag = !Move.ghostToggled && GorillaTagger.Instance.offlineVRRig.enabled;
				if (flag)
				{
					GorillaTagger.Instance.offlineVRRig.enabled = false;
					Move.ghostToggled = true;
				}
				else
				{
					bool flag2 = !Move.ghostToggled && !GorillaTagger.Instance.offlineVRRig.enabled;
					if (flag2)
					{
						GorillaTagger.Instance.offlineVRRig.enabled = true;
						Move.ghostToggled = true;
					}
				}
			}
			else
			{
				Move.ghostToggled = false;
			}
		}

		// Token: 0x060000A1 RID: 161 RVA: 0x000086AC File Offset: 0x000068AC
		public static void Invis()
		{
			bool rightPrimary = Move.RightPrimary;
			if (rightPrimary)
			{
				bool flag = Move.canToggle;
				if (flag)
				{
					bool flag2 = !Move.ghostToggled && GorillaTagger.Instance.offlineVRRig.enabled;
					if (flag2)
					{
						GorillaTagger.Instance.offlineVRRig.enabled = false;
						GorillaTagger.Instance.offlineVRRig.transform.position = Vector3.zero;
						Move.canToggle = false;
					}
					else
					{
						bool flag3 = !Move.ghostToggled && !GorillaTagger.Instance.offlineVRRig.enabled;
						if (flag3)
						{
							GorillaTagger.Instance.offlineVRRig.enabled = true;
							Move.canToggle = false;
						}
					}
				}
			}
			else
			{
				Move.ghostToggled = false;
				Move.canToggle = true;
			}
		}

		// Token: 0x060000A2 RID: 162 RVA: 0x00008774 File Offset: 0x00006974
		public static void SEtMeshColliders(bool isNocliping)
		{
			foreach (MeshCollider meshCollider in Resources.FindObjectsOfTypeAll<MeshCollider>())
			{
				meshCollider.enabled = isNocliping;
			}
		}

		// Token: 0x060000A3 RID: 163 RVA: 0x000087A5 File Offset: 0x000069A5
		public static IEnumerator TimeWait(float time)
		{
			yield return new WaitForSeconds(time);
			yield break;
		}

		// Token: 0x060000A4 RID: 164 RVA: 0x000087B4 File Offset: 0x000069B4
		public static void TpHELPER(Vector3 b)
		{
			bool flag = GTPlayer.Instance.transform.position == b;
			if (flag)
			{
				Move.isAtPos = true;
			}
			else
			{
				Move.isAtPos = false;
				GTPlayer.Instance.transform.position = b;
			}
		}

		// Token: 0x060000A5 RID: 165 RVA: 0x00008800 File Offset: 0x00006A00
		public static void TPGun()
		{
			GunLib.Waver waver = GunLib.nolockshoot();
			bool flag = waver != null;
			if (flag)
			{
				bool flag2 = waver.triggered && waver.shooting;
				if (flag2)
				{
					bool flag3 = Move.canTp;
					if (flag3)
					{
						foreach (MeshCollider meshCollider in Resources.FindObjectsOfTypeAll<MeshCollider>())
						{
							meshCollider.enabled = false;
							GTPlayer.Instance.transform.position = waver.pointerPos;
							new WaitForSeconds(1f);
							meshCollider.enabled = true;
						}
						Move.TpHELPER(waver.pointerPos);
						GTPlayer.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
						Move.canTp = false;
					}
				}
				else
				{
					Move.canTp = true;
				}
			}
		}

		// Token: 0x060000A6 RID: 166 RVA: 0x000088D4 File Offset: 0x00006AD4
		public static void AirStrikeGun()
		{
			GunLib.Waver waver = GunLib.nolockshoot();
			bool flag = waver != null;
			if (flag)
			{
				bool flag2 = waver.triggered && waver.shooting;
				if (flag2)
				{
					bool flag3 = Move.canTp;
					if (flag3)
					{
						foreach (MeshCollider meshCollider in Resources.FindObjectsOfTypeAll<MeshCollider>())
						{
							meshCollider.enabled = false;
							GTPlayer.Instance.transform.position = waver.pointerPos + new Vector3(0f, 1000f, 0f);
							new WaitForSeconds(0.01f);
							meshCollider.enabled = true;
						}
						GTPlayer.Instance.GetComponent<Rigidbody>().velocity = new Vector3(0f, -250f, 0f);
						Move.canTp = false;
					}
				}
				else
				{
					Move.canTp = true;
				}
			}
		}

		// Token: 0x060000A7 RID: 167 RVA: 0x000089C4 File Offset: 0x00006BC4
		public static void PunchMod()
		{
			foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
			{
				bool flag = !vrrig.isOfflineVRRig;
				if (flag)
				{
					GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Sphere);
					GameObject gameObject2 = GameObject.CreatePrimitive(PrimitiveType.Sphere);
					global::UnityEngine.Object.Destroy(gameObject.GetComponent<SphereCollider>());
					global::UnityEngine.Object.Destroy(gameObject2.GetComponent<SphereCollider>());
					gameObject.transform.localScale = new Vector3(0.25f, 0.25f, 0.25f);
					gameObject2.transform.localScale = new Vector3(0.25f, 0.25f, 0.25f);
					gameObject.transform.position = vrrig.leftHandTransform.position;
					gameObject2.transform.position = vrrig.rightHandTransform.position;
					gameObject.GetComponent<Renderer>().material = null;
					gameObject2.GetComponent<Renderer>().material = null;
					foreach (VRRig vrrig2 in GorillaParent.instance.vrrigs)
					{
						bool flag2 = vrrig2 != GorillaTagger.Instance.offlineVRRig && (Vector3.Distance(GorillaTagger.Instance.leftHandTransform.position, vrrig2.headMesh.transform.position) < 0.25f || Vector3.Distance(GorillaTagger.Instance.rightHandTransform.position, vrrig2.headMesh.transform.position) < 0.25f);
						if (flag2)
						{
							GTPlayer.Instance.GetComponent<Rigidbody>().velocity += Vector3.Normalize(vrrig.rightHandTransform.position - Vector3.zero) * 4f;
						}
					}
					global::UnityEngine.Object.Destroy(gameObject, Time.deltaTime);
					global::UnityEngine.Object.Destroy(gameObject2, Time.deltaTime);
				}
			}
		}

		// Token: 0x060000A8 RID: 168 RVA: 0x00008C24 File Offset: 0x00006E24
		public static void SpazSelf()
		{
			GorillaTagger.Instance.offlineVRRig.headBodyOffset.x = 180f;
			GorillaTagger.Instance.offlineVRRig.headBodyOffset.x = 0f;
		}

		// Token: 0x060000A9 RID: 169 RVA: 0x00008C5C File Offset: 0x00006E5C
		public static void PlatformsMod()
		{
			bool flag = ControllerInputPoller.instance.leftGrab && Move.leftplat == null;
			if (flag)
			{
				Move.leftplat = Move.CreatePlatformOnHand(GorillaTagger.Instance.leftHandTransform);
			}
			bool flag2 = ControllerInputPoller.instance.rightGrab && Move.rightplat == null;
			if (flag2)
			{
				Move.rightplat = Move.CreatePlatformOnHand(GorillaTagger.Instance.rightHandTransform);
			}
			bool flag3 = ControllerInputPoller.instance.rightGrabRelease && Move.rightplat != null;
			if (flag3)
			{
				Utils.Disable(Move.rightplat);
				Move.rightplat = null;
			}
			bool flag4 = ControllerInputPoller.instance.leftGrabRelease && Move.leftplat != null;
			if (flag4)
			{
				Utils.Disable(Move.leftplat);
				Move.leftplat = null;
			}
		}

		// Token: 0x060000AA RID: 170 RVA: 0x00008D3C File Offset: 0x00006F3C
		public static GameObject CreatePlatformOnHand(Transform handTransform)
		{
			GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
			gameObject.transform.localScale = new Vector3(0.025f, 0.3f, 0.4f);
			gameObject.transform.position = handTransform.position;
			gameObject.transform.rotation = handTransform.rotation;
			gameObject.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
			gameObject.GetComponent<Renderer>().material.color = new Color(Settings.theme.r, Settings.theme.g, Settings.theme.b, 0.25f);
			float num = (float)Time.frameCount / 180f % 1f;
			return gameObject;
		}

		// Token: 0x060000AB RID: 171 RVA: 0x00008E04 File Offset: 0x00007004
		public static void rty()
		{
			float num = global::UnityEngine.Random.Range(0f, 40f);
			float num2 = global::UnityEngine.Random.Range(0.8f, 1f);
			float num3 = global::UnityEngine.Random.Range(0.7f, 1f);
			Move.col = Color.HSVToRGB(num / 360f, num2, num3);
		}

		// Token: 0x060000AC RID: 172 RVA: 0x00008E58 File Offset: 0x00007058
		public static void FlySpeedChanger()
		{
			CanvasGUI.Management.Module module = null;
			Action <>9__33_;
			if ((<>9__33_ = Move.<>c.<>9__33_0) == null)
			{
				Move.<>c.<>9__33_0 = delegate
				{
					Move.ChangewallwalkStrength();
				};
			}
			foreach (Category category in Menu.categories)
			{
				foreach (CanvasGUI.Management.Module module2 in category.buttons)
				{
					bool flag = module2.title == "Fly Speed: " + Move.wallwalkStrengthCur;
					if (flag)
					{
						module = module2;
					}
				}
			}
			bool flag2 = Move.FlyCurrently == "Slow";
			if (flag2)
			{
				Move.wallwalkStrengthCur = "Medium";
				Move.wallwalkStrength = 1.01f;
			}
			else
			{
				bool flag3 = Move.FlyCurrently == "Medium";
				if (flag3)
				{
					Move.wallwalkStrengthCur = "Fast";
					Move.wallwalkStrength = 2f;
				}
				else
				{
					bool flag4 = Move.FlyCurrently == "Fast";
					if (flag4)
					{
						Move.wallwalkStrengthCur = "Blazing";
						Move.wallwalkStrength = 5f;
					}
					else
					{
						bool flag5 = Move.FlyCurrently == "Blazing";
						if (flag5)
						{
							Move.wallwalkStrengthCur = "Slow";
							Move.wallwalkStrength = 0.5f;
						}
					}
				}
			}
			module.title = "Fly Speed: " + Move.wallwalkStrengthCur;
			foreach (GameObject gameObject in Menu.buttons)
			{
				global::UnityEngine.Object.Destroy(gameObject);
			}
			RectTransform component = Menu.menu.transform.Find("Canvas/Module Scrolling/Modules").GetComponent<RectTransform>();
			component.anchoredPosition = new Vector2(component.anchoredPosition.x, ScrollInteractor.scroll);
		}

		// Token: 0x060000AD RID: 173 RVA: 0x00009060 File Offset: 0x00007260
		public static void Fly()
		{
			Vector3 vector = GorillaTagger.Instance.headCollider.transform.forward * Time.deltaTime;
			bool leftControllerSecondaryButton = ControllerInputPoller.instance.leftControllerSecondaryButton;
			bool flag = leftControllerSecondaryButton;
			if (flag)
			{
				GTPlayer.Instance.transform.position += GorillaTagger.Instance.headCollider.transform.forward * Time.deltaTime * 10f;
				GTPlayer.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
			}
		}

		// Token: 0x060000AE RID: 174 RVA: 0x000090FC File Offset: 0x000072FC
		public static void ChangewallwalkStrength()
		{
			try
			{
				CanvasGUI.Management.Module module = null;
				Action <>9__37_;
				if ((<>9__37_ = Move.<>c.<>9__37_0) == null)
				{
					Move.<>c.<>9__37_0 = delegate
					{
						Move.ChangewallwalkStrength();
					};
				}
				foreach (Category category in Menu.categories)
				{
					foreach (CanvasGUI.Management.Module module2 in category.buttons)
					{
						bool flag = module2.title == "Wall-Walk Power: " + Move.wallwalkStrengthCur;
						if (flag)
						{
							module = module2;
						}
					}
				}
				bool flag2 = Move.wallwalkStrengthCur == "Weak";
				if (flag2)
				{
					Move.wallwalkStrengthCur = "Medium";
					Move.wallwalkStrength = 1.01f;
				}
				else
				{
					bool flag3 = Move.wallwalkStrengthCur == "Medium";
					if (flag3)
					{
						Move.wallwalkStrengthCur = "Strong";
						Move.wallwalkStrength = 2f;
					}
					else
					{
						bool flag4 = Move.wallwalkStrengthCur == "Strong";
						if (flag4)
						{
							Move.wallwalkStrengthCur = "Insane";
							Move.wallwalkStrength = 5f;
						}
						else
						{
							bool flag5 = Move.wallwalkStrengthCur == "Insane";
							if (flag5)
							{
								Move.wallwalkStrengthCur = "Weak";
								Move.wallwalkStrength = 0.8f;
							}
						}
					}
				}
				module.title = "Wall-Walk Power: " + Move.wallwalkStrengthCur;
				foreach (GameObject gameObject in Menu.buttons)
				{
					global::UnityEngine.Object.Destroy(gameObject);
				}
				RectTransform component = Menu.menu.transform.Find("Canvas/Module Scrolling/Modules").GetComponent<RectTransform>();
				component.anchoredPosition = new Vector2(component.anchoredPosition.x, ScrollInteractor.scroll);
			}
			catch
			{
				Debug.LogError("fail");
			}
		}

		// Token: 0x060000AF RID: 175 RVA: 0x00009348 File Offset: 0x00007548
		public static void WallWalk()
		{
			bool flag = GTPlayer.Instance.IsHandTouching(true) || GTPlayer.Instance.IsHandTouching(false);
			if (flag)
			{
				FieldInfo field = typeof(GTPlayer).GetField("lastHitInfoHand", BindingFlags.Instance | BindingFlags.NonPublic);
				RaycastHit raycastHit = (RaycastHit)field.GetValue(GTPlayer.Instance);
				Move.pos = raycastHit.point;
				Move.e = raycastHit.normal;
			}
			bool flag2 = Move.pos != Vector3.zero && ControllerInputs.rightGrip();
			if (flag2)
			{
				GTPlayer.Instance.bodyCollider.attachedRigidbody.AddForce(Move.e * -5f * Move.wallwalkStrength, ForceMode.Acceleration);
			}
		}

		// Token: 0x060000B0 RID: 176 RVA: 0x00009408 File Offset: 0x00007608
		public static void Noclip()
		{
			bool flag = ControllerInputs.rightTrigger();
			if (flag)
			{
				foreach (MeshCollider meshCollider in Resources.FindObjectsOfTypeAll<MeshCollider>())
				{
					meshCollider.enabled = false;
				}
			}
			else
			{
				foreach (MeshCollider meshCollider2 in Resources.FindObjectsOfTypeAll<MeshCollider>())
				{
					meshCollider2.enabled = true;
				}
			}
		}

		// Token: 0x060000B1 RID: 177 RVA: 0x00009478 File Offset: 0x00007678
		public static void iron()
		{
			bool leftGrab = ControllerInputPoller.instance.leftGrab;
			bool flag = leftGrab;
			if (flag)
			{
				GTPlayer.Instance.bodyCollider.attachedRigidbody.AddForce(20f * -GorillaTagger.Instance.leftHandTransform.right, ForceMode.Acceleration);
				GorillaTagger.Instance.StartVibration(true, GorillaTagger.Instance.tapHapticStrength / 50f * GTPlayer.Instance.bodyCollider.attachedRigidbody.velocity.magnitude, GorillaTagger.Instance.tapHapticDuration);
				ParticleSystem particleSystem = new GameObject("LeftIronParticle").AddComponent<ParticleSystem>();
				particleSystem.transform.position = GTPlayer.Instance.leftControllerTransform.position;
				particleSystem.transform.localScale = new Vector3(0.15f, 0.15f, 0.15f);
				particleSystem.transform.rotation = GTPlayer.Instance.leftControllerTransform.rotation;
				particleSystem.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
				Move.rty();
				particleSystem.GetComponent<Renderer>().material.color = Move.col;
				particleSystem.Play();
				global::UnityEngine.Object.Destroy(particleSystem, 0.5f);
			}
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			bool flag2 = rightGrab;
			if (flag2)
			{
				GTPlayer.Instance.bodyCollider.attachedRigidbody.AddForce(20f * GorillaTagger.Instance.rightHandTransform.right, ForceMode.Acceleration);
				GorillaTagger.Instance.StartVibration(false, GorillaTagger.Instance.tapHapticStrength / 50f * GTPlayer.Instance.bodyCollider.attachedRigidbody.velocity.magnitude, GorillaTagger.Instance.tapHapticDuration);
				ParticleSystem particleSystem2 = new GameObject("RightIronParticle").AddComponent<ParticleSystem>();
				particleSystem2.transform.position = GTPlayer.Instance.rightControllerTransform.position;
				particleSystem2.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
				particleSystem2.transform.rotation = GTPlayer.Instance.rightControllerTransform.rotation;
				particleSystem2.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
				GradientColorKey[] array = new GradientColorKey[3];
				array[0].color = Color.gray;
				array[0].time = 0f;
				array[1].color = new Color32(230, 108, 44, byte.MaxValue);
				array[1].time = 0.5f;
				array[2].color = Color.gray;
				array[2].time = 1f;
				Move.rty();
				particleSystem2.GetComponent<Renderer>().material.color = Move.col;
				particleSystem2.Play();
				global::UnityEngine.Object.Destroy(particleSystem2, 0.5f);
			}
		}

		// Token: 0x060000B2 RID: 178 RVA: 0x00009790 File Offset: 0x00007990
		public static void PcMovemeent()
		{
			GorillaTagger.Instance.leftHandTransform.position = GameObject.Find("head").gameObject.transform.position;
			GorillaTagger.Instance.rightHandTransform.position = GameObject.Find("head").gameObject.transform.position;
			bool key = UnityInput.Current.GetKey(KeyCode.W);
			if (key)
			{
				GTPlayer.Instance.transform.position += GTPlayer.Instance.headCollider.transform.forward * Time.deltaTime * 5f;
			}
			bool key2 = UnityInput.Current.GetKey(KeyCode.A);
			if (key2)
			{
				GTPlayer.Instance.transform.position += GTPlayer.Instance.headCollider.transform.right * Time.deltaTime * -5f;
			}
			bool key3 = UnityInput.Current.GetKey(KeyCode.S);
			if (key3)
			{
				GTPlayer.Instance.transform.position += GTPlayer.Instance.headCollider.transform.forward * Time.deltaTime * -5f;
			}
			bool key4 = UnityInput.Current.GetKey(KeyCode.D);
			if (key4)
			{
				GTPlayer.Instance.transform.position += GTPlayer.Instance.headCollider.transform.right * Time.deltaTime * 5f;
			}
			bool key5 = UnityInput.Current.GetKey(KeyCode.Space);
			if (key5)
			{
				GTPlayer.Instance.transform.position += GTPlayer.Instance.headCollider.transform.up * Time.deltaTime * 5f;
			}
			bool key6 = UnityInput.Current.GetKey(KeyCode.LeftControl);
			if (key6)
			{
				GTPlayer.Instance.transform.position += GTPlayer.Instance.headCollider.transform.up * Time.deltaTime * -5f;
			}
			GTPlayer.Instance.GetComponent<Rigidbody>().velocity = Vector3.zero;
		}

		// Token: 0x060000B3 RID: 179 RVA: 0x00009A0C File Offset: 0x00007C0C
		public static void Helicopter()
		{
			bool rightControllerPrimaryButton = ControllerInputPoller.instance.rightControllerPrimaryButton;
			bool flag = rightControllerPrimaryButton;
			if (flag)
			{
				GorillaTagger.Instance.offlineVRRig.enabled = false;
				GorillaTagger.Instance.offlineVRRig.transform.position += new Vector3(0f, 0.1f, 0f);
				GorillaTagger.Instance.offlineVRRig.transform.Rotate(new Vector3(0f, 7f, 0f));
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.enabled = true;
			}
		}

		// Token: 0x060000B4 RID: 180 RVA: 0x00009AB4 File Offset: 0x00007CB4
		public static void SpinnyMonkeV1()
		{
			bool leftGrab = ControllerInputPoller.instance.leftGrab;
			bool flag = leftGrab;
			if (flag)
			{
				GorillaTagger.Instance.offlineVRRig.enabled = false;
				GorillaTagger.Instance.offlineVRRig.transform.Rotate(new Vector3(0f, 7f, 0f));
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.enabled = true;
			}
		}

		// Token: 0x060000B5 RID: 181 RVA: 0x00009B28 File Offset: 0x00007D28
		public static void SpinnyMonkeV2()
		{
			bool leftGrab = ControllerInputPoller.instance.leftGrab;
			bool flag = leftGrab;
			if (flag)
			{
				GorillaTagger.Instance.offlineVRRig.enabled = false;
				GorillaTagger.Instance.offlineVRRig.transform.Rotate(new Vector3(0f, 0f, 7f));
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.enabled = true;
			}
		}

		// Token: 0x060000B6 RID: 182 RVA: 0x00009B9C File Offset: 0x00007D9C
		public static void SpinnyMonkeV3()
		{
			bool leftGrab = ControllerInputPoller.instance.leftGrab;
			bool flag = leftGrab;
			if (flag)
			{
				GorillaTagger.Instance.offlineVRRig.enabled = false;
				GorillaTagger.Instance.offlineVRRig.transform.Rotate(new Vector3(7f, 0f, 0f));
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.enabled = true;
			}
		}

		// Token: 0x060000B7 RID: 183 RVA: 0x00009C10 File Offset: 0x00007E10
		public static void SpazSpinnyMonke()
		{
			bool leftGrab = ControllerInputPoller.instance.leftGrab;
			bool flag = leftGrab;
			if (flag)
			{
				GorillaTagger.Instance.offlineVRRig.enabled = false;
				GorillaTagger.Instance.offlineVRRig.transform.Rotate(new Vector3(90f, 90f, 90f));
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.enabled = true;
			}
		}

		// Token: 0x060000B8 RID: 184 RVA: 0x00009C81 File Offset: 0x00007E81
		public static void SpeedMultiplier(float speed)
		{
			GTPlayer.Instance.maxJumpSpeed = Move.normal * speed;
			GTPlayer.Instance.jumpMultiplier = Move.normal2 * speed;
		}

		// Token: 0x04000063 RID: 99
		public static bool ghostToggled = false;

		// Token: 0x04000064 RID: 100
		public static Vector3 handScale = new Vector3(0.1f, 0.1f, 0.1f);

		// Token: 0x04000065 RID: 101
		public static GameObject l;

		// Token: 0x04000066 RID: 102
		public static GameObject r;

		// Token: 0x04000067 RID: 103
		public static Material mat;

		// Token: 0x04000068 RID: 104
		public static VRRig GhostRig;

		// Token: 0x04000069 RID: 105
		public static Color ghostColor;

		// Token: 0x0400006A RID: 106
		public static GTPlayer player = null;

		// Token: 0x0400006B RID: 107
		private static Dictionary<VRRig, float> delays = new Dictionary<VRRig, float>();

		// Token: 0x0400006C RID: 108
		public static bool canToggle = true;

		// Token: 0x0400006D RID: 109
		public static bool canTp = true;

		// Token: 0x0400006E RID: 110
		public static bool isAtPos;

		// Token: 0x0400006F RID: 111
		public static bool rightTrigger = (double)ControllerInputPoller.TriggerFloat(5) > 0.5;

		// Token: 0x04000070 RID: 112
		private static GameObject leftplat = null;

		// Token: 0x04000071 RID: 113
		private static GameObject rightplat = null;

		// Token: 0x04000072 RID: 114
		public static Color col = Color.gray;

		// Token: 0x04000073 RID: 115
		public static float flySpeed;

		// Token: 0x04000074 RID: 116
		public static string FlyCurrently = "Slow";

		// Token: 0x04000075 RID: 117
		public static float wallwalkStrength = 0.8f;

		// Token: 0x04000076 RID: 118
		public static string wallwalkStrengthCur = "Weak";

		// Token: 0x04000077 RID: 119
		private static Vector3 pos;

		// Token: 0x04000078 RID: 120
		private static Vector3 e;

		// Token: 0x04000079 RID: 121
		private static float normal = GTPlayer.Instance.maxJumpSpeed;

		// Token: 0x0400007A RID: 122
		private static float normal2 = GTPlayer.Instance.jumpMultiplier;
	}
}
