﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using CanvasGUI.Components;
using CanvasGUI.Mods;
using GorillaExtensions;
using GorillaLocomotion;
using GorillaNetworking;
using Photon.Pun;
using TMPro;
using UnityEngine;

namespace Abyss.Mods
{
	// Token: 0x02000016 RID: 22
	internal class Visuals
	{
		// Token: 0x0600013D RID: 317 RVA: 0x0000F494 File Offset: 0x0000D694
		public static void SetTime(string time)
		{
			bool flag = time == "night";
			if (flag)
			{
				BetterDayNightManager.instance.SetTimeOfDay(0);
			}
			bool flag2 = time == "evening";
			if (flag2)
			{
				BetterDayNightManager.instance.SetTimeOfDay(7);
			}
			bool flag3 = time == "day";
			if (flag3)
			{
				BetterDayNightManager.instance.SetTimeOfDay(3);
			}
			bool flag4 = time == "morning";
			if (flag4)
			{
				BetterDayNightManager.instance.SetTimeOfDay(1);
			}
		}

		// Token: 0x0600013E RID: 318 RVA: 0x0000F518 File Offset: 0x0000D718
		public static void ChangeButtonSound()
		{
			bool flag = ButtonInteractor.ButtonType < 7;
			if (flag)
			{
				ButtonInteractor.ButtonType++;
			}
			else
			{
				ButtonInteractor.ButtonType = 0;
			}
		}

		// Token: 0x0600013F RID: 319 RVA: 0x0000F54C File Offset: 0x0000D74C
		public static void Draw()
		{
			bool leftControllerPrimaryButton = ControllerInputPoller.instance.leftControllerPrimaryButton;
			if (leftControllerPrimaryButton)
			{
				Vector3 position = GorillaTagger.Instance.leftHandTransform.position;
				Quaternion rotation = GorillaTagger.Instance.leftHandTransform.rotation;
				GameObject gameObject = new GameObject("woah");
				gameObject.transform.position = position;
				ParticleSystem particleSystem = gameObject.AddComponent<ParticleSystem>();
				ParticleSystem.MainModule main = particleSystem.main;
				main.startColor = new ParticleSystem.MinMaxGradient(new Color(0.4f, 0.7f, 1f), new Color(0.9f, 0.4f, 1f));
				main.startSize = 0.05f;
				main.startSpeed = 0.1f;
				main.startLifetime = 2f;
				main.loop = true;
				main.simulationSpace = 1;
				particleSystem.emission.rateOverTime = 100f;
				ParticleSystem.ShapeModule shape = particleSystem.shape;
				shape.shapeType = 0;
				shape.radius = 0.005f;
				ParticleSystem.VelocityOverLifetimeModule velocityOverLifetime = particleSystem.velocityOverLifetime;
				velocityOverLifetime.x = new ParticleSystem.MinMaxCurve(0f, 0f);
				velocityOverLifetime.y = new ParticleSystem.MinMaxCurve(0f, 0f);
				velocityOverLifetime.z = new ParticleSystem.MinMaxCurve(8f, 12f);
				particleSystem.transform.rotation = rotation;
				gameObject.transform.Rotate(Vector3.up, Time.time * 300f, Space.World);
				ParticleSystemRenderer component = particleSystem.GetComponent<ParticleSystemRenderer>();
				component.material = new Material(Shader.Find("Particles/Standard Unlit"));
				particleSystem.Play();
				global::UnityEngine.Object.Destroy(gameObject, 2f);
			}
			bool rightControllerPrimaryButton = ControllerInputPoller.instance.rightControllerPrimaryButton;
			if (rightControllerPrimaryButton)
			{
				Vector3 position2 = GorillaTagger.Instance.rightHandTransform.position;
				Quaternion rotation2 = GorillaTagger.Instance.rightHandTransform.rotation;
				GameObject gameObject2 = new GameObject("woah");
				gameObject2.transform.position = position2;
				ParticleSystem particleSystem2 = gameObject2.AddComponent<ParticleSystem>();
				ParticleSystem.MainModule main2 = particleSystem2.main;
				main2.startColor = new ParticleSystem.MinMaxGradient(new Color(0.4f, 0.7f, 1f), new Color(0.9f, 0.4f, 1f));
				main2.startSize = 0.05f;
				main2.startSpeed = 0.1f;
				main2.startLifetime = 2f;
				main2.loop = true;
				main2.simulationSpace = 1;
				particleSystem2.emission.rateOverTime = 100f;
				ParticleSystem.ShapeModule shape2 = particleSystem2.shape;
				shape2.shapeType = 0;
				shape2.radius = 0.005f;
				ParticleSystem.VelocityOverLifetimeModule velocityOverLifetime2 = particleSystem2.velocityOverLifetime;
				velocityOverLifetime2.x = new ParticleSystem.MinMaxCurve(0f, 0f);
				velocityOverLifetime2.y = new ParticleSystem.MinMaxCurve(0f, 0f);
				velocityOverLifetime2.z = new ParticleSystem.MinMaxCurve(8f, 12f);
				particleSystem2.transform.rotation = rotation2;
				gameObject2.transform.Rotate(Vector3.up, Time.time * 300f, Space.World);
				ParticleSystemRenderer component2 = particleSystem2.GetComponent<ParticleSystemRenderer>();
				component2.material = new Material(Shader.Find("Particles/Standard Unlit"));
				particleSystem2.Play();
				global::UnityEngine.Object.Destroy(gameObject2, 6f);
			}
		}

		// Token: 0x06000140 RID: 320 RVA: 0x0000F8EC File Offset: 0x0000DAEC
		public static void DrawGun()
		{
			GunLib.Waver waver = GunLib.nolockshoot();
			bool flag = waver != null;
			if (flag)
			{
				bool flag2 = waver.triggered && waver.shooting;
				if (flag2)
				{
					Vector3 pointerPos = waver.pointerPos;
					GameObject gameObject = new GameObject("woah");
					gameObject.transform.position = pointerPos;
					ParticleSystem particleSystem = gameObject.AddComponent<ParticleSystem>();
					ParticleSystem.MainModule main = particleSystem.main;
					main.startColor = new ParticleSystem.MinMaxGradient(new Color(0.4f, 0.7f, 1f), new Color(0.9f, 0.4f, 1f));
					main.startSize = 0.05f;
					main.startSpeed = 0.1f;
					main.startLifetime = 2f;
					main.loop = true;
					main.simulationSpace = 1;
					particleSystem.emission.rateOverTime = 100f;
					ParticleSystem.ShapeModule shape = particleSystem.shape;
					shape.shapeType = 0;
					shape.radius = 0.005f;
					ParticleSystem.VelocityOverLifetimeModule velocityOverLifetime = particleSystem.velocityOverLifetime;
					velocityOverLifetime.x = new ParticleSystem.MinMaxCurve(0f, 0f);
					velocityOverLifetime.y = new ParticleSystem.MinMaxCurve(0f, 0f);
					velocityOverLifetime.z = new ParticleSystem.MinMaxCurve(8f, 12f);
					particleSystem.transform.rotation = Quaternion.identity;
					gameObject.transform.Rotate(Vector3.up, Time.time * 300f, Space.World);
					ParticleSystemRenderer component = particleSystem.GetComponent<ParticleSystemRenderer>();
					component.material = new Material(Shader.Find("Particles/Standard Unlit"));
					particleSystem.Play();
					global::UnityEngine.Object.Destroy(gameObject, 6f);
				}
			}
		}

		// Token: 0x06000141 RID: 321 RVA: 0x0000FAC4 File Offset: 0x0000DCC4
		public static void ClickMore()
		{
			ButtonInteractor.ButtonVolume += 0.1f;
		}

		// Token: 0x06000142 RID: 322 RVA: 0x0000FAD8 File Offset: 0x0000DCD8
		public static void ClickLess()
		{
			bool flag = ButtonInteractor.ButtonVolume > 0f;
			if (flag)
			{
				ButtonInteractor.ButtonVolume -= 0.1f;
			}
		}

		// Token: 0x06000143 RID: 323 RVA: 0x0000FB08 File Offset: 0x0000DD08
		public static void VFX()
		{
			bool flag = Time.time - Visuals.del > 0.2f;
			if (flag)
			{
				Visuals.del = Time.time;
				GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/StumpVRHeadset/ModIOArcadeTeleporter (1)/NetObject_VRTeleporter").GetComponent<PhotonView>().RPC("ActivateTeleportVFX", 0, new object[1]);
				GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/StumpVRHeadset/ModIOArcadeTeleporter (1)/NetObject_VRTeleporter").GetComponent<PhotonView>().RPC("ActivateReturnVFX", 0, new object[1]);
				OP.RPCProtection();
			}
		}

		// Token: 0x06000144 RID: 324 RVA: 0x0000FB80 File Offset: 0x0000DD80
		public static void VFXG()
		{
			GunLib.Waver waver = GunLib.lockShoot();
			bool flag = waver != null;
			if (flag)
			{
				bool flag2 = waver.lockedOn && waver.shooting && waver.triggered;
				if (flag2)
				{
					bool flag3 = Time.time - Visuals.del > 0.2f;
					if (flag3)
					{
						Visuals.del = Time.time;
						GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/StumpVRHeadset/ModIOArcadeTeleporter (1)/NetObject_VRTeleporter").GetComponent<PhotonView>().RPC("ActivateTeleportVFX", OP.VRRIgToPlayer(waver.Target), new object[1]);
						GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/StumpVRHeadset/ModIOArcadeTeleporter (1)/NetObject_VRTeleporter").GetComponent<PhotonView>().RPC("ActivateReturnVFX", OP.VRRIgToPlayer(waver.Target), new object[1]);
						OP.RPCProtection();
					}
				}
			}
		}

		// Token: 0x06000145 RID: 325 RVA: 0x0000FC41 File Offset: 0x0000DE41
		public static void SetWthenF(int WaveAmmount, int Frequency)
		{
			GunLib.Wavy = WaveAmmount;
			GunLib.Freq = (float)Frequency;
		}

		// Token: 0x06000146 RID: 326 RVA: 0x0000FC51 File Offset: 0x0000DE51
		public static void ResetGun()
		{
			GunLib.Wavy = 200;
			GunLib.Freq = 35f;
		}

		// Token: 0x06000147 RID: 327 RVA: 0x0000FC68 File Offset: 0x0000DE68
		public static void StupidGunLib()
		{
			GunLib.Wavy = 20;
			GunLib.Freq = 60f;
		}

		// Token: 0x06000148 RID: 328 RVA: 0x0000FC7C File Offset: 0x0000DE7C
		public static void Display()
		{
			bool flag = !Visuals.hasImage;
			if (flag)
			{
				Visuals.DownloadImage();
			}
			else
			{
				bool flag2 = Visuals.imageObject != null;
				if (flag2)
				{
					Visuals.PositionImage();
				}
			}
		}

		// Token: 0x06000149 RID: 329 RVA: 0x0000FCB8 File Offset: 0x0000DEB8
		private static void DownloadImage()
		{
			bool flag = !Directory.Exists(Visuals.directoryPath);
			if (flag)
			{
				Directory.CreateDirectory(Visuals.directoryPath);
			}
			bool flag2 = !File.Exists(Visuals.imagePath);
			if (flag2)
			{
				using (WebClient webClient = new WebClient())
				{
					try
					{
						webClient.DownloadFile(Visuals.imageUrl, Visuals.imagePath);
					}
					catch
					{
					}
				}
			}
			Visuals.LoadAndApplyImage();
			Visuals.hasImage = true;
			bool flag3 = Visuals.imageObject.GetComponent<Collider>() != null;
			if (flag3)
			{
				Visuals.imageObject.GetComponent<Collider>().enabled = false;
			}
			bool flag4 = Visuals.imageObject.GetComponent<MeshCollider>() != null;
			if (flag4)
			{
				Visuals.imageObject.GetComponent<MeshCollider>().enabled = false;
			}
		}

		// Token: 0x0600014A RID: 330 RVA: 0x0000FDA0 File Offset: 0x0000DFA0
		private static void LoadAndApplyImage()
		{
			bool flag = !File.Exists(Visuals.imagePath);
			if (!flag)
			{
				byte[] array = File.ReadAllBytes(Visuals.imagePath);
				Visuals.texture = new Texture2D(2, 2);
				bool flag2 = ImageConversion.LoadImage(Visuals.texture, array);
				if (flag2)
				{
					Visuals.imageObject = GameObject.CreatePrimitive(PrimitiveType.Quad);
					Visuals.imageObject.transform.localScale = Visuals.imageScale;
					Visuals.imageObject.transform.position = Visuals.imagePosition;
					Material material = new Material(Shader.Find("Sprites/Default"));
					material.mainTexture = Visuals.texture;
					Visuals.imageObject.GetComponent<Renderer>().material = material;
				}
			}
		}

		// Token: 0x0600014B RID: 331 RVA: 0x0000FE50 File Offset: 0x0000E050
		private static void PositionImage()
		{
			Camera main = Camera.main;
			bool flag = main != null && Visuals.imageObject != null;
			if (flag)
			{
				Visuals.imageObject.transform.position = new Vector3(-63.83f, 12.57f, -82.77f);
				Visuals.imageObject.transform.LookAt(main.transform);
				Visuals.imageObject.transform.Rotate(0f, 180f, 0f);
			}
		}

		// Token: 0x0600014C RID: 332 RVA: 0x0000FEDC File Offset: 0x0000E0DC
		public static void Chams2()
		{
			foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
			{
				bool flag = !vrrig.isOfflineVRRig || !vrrig.isMyPlayer;
				bool flag2 = flag;
				if (flag2)
				{
					vrrig.mainSkin.material.shader = Shader.Find("GUI/Text Shader");
					vrrig.mainSkin.material.color = Color.Lerp(Color.gray, Color.black, Mathf.PingPong(Time.time, 1f));
				}
			}
		}

		// Token: 0x0600014D RID: 333 RVA: 0x0000FF9C File Offset: 0x0000E19C
		public static void ParticleSpam(Vector3 Size, Color col, PrimitiveType type, Vector3 pos, Vector3 vel)
		{
			Quaternion rotation = GorillaTagger.Instance.offlineVRRig.rightHandTransform.rotation;
			GameObject gameObject = GameObject.CreatePrimitive(type);
			gameObject.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
			gameObject.transform.localScale = Size;
			gameObject.transform.position = pos;
			gameObject.transform.rotation = rotation;
			gameObject.AddComponent<Renderer>();
			Rigidbody rigidbody = gameObject.AddComponent<Rigidbody>();
			rigidbody.velocity = vel;
			MeshCollider meshCollider = gameObject.AddComponent<MeshCollider>();
			Visuals.projRend = gameObject.GetComponent<Renderer>();
			bool flag = !Visuals.isRainbow && Visuals.projRend != null;
			if (flag)
			{
				Visuals.projRend.material.color = col;
			}
			else
			{
				bool flag2 = Visuals.isRainbow && Visuals.projRend != null;
				if (flag2)
				{
					Visuals.projRend.material.color = Color.HSVToRGB(Visuals.hue, 1f, 1f);
				}
			}
			GameObject.Find("Environment Objects/LocalObjects_Prefab/Forest/Terrain/pitgeo/pit ground").layer = gameObject.layer;
			Visuals.projs = Visuals.projs.Append(gameObject).ToArray<GameObject>();
			Visuals.renders = Visuals.renders.Append(gameObject.GetComponent<Renderer>()).ToArray<Renderer>();
		}

		// Token: 0x0600014E RID: 334 RVA: 0x000100F0 File Offset: 0x0000E2F0
		public static void FPP()
		{
			GunLib.Waver waver = GunLib.nolockshoot();
			bool flag = waver != null;
			if (flag)
			{
				bool flag2 = waver.shooting && waver.triggered;
				if (flag2)
				{
					foreach (GameObject gameObject in Visuals.projs)
					{
						bool flag3 = Vector3.Distance(waver.pointerPos, gameObject.transform.position) < 0.25f;
						if (flag3)
						{
							gameObject.GetComponent<Rigidbody>().velocity = new Vector3(0f, 10f, 0f);
						}
					}
				}
			}
		}

		// Token: 0x0600014F RID: 335 RVA: 0x00010190 File Offset: 0x0000E390
		public static void FPPAura()
		{
			float num = 3.2f;
			List<GameObject> list = new List<GameObject>();
			foreach (GameObject gameObject in Visuals.projs)
			{
				float num2 = Vector3.Distance(gameObject.transform.position, GorillaTagger.Instance.offlineVRRig.transform.position);
				bool flag = num2 <= num && gameObject != GorillaTagger.Instance.offlineVRRig;
				bool flag2 = flag;
				if (flag2)
				{
					list.Add(gameObject);
				}
			}
			foreach (GameObject gameObject2 in list)
			{
				gameObject2.GetComponent<Rigidbody>().velocity = new Vector3(0f, 10f, 0f);
			}
		}

		// Token: 0x06000150 RID: 336 RVA: 0x0001027C File Offset: 0x0000E47C
		public static void FPPAll()
		{
			foreach (GameObject gameObject in Visuals.projs)
			{
				gameObject.GetComponent<Rigidbody>().velocity = new Vector3(0f, 10f, 0f);
			}
		}

		// Token: 0x06000151 RID: 337 RVA: 0x000102C8 File Offset: 0x0000E4C8
		public static void BP()
		{
			GunLib.Waver waver = GunLib.nolockshoot();
			bool flag = waver != null;
			if (flag)
			{
				bool flag2 = waver.shooting && waver.triggered;
				if (flag2)
				{
					foreach (GameObject gameObject in Visuals.projs)
					{
						bool flag3 = Vector3.Distance(waver.pointerPos, gameObject.transform.position) < 0.25f;
						if (flag3)
						{
							gameObject.transform.position = GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position;
							gameObject.GetComponent<Rigidbody>().velocity = Vector3.zero;
						}
					}
				}
			}
		}

		// Token: 0x06000152 RID: 338 RVA: 0x00010384 File Offset: 0x0000E584
		public static void Trails()
		{
			foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
			{
				bool flag = vrrig != GorillaTagger.Instance.offlineVRRig;
				if (flag)
				{
					GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Sphere);
					gameObject.transform.position = vrrig.transform.position;
					gameObject.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f) * vrrig.scaleFactor;
					Renderer component = gameObject.GetComponent<Renderer>();
					Material material = component.material;
					material.shader = Shader.Find("GUI/Text Shader");
					global::UnityEngine.Object.Destroy(gameObject.GetComponent<BoxCollider>());
					global::UnityEngine.Object.Destroy(gameObject.GetComponent<Rigidbody>());
					bool flag2 = vrrig.mainSkin.material.name.Contains("fected") || vrrig.mainSkin.material.name.Contains("It") || vrrig.mainSkin.material.name.Contains("stealth") || vrrig.mainSkin.material.name.Contains("Ice");
					if (flag2)
					{
						material.color = Color.red;
					}
					else
					{
						material.color = Color.blue;
					}
					global::UnityEngine.Object.Destroy(gameObject, 0.3f);
					global::UnityEngine.Object.Destroy(material, 0.3f);
					global::UnityEngine.Object.Destroy(component, 0.3f);
				}
			}
		}

		// Token: 0x06000153 RID: 339 RVA: 0x00010548 File Offset: 0x0000E748
		public static void BPA()
		{
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			if (rightGrab)
			{
				bool flag = Visuals.rightGrabbed;
				if (flag)
				{
					foreach (GameObject gameObject in Visuals.projs)
					{
						gameObject.transform.position = GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position;
					}
				}
				else
				{
					bool flag2 = Visuals.leftGrabbed;
					if (flag2)
					{
						foreach (GameObject gameObject2 in Visuals.projs)
						{
							gameObject2.transform.position = GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.position;
						}
					}
				}
			}
		}

		// Token: 0x06000154 RID: 340 RVA: 0x0001061C File Offset: 0x0000E81C
		public static void CubeSpam(Vector3 Size, Color col)
		{
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			if (rightGrab)
			{
				Visuals.ParticleSpam(Size, col, PrimitiveType.Cube, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
			}
		}

		// Token: 0x06000155 RID: 341 RVA: 0x00010688 File Offset: 0x0000E888
		public static void SphereSpam(Vector3 Size, Color col)
		{
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			if (rightGrab)
			{
				Visuals.ParticleSpam(Size, col, PrimitiveType.Sphere, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
			}
		}

		// Token: 0x06000156 RID: 342 RVA: 0x000106F4 File Offset: 0x0000E8F4
		public static void CubeGun(Vector3 Size, Color col)
		{
			GunLib.Waver waver = GunLib.nolockshoot();
			bool flag = waver != null;
			if (flag)
			{
				bool flag2 = waver.shooting && waver.triggered;
				if (flag2)
				{
					Visuals.ParticleSpam(Size, col, PrimitiveType.Cube, waver.pointerPos, Vector3.zero);
					Visuals.ParticleSpam(Size, col, PrimitiveType.Cube, waver.pointerPos, Vector3.zero);
					Visuals.ParticleSpam(Size, col, PrimitiveType.Cube, waver.pointerPos, Vector3.zero);
					Visuals.ParticleSpam(Size, col, PrimitiveType.Cube, waver.pointerPos, Vector3.zero);
					Visuals.ParticleSpam(Size, col, PrimitiveType.Cube, waver.pointerPos, Vector3.zero);
				}
			}
		}

		// Token: 0x06000157 RID: 343 RVA: 0x00010790 File Offset: 0x0000E990
		public static void Miniguun()
		{
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			if (rightGrab)
			{
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Color.black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.SphereSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.CubeSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
				Visuals.ParticleSpam(new Vector3(0.5f, 0.5f, 0.5f), Visuals.Black, PrimitiveType.Cylinder, GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.position, -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f);
			}
		}

		// Token: 0x06000158 RID: 344 RVA: 0x000150BC File Offset: 0x000132BC
		public static void SphereGun(Vector3 Size, Color col)
		{
			GunLib.Waver waver = GunLib.nolockshoot();
			bool flag = waver != null;
			if (flag)
			{
				bool flag2 = waver.shooting && waver.triggered;
				if (flag2)
				{
					Visuals.ParticleSpam(Size, col, PrimitiveType.Sphere, waver.pointerPos, Vector3.zero);
					Visuals.ParticleSpam(Size, col, PrimitiveType.Sphere, waver.pointerPos, Vector3.zero);
					Visuals.ParticleSpam(Size, col, PrimitiveType.Sphere, waver.pointerPos, Vector3.zero);
					Visuals.ParticleSpam(Size, col, PrimitiveType.Sphere, waver.pointerPos, Vector3.zero);
					Visuals.ParticleSpam(Size, col, PrimitiveType.Sphere, waver.pointerPos, Vector3.zero);
				}
			}
		}

		// Token: 0x06000159 RID: 345 RVA: 0x00015158 File Offset: 0x00013358
		public static void GrabProjectiles()
		{
			Transform rightHandTransform = GorillaTagger.Instance.rightHandTransform;
			Transform leftHandTransform = GorillaTagger.Instance.leftHandTransform;
			Rigidbody component = GorillaTagger.Instance.offlineVRRig.rightHandTransform.GetComponent<Rigidbody>();
			Rigidbody component2 = GorillaTagger.Instance.offlineVRRig.leftHandTransform.GetComponent<Rigidbody>();
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			if (rightGrab)
			{
				foreach (GameObject gameObject in Visuals.projs)
				{
					bool flag = Vector3.Distance(rightHandTransform.position, gameObject.transform.position) < 0.25f && gameObject != Visuals.leftGrabbed;
					if (flag)
					{
						Visuals.rightGrabbed = gameObject;
						Visuals.rightCol = gameObject.GetComponent<MeshCollider>();
						Visuals.rightCol.enabled = false;
						break;
					}
				}
				bool flag2 = Visuals.rightGrabbed != null;
				if (flag2)
				{
					Visuals.rightGrabbed.transform.position = rightHandTransform.position;
					Visuals.rightGrabbed.transform.rotation = rightHandTransform.rotation;
					Visuals.rightCol.isTrigger = true;
					Visuals.rightGrabbed.GetComponent<Rigidbody>().velocity = Vector3.zero;
				}
			}
			else
			{
				bool flag3 = Visuals.rightGrabbed != null;
				if (flag3)
				{
					Visuals.rightGrabbed.GetComponent<Rigidbody>().velocity = component.velocity;
					Visuals.rightCol.isTrigger = false;
					Visuals.rightGrabbed = null;
					Visuals.rightCol = null;
				}
			}
			bool leftGrab = ControllerInputPoller.instance.leftGrab;
			if (leftGrab)
			{
				foreach (GameObject gameObject2 in Visuals.projs)
				{
					bool flag4 = Vector3.Distance(leftHandTransform.position, gameObject2.transform.position) < 0.25f && gameObject2 != Visuals.rightGrabbed;
					if (flag4)
					{
						Visuals.leftGrabbed = gameObject2;
						Visuals.leftCol = gameObject2.GetComponent<MeshCollider>();
						Visuals.leftCol.isTrigger = true;
						break;
					}
				}
				bool flag5 = Visuals.leftGrabbed != null;
				if (flag5)
				{
					Visuals.leftGrabbed.transform.position = leftHandTransform.position;
					Visuals.leftGrabbed.transform.rotation = leftHandTransform.rotation;
					Visuals.leftCol.isTrigger = false;
					Visuals.leftGrabbed.GetComponent<Rigidbody>().velocity = Vector3.zero;
				}
			}
			else
			{
				bool flag6 = Visuals.leftGrabbed != null;
				if (flag6)
				{
					Visuals.leftGrabbed.GetComponent<Rigidbody>().velocity = component2.velocity;
					Visuals.leftCol.enabled = true;
					Visuals.leftGrabbed = null;
					Visuals.leftCol = null;
				}
			}
		}

		// Token: 0x0600015A RID: 346 RVA: 0x0001540C File Offset: 0x0001360C
		public static void DelProj()
		{
			foreach (GameObject gameObject in Visuals.projs)
			{
				bool flag = gameObject != null;
				if (flag)
				{
					global::UnityEngine.Object.Destroy(gameObject);
				}
			}
			Visuals.projs = new GameObject[0];
		}

		// Token: 0x0600015B RID: 347 RVA: 0x00015454 File Offset: 0x00013654
		public static void RainbowProj()
		{
			bool flag = Visuals.projs != null;
			if (flag)
			{
				foreach (Renderer renderer in Visuals.renders)
				{
					renderer.material.color = Color.HSVToRGB(Visuals.hue, 1f, 1f);
					Visuals.isRainbow = true;
				}
			}
			Visuals.hue += Time.deltaTime * 0.5f;
			bool flag2 = Visuals.hue > 1f;
			if (flag2)
			{
				Visuals.hue = 0f;
			}
		}

		// Token: 0x0600015C RID: 348 RVA: 0x000154E4 File Offset: 0x000136E4
		public static void ThickAdvTracers()
		{
			foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
			{
				bool flag = vrrig != GorillaTagger.Instance.offlineVRRig;
				if (flag)
				{
					GameObject gameObject = new GameObject("IM NOT OKAY");
					LineRenderer lineRenderer = gameObject.AddComponent<LineRenderer>();
					lineRenderer.positionCount = 2;
					lineRenderer.SetPosition(0, GTPlayer.Instance.rightControllerTransform.position);
					lineRenderer.SetPosition(1, vrrig.transform.position);
					lineRenderer.startWidth = 0.02f;
					lineRenderer.endWidth = 0.02f;
					lineRenderer.material.shader = Shader.Find("GUI/Text Shader");
					bool flag2 = vrrig.mainSkin.material.name.Contains("fected");
					if (flag2)
					{
						lineRenderer.startColor = Color.gray;
					}
					else
					{
						lineRenderer.startColor = vrrig.playerColor;
					}
					global::UnityEngine.Object.Destroy(lineRenderer, Time.deltaTime);
				}
			}
		}

		// Token: 0x0600015D RID: 349 RVA: 0x00015624 File Offset: 0x00013824
		public static void ThinAdvTracers()
		{
			foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
			{
				bool flag = vrrig != GorillaTagger.Instance.offlineVRRig;
				if (flag)
				{
					GameObject gameObject = new GameObject("IM NOT OKAY");
					LineRenderer lineRenderer = gameObject.AddComponent<LineRenderer>();
					lineRenderer.positionCount = 2;
					lineRenderer.SetPosition(0, GTPlayer.Instance.rightControllerTransform.position);
					lineRenderer.SetPosition(1, vrrig.transform.position);
					lineRenderer.startWidth = 0.01f;
					lineRenderer.endWidth = 0.01f;
					lineRenderer.material.shader = Shader.Find("GUI/Text Shader");
					bool flag2 = vrrig.mainSkin.material.name.Contains("fected");
					bool flag3 = flag2;
					if (flag3)
					{
						lineRenderer.startColor = Color.gray;
					}
					else
					{
						lineRenderer.startColor = vrrig.playerColor;
					}
					global::UnityEngine.Object.Destroy(lineRenderer, Time.deltaTime);
				}
			}
		}

		// Token: 0x0600015E RID: 350 RVA: 0x00015774 File Offset: 0x00013974
		public static void NameTagESP()
		{
			foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
			{
				bool flag = !vrrig.isOfflineVRRig && !vrrig.isMyPlayer;
				if (flag)
				{
					Transform transform = vrrig.transform.Find("Name Mod");
					GameObject gameObject = ((transform != null) ? transform.gameObject : null);
					bool flag2 = gameObject == null;
					if (flag2)
					{
						gameObject = new GameObject("Name Mod");
					}
					TextMeshPro textMeshPro = gameObject.AddComponent<TextMeshPro>();
					textMeshPro.richText = true;
					textMeshPro.text = "\nDistance: " + Vector3.Distance(GorillaTagger.Instance.headCollider.transform.position, vrrig.headConstraint.position).ToString("F1") + "m\nFPS: " + OP.GetFpsOfPlayer(vrrig).ToString();
					textMeshPro.fontSize = 2f;
					textMeshPro.alignment = 514;
					textMeshPro.color = Color.white;
					gameObject.transform.SetParent(vrrig.transform);
					global::UnityEngine.Object.Destroy(gameObject, Time.deltaTime);
					Transform transform2 = gameObject.transform;
					transform2.position = vrrig.headConstraint.position + new Vector3(0f, 0.7f, 0f);
					transform2.LookAt(Camera.main.transform.position);
					transform2.Rotate(0f, 180f, 0f);
					gameObject.GetComponent<TextMeshPro>().renderer.material.shader = Shader.Find("GUI/Text Shader");
					gameObject.transform.localScale = new Vector3(0.5f, 0.5f, 0.5f);
				}
			}
		}

		// Token: 0x0600015F RID: 351 RVA: 0x00015994 File Offset: 0x00013B94
		public static void WireFrame()
		{
			foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
			{
				bool flag = vrrig != GorillaTagger.Instance.offlineVRRig;
				if (flag)
				{
					GameObject gameObject = new GameObject("WireframeBox");
					gameObject.transform.position = vrrig.transform.position;
					LineRenderer lineRenderer = gameObject.AddComponent<LineRenderer>();
					lineRenderer.startWidth = 0.02f;
					lineRenderer.endWidth = 0.02f;
					lineRenderer.loop = false;
					lineRenderer.useWorldSpace = true;
					lineRenderer.material = new Material(Shader.Find("Sprites/Default"));
					lineRenderer.startColor = Color.gray;
					lineRenderer.endColor = Color.gray;
					Vector3[] array = new Vector3[]
					{
						vrrig.transform.position + new Vector3(-0.5f, -0.5f, -0.5f),
						vrrig.transform.position + new Vector3(0.5f, -0.5f, -0.5f),
						vrrig.transform.position + new Vector3(0.5f, -0.5f, 0.5f),
						vrrig.transform.position + new Vector3(-0.5f, -0.5f, 0.5f),
						vrrig.transform.position + new Vector3(-0.5f, -0.5f, -0.5f),
						vrrig.transform.position + new Vector3(-0.5f, 0.5f, -0.5f),
						vrrig.transform.position + new Vector3(0.5f, 0.5f, -0.5f),
						vrrig.transform.position + new Vector3(0.5f, 0.5f, 0.5f),
						vrrig.transform.position + new Vector3(-0.5f, 0.5f, 0.5f),
						vrrig.transform.position + new Vector3(-0.5f, 0.5f, -0.5f),
						vrrig.transform.position + new Vector3(-0.5f, 0.5f, -0.5f),
						vrrig.transform.position + new Vector3(-0.5f, -0.5f, -0.5f),
						vrrig.transform.position + new Vector3(0.5f, 0.5f, -0.5f),
						vrrig.transform.position + new Vector3(0.5f, -0.5f, -0.5f),
						vrrig.transform.position + new Vector3(0.5f, 0.5f, 0.5f),
						vrrig.transform.position + new Vector3(0.5f, -0.5f, 0.5f),
						vrrig.transform.position + new Vector3(-0.5f, 0.5f, 0.5f),
						vrrig.transform.position + new Vector3(-0.5f, -0.5f, 0.5f)
					};
					lineRenderer.positionCount = array.Length;
					lineRenderer.SetPositions(array);
					global::UnityEngine.Object.Destroy(gameObject, 0.03f);
				}
			}
		}

		// Token: 0x06000160 RID: 352 RVA: 0x00015DD8 File Offset: 0x00013FD8
		public static void UnlockAllCosmetics()
		{
			foreach (CosmeticsController.CosmeticItem cosmeticItem in CosmeticsController.instance.allCosmetics)
			{
				CosmeticsController.instance.ProcessExternalUnlock(cosmeticItem.itemName, false, false);
			}
			CosmeticsController.instance.UpdateMyCosmetics();
			CosmeticsController.instance.UpdateWardrobeModelsAndButtons();
			Action onCosmeticsUpdated = CosmeticsController.instance.OnCosmeticsUpdated;
			if (onCosmeticsUpdated != null)
			{
				onCosmeticsUpdated();
			}
		}

		// Token: 0x06000161 RID: 353 RVA: 0x00015E78 File Offset: 0x00014078
		public static void BoneESP()
		{
			foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
			{
				Color playerColor = vrrig.playerColor;
				bool flag = vrrig != GorillaTagger.Instance.offlineVRRig;
				if (flag)
				{
					LineRenderer lineRenderer = GTExt.GetOrAddComponent<LineRenderer>(vrrig.head.rigTarget.gameObject);
					lineRenderer.startWidth = 0.025f;
					lineRenderer.endWidth = 0.025f;
					lineRenderer.startColor = playerColor;
					lineRenderer.endColor = playerColor;
					lineRenderer.material.shader = Shader.Find("GUI/Text Shader");
					lineRenderer.SetPosition(0, vrrig.head.rigTarget.transform.position + new Vector3(0f, 0.16f, 0f));
					lineRenderer.SetPosition(1, vrrig.head.rigTarget.transform.position - new Vector3(0f, 0.4f, 0f));
					global::UnityEngine.Object.Destroy(lineRenderer, Time.deltaTime);
					for (int i = 0; i < Visuals.bones.Count<int>(); i += 2)
					{
						lineRenderer = GTExt.GetOrAddComponent<LineRenderer>(vrrig.mainSkin.bones[Visuals.bones[i]].gameObject);
						lineRenderer.startWidth = 0.025f;
						lineRenderer.endWidth = 0.025f;
						lineRenderer.startColor = Color.gray;
						lineRenderer.endColor = Color.black;
						lineRenderer.material.shader = Shader.Find("GUI/Text Shader");
						lineRenderer.SetPosition(0, vrrig.mainSkin.bones[Visuals.bones[i]].position);
						lineRenderer.SetPosition(1, vrrig.mainSkin.bones[Visuals.bones[i + 1]].position);
						global::UnityEngine.Object.Destroy(lineRenderer, Time.deltaTime);
					}
				}
			}
		}

		// Token: 0x06000162 RID: 354 RVA: 0x000160BC File Offset: 0x000142BC
		public static void BoxESP()
		{
			foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
			{
				bool flag = vrrig != null && !vrrig.isOfflineVRRig && !vrrig.isMyPlayer;
				bool flag2 = flag;
				if (flag2)
				{
					GameObject gameObject = new GameObject("box");
					gameObject.transform.position = vrrig.transform.position;
					GameObject gameObject2 = GameObject.CreatePrimitive(PrimitiveType.Cube);
					GameObject gameObject3 = GameObject.CreatePrimitive(PrimitiveType.Cube);
					GameObject gameObject4 = GameObject.CreatePrimitive(PrimitiveType.Cube);
					GameObject gameObject5 = GameObject.CreatePrimitive(PrimitiveType.Cube);
					global::UnityEngine.Object.Destroy(gameObject2.GetComponent<BoxCollider>());
					global::UnityEngine.Object.Destroy(gameObject5.GetComponent<BoxCollider>());
					global::UnityEngine.Object.Destroy(gameObject4.GetComponent<BoxCollider>());
					global::UnityEngine.Object.Destroy(gameObject3.GetComponent<BoxCollider>());
					gameObject2.transform.SetParent(gameObject.transform);
					gameObject2.transform.localPosition = new Vector3(0f, 0.49f, 0f);
					gameObject2.transform.localScale = new Vector3(1f, 0.02f, 0.02f);
					gameObject5.transform.SetParent(gameObject.transform);
					gameObject5.transform.localPosition = new Vector3(0f, -0.49f, 0f);
					gameObject5.transform.localScale = new Vector3(1f, 0.02f, 0.02f);
					gameObject4.transform.SetParent(gameObject.transform);
					gameObject4.transform.localPosition = new Vector3(-0.49f, 0f, 0f);
					gameObject4.transform.localScale = new Vector3(0.02f, 1f, 0.02f);
					gameObject3.transform.SetParent(gameObject.transform);
					gameObject3.transform.localPosition = new Vector3(0.49f, 0f, 0f);
					gameObject3.transform.localScale = new Vector3(0.02f, 1f, 0.02f);
					Color[] array = new Color[]
					{
						new Color(0f, 0f, 1f),
						new Color(0f, 1f, 0f),
						new Color(1f, 0f, 0f)
					};
					Color color = Color.Lerp(array[(int)(Time.time % 3f / 3f * (float)(array.Length - 1))], array[((int)(Time.time % 3f / 3f * (float)(array.Length - 1)) + 1) % array.Length], Time.time % 3f / 3f * (float)(array.Length - 1) % 1f);
					gameObject2.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
					gameObject5.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
					gameObject4.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
					gameObject3.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
					gameObject2.GetComponent<Renderer>().material.color = color;
					gameObject5.GetComponent<Renderer>().material.color = color;
					gameObject4.GetComponent<Renderer>().material.color = color;
					gameObject3.GetComponent<Renderer>().material.color = color;
					gameObject.transform.LookAt(gameObject.transform.position + Camera.main.transform.rotation * Vector3.forward, Camera.main.transform.rotation * Vector3.up);
					global::UnityEngine.Object.Destroy(gameObject, Time.deltaTime);
				}
			}
		}

		// Token: 0x06000163 RID: 355 RVA: 0x00016504 File Offset: 0x00014704
		public static void r()
		{
			Visuals.hue2 += Time.deltaTime * 0.5f;
			bool flag = Visuals.hue2 > 1f;
			if (flag)
			{
				Visuals.hue2 = 0f;
			}
			bool flag2 = Visuals.grenade != null;
			if (flag2)
			{
				Visuals.grenade.GetComponent<Renderer>().material.color = Color.HSVToRGB(Visuals.hue2, 1f, 1f);
			}
			bool flag3 = Visuals.canGhost;
			if (flag3)
			{
				Move.Body();
			}
			NetworkingMods.NWC();
		}

		// Token: 0x06000164 RID: 356 RVA: 0x00016594 File Offset: 0x00014794
		public static void GrenadeMinigun()
		{
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			if (rightGrab)
			{
				GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
				gameObject.transform.position = GorillaTagger.Instance.rightHandTransform.position;
				gameObject.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
				gameObject.GetComponent<Collider>().enabled = false;
				Rigidbody rigidbody = gameObject.AddComponent<Rigidbody>();
				Rigidbody component = gameObject.GetComponent<Rigidbody>();
				gameObject.GetComponent<Collider>().enabled = true;
				component.velocity = -GorillaTagger.Instance.offlineVRRig.rightHandTransform.transform.up * -70f;
				gameObject.AddComponent<SphereCollider>();
				gameObject.AddComponent<eoc>();
			}
			bool leftGrab = ControllerInputPoller.instance.leftGrab;
			if (leftGrab)
			{
				GameObject gameObject2 = GameObject.CreatePrimitive(PrimitiveType.Cube);
				gameObject2.transform.position = GorillaTagger.Instance.leftHandTransform.position;
				gameObject2.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
				gameObject2.GetComponent<Collider>().enabled = false;
				Rigidbody rigidbody2 = gameObject2.AddComponent<Rigidbody>();
				Rigidbody component2 = gameObject2.GetComponent<Rigidbody>();
				gameObject2.GetComponent<Collider>().enabled = true;
				component2.velocity = -GorillaTagger.Instance.offlineVRRig.leftHandTransform.transform.up * -70f;
				gameObject2.AddComponent<SphereCollider>();
				gameObject2.AddComponent<eoc>();
			}
		}

		// Token: 0x06000165 RID: 357 RVA: 0x00016728 File Offset: 0x00014928
		public static void Grenade(float Size)
		{
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			if (rightGrab)
			{
				bool flag = Visuals.grenade == null;
				if (flag)
				{
					Visuals.grenade = GameObject.CreatePrimitive(PrimitiveType.Cube);
					Visuals.grenade.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
					Visuals.grenade.transform.position = GorillaTagger.Instance.rightHandTransform.position;
					Visuals.grenade.transform.localScale = new Vector3(Size, Size, Size);
					Visuals.grenade.GetComponent<Collider>().enabled = false;
					Visuals.grenade.GetComponent<Collider>().isTrigger = true;
					Rigidbody rigidbody = Visuals.grenade.AddComponent<Rigidbody>();
					rigidbody.useGravity = false;
					Visuals.isHolding = true;
				}
				Visuals.grenade.transform.position = GorillaTagger.Instance.rightHandTransform.position;
				Visuals.grenade.transform.rotation = GorillaTagger.Instance.rightHandTransform.rotation;
				Visuals.size = Size * 5f;
			}
			bool flag2 = !ControllerInputPoller.instance.rightGrab && Visuals.isHolding;
			if (flag2)
			{
				Rigidbody component = Visuals.grenade.GetComponent<Rigidbody>();
				component.useGravity = true;
				component.velocity = GTPlayer.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(true, 0f, false);
				Visuals.grenade.AddComponent<SphereCollider>();
				Visuals.grenade.AddComponent<eoc>();
				Visuals.grenade.GetComponent<Collider>().enabled = true;
				Visuals.isHolding = false;
				Visuals.grenade = null;
			}
		}

		// Token: 0x06000166 RID: 358 RVA: 0x000168C8 File Offset: 0x00014AC8
		public static void ExplodeGun()
		{
			GunLib.Waver waver = GunLib.nolockshoot();
			bool flag = waver != null;
			if (flag)
			{
				bool flag2 = waver.shooting && waver.triggered;
				if (flag2)
				{
					GameObject gameObject = new GameObject("Explosion");
					ParticleSystem particleSystem = gameObject.AddComponent<ParticleSystem>();
					ParticleSystem.MainModule main = particleSystem.main;
					particleSystem.transform.position = waver.pointerPos;
					main.startSize = new ParticleSystem.MinMaxCurve(0.4f, 1f);
					main.startLifetime = new ParticleSystem.MinMaxCurve(0.3f, 0.6f);
					main.startSpeed = new ParticleSystem.MinMaxCurve(1f, 3f);
					main.startColor = new ParticleSystem.MinMaxGradient(Color.red, Color.gray);
					main.simulationSpace = 1;
					main.gravityModifier = -0.05f;
					main.loop = false;
					ParticleSystem.EmissionModule emission = particleSystem.emission;
					emission.rateOverTime = 0f;
					emission.SetBursts(new ParticleSystem.Burst[]
					{
						new ParticleSystem.Burst(0f, 80)
					});
					ParticleSystem.ShapeModule shape = particleSystem.shape;
					shape.shapeType = 0;
					shape.radius = 0.2f;
					ParticleSystemRenderer component = particleSystem.GetComponent<ParticleSystemRenderer>();
					component.material = new Material(Shader.Find("Particles/Standard Unlit"));
					Camera component2 = GameObject.Find("Shoulder Camera").GetComponent<Camera>();
					GameObject gameObject2 = new GameObject("Sparks");
					ParticleSystem particleSystem2 = gameObject2.AddComponent<ParticleSystem>();
					particleSystem2.transform.position = waver.pointerPos;
					ParticleSystem.MainModule main2 = particleSystem2.main;
					main2.startSize = new ParticleSystem.MinMaxCurve(0.05f, 0.2f);
					main2.startLifetime = new ParticleSystem.MinMaxCurve(0.2f, 0.5f);
					main2.startSpeed = new ParticleSystem.MinMaxCurve(2f, 4f);
					main2.startColor = Color.red;
					main2.loop = false;
					ParticleSystem.EmissionModule emission2 = particleSystem2.emission;
					emission2.rateOverTime = 0f;
					emission2.SetBursts(new ParticleSystem.Burst[]
					{
						new ParticleSystem.Burst(0f, 100)
					});
					ParticleSystem.ShapeModule shape2 = particleSystem2.shape;
					shape2.shapeType = 0;
					shape2.radius = 0.1f;
					ParticleSystemRenderer component3 = particleSystem2.GetComponent<ParticleSystemRenderer>();
					component3.material = new Material(Shader.Find("Particles/Standard Unlit"));
					GameObject gameObject3 = new GameObject("ExplosionLight");
					Light light = gameObject3.AddComponent<Light>();
					light.transform.position = waver.pointerPos;
					light.intensity = 4f;
					light.range = 3f;
					light.color = Color.red;
					particleSystem.Play();
					particleSystem2.Play();
					global::UnityEngine.Object.Destroy(gameObject, 3f);
					global::UnityEngine.Object.Destroy(gameObject2, 0.5f);
					global::UnityEngine.Object.Destroy(gameObject3, 0.2f);
				}
			}
		}

		// Token: 0x06000167 RID: 359 RVA: 0x00016BD0 File Offset: 0x00014DD0
		public static void Tracersv2()
		{
			bool flag = PhotonNetwork.InLobby || PhotonNetwork.InRoom;
			bool flag2 = flag;
			if (flag2)
			{
				foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
				{
					bool flag3 = !vrrig.isOfflineVRRig;
					bool flag4 = flag3;
					if (flag4)
					{
						GameObject gameObject = new GameObject("Line");
						LineRenderer lineRenderer = gameObject.AddComponent<LineRenderer>();
						Color[] array = new Color[]
						{
							new Color(0f, 0f, 1f),
							new Color(0f, 1f, 0f),
							new Color(1f, 0f, 0f)
						};
						float num = 3f;
						float num2 = Time.time % num / num;
						int num3 = (int)(num2 * (float)(array.Length - 1));
						int num4 = (num3 + 1) % array.Length;
						float num5 = num2 * (float)(array.Length - 1) % 1f;
						Color color = Color.Lerp(array[num3], array[num4], num5);
						lineRenderer.startWidth = 0.05f;
						lineRenderer.endWidth = 0.05f;
						lineRenderer.startColor = color;
						lineRenderer.endColor = color;
						lineRenderer.SetPositions(new Vector3[]
						{
							GTPlayer.Instance.rightControllerTransform.position,
							vrrig.transform.position
						});
						lineRenderer.material.shader = Shader.Find("GUI/Text Shader");
						global::UnityEngine.Object.Destroy(gameObject, Time.deltaTime);
					}
				}
			}
		}

		// Token: 0x06000168 RID: 360 RVA: 0x00016DBC File Offset: 0x00014FBC
		public static void CastLightningBoltGun()
		{
			GunLib.Waver waver = GunLib.nolockshoot();
			bool flag = waver != null;
			if (flag)
			{
				bool flag2 = waver.shooting && waver.triggered;
				if (flag2)
				{
					Vector3 vector = waver.pointerPos + new Vector3(0f, 10f, 0f);
					Vector3 pointerPos = waver.pointerPos;
					Visuals.SpawnLightning(vector, Quaternion.identity, pointerPos);
				}
			}
		}

		// Token: 0x06000169 RID: 361 RVA: 0x00016E28 File Offset: 0x00015028
		public static void SpawnLightning(Vector3 start, Quaternion rotation, Vector3 end)
		{
			GameObject gameObject = new GameObject("LightningBolt");
			LineRenderer lineRenderer = gameObject.AddComponent<LineRenderer>();
			lineRenderer.positionCount = 10;
			lineRenderer.startWidth = 0.05f;
			lineRenderer.endWidth = 0.2f;
			lineRenderer.material = new Material(Shader.Find("Particles/Standard Unlit"));
			for (int i = 0; i < 10; i++)
			{
				float num = (float)i / 9f;
				Vector3 vector = Vector3.Lerp(start, end, num);
				vector += new Vector3(global::UnityEngine.Random.Range(-0.3f, 0.3f), global::UnityEngine.Random.Range(-0.3f, 0.3f), 0f);
				lineRenderer.SetPosition(i, vector);
			}
			GameObject gameObject2 = new GameObject("LightningSparks");
			gameObject2.transform.position = end;
			ParticleSystem particleSystem = gameObject2.AddComponent<ParticleSystem>();
			ParticleSystem.MainModule main = particleSystem.main;
			bool flag = Visuals.isLightningRainbow;
			if (flag)
			{
				main.startColor = new ParticleSystem.MinMaxGradient(Color.HSVToRGB(Visuals.hue, 1f, 1f), Color.white);
				lineRenderer.startColor = Color.HSVToRGB(Visuals.hue, 1f, 1f);
				lineRenderer.endColor = Color.HSVToRGB(Visuals.hue, 1f, 1f);
			}
			else
			{
				main.startColor = new ParticleSystem.MinMaxGradient(Color.red, Color.white);
				lineRenderer.startColor = Color.red;
				lineRenderer.endColor = Visuals.Lightred;
			}
			main.startSize = 0.5f;
			main.startLifetime = 0.2f;
			main.startSpeed = 2f;
			particleSystem.emission.rateOverTime = 50f;
			ParticleSystem.ShapeModule shape = particleSystem.shape;
			shape.shapeType = 0;
			shape.radius = 0.5f;
			ParticleSystemRenderer component = particleSystem.GetComponent<ParticleSystemRenderer>();
			component.material = new Material(Shader.Find("Particles/Standard Unlit"));
			particleSystem.Play();
			global::UnityEngine.Object.Destroy(gameObject, 0.3f);
			global::UnityEngine.Object.Destroy(gameObject2, 0.5f);
		}

		// Token: 0x0600016A RID: 362 RVA: 0x00017060 File Offset: 0x00015260
		public static void Rainbow(bool a)
		{
			if (a)
			{
				Visuals.hue += Time.deltaTime * 0.5f;
				bool flag = Visuals.hue > 1f;
				if (flag)
				{
					Visuals.hue = 0f;
				}
				Visuals.isLightningRainbow = true;
			}
			else
			{
				Visuals.isLightningRainbow = false;
			}
		}

		// Token: 0x0600016B RID: 363 RVA: 0x000170B8 File Offset: 0x000152B8
		public static void LightningAura()
		{
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			if (rightGrab)
			{
				Vector3 vector = GorillaTagger.Instance.bodyCollider.gameObject.transform.position + new Vector3((float)global::UnityEngine.Random.Range(-10, 10), (float)global::UnityEngine.Random.Range(10, 50), (float)global::UnityEngine.Random.Range(-10, 10));
				Vector3 vector2 = vector + Quaternion.identity * Vector3.down * 10f;
				Visuals.SpawnLightning(vector, Quaternion.identity, vector2);
			}
		}

		// Token: 0x0600016C RID: 364 RVA: 0x00017148 File Offset: 0x00015348
		public static void CastLightningBolt()
		{
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			if (rightGrab)
			{
				Vector3 position = GorillaTagger.Instance.rightHandTransform.position;
				Quaternion rotation = GorillaTagger.Instance.rightHandTransform.rotation;
				Vector3 vector = position + rotation * Vector3.down * 10f;
				Visuals.SpawnLightning(position, rotation, vector);
			}
			bool leftGrab = ControllerInputPoller.instance.leftGrab;
			if (leftGrab)
			{
				Vector3 position2 = GorillaTagger.Instance.leftHandTransform.position;
				Quaternion rotation2 = GorillaTagger.Instance.leftHandTransform.rotation;
				Vector3 vector2 = position2 + rotation2 * Vector3.down * 10f;
				Visuals.SpawnLightning(position2, rotation2, vector2);
			}
		}

		// Token: 0x0600016D RID: 365 RVA: 0x00017210 File Offset: 0x00015410
		public static void BlackHoleGun()
		{
			GunLib.Waver waver = GunLib.nolockshoot();
			bool flag = waver != null;
			if (flag)
			{
				bool flag2 = waver.triggered && waver.shooting;
				if (flag2)
				{
					Visuals.pos = waver.pointerPos + new Vector3(0f, 2f, 0f);
				}
			}
		}

		// Token: 0x0600016E RID: 366 RVA: 0x0001726C File Offset: 0x0001546C
		public static void StopSound()
		{
			bool flag = ButtonInteractor.ausrc != null;
			if (flag)
			{
				ButtonInteractor.ausrc.Stop();
				OP.ina = Time.time;
			}
		}

		// Token: 0x0600016F RID: 367 RVA: 0x000172A0 File Offset: 0x000154A0
		public static void CreateBlackHole(float Size, bool isSlowlyGrowing)
		{
			bool flag = Time.time > OP.ina;
			if (flag)
			{
				OP.ina = Time.time + 61f;
				ButtonInteractor.Play2DAudio(ButtonInteractor.LoadSoundFromURL("https://github.com/MalzBuilds/btnsound/raw/main/b.mp3", "b.mp3"), 0.5f);
			}
			bool flag2 = !isSlowlyGrowing;
			if (flag2)
			{
				Visuals.particleSystem = new GameObject("BlackHoleEffect")
				{
					transform = 
					{
						position = Visuals.pos
					}
				}.AddComponent<ParticleSystem>();
				ParticleSystem.MainModule main = Visuals.particleSystem.main;
				main.startColor = new ParticleSystem.MinMaxGradient(new Color(0f, 0f, 0f), new Color(0.1f, 0.1f, 0.1f));
				bool flag3 = Size > 2.5f;
				if (flag3)
				{
					main.startSize = 0.4f * Size / 2.5f;
				}
				else
				{
					main.startSize = 0.3f;
				}
				main.startRotationYMultiplier = 0.5f;
				main.startSpeed = 0.5f * Size;
				main.startLifetime = 2f;
				main.loop = true;
				main.simulationSpace = 1;
				bool flag4 = (int)Size > 0;
				if (flag4)
				{
					main.maxParticles = 300 * (int)Size;
				}
				else
				{
					main.maxParticles = 75;
				}
				ParticleSystemRenderer component = Visuals.particleSystem.GetComponent<ParticleSystemRenderer>();
				component.material = new Material(Shader.Find("Particles/Standard Unlit"));
				Visuals.particleSystem.emission.rateOverTime = 30f * Size;
				ParticleSystem.RotationOverLifetimeModule rotationOverLifetime = Visuals.particleSystem.rotationOverLifetime;
				rotationOverLifetime.enabled = true;
				rotationOverLifetime.yMultiplier = 5f;
				ParticleSystem.ShapeModule shape = Visuals.particleSystem.shape;
				shape.shapeType = 0;
				shape.radius = 2.5f * Size;
				shape.randomDirectionAmount = 0.1f;
				Visuals.particleSystem.rotationOverLifetime.z = new ParticleSystem.MinMaxCurve(0.5f, 1f);
				ParticleSystem.VelocityOverLifetimeModule velocityOverLifetime = Visuals.particleSystem.velocityOverLifetime;
				velocityOverLifetime.x = new ParticleSystem.MinMaxCurve(0f, 0f);
				velocityOverLifetime.y = new ParticleSystem.MinMaxCurve(0f, 0f);
				velocityOverLifetime.z = new ParticleSystem.MinMaxCurve(-1f, -2f);
				GameObject gameObject = new GameObject("BlackHoleRing");
				gameObject.transform.position = Visuals.pos;
				gameObject.transform.rotation = Quaternion.Euler(90f, 0f, 0f);
				ParticleSystem particleSystem = gameObject.AddComponent<ParticleSystem>();
				ParticleSystem.MainModule main2 = particleSystem.main;
				int num = global::UnityEngine.Random.Range(20, 76);
				main2.startColor = new Color((float)num / 255f, (float)num / 255f, (float)num / 255f);
				main2.startSize = Size / 4f;
				main2.startSpeed = 0f;
				main2.startLifetime = 2f;
				main2.startRotationY = 90f;
				main2.loop = true;
				ParticleSystemRenderer component2 = particleSystem.GetComponent<ParticleSystemRenderer>();
				component2.material = new Material(Shader.Find("Particles/Standard Unlit"));
				ParticleSystem.ShapeModule shape2 = particleSystem.shape;
				shape2.shapeType = 17;
				shape2.radius = 5f * Size;
				shape2.angle = 5f;
				particleSystem.Play();
				global::UnityEngine.Object.Destroy(gameObject, 2f);
				global::UnityEngine.Object.Destroy(Visuals.particleSystem.gameObject, 2f);
				Visuals.particleSystem.Play();
				global::UnityEngine.Object.Destroy(Visuals.particleSystem, 2f);
				Rigidbody attachedRigidbody = GTPlayer.Instance.bodyCollider.attachedRigidbody;
				Vector3 position = Visuals.particleSystem.gameObject.transform.position;
				bool flag5 = attachedRigidbody != null;
				if (flag5)
				{
					Vector3 vector = position - GTPlayer.Instance.bodyCollider.transform.position;
					float magnitude = vector.magnitude;
					float num2 = Mathf.Clamp(1000f / magnitude, 0f, 10f);
					attachedRigidbody.AddForce(vector.normalized * num2 * Size * Size * 2f / Vector3.Distance(GTPlayer.Instance.bodyCollider.transform.position, position) * Time.deltaTime, ForceMode.VelocityChange);
				}
				Collider[] array = Physics.OverlapSphere(position, 10f * Size * 5f);
				foreach (Collider collider in array)
				{
					Rigidbody component3 = collider.GetComponent<Rigidbody>();
					bool flag6 = component3 != null;
					if (flag6)
					{
						Vector3 vector2 = position - collider.transform.position;
						float magnitude2 = vector2.magnitude;
						float num3 = Mathf.Clamp(1000f / magnitude2, 0f, 10f);
						component3.AddForce(vector2.normalized * 2f * Size * Visuals.size * num3 * Time.deltaTime, ForceMode.VelocityChange);
					}
					bool flag7 = Vector3.Distance(collider.transform.position, position) < 1f * Size;
					if (flag7)
					{
						global::UnityEngine.Object.Destroy(collider.gameObject);
					}
				}
				bool flag8 = Vector3.Distance(GTPlayer.Instance.bodyCollider.transform.position, position) < 1f * Size;
				if (flag8)
				{
					Thread.Sleep(2000);
					Application.Quit();
				}
				foreach (ParticleSystem particleSystem2 in global::UnityEngine.Object.FindObjectsOfType<ParticleSystem>())
				{
					bool flag9 = particleSystem2.gameObject.name == particleSystem.gameObject.name || particleSystem2.gameObject.name == Visuals.particleSystem.gameObject.name;
					if (!flag9)
					{
						bool flag10 = Vector3.Distance(particleSystem2.transform.position, position) < Size * Size * 8f && particleSystem2 != component;
						if (flag10)
						{
							ParticleSystem.VelocityOverLifetimeModule velocityOverLifetime2 = particleSystem2.velocityOverLifetime;
							velocityOverLifetime2.enabled = true;
							velocityOverLifetime2.orbitalY = 5f;
							velocityOverLifetime2.radial = -Size * 0.1f / 10f;
							bool flag11 = Vector3.Distance(particleSystem2.transform.position, position) < Size;
							if (flag11)
							{
								global::UnityEngine.Object.Destroy(particleSystem2.gameObject);
							}
						}
					}
				}
			}
			else if (isSlowlyGrowing)
			{
				Visuals.particleSystem = new GameObject("BlackHoleEffect")
				{
					transform = 
					{
						position = Visuals.pos
					}
				}.AddComponent<ParticleSystem>();
				ParticleSystem.MainModule main3 = Visuals.particleSystem.main;
				main3.startColor = new ParticleSystem.MinMaxGradient(new Color(0f, 0f, 0f), new Color(0.1f, 0.1f, 0.1f));
				bool flag12 = Visuals.b > 2.5f;
				if (flag12)
				{
					main3.startSize = 0.4f * Visuals.b / 2.5f;
				}
				else
				{
					main3.startSize = 0.3f;
				}
				main3.startRotationYMultiplier = 0.5f;
				main3.startSpeed = 0.5f * Visuals.b;
				main3.startLifetime = 2f;
				main3.loop = true;
				main3.simulationSpace = 1;
				bool flag13 = (int)Visuals.b > 0;
				if (flag13)
				{
					main3.maxParticles = 300 * (int)Visuals.b;
				}
				else
				{
					main3.maxParticles = 75;
				}
				ParticleSystemRenderer component4 = Visuals.particleSystem.GetComponent<ParticleSystemRenderer>();
				component4.material = new Material(Shader.Find("Particles/Standard Unlit"));
				Visuals.particleSystem.emission.rateOverTime = 30f * Visuals.b;
				ParticleSystem.RotationOverLifetimeModule rotationOverLifetime2 = Visuals.particleSystem.rotationOverLifetime;
				rotationOverLifetime2.enabled = true;
				rotationOverLifetime2.yMultiplier = 5f;
				ParticleSystem.ShapeModule shape3 = Visuals.particleSystem.shape;
				shape3.shapeType = 0;
				shape3.radius = 2.5f * Visuals.b;
				shape3.randomDirectionAmount = 0.1f;
				Visuals.particleSystem.rotationOverLifetime.z = new ParticleSystem.MinMaxCurve(0.5f, 1f);
				ParticleSystem.VelocityOverLifetimeModule velocityOverLifetime3 = Visuals.particleSystem.velocityOverLifetime;
				velocityOverLifetime3.x = new ParticleSystem.MinMaxCurve(0f, 0f);
				velocityOverLifetime3.y = new ParticleSystem.MinMaxCurve(0f, 0f);
				velocityOverLifetime3.z = new ParticleSystem.MinMaxCurve(-1f, -2f);
				GameObject gameObject2 = new GameObject("BlackHoleRing");
				gameObject2.transform.position = Visuals.pos;
				ParticleSystem particleSystem3 = gameObject2.AddComponent<ParticleSystem>();
				ParticleSystem.MainModule main4 = particleSystem3.main;
				int num4 = global::UnityEngine.Random.Range(20, 76);
				gameObject2.transform.rotation = Quaternion.Euler(90f, 0f, 0f);
				main4.startColor = new Color((float)num4 / 255f, (float)num4 / 255f, (float)num4 / 255f);
				main4.startSize = Visuals.b / 4f;
				main4.startSpeed = 0f;
				main4.startLifetime = 2f;
				main4.startRotationY = 90f;
				main4.loop = true;
				ParticleSystemRenderer component5 = particleSystem3.GetComponent<ParticleSystemRenderer>();
				component5.material = new Material(Shader.Find("Particles/Standard Unlit"));
				ParticleSystem.ShapeModule shape4 = particleSystem3.shape;
				shape4.shapeType = 17;
				shape4.radius = 5f * Visuals.b;
				shape4.angle = 5f;
				particleSystem3.Play();
				global::UnityEngine.Object.Destroy(gameObject2, 2f);
				global::UnityEngine.Object.Destroy(Visuals.particleSystem.gameObject, 2f);
				Visuals.b += 0.0005f * Visuals.b;
				bool flag14 = Visuals.t == null;
				if (flag14)
				{
					GameObject gameObject3 = new GameObject("BlackHoleText");
					Visuals.t = gameObject3.AddComponent<TextMeshPro>();
					Visuals.t.alignment = 514;
					Visuals.t.fontSize = 1f;
					Visuals.t.fontStyle = 32;
					Visuals.t.color = Color.white;
				}
				Visuals.t.text = "Size: " + (Mathf.Round(10f * Visuals.b) / 10f).ToString();
				bool flag15 = Visuals.b >= 100f;
				if (flag15)
				{
					Visuals.t.color = Visuals.RedTransparent;
				}
				else
				{
					bool flag16 = Visuals.b >= 50f && Visuals.b < 100f;
					if (flag16)
					{
						Visuals.t.color = Visuals.OrangeRedTransparent;
					}
					else
					{
						bool flag17 = Visuals.b >= 25f && Visuals.b < 50f;
						if (flag17)
						{
							Visuals.t.color = Visuals.redTransparent;
						}
						else
						{
							bool flag18 = Visuals.b >= 10f && Visuals.b < 25f;
							if (flag18)
							{
								Visuals.t.color = Visuals.GreenTransparent;
							}
							else
							{
								bool flag19 = Visuals.b >= 5f && Visuals.b < 10f;
								if (flag19)
								{
									Visuals.t.color = Visuals.SkyBlue;
								}
								else
								{
									Visuals.t.color = Color.white;
								}
							}
						}
					}
				}
				Visuals.t.transform.position = GorillaTagger.Instance.rightHandTransform.position + new Vector3(0f, 0.12f, 0f);
				Visuals.t.transform.rotation = Quaternion.LookRotation(-GorillaTagger.Instance.rightHandTransform.up);
				Visuals.particleSystem.Play();
				global::UnityEngine.Object.Destroy(Visuals.particleSystem, 2f);
				Rigidbody attachedRigidbody2 = GTPlayer.Instance.bodyCollider.attachedRigidbody;
				Vector3 position2 = Visuals.particleSystem.gameObject.transform.position;
				bool flag20 = attachedRigidbody2 != null;
				if (flag20)
				{
					Vector3 vector3 = position2 - GTPlayer.Instance.bodyCollider.transform.position;
					float magnitude3 = vector3.magnitude;
					float num5 = Mathf.Clamp(1000f / magnitude3, 0f, 10f);
					attachedRigidbody2.AddForce(vector3.normalized * num5 * Visuals.b * Visuals.b * 2f / Vector3.Distance(GTPlayer.Instance.bodyCollider.transform.position, position2) * Time.deltaTime, ForceMode.VelocityChange);
				}
				Collider[] array4 = Physics.OverlapSphere(position2, 50f * Visuals.b);
				foreach (Collider collider2 in array4)
				{
					Rigidbody component6 = collider2.GetComponent<Rigidbody>();
					bool flag21 = component6 != null;
					if (flag21)
					{
						Vector3 vector4 = position2 - collider2.transform.position;
						float magnitude4 = vector4.magnitude;
						float num6 = Mathf.Clamp(1000f / magnitude4, 0f, 10f);
						component6.AddForce(vector4.normalized * num6 * 2f * Visuals.b * Visuals.b * Time.deltaTime, ForceMode.VelocityChange);
					}
					bool flag22 = Vector3.Distance(collider2.transform.position, position2) < Visuals.b;
					if (flag22)
					{
						Visuals.b += collider2.gameObject.transform.localScale.x / 100f;
						collider2.transform.position.y = float.MaxValue;
						global::UnityEngine.Object.Destroy(collider2.gameObject);
					}
				}
				foreach (ParticleSystem particleSystem4 in global::UnityEngine.Object.FindObjectsOfType<ParticleSystem>())
				{
					bool flag23 = particleSystem4.gameObject.name == particleSystem3.gameObject.name || particleSystem4.gameObject.name == Visuals.particleSystem.gameObject.name;
					if (!flag23)
					{
						bool flag24 = Vector3.Distance(particleSystem4.transform.position, Visuals.particleSystem.gameObject.transform.position) < Visuals.b * Visuals.b * 8f && particleSystem4 != component4;
						if (flag24)
						{
							ParticleSystem.VelocityOverLifetimeModule velocityOverLifetime4 = particleSystem4.velocityOverLifetime;
							velocityOverLifetime4.enabled = true;
							Vector3 normalized = (Visuals.particleSystem.gameObject.transform.position - particleSystem4.transform.position).normalized;
							float num7 = Vector3.Distance(particleSystem4.transform.position, Visuals.particleSystem.gameObject.transform.position);
							float num8 = Mathf.Lerp(-5f, -50f, 1f - num7 / (Visuals.b * Visuals.b * 8f));
							Vector3 vector5 = Vector3.Cross(normalized, Vector3.up).normalized * Mathf.Sqrt(Mathf.Abs(num8)) * 0.5f;
							velocityOverLifetime4.x = new ParticleSystem.MinMaxCurve(normalized.x * num8 + vector5.x);
							velocityOverLifetime4.y = new ParticleSystem.MinMaxCurve(normalized.y * num8 + vector5.y);
							velocityOverLifetime4.z = new ParticleSystem.MinMaxCurve(normalized.z * num8 + vector5.z);
							bool flag25 = num7 < Visuals.b * 4f;
							if (flag25)
							{
								num8 = Mathf.Lerp(-50f, -200f, 1f - num7 / (Visuals.b * 4f));
								vector5 = Vector3.Cross(normalized, Vector3.up).normalized * Mathf.Sqrt(Mathf.Abs(num8)) * 0.75f;
								velocityOverLifetime4.x = new ParticleSystem.MinMaxCurve(normalized.x * num8 + vector5.x);
								velocityOverLifetime4.y = new ParticleSystem.MinMaxCurve(normalized.y * num8 + vector5.y);
								velocityOverLifetime4.z = new ParticleSystem.MinMaxCurve(normalized.z * num8 + vector5.z);
							}
							bool flag26 = Vector3.Distance(particleSystem4.transform.position, Visuals.particleSystem.gameObject.transform.position) < Visuals.b;
							if (flag26)
							{
								Visuals.b += particleSystem4.gameObject.transform.localScale.x / 100f;
								particleSystem4.transform.position.y = float.MaxValue;
								global::UnityEngine.Object.Destroy(particleSystem4.gameObject);
							}
						}
					}
				}
			}
		}

		// Token: 0x040000B0 RID: 176
		public static float size = 0.1f;

		// Token: 0x040000B1 RID: 177
		public static Color32 Red = new Color32(byte.MaxValue, 0, 0, byte.MaxValue);

		// Token: 0x040000B2 RID: 178
		public static Color32 DarkRed = new Color32(140, 0, 0, byte.MaxValue);

		// Token: 0x040000B3 RID: 179
		public static Color32 Salmon = new Color32(250, 128, 114, byte.MaxValue);

		// Token: 0x040000B4 RID: 180
		public static Color32 WineRed = new Color32(123, 0, 0, byte.MaxValue);

		// Token: 0x040000B5 RID: 181
		public static Color32 IndianRed = new Color32(205, 92, 92, byte.MaxValue);

		// Token: 0x040000B6 RID: 182
		public static Color32 Crimson = new Color32(220, 20, 60, byte.MaxValue);

		// Token: 0x040000B7 RID: 183
		public static Color32 FireBrick = new Color32(178, 34, 34, byte.MaxValue);

		// Token: 0x040000B8 RID: 184
		public static Color32 Coral = new Color32(byte.MaxValue, 127, 80, byte.MaxValue);

		// Token: 0x040000B9 RID: 185
		public static Color32 Tomato = new Color32(byte.MaxValue, 99, 71, byte.MaxValue);

		// Token: 0x040000BA RID: 186
		public static Color32 Maroon = new Color32(128, 0, 0, byte.MaxValue);

		// Token: 0x040000BB RID: 187
		public static Color32 Green = new Color32(0, byte.MaxValue, 0, byte.MaxValue);

		// Token: 0x040000BC RID: 188
		public static Color32 Lime = new Color32(0, 128, 0, byte.MaxValue);

		// Token: 0x040000BD RID: 189
		public static Color32 DarkGreen = new Color32(0, 100, 0, byte.MaxValue);

		// Token: 0x040000BE RID: 190
		public static Color32 Olive = new Color32(128, 128, 0, byte.MaxValue);

		// Token: 0x040000BF RID: 191
		public static Color32 ForestGreen = new Color32(34, 139, 34, byte.MaxValue);

		// Token: 0x040000C0 RID: 192
		public static Color32 SeaGreen = new Color32(46, 139, 87, byte.MaxValue);

		// Token: 0x040000C1 RID: 193
		public static Color32 MediumSeaGreen = new Color32(60, 179, 113, byte.MaxValue);

		// Token: 0x040000C2 RID: 194
		public static Color32 Aquamarine = new Color32(127, byte.MaxValue, 212, byte.MaxValue);

		// Token: 0x040000C3 RID: 195
		public static Color32 MediumAquamarine = new Color32(102, 205, 170, byte.MaxValue);

		// Token: 0x040000C4 RID: 196
		public static Color32 DarkSeaGreen = new Color32(143, 188, 143, byte.MaxValue);

		// Token: 0x040000C5 RID: 197
		public static Color32 Blue = new Color32(0, 0, byte.MaxValue, byte.MaxValue);

		// Token: 0x040000C6 RID: 198
		public static Color32 Navy = new Color32(0, 0, 128, byte.MaxValue);

		// Token: 0x040000C7 RID: 199
		public static Color32 DarkBlue = new Color32(0, 0, 160, byte.MaxValue);

		// Token: 0x040000C8 RID: 200
		public static Color32 RoyalBlue = new Color32(65, 105, 225, byte.MaxValue);

		// Token: 0x040000C9 RID: 201
		public static Color32 DodgerBlue = new Color32(30, 144, byte.MaxValue, byte.MaxValue);

		// Token: 0x040000CA RID: 202
		public static Color32 DarkDodgerBlue = new Color32(8, 90, 177, byte.MaxValue);

		// Token: 0x040000CB RID: 203
		public static Color32 DeepSkyBlue = new Color32(0, 191, byte.MaxValue, byte.MaxValue);

		// Token: 0x040000CC RID: 204
		public static Color32 SkyBlue = new Color32(135, 206, 235, byte.MaxValue);

		// Token: 0x040000CD RID: 205
		public static Color32 SteelBlue = new Color32(70, 130, 180, byte.MaxValue);

		// Token: 0x040000CE RID: 206
		public static Color32 Cyan = new Color32(0, byte.MaxValue, byte.MaxValue, byte.MaxValue);

		// Token: 0x040000CF RID: 207
		public static Color32 red = new Color32(byte.MaxValue, byte.MaxValue, 0, byte.MaxValue);

		// Token: 0x040000D0 RID: 208
		public static Color32 Gold = new Color32(byte.MaxValue, 215, 0, byte.MaxValue);

		// Token: 0x040000D1 RID: 209
		public static Color32 Lightred = new Color32(byte.MaxValue, byte.MaxValue, 224, byte.MaxValue);

		// Token: 0x040000D2 RID: 210
		public static Color32 LemonChiffon = new Color32(byte.MaxValue, 250, 205, byte.MaxValue);

		// Token: 0x040000D3 RID: 211
		public static Color32 Khaki = new Color32(240, 230, 140, byte.MaxValue);

		// Token: 0x040000D4 RID: 212
		public static Color32 PaleGoldenrod = new Color32(238, 232, 170, byte.MaxValue);

		// Token: 0x040000D5 RID: 213
		public static Color32 LightGoldenrodred = new Color32(250, 250, 210, byte.MaxValue);

		// Token: 0x040000D6 RID: 214
		public static Color32 Orange = new Color32(byte.MaxValue, 165, 0, byte.MaxValue);

		// Token: 0x040000D7 RID: 215
		public static Color32 DarkOrange = new Color32(byte.MaxValue, 140, 0, byte.MaxValue);

		// Token: 0x040000D8 RID: 216
		public static Color32 RedOrange = new Color32(byte.MaxValue, 69, 0, byte.MaxValue);

		// Token: 0x040000D9 RID: 217
		public static Color32 PeachPuff = new Color32(byte.MaxValue, 218, 185, byte.MaxValue);

		// Token: 0x040000DA RID: 218
		public static Color32 DarkGoldenrod = new Color32(184, 134, 11, byte.MaxValue);

		// Token: 0x040000DB RID: 219
		public static Color32 Peru = new Color32(205, 133, 63, byte.MaxValue);

		// Token: 0x040000DC RID: 220
		public static Color32 OrangeRed = new Color32(byte.MaxValue, 69, 0, byte.MaxValue);

		// Token: 0x040000DD RID: 221
		public static Color32 Magenta = new Color32(byte.MaxValue, 0, byte.MaxValue, byte.MaxValue);

		// Token: 0x040000DE RID: 222
		public static Color32 Purple = new Color32(123, 3, 252, byte.MaxValue);

		// Token: 0x040000DF RID: 223
		public static Color32 Lavender = new Color32(230, 230, 250, byte.MaxValue);

		// Token: 0x040000E0 RID: 224
		public static Color32 Plum = new Color32(221, 160, 221, byte.MaxValue);

		// Token: 0x040000E1 RID: 225
		public static Color32 Indigo = new Color32(75, 0, 130, byte.MaxValue);

		// Token: 0x040000E2 RID: 226
		public static Color32 MediumOrchid = new Color32(186, 85, 211, byte.MaxValue);

		// Token: 0x040000E3 RID: 227
		public static Color32 SlateBlue = new Color32(106, 90, 205, byte.MaxValue);

		// Token: 0x040000E4 RID: 228
		public static Color32 DarkSlateBlue = new Color32(72, 61, 139, byte.MaxValue);

		// Token: 0x040000E5 RID: 229
		public static Color32 Pink = new Color32(byte.MaxValue, 192, 203, byte.MaxValue);

		// Token: 0x040000E6 RID: 230
		public static Color32 LightSalmon = new Color32(byte.MaxValue, 160, 122, byte.MaxValue);

		// Token: 0x040000E7 RID: 231
		public static Color32 DarkSalmon = new Color32(233, 150, 122, byte.MaxValue);

		// Token: 0x040000E8 RID: 232
		public static Color32 LightCoral = new Color32(240, 128, 128, byte.MaxValue);

		// Token: 0x040000E9 RID: 233
		public static Color32 MistyRose = new Color32(byte.MaxValue, 228, 225, byte.MaxValue);

		// Token: 0x040000EA RID: 234
		public static Color32 HotPink = new Color32(byte.MaxValue, 105, 180, byte.MaxValue);

		// Token: 0x040000EB RID: 235
		public static Color32 DeepPink = new Color32(byte.MaxValue, 20, 147, byte.MaxValue);

		// Token: 0x040000EC RID: 236
		public static Color32 Brown = new Color32(139, 69, 19, byte.MaxValue);

		// Token: 0x040000ED RID: 237
		public static Color32 RosyBrown = new Color32(188, 143, 143, byte.MaxValue);

		// Token: 0x040000EE RID: 238
		public static Color32 SaddleBrown = new Color32(139, 69, 19, byte.MaxValue);

		// Token: 0x040000EF RID: 239
		public static Color32 Sienna = new Color32(160, 82, 45, byte.MaxValue);

		// Token: 0x040000F0 RID: 240
		public static Color32 Chocolate = new Color32(210, 105, 30, byte.MaxValue);

		// Token: 0x040000F1 RID: 241
		public static Color32 SandyBrown = new Color32(244, 164, 96, byte.MaxValue);

		// Token: 0x040000F2 RID: 242
		public static Color32 BurlyWood = new Color32(222, 184, 135, byte.MaxValue);

		// Token: 0x040000F3 RID: 243
		public static Color32 Tan = new Color32(210, 180, 140, byte.MaxValue);

		// Token: 0x040000F4 RID: 244
		public static Color32 White = new Color32(byte.MaxValue, byte.MaxValue, byte.MaxValue, byte.MaxValue);

		// Token: 0x040000F5 RID: 245
		public static Color32 Linen = new Color32(250, 240, 230, byte.MaxValue);

		// Token: 0x040000F6 RID: 246
		public static Color32 OldLace = new Color32(253, 245, 230, byte.MaxValue);

		// Token: 0x040000F7 RID: 247
		public static Color32 SeaShell = new Color32(byte.MaxValue, 245, 238, byte.MaxValue);

		// Token: 0x040000F8 RID: 248
		public static Color32 MintCream = new Color32(245, byte.MaxValue, 250, byte.MaxValue);

		// Token: 0x040000F9 RID: 249
		public static Color32 Black = new Color32(0, 0, 0, byte.MaxValue);

		// Token: 0x040000FA RID: 250
		public static Color32 Grey = new Color32(128, 128, 128, byte.MaxValue);

		// Token: 0x040000FB RID: 251
		public static Color32 LightGrey = new Color32(192, 192, 192, byte.MaxValue);

		// Token: 0x040000FC RID: 252
		public static Color32 DarkGrey = new Color32(80, 80, 80, byte.MaxValue);

		// Token: 0x040000FD RID: 253
		public static Color32 DarkerGrey = new Color32(40, 40, 40, byte.MaxValue);

		// Token: 0x040000FE RID: 254
		public static Color32 RedTransparent = new Color32(byte.MaxValue, 0, 0, 80);

		// Token: 0x040000FF RID: 255
		public static Color32 DarkRedTransparent = new Color32(180, 0, 0, 80);

		// Token: 0x04000100 RID: 256
		public static Color32 SalmonTransparent = new Color32(250, 128, 114, 80);

		// Token: 0x04000101 RID: 257
		public static Color32 IndianRedTransparent = new Color32(205, 92, 92, 80);

		// Token: 0x04000102 RID: 258
		public static Color32 CrimsonTransparent = new Color32(220, 20, 60, 80);

		// Token: 0x04000103 RID: 259
		public static Color32 WineRedTransparent = new Color32(123, 0, 0, 80);

		// Token: 0x04000104 RID: 260
		public static Color32 FireBrickTransparent = new Color32(178, 34, 34, 80);

		// Token: 0x04000105 RID: 261
		public static Color32 CoralTransparent = new Color32(byte.MaxValue, 127, 80, 80);

		// Token: 0x04000106 RID: 262
		public static Color32 TomatoTransparent = new Color32(byte.MaxValue, 99, 71, 80);

		// Token: 0x04000107 RID: 263
		public static Color32 MaroonTransparent = new Color32(128, 0, 0, 80);

		// Token: 0x04000108 RID: 264
		public static Color32 GreenTransparent = new Color32(0, byte.MaxValue, 0, 80);

		// Token: 0x04000109 RID: 265
		public static Color32 LimeTransparent = new Color32(0, 128, 0, 80);

		// Token: 0x0400010A RID: 266
		public static Color32 DarkGreenTransparent = new Color32(0, 100, 0, 80);

		// Token: 0x0400010B RID: 267
		public static Color32 OliveTransparent = new Color32(128, 128, 0, 80);

		// Token: 0x0400010C RID: 268
		public static Color32 ForestGreenTransparent = new Color32(34, 139, 34, 80);

		// Token: 0x0400010D RID: 269
		public static Color32 SeaGreenTransparent = new Color32(46, 139, 87, 80);

		// Token: 0x0400010E RID: 270
		public static Color32 MediumSeaGreenTransparent = new Color32(60, 179, 113, 80);

		// Token: 0x0400010F RID: 271
		public static Color32 AquamarineTransparent = new Color32(127, byte.MaxValue, 212, 80);

		// Token: 0x04000110 RID: 272
		public static Color32 MediumAquamarineTransparent = new Color32(102, 205, 170, 80);

		// Token: 0x04000111 RID: 273
		public static Color32 DarkSeaGreenTransparent = new Color32(143, 188, 143, 80);

		// Token: 0x04000112 RID: 274
		public static Color32 BlueTransparent = new Color32(0, 0, byte.MaxValue, 80);

		// Token: 0x04000113 RID: 275
		public static Color32 NavyTransparent = new Color32(0, 0, 128, 80);

		// Token: 0x04000114 RID: 276
		public static Color32 DarkBlueTransparent = new Color32(0, 0, 139, 80);

		// Token: 0x04000115 RID: 277
		public static Color32 RoyalBlueTransparent = new Color32(65, 105, 225, 80);

		// Token: 0x04000116 RID: 278
		public static Color32 DodgerBlueTransparent = new Color32(30, 144, byte.MaxValue, 80);

		// Token: 0x04000117 RID: 279
		public static Color32 DarkDodgerBlueTransparent = new Color32(8, 90, 177, 80);

		// Token: 0x04000118 RID: 280
		public static Color32 DeepSkyBlueTransparent = new Color32(0, 191, byte.MaxValue, 80);

		// Token: 0x04000119 RID: 281
		public static Color32 SkyBlueTransparent = new Color32(135, 206, 235, 80);

		// Token: 0x0400011A RID: 282
		public static Color32 SteelBlueTransparent = new Color32(70, 130, 180, 80);

		// Token: 0x0400011B RID: 283
		public static Color32 CyanTransparent = new Color32(0, byte.MaxValue, byte.MaxValue, 80);

		// Token: 0x0400011C RID: 284
		public static Color32 redTransparent = new Color32(byte.MaxValue, byte.MaxValue, 0, 80);

		// Token: 0x0400011D RID: 285
		public static Color32 GoldTransparent = new Color32(byte.MaxValue, 215, 0, 80);

		// Token: 0x0400011E RID: 286
		public static Color32 LightredTransparent = new Color32(byte.MaxValue, byte.MaxValue, 224, 80);

		// Token: 0x0400011F RID: 287
		public static Color32 LemonChiffonTransparent = new Color32(byte.MaxValue, 250, 205, 80);

		// Token: 0x04000120 RID: 288
		public static Color32 KhakiTransparent = new Color32(240, 230, 140, 80);

		// Token: 0x04000121 RID: 289
		public static Color32 PaleGoldenrodTransparent = new Color32(238, 232, 170, 80);

		// Token: 0x04000122 RID: 290
		public static Color32 LightGoldenrodredTransparent = new Color32(250, 250, 210, 80);

		// Token: 0x04000123 RID: 291
		public static Color32 OrangeTransparent = new Color32(byte.MaxValue, 165, 0, 80);

		// Token: 0x04000124 RID: 292
		public static Color32 DarkOrangeTransparent = new Color32(byte.MaxValue, 140, 0, 80);

		// Token: 0x04000125 RID: 293
		public static Color32 RedOrangeTransparent = new Color32(byte.MaxValue, 69, 0, 80);

		// Token: 0x04000126 RID: 294
		public static Color32 PeachPuffTransparent = new Color32(byte.MaxValue, 218, 185, 80);

		// Token: 0x04000127 RID: 295
		public static Color32 DarkGoldenrodTransparent = new Color32(184, 134, 11, 80);

		// Token: 0x04000128 RID: 296
		public static Color32 PeruTransparent = new Color32(205, 133, 63, 80);

		// Token: 0x04000129 RID: 297
		public static Color32 OrangeRedTransparent = new Color32(byte.MaxValue, 69, 0, 80);

		// Token: 0x0400012A RID: 298
		public static Color32 MagentaTransparent = new Color32(byte.MaxValue, 0, byte.MaxValue, 80);

		// Token: 0x0400012B RID: 299
		public static Color32 PurpleTransparent = new Color32(123, 3, 252, 80);

		// Token: 0x0400012C RID: 300
		public static Color32 LavenderTransparent = new Color32(230, 230, 250, 80);

		// Token: 0x0400012D RID: 301
		public static Color32 PlumTransparent = new Color32(221, 160, 221, 80);

		// Token: 0x0400012E RID: 302
		public static Color32 IndigoTransparent = new Color32(75, 0, 130, 80);

		// Token: 0x0400012F RID: 303
		public static Color32 MediumOrchidTransparent = new Color32(186, 85, 211, 80);

		// Token: 0x04000130 RID: 304
		public static Color32 SlateBlueTransparent = new Color32(106, 90, 205, 80);

		// Token: 0x04000131 RID: 305
		public static Color32 DarkSlateBlueTransparent = new Color32(72, 61, 139, 80);

		// Token: 0x04000132 RID: 306
		public static Color32 PinkTransparent = new Color32(byte.MaxValue, 192, 203, 80);

		// Token: 0x04000133 RID: 307
		public static Color32 LightSalmonTransparent = new Color32(byte.MaxValue, 160, 122, 80);

		// Token: 0x04000134 RID: 308
		public static Color32 DarkSalmonTransparent = new Color32(233, 150, 122, 80);

		// Token: 0x04000135 RID: 309
		public static Color32 LightCoralTransparent = new Color32(240, 128, 128, 80);

		// Token: 0x04000136 RID: 310
		public static Color32 MistyRoseTransparent = new Color32(byte.MaxValue, 228, 225, 80);

		// Token: 0x04000137 RID: 311
		public static Color32 HotPinkTransparent = new Color32(byte.MaxValue, 105, 180, 80);

		// Token: 0x04000138 RID: 312
		public static Color32 DeepPinkTransparent = new Color32(byte.MaxValue, 20, 147, 80);

		// Token: 0x04000139 RID: 313
		public static Color32 BrownTransparent = new Color32(165, 42, 42, 80);

		// Token: 0x0400013A RID: 314
		public static Color32 RosyBrownTransparent = new Color32(188, 143, 143, 80);

		// Token: 0x0400013B RID: 315
		public static Color32 SaddleBrownTransparent = new Color32(139, 69, 19, 80);

		// Token: 0x0400013C RID: 316
		public static Color32 SiennaTransparent = new Color32(160, 82, 45, 80);

		// Token: 0x0400013D RID: 317
		public static Color32 ChocolateTransparent = new Color32(210, 105, 30, 80);

		// Token: 0x0400013E RID: 318
		public static Color32 SandyBrownTransparent = new Color32(244, 164, 96, 80);

		// Token: 0x0400013F RID: 319
		public static Color32 BurlyWoodTransparent = new Color32(222, 184, 135, 80);

		// Token: 0x04000140 RID: 320
		public static Color32 TanTransparent = new Color32(210, 180, 140, 80);

		// Token: 0x04000141 RID: 321
		public static Color32 WhiteTransparent = new Color32(byte.MaxValue, byte.MaxValue, byte.MaxValue, 80);

		// Token: 0x04000142 RID: 322
		public static Color32 LightWhiteTransparent = new Color32(byte.MaxValue, byte.MaxValue, byte.MaxValue, 10);

		// Token: 0x04000143 RID: 323
		public static Color32 LinenTransparent = new Color32(250, 240, 230, 80);

		// Token: 0x04000144 RID: 324
		public static Color32 OldLaceTransparent = new Color32(253, 245, 230, 80);

		// Token: 0x04000145 RID: 325
		public static Color32 SeaShellTransparent = new Color32(byte.MaxValue, 245, 238, 80);

		// Token: 0x04000146 RID: 326
		public static Color32 MintCreamTransparent = new Color32(245, byte.MaxValue, 250, 80);

		// Token: 0x04000147 RID: 327
		public static Color32 BlackTransparent = new Color32(0, 0, 0, 80);

		// Token: 0x04000148 RID: 328
		public static Color32 GreyTransparent = new Color32(80, 80, 80, 80);

		// Token: 0x04000149 RID: 329
		public static Color32 LightGreyTransparent = new Color32(192, 192, 192, 80);

		// Token: 0x0400014A RID: 330
		public static Color32 DarkGreyTransparent = new Color32(40, 40, 40, 80);

		// Token: 0x0400014B RID: 331
		public static Color32 DarkerGreyTransparent = new Color32(40, 40, 40, 80);

		// Token: 0x0400014C RID: 332
		public static float del;

		// Token: 0x0400014D RID: 333
		public static Vector3 imagePosition = new Vector3(0f, 2f, 0f);

		// Token: 0x0400014E RID: 334
		public static Vector3 imageScale = new Vector3(4.5f, 2f, 1f);

		// Token: 0x0400014F RID: 335
		public static bool hasImage = false;

		// Token: 0x04000150 RID: 336
		public static GameObject imageObject = null;

		// Token: 0x04000151 RID: 337
		private static readonly string imagePath = "Obsidian/image-Photoroom.png";

		// Token: 0x04000152 RID: 338
		private static readonly string directoryPath = "Obsidian";

		// Token: 0x04000153 RID: 339
		private static readonly string imageUrl = "https://github.com/MalzBuilds/btnsound/raw/main/Obsidian.png";

		// Token: 0x04000154 RID: 340
		public static Texture2D texture;

		// Token: 0x04000155 RID: 341
		private static float hue;

		// Token: 0x04000156 RID: 342
		public static bool isRainbow;

		// Token: 0x04000157 RID: 343
		public static Renderer projRend = new Renderer();

		// Token: 0x04000158 RID: 344
		public static GameObject[] projs = new GameObject[0];

		// Token: 0x04000159 RID: 345
		public static Renderer[] renders = new Renderer[0];

		// Token: 0x0400015A RID: 346
		public static GameObject leftGrabbed = null;

		// Token: 0x0400015B RID: 347
		public static GameObject rightGrabbed = null;

		// Token: 0x0400015C RID: 348
		public static Collider rightCol = null;

		// Token: 0x0400015D RID: 349
		public static Collider leftCol = null;

		// Token: 0x0400015E RID: 350
		public static float Theme;

		// Token: 0x0400015F RID: 351
		public static int[] bones = new int[]
		{
			4, 3, 5, 4, 19, 18, 20, 19, 3, 18,
			21, 20, 22, 21, 25, 21, 29, 21, 31, 29,
			27, 25, 24, 22, 6, 5, 7, 6, 10, 6,
			14, 6, 16, 14, 12, 10, 9, 7
		};

		// Token: 0x04000160 RID: 352
		public static GameObject grenade = null;

		// Token: 0x04000161 RID: 353
		public static bool isHolding = false;

		// Token: 0x04000162 RID: 354
		public static Rigidbody rb = null;

		// Token: 0x04000163 RID: 355
		public static float hue2 = 0f;

		// Token: 0x04000164 RID: 356
		public static bool canGhost = true;

		// Token: 0x04000165 RID: 357
		public static bool isLightningRainbow = false;

		// Token: 0x04000166 RID: 358
		public static Vector3 pos = new Vector3(-63.2589f, 9.4352f, -65.2775f);

		// Token: 0x04000167 RID: 359
		public static ParticleSystem particleSystem = null;

		// Token: 0x04000168 RID: 360
		public static float b = 0.1f;

		// Token: 0x04000169 RID: 361
		public static TextMeshPro t = null;
	}
}
