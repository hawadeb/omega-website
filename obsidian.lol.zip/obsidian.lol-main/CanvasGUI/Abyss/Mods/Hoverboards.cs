﻿using System;
using GorillaLocomotion;
using HarmonyLib;
using UnityEngine;

namespace Abyss.Mods
{
	// Token: 0x0200000D RID: 13
	internal static class Hoverboards
	{
		// Token: 0x06000096 RID: 150 RVA: 0x00007E0C File Offset: 0x0000600C
		public static void Give()
		{
			GunLib.Waver waver = GunLib.nolockshoot();
			bool flag = waver != null;
			if (flag)
			{
				bool flag2 = waver.shooting && waver.triggered && waver.lockedOn;
				if (flag2)
				{
					Hoverboards.GiveHoverboardd(waver.Target, true);
				}
			}
		}

		// Token: 0x06000097 RID: 151 RVA: 0x00007E58 File Offset: 0x00006058
		private static void GiveHoverboardd(VRRig rig, bool state)
		{
			Transform transform = rig.transform.Find("Local Gorilla Player/RigAnchor/rig/body/HoverboardVisual");
			bool flag = transform != null;
			if (flag)
			{
				transform.gameObject.SetActive(state);
				Debug.Log("Hoverboard set to: " + state.ToString() + " on " + rig.name);
			}
			else
			{
				Debug.LogWarning("HoverboardVisual not found on: " + rig.name);
			}
		}

		// Token: 0x06000098 RID: 152 RVA: 0x00007ED0 File Offset: 0x000060D0
		public static void BoardSpeed(int maxSpeed, float pushMul)
		{
			HoverboardVisual hoverboardVisual = new HoverboardVisual();
			Traverse.Create(hoverboardVisual).Field("maxSpeed").SetValue(maxSpeed);
			Traverse.Create(hoverboardVisual).Field("pushMultiplyer").SetValue(pushMul);
			GameObject gameObject = GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/HoverboardVisual");
			gameObject = hoverboardVisual.gameObject;
		}

		// Token: 0x06000099 RID: 153 RVA: 0x00007F30 File Offset: 0x00006130
		public static void GetHoverboard()
		{
			GTPlayer instance = GTPlayer.Instance;
			bool flag = instance == null;
			if (!flag)
			{
				bool rightGrab = ControllerInputPoller.instance.rightGrab;
				if (rightGrab)
				{
					bool flag2 = Hoverboards.cangrabR;
					if (flag2)
					{
						instance.GrabPersonalHoverboard(false, Vector3.zero, GorillaTagger.Instance.rightHandTransform.transform.rotation * Quaternion.Euler(0f, 180f, 0f), Color.red);
						Hoverboards.cangrabR = false;
					}
				}
				else
				{
					Hoverboards.cangrabR = true;
				}
				bool leftGrab = ControllerInputPoller.instance.leftGrab;
				if (leftGrab)
				{
					bool flag3 = Hoverboards.cangrabL;
					if (flag3)
					{
						instance.GrabPersonalHoverboard(true, Vector3.zero, GorillaTagger.Instance.leftHandTransform.transform.rotation * Quaternion.Euler(0f, 180f, 0f), Color.red);
						Hoverboards.cangrabL = false;
					}
				}
				else
				{
					Hoverboards.cangrabL = true;
				}
			}
		}

		// Token: 0x04000060 RID: 96
		public static bool cangrabR = true;

		// Token: 0x04000061 RID: 97
		public static bool cangrabL = true;
	}
}
