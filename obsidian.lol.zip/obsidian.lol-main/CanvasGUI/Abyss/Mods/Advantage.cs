﻿using System;
using System.Collections;
using System.Collections.Generic;
using GorillaGameModes;
using GorillaLocomotion;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Abyss.Mods
{
	// Token: 0x0200000A RID: 10
	internal class Advantage
	{
		// Token: 0x06000084 RID: 132 RVA: 0x000070D0 File Offset: 0x000052D0
		public static void FlickTagGun()
		{
			GunLib.Waver waver = GunLib.lockShoot();
			bool flag = waver != null;
			if (flag)
			{
				bool flag2 = waver.shooting && waver.triggered;
				if (flag2)
				{
					GTPlayer.Instance.rightControllerTransform.position = waver.Target.transform.position;
				}
			}
		}

		// Token: 0x06000085 RID: 133 RVA: 0x00007128 File Offset: 0x00005328
		public static void FlickTagAura()
		{
			float num = 3.2f;
			List<VRRig> list = new List<VRRig>();
			foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
			{
				float num2 = Vector3.Distance(vrrig.transform.position, GorillaTagger.Instance.offlineVRRig.transform.position);
				bool flag = num2 <= num && vrrig != GorillaTagger.Instance.offlineVRRig;
				bool flag2 = flag;
				if (flag2)
				{
					list.Add(vrrig);
				}
			}
			foreach (VRRig vrrig2 in list)
			{
				bool flag3 = !vrrig2.mainSkin.material.name.Contains("fected") && GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected");
				if (flag3)
				{
					GTPlayer.Instance.rightControllerTransform.position = vrrig2.transform.position;
				}
			}
		}

		// Token: 0x06000086 RID: 134 RVA: 0x00007280 File Offset: 0x00005480
		public static void TagAll()
		{
			foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
			{
				bool flag = !GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected") && !GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("it") && !GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("ice");
				if (flag)
				{
					break;
				}
				bool flag2 = (!vrrig.mainSkin.material.name.Contains("ice") && GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("ice") && !vrrig.mainSkin.material.name.Contains("it") && GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("it")) || (!vrrig.mainSkin.material.name.Contains("fected") && GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected"));
				if (flag2)
				{
					VRRig offlineVRRig = GorillaTagger.Instance.offlineVRRig;
					offlineVRRig.enabled = false;
					offlineVRRig.transform.position = vrrig.transform.position + Vector3.up;
					GTPlayer.Instance.rightControllerTransform.position = vrrig.transform.position;
					GTPlayer.Instance.leftControllerTransform.position = vrrig.transform.position;
				}
				else
				{
					GorillaTagger.Instance.offlineVRRig.enabled = true;
					GorillaTagger.Instance.offlineVRRig.enabled = true;
				}
			}
		}

		// Token: 0x06000087 RID: 135 RVA: 0x000074C8 File Offset: 0x000056C8
		public static void TagGun()
		{
			GunLib.Waver waver = GunLib.lockShoot();
			bool flag = waver != null;
			if (flag)
			{
				bool flag2 = waver.triggered && waver.shooting && waver.lockedOn;
				if (flag2)
				{
					VRRig offlineVRRig = GorillaTagger.Instance.offlineVRRig;
					offlineVRRig.enabled = false;
					offlineVRRig.transform.position = waver.pointerPos + Vector3.up;
					GTPlayer.Instance.rightControllerTransform.position = waver.Target.transform.position;
					GTPlayer.Instance.leftControllerTransform.position = waver.Target.transform.position;
				}
				else
				{
					VRRig offlineVRRig2 = GorillaTagger.Instance.offlineVRRig;
					offlineVRRig2.enabled = true;
				}
			}
		}

		// Token: 0x06000088 RID: 136 RVA: 0x00007590 File Offset: 0x00005790
		public static void TagSelf()
		{
			foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
			{
				bool flag = ControllerInputPoller.instance.rightControllerIndexFloat > 0.5f || Mouse.current.rightButton.isPressed;
				if (flag)
				{
					bool flag2 = vrrig.mainSkin.material.name.Contains("fected") && !GorillaTagger.Instance.offlineVRRig.mainSkin.material.name.Contains("fected");
					if (flag2)
					{
						GorillaTagger.Instance.offlineVRRig.enabled = false;
						GorillaTagger.Instance.offlineVRRig.transform.position = vrrig.rightHandTransform.transform.position;
						GorillaTagger.Instance.myVRRig.transform.position = vrrig.rightHandTransform.transform.position;
					}
				}
			}
			GorillaTagger.Instance.offlineVRRig.enabled = true;
		}

		// Token: 0x06000089 RID: 137 RVA: 0x000076D4 File Offset: 0x000058D4
		public static void crash()
		{
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			if (rightGrab)
			{
				foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
				{
					GorillaTagger.Instance.offlineVRRig.enabled = false;
					GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(0f, 99999f, 0f);
					OP.GetNetworkViewFromVRRig(vrrig).SendRPC("GrabbedByPlayer", vrrig.Creator, new object[] { true, false, false });
					OP.RPCProtection();
				}
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.enabled = true;
			}
		}

		// Token: 0x0600008A RID: 138 RVA: 0x000077D4 File Offset: 0x000059D4
		public static IEnumerator Wait(float time)
		{
			yield return new WaitForSeconds(time);
			yield break;
		}

		// Token: 0x0600008B RID: 139 RVA: 0x000077E4 File Offset: 0x000059E4
		public static void crashgun2()
		{
			GunLib.Waver waver = GunLib.lockShoot();
			bool flag = waver != null;
			if (flag)
			{
				bool flag2 = waver.shooting && waver.triggered;
				if (flag2)
				{
					GorillaTagger.Instance.offlineVRRig.enabled = false;
					GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(0f, 999f, 0f);
					OP.GetNetworkViewFromVRRig(waver.Target).SendRPC("GrabbedByPlayer", waver.Target.Creator, new object[] { true, false, false });
					Advantage.Wait(0.1f);
					OP.RPCProtection();
					GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(300f, 999f, 0f);
					OP.GetNetworkViewFromVRRig(waver.Target).SendRPC("GrabbedByPlayer", waver.Target.Creator, new object[] { true, false, false });
					Advantage.Wait(0.1f);
					OP.RPCProtection();
					GorillaTagger.Instance.offlineVRRig.transform.position = new Vector3(300f, -999f, 0f);
					OP.GetNetworkViewFromVRRig(waver.Target).SendRPC("GrabbedByPlayer", waver.Target.Creator, new object[] { true, false, false });
					Advantage.Wait(0.1f);
					OP.RPCProtection();
					waver.shooting = false;
				}
				else
				{
					GorillaTagger.Instance.offlineVRRig.enabled = true;
				}
			}
		}

		// Token: 0x0600008C RID: 140 RVA: 0x000079C4 File Offset: 0x00005BC4
		public static void GrabGun()
		{
			GunLib.Waver waver = GunLib.lockShoot();
			bool flag = waver != null;
			if (flag)
			{
				bool rightGrab = ControllerInputPoller.instance.rightGrab;
				if (rightGrab)
				{
					bool flag2 = !Advantage.HasGrabbedAll;
					if (flag2)
					{
						OP.GetNetworkViewFromVRRig(waver.Target).SendRPC("GrabbedByPlayer", waver.Target.Creator, new object[] { true, false, false });
						OP.RPCProtection();
						Advantage.HasGrabbedAll = true;
					}
				}
				else
				{
					bool hasGrabbedAll = Advantage.HasGrabbedAll;
					if (hasGrabbedAll)
					{
						OP.GetNetworkViewFromVRRig(waver.Target).SendRPC("DroppedByPlayer", waver.Target.Creator, new object[] { true, false, false });
						OP.RPCProtection();
						Advantage.HasGrabbedAll = false;
					}
				}
			}
		}

		// Token: 0x0600008D RID: 141 RVA: 0x00007AB4 File Offset: 0x00005CB4
		public static void GrabAll()
		{
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			if (rightGrab)
			{
				bool flag = !Advantage.HasGrabbedAll;
				if (flag)
				{
					GorillaParent.instance.vrrigs.ForEach(delegate(VRRig vrrig)
					{
						OP.GetNetworkViewFromVRRig(vrrig).SendRPC("GrabbedByPlayer", vrrig.Creator, new object[] { true, false, false });
						OP.RPCProtection();
					});
					Advantage.HasGrabbedAll = true;
				}
			}
			else
			{
				bool hasGrabbedAll = Advantage.HasGrabbedAll;
				if (hasGrabbedAll)
				{
					GorillaParent.instance.vrrigs.ForEach(delegate(VRRig vrrig)
					{
						OP.GetNetworkViewFromVRRig(vrrig).SendRPC("DroppedByPlayer", vrrig.Creator, new object[] { true, false, false });
						OP.RPCProtection();
					});
					Advantage.HasGrabbedAll = false;
				}
			}
		}

		// Token: 0x0600008E RID: 142 RVA: 0x00007B60 File Offset: 0x00005D60
		public static void AutoGuardian()
		{
			bool flag = !GameMode.ActiveGameMode.name.Contains("fected");
			bool flag2 = flag;
			if (flag2)
			{
				foreach (TappableGuardianIdol tappableGuardianIdol in global::UnityEngine.Object.FindObjectsOfType<TappableGuardianIdol>())
				{
					bool isChangingPositions = tappableGuardianIdol.isChangingPositions;
					bool flag3 = isChangingPositions;
					if (flag3)
					{
						GorillaTagger.Instance.offlineVRRig.enabled = true;
					}
					else
					{
						foreach (GorillaGuardianManager gorillaGuardianManager in global::UnityEngine.Object.FindObjectsOfType<GorillaGuardianManager>())
						{
							bool flag4 = gorillaGuardianManager.IsPlayerGuardian(NetworkSystem.Instance.LocalPlayer);
							bool flag5 = flag4;
							if (flag5)
							{
								GorillaTagger.Instance.offlineVRRig.enabled = true;
							}
							else
							{
								VRRig offlineVRRig = GorillaTagger.Instance.offlineVRRig;
								offlineVRRig.enabled = false;
								offlineVRRig.transform.position = tappableGuardianIdol.transform.position;
								offlineVRRig.leftHand.rigTarget.transform.position = tappableGuardianIdol.transform.position;
								offlineVRRig.rightHand.rigTarget.transform.position = tappableGuardianIdol.transform.position;
								tappableGuardianIdol.manager.photonView.RPC("SendOnTapRPC", 0, new object[]
								{
									tappableGuardianIdol.tappableId,
									global::UnityEngine.Random.Range(0.2f, 0.4f)
								});
							}
						}
					}
				}
			}
		}

		// Token: 0x0400005C RID: 92
		public static float crashed;

		// Token: 0x0400005D RID: 93
		public static bool HasGrabbedAll;
	}
}
