﻿using System;
using System.Collections.Generic;
using System.Linq;
using GorillaLocomotion;
using UnityEngine;

namespace Abyss.Mods
{
	// Token: 0x02000017 RID: 23
	public class eocc : MonoBehaviour
	{
		// Token: 0x06000172 RID: 370 RVA: 0x000194DC File Offset: 0x000176DC
		public static void color(VRRig rig)
		{
			bool flag = (eocc.delays.ContainsKey(rig) && Time.time > eocc.delays[rig]) || !eocc.delays.ContainsKey(rig);
			if (flag)
			{
				bool flag2 = eocc.delays.ContainsKey(rig);
				if (flag2)
				{
					eocc.delays[rig] = Time.time + 5f;
				}
				else
				{
					eocc.delays.Add(rig, Time.time + 5f);
				}
				rig.mainSkin.sharedMesh.colors32 = Enumerable.Repeat<Color32>(Color.white, rig.mainSkin.sharedMesh.colors32.Length).ToArray<Color32>();
				rig.mainSkin.sharedMesh.colors = Enumerable.Repeat<Color>(Color.white, rig.mainSkin.sharedMesh.colors.Length).ToArray<Color>();
			}
		}

		// Token: 0x06000173 RID: 371 RVA: 0x000195D0 File Offset: 0x000177D0
		public static void GhostBody(bool on)
		{
			if (on)
			{
				bool flag = eocc.GhostRig == null;
				if (flag)
				{
					eocc.GhostRig = global::UnityEngine.Object.Instantiate<VRRig>(GorillaTagger.Instance.offlineVRRig, GTPlayer.Instance.transform.position, GTPlayer.Instance.transform.rotation);
					eocc.GhostRig.headBodyOffset = Vector3.zero;
					eocc.GhostRig.enabled = true;
					eocc.GhostRig.transform.Find("VR Constraints/LeftArm/Left Arm IK/SlideAudio").gameObject.SetActive(false);
					eocc.GhostRig.transform.Find("VR Constraints/RightArm/Right Arm IK/SlideAudio").gameObject.SetActive(false);
					eocc.color(eocc.GhostRig);
				}
				bool flag2 = eocc.ghost == null;
				if (flag2)
				{
					eocc.ghost = new Material(Shader.Find("GUI/Text Shader"));
				}
				Color black = Color.black;
				black.a = 0.5f;
				eocc.ghost.color = black;
				eocc.GhostRig.mainSkin.material = eocc.ghost;
				eocc.GhostRig.headConstraint.transform.position = GTPlayer.Instance.headCollider.transform.position;
				eocc.GhostRig.headConstraint.transform.rotation = GTPlayer.Instance.headCollider.transform.rotation;
				eocc.GhostRig.leftHandTransform.position = GTPlayer.Instance.leftControllerTransform.position;
				eocc.GhostRig.rightHandTransform.position = GTPlayer.Instance.rightControllerTransform.position;
				eocc.GhostRig.leftHandTransform.rotation = GTPlayer.Instance.leftControllerTransform.rotation;
				eocc.GhostRig.rightHandTransform.rotation = GTPlayer.Instance.rightControllerTransform.rotation;
				eocc.GhostRig.transform.position = GTPlayer.Instance.transform.position;
				eocc.GhostRig.transform.rotation = GTPlayer.Instance.transform.rotation;
			}
			else
			{
				bool flag3 = eocc.GhostRig != null;
				if (flag3)
				{
					global::UnityEngine.Object.Destroy(eocc.GhostRig.gameObject);
				}
			}
			bool flag4 = eocc.clonedPlayer != null;
			if (flag4)
			{
				eocc.clonedPlayer.SetActive(!GorillaTagger.Instance.offlineVRRig.enabled);
				Transform transform = eocc.clonedPlayer.transform.Find("Local Gorilla Player/gorilla_new");
				bool flag5 = transform != null;
				if (flag5)
				{
					SkinnedMeshRenderer component = transform.GetComponent<SkinnedMeshRenderer>();
					bool flag6 = component != null;
					if (flag6)
					{
						Color color = Color.Lerp(Color.magenta, new Color(0.392f, 0f, 0.588f, 1f), Mathf.PingPong(Time.time, 1f));
						color.a = 0.5f;
						component.material.shader = Shader.Find("GUI/Text Shader");
						component.material.color = color;
					}
				}
			}
		}

		// Token: 0x0400016A RID: 362
		private static GameObject clonedPlayer;

		// Token: 0x0400016B RID: 363
		private static VRRig GhostRig;

		// Token: 0x0400016C RID: 364
		public static Material ghost;

		// Token: 0x0400016D RID: 365
		private static Dictionary<VRRig, float> delays = new Dictionary<VRRig, float>();
	}
}
