﻿using System;
using Photon.Pun;

namespace Abyss.Mods
{
	// Token: 0x0200000C RID: 12
	internal class Tracker
	{
		// Token: 0x06000094 RID: 148 RVA: 0x00007D68 File Offset: 0x00005F68
		public static void TrackRoom()
		{
			bool flag = PhotonNetwork.InRoom && Tracker.i < 1;
			if (flag)
			{
				Tracker.i++;
				Fun.SendWeb("**" + PhotonNetwork.LocalPlayer.NickName + "** has joined code: " + PhotonNetwork.CurrentRoom.Name);
			}
			bool flag2 = !PhotonNetwork.InRoom && Tracker.i >= 1;
			if (flag2)
			{
				Tracker.i = 0;
				Fun.SendWeb("**" + PhotonNetwork.LocalPlayer.NickName + "** has left the previous code");
			}
		}

		// Token: 0x0400005F RID: 95
		private static int i;
	}
}
