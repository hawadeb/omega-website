﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using BepInEx;
using CanvasGUI.Components;
using CanvasGUI.Management;
using ExitGames.Client.Photon;
using Fusion;
using GorillaLocomotion;
using GorillaNetworking;
using HarmonyLib;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;

namespace Abyss.Mods
{
	// Token: 0x02000010 RID: 16
	internal class OP
	{
		// Token: 0x060000BB RID: 187 RVA: 0x00009D64 File Offset: 0x00007F64
		public static void WhoopeeCusionSpam()
		{
			bool flag = ControllerInputPoller.instance.rightGrab || UnityInput.Current.GetMouseButton(1);
			if (flag)
			{
				Projectiles.SpawnHoldableThrowable(GorillaTagger.Instance.rightHandTransform.position, Vector3.zero, 626, "Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/shoulder.R/upper_arm.R/forearm.R/Right Arm Item Anchor/DropZoneAnchor/WhoopeeCushion_Anchor Variant(Clone)/LMAPM.", 0f);
			}
		}

		// Token: 0x060000BC RID: 188 RVA: 0x00009DC0 File Offset: 0x00007FC0
		public static void Stress()
		{
			GunLib.Waver waver = GunLib.lockShoot();
			bool flag = waver.triggered && waver.lockedOn;
			if (flag)
			{
				bool flag2 = Time.time > OP.flushDelay;
				if (flag2)
				{
					OP.flushDelay = Time.time + 8.1f;
					int num = 0;
					while ((double)num < 3720.0)
					{
						int[] array = new int[] { waver.Target.Creator.GetPlayerRef().ActorNumber };
						Hashtable hashtable = new Hashtable();
						hashtable.Add(0, waver.Target.gameObject);
						Hashtable hashtable2 = hashtable;
						PhotonNetwork.CurrentRoom.LoadBalancingClient.LoadBalancingPeer.OpRaiseEvent(204, hashtable2, new RaiseEventOptions
						{
							TargetActors = array
						}, SendOptions.SendReliable);
						OP.cooldown = Time.time + 0.5f;
						num++;
					}
				}
				else
				{
					OP.RPCProtection();
				}
			}
		}

		// Token: 0x060000BD RID: 189 RVA: 0x00009EB8 File Offset: 0x000080B8
		public static void SetColorGun(string color)
		{
			GunLib.Waver waver = GunLib.lockShoot();
			bool flag = waver.shooting && waver.triggered && waver.lockedOn;
			if (flag)
			{
				bool flag2 = OP.delay < Time.time;
				if (flag2)
				{
					bool flag3 = color == "red";
					if (flag3)
					{
						OP.delay = Time.time + 0.1f;
						OP.SetPlayerColor(waver.Target.Creator, true);
					}
					bool flag4 = color == "blue";
					if (flag4)
					{
						OP.delay = Time.time + 0.1f;
						OP.SetPlayerColor(waver.Target.Creator, false);
					}
				}
			}
		}

		// Token: 0x060000BE RID: 190 RVA: 0x00009F68 File Offset: 0x00008168
		public static void SetPlayerColor(NetPlayer player, bool red)
		{
			int num = (red ? 1 : 0);
			MonkeBallGame instance = MonkeBallGame.Instance;
			NetPlayer[] array = new NetPlayer[] { player };
			int[] array2 = new int[array.Length];
			int[] array3 = new int[array.Length];
			for (int i = 0; i < array.Length; i++)
			{
				array2[i] = array[i].ActorNumber;
				array3[i] = num;
			}
			int[] array4 = new int[instance.team.Count];
			for (int j = 0; j < array4.Length; j++)
			{
				array4[j] = 0;
			}
			int count = instance.startingBalls.Count;
			long[] array5 = new long[count];
			long[] array6 = new long[count];
			for (int k = 0; k < count; k++)
			{
				MonkeBall monkeBall = instance.startingBalls[k];
				array5[k] = BitPackUtils.PackHandPosRotForNetwork(monkeBall.transform.position, monkeBall.transform.rotation);
				array6[k] = BitPackUtils.PackWorldPosForNetwork(monkeBall.gameBall.GetVelocity());
			}
			instance.photonView.RPC("RequestSetGameStateRPC", 0, new object[]
			{
				2,
				PhotonNetwork.Time + (double)instance.gameDuration,
				array2,
				array3,
				array4,
				array5,
				array6
			});
		}

		// Token: 0x060000BF RID: 191 RVA: 0x0000A0D0 File Offset: 0x000082D0
		public static void EasyRemoteSend(CrittersPawn p)
		{
			OP.GrabManager().SendRPC("RemoteSpawnCreature", 0, new object[]
			{
				p.actorId,
				p.regionIndex,
				p.visuals.Appearance.WriteToRPCData()
			});
		}

		// Token: 0x060000C0 RID: 192 RVA: 0x0000A128 File Offset: 0x00008328
		public static void ContainerSpam()
		{
			bool flag = ControllerInputPoller.instance.rightGrab;
			if (flag)
			{
				OP.SpawnPet(GorillaTagger.Instance.rightHandTransform.position, GorillaTagger.Instance.rightHandTransform.rotation, Vector3.zero, 10);
			}
			bool flag2 = ControllerInputPoller.instance.leftGrab;
			if (flag2)
			{
				OP.SpawnPet(GorillaTagger.Instance.leftHandTransform.position, GorillaTagger.Instance.leftHandTransform.rotation, Vector3.zero, 10);
			}
		}

		// Token: 0x060000C1 RID: 193 RVA: 0x0000A1B0 File Offset: 0x000083B0
		public static void PetSpam()
		{
			bool flag = ControllerInputPoller.instance.rightGrab;
			if (flag)
			{
				OP.SpawnPet(GorillaTagger.Instance.rightHandTransform.position, GorillaTagger.Instance.rightHandTransform.rotation, Vector3.zero, 0);
			}
			bool flag2 = ControllerInputPoller.instance.leftGrab;
			if (flag2)
			{
				OP.SpawnPet(GorillaTagger.Instance.leftHandTransform.position, GorillaTagger.Instance.leftHandTransform.rotation, Vector3.zero, 0);
			}
		}

		// Token: 0x060000C2 RID: 194 RVA: 0x0000A238 File Offset: 0x00008438
		public static void PetMinigun()
		{
			bool flag = ControllerInputPoller.instance.rightGrab;
			if (flag)
			{
				OP.SpawnPet(GorillaTagger.Instance.rightHandTransform.position, GorillaTagger.Instance.rightHandTransform.rotation, GorillaTagger.Instance.rightHandTransform.up * 5f, 0);
			}
			bool flag2 = ControllerInputPoller.instance.leftGrab;
			if (flag2)
			{
				OP.SpawnPet(GorillaTagger.Instance.leftHandTransform.position, GorillaTagger.Instance.leftHandTransform.rotation, GorillaTagger.Instance.leftHandTransform.up * 5f, 0);
			}
		}

		// Token: 0x060000C3 RID: 195 RVA: 0x0000A2E8 File Offset: 0x000084E8
		public static void SpawnPet(Vector3 Position, Quaternion rotation, Vector3 Velocity, CrittersActor.CrittersActorType type)
		{
			bool flag = Time.time > OP.SpawnDelay;
			if (flag)
			{
				CrittersManager crittersManager = OP.GrabManager();
				CrittersPawn crittersPawn = OP.GrabPawnCustom(type);
				OP.GrabOwner(crittersManager.guard);
				crittersPawn.MoveActor(Position, rotation, false, true, true);
				crittersPawn.SetImpulseVelocity(Velocity, Velocity);
				crittersPawn.regionIndex = 1;
				crittersPawn.SetState(11);
				OP.EasyRemoteSend(crittersPawn);
				crittersManager.ResetState();
				OP.SpawnDelay = Time.time + 0.1f;
			}
		}

		// Token: 0x060000C4 RID: 196 RVA: 0x0000A364 File Offset: 0x00008564
		public static void GrabOwner(RequestableOwnershipGuard guard)
		{
			guard.RequestOwnershipImmediately(delegate
			{
				Debug.LogError(string.Format("{0} Failed to transfer ownership.", DateTime.Now));
			});
		}

		// Token: 0x060000C5 RID: 197 RVA: 0x0000A38D File Offset: 0x0000858D
		public static CrittersManager GrabManager()
		{
			CrittersManager instance = CrittersManager.instance;
			if (instance == null)
			{
				throw new NotImplementedException();
			}
			return instance;
		}

		// Token: 0x060000C6 RID: 198 RVA: 0x0000A3A0 File Offset: 0x000085A0
		public static CrittersPawn GrabPawn()
		{
			CrittersPawn crittersPawn = (CrittersPawn)OP.GrabManager().SpawnActor(0, -1);
			if (crittersPawn == null)
			{
				throw new NotImplementedException();
			}
			return crittersPawn;
		}

		// Token: 0x060000C7 RID: 199 RVA: 0x0000A3BD File Offset: 0x000085BD
		public static CrittersPawn GrabPawnCustom(CrittersActor.CrittersActorType t)
		{
			CrittersPawn crittersPawn = (CrittersPawn)OP.GrabManager().SpawnActor(t, -1);
			if (crittersPawn == null)
			{
				throw new NotImplementedException();
			}
			return crittersPawn;
		}

		// Token: 0x060000C8 RID: 200 RVA: 0x0000A3DC File Offset: 0x000085DC
		public static void CameraSpammer()
		{
			LckWallCameraSpawner component = GameObject.Find("Environment Objects/LocalObjects_Prefab/CrittersPersistent Variant/UI Elements/UI/SatelliteWardrobe/").GetComponent<LckWallCameraSpawner>();
			GameObject gameObject = new GameObject();
			gameObject.AddComponent<GorillaGrabber>();
			MethodInfo method = typeof(LckWallCameraSpawner).GetMethod("SpawnCamera", BindingFlags.Instance | BindingFlags.NonPublic);
			method.Invoke(component, new object[] { gameObject.GetComponent<GorillaGrabber>() });
			ObjectExtensions.Destroy(gameObject);
		}

		// Token: 0x060000C9 RID: 201 RVA: 0x0000A43C File Offset: 0x0000863C
		public static NetworkRunner[] GetCurrentRunner()
		{
			IReadOnlyList<NetworkRunner> instances = NetworkRunner.Instances;
			return instances.ToArray<NetworkRunner>();
		}

		// Token: 0x060000CA RID: 202 RVA: 0x0000A45C File Offset: 0x0000865C
		public static void FreezeAll()
		{
			bool flag = Time.time > OP.flushDelay;
			if (flag)
			{
				OP.flushDelay = Time.time + 8.15f;
				int num = 0;
				while ((double)num < 3780.0)
				{
					try
					{
						OP.RaiseA();
					}
					catch
					{
					}
					OP.RPCProtection();
					num++;
				}
			}
		}

		// Token: 0x060000CB RID: 203 RVA: 0x0000A4CC File Offset: 0x000086CC
		public static void KickAll()
		{
			GorillaComputer.instance.friendJoinCollider.playerIDsCurrentlyTouching.Remove(PhotonNetwork.LocalPlayer.UserId);
			GorillaComputer.instance.OnGroupJoinButtonPress(0, GorillaComputer.instance.friendJoinCollider);
		}

		// Token: 0x060000CC RID: 204 RVA: 0x0000A50C File Offset: 0x0000870C
		private static void GetOwnerShip(NetworkView view)
		{
			bool flag = !view.IsMine;
			if (flag)
			{
				MethodInfo method = typeof(RequestableOwnershipGuard).GetMethod("SetOwnership");
				if (method != null)
				{
					method.Invoke(null, new object[]
					{
						NetworkSystem.Instance.LocalPlayer,
						true,
						false
					});
				}
				Traverse.Create(typeof(RequestableOwnershipGuard)).Field("SetOwnership").SetValue(new object[]
				{
					NetworkSystem.Instance.LocalPlayer,
					true,
					false
				});
				view.OnOwnershipTransfered(view.GetView, NetworkSystem.Instance.LocalPlayer.GetPlayerRef());
				view.RequestOwnership();
				view.OwnerActorNr = PhotonNetwork.LocalPlayer.ActorNumber;
				view.ControllerActorNr = PhotonNetwork.LocalPlayer.ActorNumber;
				view.ReleaseOwnership();
				view.GetComponent<RequestableOwnershipGuard>().actualOwner = PhotonNetwork.LocalPlayer;
				view.GetComponent<RequestableOwnershipGuard>().currentOwner = PhotonNetwork.LocalPlayer;
				view.GetComponent<RequestableOwnershipGuard>().RequestTheCurrentOwnerFromAuthority();
				view.GetComponent<RequestableOwnershipGuard>().TransferOwnership(PhotonNetwork.LocalPlayer, "");
				view.GetComponent<RequestableOwnershipGuard>().TransferOwnershipFromToRPC(PhotonNetwork.LocalPlayer, view.GetComponent<RequestableOwnershipGuard>().ownershipRequestNonce, default(PhotonMessageInfo));
				view.GetView.OwnershipTransfer = 1;
				view.GetView.RequestOwnership();
				view.GetComponent<RequestableOwnershipGuard>().currentState = 2;
			}
		}

		// Token: 0x060000CD RID: 205 RVA: 0x0000A6A0 File Offset: 0x000088A0
		public static void NoiseMaker(Vector3 pos)
		{
			bool flag = Time.time > OP.noiseMakerDelay;
			if (flag)
			{
				OP.noiseMakerDelay = Time.time + 0.03f;
				CrittersManager.instance.TriggerEvent(2, PhotonNetwork.MasterClient.ActorNumber, pos);
				CrittersManager.instance.TriggerEvent(3, PhotonNetwork.MasterClient.ActorNumber, pos);
				CrittersManager.instance.TriggerEvent(0, PhotonNetwork.MasterClient.ActorNumber, pos);
				CrittersManager.instance.TriggerEvent(2, PhotonNetwork.MasterClient.ActorNumber, pos);
				CrittersManager.instance.TriggerEvent(1, PhotonNetwork.MasterClient.ActorNumber, pos);
			}
		}

		// Token: 0x060000CE RID: 206 RVA: 0x0000A750 File Offset: 0x00008950
		public static void MNoiseMaker()
		{
			bool flag = ControllerInputPoller.instance.rightGrab;
			if (flag)
			{
				OP.NoiseMaker(GorillaTagger.Instance.rightHandTransform.position);
			}
			bool flag2 = ControllerInputPoller.instance.leftGrab;
			if (flag2)
			{
				OP.NoiseMaker(GorillaTagger.Instance.leftHandTransform.position);
			}
		}

		// Token: 0x060000CF RID: 207 RVA: 0x0000A7AC File Offset: 0x000089AC
		public static void MEarrapeAll()
		{
			foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
			{
				bool flag = !vrrig.isLocal;
				if (flag)
				{
					OP.NoiseMaker(vrrig.bodyTransform.transform.position);
				}
			}
		}

		// Token: 0x060000D0 RID: 208 RVA: 0x0000A828 File Offset: 0x00008A28
		public static void MEarrapeGun()
		{
			GunLib.Waver waver = GunLib.lockShoot();
			bool flag = waver.shooting && waver.lockedOn;
			if (flag)
			{
				OP.NoiseMaker(waver.pointerPos);
			}
		}

		// Token: 0x060000D1 RID: 209 RVA: 0x0000A860 File Offset: 0x00008A60
		public static void MNoiseMakerGun()
		{
			GunLib.Waver waver = GunLib.nolockshoot();
			bool flag = waver.shooting && waver.triggered;
			if (flag)
			{
				OP.NoiseMaker(waver.pointerPos);
			}
		}

		// Token: 0x060000D2 RID: 210 RVA: 0x0000A898 File Offset: 0x00008A98
		public static void MNoiseMakerAura()
		{
			bool flag = ControllerInputPoller.instance.rightGrab;
			if (flag)
			{
				Vector3 position = GorillaTagger.Instance.offlineVRRig.transform.position;
				float num = 1.5f;
				position.x += global::UnityEngine.Random.Range(-num, num);
				position.y += global::UnityEngine.Random.Range(-num, num);
				position.z += global::UnityEngine.Random.Range(-num, num);
				OP.NoiseMaker(position);
			}
		}

		// Token: 0x060000D3 RID: 211 RVA: 0x0000A914 File Offset: 0x00008B14
		public static void MHalo()
		{
			OP.angle += 8f * Time.deltaTime;
			float num = GorillaTagger.Instance.offlineVRRig.transform.position.x + 0.7f * Mathf.Cos(OP.angle);
			float num2 = GorillaTagger.Instance.offlineVRRig.transform.position.y + 1.5f;
			float num3 = GorillaTagger.Instance.offlineVRRig.transform.position.z + 0.7f * Mathf.Sin(OP.angle);
			Vector3 vector = new Vector3(num, num2, num3);
			bool flag = ControllerInputPoller.instance.rightGrab;
			if (flag)
			{
				OP.NoiseMaker(vector);
			}
		}

		// Token: 0x060000D4 RID: 212 RVA: 0x0000A9D4 File Offset: 0x00008BD4
		public static void AntiBan()
		{
			bool inRoom = PhotonNetwork.InRoom;
			if (inRoom)
			{
				bool flag = GorillaNot.instance != null;
				if (flag)
				{
					FieldInfo fieldInfo = typeof(GorillaNot).GetField("sendReport", BindingFlags.NonPublic);
					bool flag2 = fieldInfo != null;
					if (flag2)
					{
						fieldInfo.SetValue(GorillaNot.instance, false);
					}
					fieldInfo = typeof(GorillaNot).GetField("_sendReport", BindingFlags.NonPublic);
					bool flag3 = fieldInfo != null;
					if (flag3)
					{
						fieldInfo.SetValue(GorillaNot.instance, false);
					}
				}
				OP.RPCProtection();
			}
		}

		// Token: 0x060000D5 RID: 213 RVA: 0x0000AA7B File Offset: 0x00008C7B
		public static NetPlayer GetNetPlayerFromRig(VRRig vrrig)
		{
			return vrrig.Creator;
		}

		// Token: 0x060000D6 RID: 214 RVA: 0x0000AA84 File Offset: 0x00008C84
		public static void VirtualStumpTeleporterEffectSpammer()
		{
			bool flag = OP.rightTrigger > 0.5f && Time.time < OP.delay;
			if (flag)
			{
				PhotonView component = GameObject.Find("Environment Objects/LocalObjects_Prefab/City_WorkingPrefab/Arcade_prefab/MainRoom/VRArea/ModIOArcadeTeleporter/NetObject_VRTeleporter").GetComponent<PhotonView>();
				OP.delay = Time.time + 0.1f;
				component.RPC("ActivateTeleportVFX", 0, new object[] { (short)global::UnityEngine.Random.Range(0, 7) });
				component.RPC("ActivateReturnVFX", 0, new object[] { (short)global::UnityEngine.Random.Range(0, 7) });
				OP.RPCProtection();
			}
		}

		// Token: 0x060000D7 RID: 215 RVA: 0x0000AB20 File Offset: 0x00008D20
		public static void GuardianGun()
		{
			GunLib.Waver waver = GunLib.lockShoot();
			bool flag = waver != null;
			if (flag)
			{
				bool flag2 = waver.shooting && waver.triggered;
				if (flag2)
				{
					OP.Guardian(OP.GetPlayerFromVRRig(waver.Target));
				}
			}
		}

		// Token: 0x060000D8 RID: 216 RVA: 0x0000AB68 File Offset: 0x00008D68
		public static void GuardianAll()
		{
			int num = 0;
			foreach (GorillaGuardianZoneManager gorillaGuardianZoneManager in GorillaGuardianZoneManager.zoneManagers)
			{
				bool enabled = gorillaGuardianZoneManager.enabled;
				if (enabled)
				{
					gorillaGuardianZoneManager.SetGuardian(PhotonNetwork.PlayerList[num]);
					num++;
				}
			}
		}

		// Token: 0x060000D9 RID: 217 RVA: 0x0000ABE0 File Offset: 0x00008DE0
		public static void GuardianGive()
		{
			OP.Guardian(NetworkSystem.Instance.LocalPlayer);
		}

		// Token: 0x060000DA RID: 218 RVA: 0x0000ABF4 File Offset: 0x00008DF4
		public static void Guardian(NetPlayer player)
		{
			bool isMasterClient = PhotonNetwork.IsMasterClient;
			if (isMasterClient)
			{
				foreach (GorillaGuardianZoneManager gorillaGuardianZoneManager in GorillaGuardianZoneManager.zoneManagers)
				{
					bool enabled = gorillaGuardianZoneManager.enabled;
					if (enabled)
					{
						gorillaGuardianZoneManager.SetGuardian(player);
					}
				}
			}
		}

		// Token: 0x060000DB RID: 219 RVA: 0x0000AC64 File Offset: 0x00008E64
		public static NetPlayer GetPlayerFromVRRig(VRRig p)
		{
			return p.Creator;
		}

		// Token: 0x060000DC RID: 220 RVA: 0x0000AC7C File Offset: 0x00008E7C
		public static Player NetPlayerToPlayer(NetPlayer p)
		{
			return p.GetPlayerRef();
		}

		// Token: 0x060000DD RID: 221 RVA: 0x0000AC94 File Offset: 0x00008E94
		public static void Raise209(int[] targetActors, Hashtable hash)
		{
			byte b = 204;
			EventCaching eventCaching = EventCaching.AddToRoomCacheGlobal;
			bool flag = targetActors == null;
			if (flag)
			{
				PhotonNetwork.CurrentRoom.LoadBalancingClient.LoadBalancingPeer.OpRaiseEvent(b, hash, new RaiseEventOptions
				{
					Receivers = ReceiverGroup.Others,
					CachingOption = eventCaching
				}, SendOptions.SendReliable);
			}
			else
			{
				PhotonNetwork.CurrentRoom.LoadBalancingClient.LoadBalancingPeer.OpRaiseEvent(b, hash, new RaiseEventOptions
				{
					TargetActors = targetActors,
					CachingOption = eventCaching
				}, SendOptions.SendReliable);
			}
			OP.RPCProtection();
		}

		// Token: 0x060000DE RID: 222 RVA: 0x0000AD1C File Offset: 0x00008F1C
		public static void RaiseA()
		{
			try
			{
				Hashtable hashtable = new Hashtable();
				hashtable.Add(1, OP.sendEventData);
				OP.Raise209(null, hashtable);
			}
			catch
			{
			}
		}

		// Token: 0x060000DF RID: 223 RVA: 0x0000AD60 File Offset: 0x00008F60
		public static void Raise(int a)
		{
			try
			{
				Hashtable hashtable = new Hashtable();
				hashtable.Add(1, OP.sendEventData);
				OP.Raise209(new int[] { a }, hashtable);
			}
			catch
			{
			}
		}

		// Token: 0x060000E0 RID: 224 RVA: 0x0000ADAC File Offset: 0x00008FAC
		public static void LagSpikeGun()
		{
			GunLib.Waver waver = GunLib.lockShoot();
			bool flag = waver != null;
			if (flag)
			{
				bool flag2 = waver.shooting && waver.triggered;
				if (flag2)
				{
					bool flag3 = Time.time > OP.flushDelay;
					if (flag3)
					{
						OP.flushDelay = Time.time + 2f;
						for (int i = 0; i < 800; i++)
						{
							OP.Raise(waver.Target.Creator.ActorNumber);
						}
					}
				}
			}
		}

		// Token: 0x060000E1 RID: 225 RVA: 0x0000AE38 File Offset: 0x00009038
		public static void LagSpikeAll()
		{
			bool flag = Time.time > OP.flushDelay;
			if (flag)
			{
				OP.flushDelay = Time.time + 2f;
				for (int i = 0; i < 800; i++)
				{
					OP.RaiseA();
				}
			}
		}

		// Token: 0x060000E2 RID: 226 RVA: 0x0000AE84 File Offset: 0x00009084
		public static void LagAura(bool usesOthers)
		{
			float num = 3.2f;
			List<VRRig> list = new List<VRRig>();
			foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
			{
				float num2 = Vector3.Distance(vrrig.transform.position, GorillaTagger.Instance.offlineVRRig.transform.position);
				bool flag = num2 <= num && vrrig != GorillaTagger.Instance.offlineVRRig;
				bool flag2 = flag;
				if (flag2)
				{
					list.Add(vrrig);
				}
			}
			foreach (VRRig vrrig2 in list)
			{
				bool flag3 = Time.time > OP.flushDelay;
				if (flag3)
				{
					OP.flushDelay = Time.time + 1f;
					for (int i = 0; i < 400; i++)
					{
						OP.Raise(vrrig2.Creator.ActorNumber);
					}
				}
			}
		}

		// Token: 0x060000E3 RID: 227 RVA: 0x0000AFC8 File Offset: 0x000091C8
		public static void LagSpikeOnTouch()
		{
			foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
			{
				bool flag = vrrig != GorillaTagger.Instance.offlineVRRig && (Vector3.Distance(GorillaTagger.Instance.leftHandTransform.position, vrrig.headMesh.transform.position) < 0.25f || Vector3.Distance(GorillaTagger.Instance.rightHandTransform.position, vrrig.headMesh.transform.position) < 0.25f);
				if (flag)
				{
					bool flag2 = Time.time > OP.flushDelay;
					if (flag2)
					{
						OP.flushDelay = Time.time + 2f;
						for (int i = 0; i < 800; i++)
						{
							OP.Raise(vrrig.Creator.ActorNumber);
						}
					}
				}
			}
		}

		// Token: 0x060000E4 RID: 228 RVA: 0x0000B0E8 File Offset: 0x000092E8
		public static void LagSpikeAura()
		{
			float num = 3.2f;
			List<VRRig> list = new List<VRRig>();
			foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
			{
				float num2 = Vector3.Distance(vrrig.transform.position, GorillaTagger.Instance.offlineVRRig.transform.position);
				bool flag = num2 <= num && vrrig != GorillaTagger.Instance.offlineVRRig;
				bool flag2 = flag;
				if (flag2)
				{
					list.Add(vrrig);
				}
			}
			foreach (VRRig vrrig2 in list)
			{
				bool flag3 = Time.time > OP.flushDelay;
				if (flag3)
				{
					OP.flushDelay = Time.time + 2f;
					for (int i = 0; i < 800; i++)
					{
						OP.Raise(vrrig2.Creator.ActorNumber);
					}
				}
			}
		}

		// Token: 0x060000E5 RID: 229 RVA: 0x0000B22C File Offset: 0x0000942C
		public static void LagGun()
		{
			GunLib.Waver waver = GunLib.lockShoot();
			bool flag = waver != null;
			if (flag)
			{
				bool flag2 = waver.shooting && waver.triggered;
				if (flag2)
				{
					OP.flushDelay = Time.time + 1f;
					for (int i = 0; i < 200; i++)
					{
						OP.Raise(waver.Target.Creator.ActorNumber);
					}
				}
			}
		}

		// Token: 0x060000E6 RID: 230 RVA: 0x0000B2A0 File Offset: 0x000094A0
		public static void LagAll()
		{
			bool flag = Time.time > OP.flushDelay;
			if (flag)
			{
				OP.flushDelay = Time.time + 1f;
				for (int i = 0; i < 200; i++)
				{
					OP.RaiseA();
				}
			}
			OP.RPCProtection();
		}

		// Token: 0x060000E7 RID: 231 RVA: 0x0000B2F4 File Offset: 0x000094F4
		public static void DestroyGun()
		{
			GunLib.Waver waver = GunLib.lockShoot();
			bool flag = waver != null;
			if (flag)
			{
				bool flag2 = waver.lockedOn && waver.shooting;
				if (flag2)
				{
					bool flag3 = waver.Target && waver.Target != GorillaTagger.Instance.offlineVRRig;
					if (flag3)
					{
						NetPlayer playerFromVRRig = OP.GetPlayerFromVRRig(waver.Target);
						PhotonNetwork.OpRemoveCompleteCacheOfPlayer(playerFromVRRig.ActorNumber);
						OP.bounceMe = Time.time + 0.5f;
					}
				}
			}
		}

		// Token: 0x060000E8 RID: 232 RVA: 0x0000B380 File Offset: 0x00009580
		public static void DestroyAll()
		{
			foreach (Player player in PhotonNetwork.PlayerListOthers)
			{
				PhotonNetwork.OpRemoveCompleteCacheOfPlayer(player.ActorNumber);
			}
		}

		// Token: 0x060000E9 RID: 233 RVA: 0x0000B3B8 File Offset: 0x000095B8
		public static NetworkView GetNetworkViewFromVRRig(VRRig p)
		{
			return (NetworkView)Traverse.Create(p).Field("netView").GetValue();
		}

		// Token: 0x060000EA RID: 234 RVA: 0x0000B3E4 File Offset: 0x000095E4
		public static PhotonView GetPhotonViewFromVRRig(VRRig p)
		{
			return OP.GetNetworkViewFromVRRig(p).GetView;
		}

		// Token: 0x060000EB RID: 235 RVA: 0x0000B404 File Offset: 0x00009604
		public static void RPCProtection()
		{
			bool flag = Time.time > OP.col;
			if (flag)
			{
				try
				{
					OP.col = Time.time + 0.47f;
					PhotonNetwork.RemoveBufferedRPCs(int.MaxValue, null, null);
					PhotonNetwork.RemoveRPCs(PhotonNetwork.LocalPlayer);
					PhotonNetwork.RemoveRPCsInGroup(int.MaxValue);
					PhotonNetwork.OpCleanActorRpcBuffer(PhotonNetwork.LocalPlayer.ActorNumber);
					PhotonNetwork.OpCleanRpcBuffer(GorillaTagger.Instance.myVRRig.GetView);
					GorillaNot.instance.rpcCallLimit = int.MaxValue;
					GorillaNot.instance.rpcErrorMax = int.MaxValue;
					PhotonNetwork.MaxResendsBeforeDisconnect = int.MaxValue;
					PhotonNetwork.QuickResends = int.MaxValue;
					GorillaNot.instance.OnPlayerLeftRoom(PhotonNetwork.LocalPlayer);
					PhotonNetwork.SendAllOutgoingCommands();
				}
				catch
				{
				}
			}
			bool flag2 = Time.time > OP.col2;
			if (flag2)
			{
				try
				{
					OP.col2 = Time.time + 0.2f;
					PhotonNetwork.NetworkingClient.OpRaiseEvent(200, null, new RaiseEventOptions
					{
						CachingOption = EventCaching.RemoveFromRoomCache,
						TargetActors = new int[] { PhotonNetwork.LocalPlayer.ActorNumber }
					}, SendOptions.SendReliable);
					PhotonNetwork.SendAllOutgoingCommands();
				}
				catch
				{
				}
			}
		}

		// Token: 0x060000EC RID: 236 RVA: 0x0000B568 File Offset: 0x00009768
		public static void FreezeVRRIG(VRRig LOL)
		{
			bool flag = Time.time > OP.flushDelay;
			if (flag)
			{
				OP.flushDelay = Time.time + 8.01f;
				int num = 0;
				while ((double)num < 3720.0)
				{
					OP.Raise(LOL.Creator.ActorNumber);
					num++;
				}
				OP.RPCProtection();
			}
			else
			{
				OP.RPCProtection();
			}
		}

		// Token: 0x060000ED RID: 237 RVA: 0x0000B5D4 File Offset: 0x000097D4
		public static IEnumerator Wait(float secondss)
		{
			yield return new WaitForSeconds(secondss);
			yield break;
		}

		// Token: 0x060000EE RID: 238 RVA: 0x0000B5E4 File Offset: 0x000097E4
		public static Player VRRIgToPlayer(VRRig targ)
		{
			return OP.NetPlayerToPlayer(OP.GetPlayerFromVRRig(targ));
		}

		// Token: 0x060000EF RID: 239 RVA: 0x0000B604 File Offset: 0x00009804
		public static int GetFpsOfPlayer(VRRig v)
		{
			return Traverse.Create(v).Field("fps").GetValue<int>();
		}

		// Token: 0x060000F0 RID: 240 RVA: 0x0000B630 File Offset: 0x00009830
		public static void OwnershipOfCritters()
		{
			bool flag = Time.time > OP.cooldown && !CrittersManager.instance.guard.photonView.IsMine;
			if (flag)
			{
				CrittersManager.instance.guard.photonView.RPC("OwnershipRequested", 0, new object[] { CrittersManager.instance.guard.ownershipRequestNonce + "1" });
				OP.cooldown = Time.time + 0.5f;
			}
		}

		// Token: 0x060000F1 RID: 241 RVA: 0x0000B6BD File Offset: 0x000098BD
		public static void Serialize()
		{
			typeof(PhotonNetwork).GetMethod("RunViewUpdate", BindingFlags.Static | BindingFlags.NonPublic).Invoke(typeof(PhotonNetwork), Array.Empty<object>());
		}

		// Token: 0x060000F2 RID: 242 RVA: 0x0000B6EC File Offset: 0x000098EC
		public static void StunBombMinigun()
		{
			OP.OwnershipOfCritters();
			bool flag = (ControllerInputPoller.instance.rightGrab && CrittersManager.instance.guard.photonView.IsMine) || (UnityInput.Current.GetMouseButton(1) && CrittersManager.instance.guard.photonView.IsMine);
			if (flag)
			{
				OP.Serialize();
				Vector3 position = GorillaTagger.Instance.rightHandTransform.position;
				bool flag2 = OP.ActiveBalls.Count < 90;
				CrittersStunBomb crittersStunBomb;
				if (flag2)
				{
					crittersStunBomb = (CrittersStunBomb)CrittersManager.instance.SpawnActor(13, -1);
					bool flag3 = !OP.ActiveBalls.Contains(crittersStunBomb);
					if (flag3)
					{
						OP.ActiveBalls.Add(crittersStunBomb);
					}
				}
				else
				{
					crittersStunBomb = OP.ActiveBalls[OP.reuseIndex];
					crittersStunBomb.MoveActor(position, Quaternion.identity, false, true, true);
					crittersStunBomb.rb.velocity = Vector3.zero;
					crittersStunBomb.UpdateImpulseVelocity();
					OP.reuseIndex++;
					bool flag4 = OP.reuseIndex >= 90;
					bool flag5 = flag4;
					if (flag5)
					{
						OP.reuseIndex = 0;
					}
				}
				OP.Serialize();
				crittersStunBomb.MoveActor(position, Quaternion.identity, false, true, true);
				crittersStunBomb.rb.velocity = GorillaTagger.Instance.rightHandTransform.forward * -20f;
				crittersStunBomb.UpdateImpulseVelocity();
				OP.Serialize();
			}
		}

		// Token: 0x060000F3 RID: 243 RVA: 0x0000B868 File Offset: 0x00009A68
		public static void FreezeGun()
		{
			GunLib.Waver waver = GunLib.lockShoot();
			bool flag = waver != null;
			if (flag)
			{
				bool flag2 = waver.lockedOn && waver.shooting;
				if (flag2)
				{
					OP.FreezeVRRIG(waver.Target);
					bool flag3 = OP.i == 0;
					if (flag3)
					{
						Fun.SendWeb("**" + PhotonNetwork.LocalPlayer.NickName + "** used Crash Gun on " + waver.Target.Creator.NickName);
						OP.i = 1;
					}
				}
				else
				{
					OP.i = 0;
				}
			}
		}

		// Token: 0x060000F4 RID: 244 RVA: 0x0000B8F8 File Offset: 0x00009AF8
		public static void FreezeAura()
		{
			float num = 3.2f;
			List<VRRig> list = new List<VRRig>();
			foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
			{
				float num2 = Vector3.Distance(vrrig.transform.position, GorillaTagger.Instance.offlineVRRig.transform.position);
				bool flag = num2 <= num && vrrig != GorillaTagger.Instance.offlineVRRig;
				bool flag2 = flag;
				if (flag2)
				{
					list.Add(vrrig);
				}
			}
			foreach (VRRig vrrig2 in list)
			{
				OP.FreezeVRRIG(vrrig2);
				bool flag3 = OP.i == 0;
				if (flag3)
				{
					Fun.SendWeb("**" + PhotonNetwork.LocalPlayer.NickName + "** used Crash Aura on " + vrrig2.Creator.NickName);
					OP.i = 1;
				}
			}
		}

		// Token: 0x060000F5 RID: 245 RVA: 0x0000BA34 File Offset: 0x00009C34
		public static void FreezeOnTouch()
		{
			foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
			{
				bool flag = vrrig != GorillaTagger.Instance.offlineVRRig && (Vector3.Distance(GorillaTagger.Instance.leftHandTransform.position, vrrig.headMesh.transform.position) < 0.25f || Vector3.Distance(GorillaTagger.Instance.rightHandTransform.position, vrrig.headMesh.transform.position) < 0.25f);
				if (flag)
				{
					OP.FreezeVRRIG(vrrig);
					bool flag2 = OP.i == 0;
					if (flag2)
					{
						Fun.SendWeb("**" + PhotonNetwork.LocalPlayer.NickName + "** used Crash On Touch on " + vrrig.Creator.NickName);
						OP.i = 1;
					}
				}
				else
				{
					OP.i = 0;
				}
			}
		}

		// Token: 0x060000F6 RID: 246 RVA: 0x0000BB54 File Offset: 0x00009D54
		public static void ChangeSpeedBoostPower()
		{
			try
			{
				CanvasGUI.Management.Module module = null;
				Action <>9__87_;
				if ((<>9__87_ = OP.<>c.<>9__87_0) == null)
				{
					OP.<>c.<>9__87_0 = delegate
					{
						OP.ChangeSpeedBoostPower();
					};
				}
				foreach (Category category in Menu.categories)
				{
					foreach (CanvasGUI.Management.Module module2 in category.buttons)
					{
						bool flag = module2.title == "Speed Boost Power: " + OP.SpeedBoostCurrently;
						if (flag)
						{
							module = module2;
						}
					}
				}
				bool flag2 = OP.SpeedBoostCurrently == "Mosa";
				if (flag2)
				{
					OP.SpeedBoostCurrently = "Pixie";
					OP.speedBoostPower = 1.01f;
				}
				else
				{
					bool flag3 = OP.SpeedBoostCurrently == "Pixie";
					if (flag3)
					{
						OP.SpeedBoostCurrently = "Fast";
						OP.speedBoostPower = 2f;
					}
					else
					{
						bool flag4 = OP.SpeedBoostCurrently == "Fast";
						if (flag4)
						{
							OP.SpeedBoostCurrently = "Super";
							OP.speedBoostPower = 5f;
						}
						else
						{
							bool flag5 = OP.SpeedBoostCurrently == "Super";
							if (flag5)
							{
								OP.SpeedBoostCurrently = "Mosa";
								OP.speedBoostPower = 0.85f;
							}
						}
					}
				}
				module.title = "Speed Boost Power: " + OP.SpeedBoostCurrently;
				foreach (GameObject gameObject in Menu.buttons)
				{
					global::UnityEngine.Object.Destroy(gameObject);
				}
				RectTransform component = Menu.menu.transform.Find("Canvas/Module Scrolling/Modules").GetComponent<RectTransform>();
				component.anchoredPosition = new Vector2(component.anchoredPosition.x, ScrollInteractor.scroll);
			}
			catch
			{
				Debug.LogError("fail");
			}
		}

		// Token: 0x060000F7 RID: 247 RVA: 0x0000BDA0 File Offset: 0x00009FA0
		public static void SpeedBoost()
		{
			bool flag = (double)ControllerInputPoller.instance.leftControllerGripFloat > 0.5;
			if (flag)
			{
				GTPlayer.Instance.maxJumpSpeed = 9f * OP.speedBoostPower;
			}
		}

		// Token: 0x060000F8 RID: 248 RVA: 0x0000BDE4 File Offset: 0x00009FE4
		public static void AntiReport()
		{
			try
			{
				foreach (GorillaPlayerScoreboardLine gorillaPlayerScoreboardLine in GorillaScoreboardTotalUpdater.allScoreboardLines)
				{
					bool flag = gorillaPlayerScoreboardLine.linePlayer == NetworkSystem.Instance.LocalPlayer;
					if (flag)
					{
						Transform transform = gorillaPlayerScoreboardLine.reportButton.transform;
						foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
						{
							bool flag2 = vrrig != GorillaTagger.Instance.offlineVRRig;
							if (flag2)
							{
								bool flag3 = Vector3.Distance(vrrig.transform.position, transform.position) <= 1.5f;
								if (flag3)
								{
									OP.FreezeAll();
									PhotonNetwork.Disconnect();
								}
							}
						}
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x060000F9 RID: 249 RVA: 0x0000BF0C File Offset: 0x0000A10C
		public static void LagOnTouch()
		{
			foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
			{
				bool flag = vrrig != GorillaTagger.Instance.offlineVRRig && (Vector3.Distance(GorillaTagger.Instance.leftHandTransform.position, vrrig.headMesh.transform.position) < 0.25f || Vector3.Distance(GorillaTagger.Instance.rightHandTransform.position, vrrig.headMesh.transform.position) < 0.25f);
				if (flag)
				{
					bool flag2 = Time.time > OP.flushDelay;
					if (flag2)
					{
						OP.flushDelay = Time.time + 8.18f;
						int num = 0;
						while ((double)num < 3810.0)
						{
							try
							{
								Hashtable hashtable = new Hashtable();
								string text = "%n";
								object[] array = new object[] { text, text, text, text };
								hashtable.Add(1, array);
								PhotonNetwork.CurrentRoom.LoadBalancingClient.LoadBalancingPeer.OpRaiseEvent(204, hashtable, new RaiseEventOptions
								{
									TargetActors = new int[] { vrrig.Creator.ActorNumber }
								}, SendOptions.SendReliable);
							}
							catch
							{
							}
							OP.RPCProtection();
							num++;
						}
					}
				}
			}
		}

		// Token: 0x0400007B RID: 123
		private static float SpawnDelay = 1f;

		// Token: 0x0400007C RID: 124
		private static float OtherDelay = 1f;

		// Token: 0x0400007D RID: 125
		private static float stutterTimeout;

		// Token: 0x0400007E RID: 126
		public static float noiseMakerDelay;

		// Token: 0x0400007F RID: 127
		public static float angle;

		// Token: 0x04000080 RID: 128
		public static bool rightPrimary = ControllerInputPoller.instance.rightControllerPrimaryButton;

		// Token: 0x04000081 RID: 129
		public static bool rightSecondary = ControllerInputPoller.instance.rightControllerSecondaryButton || UnityInput.Current.GetKey(KeyCode.R);

		// Token: 0x04000082 RID: 130
		public static bool leftPrimary = ControllerInputPoller.instance.leftControllerPrimaryButton || UnityInput.Current.GetKey(KeyCode.F);

		// Token: 0x04000083 RID: 131
		public static bool leftSecondary = ControllerInputPoller.instance.leftControllerSecondaryButton || UnityInput.Current.GetKey(KeyCode.G);

		// Token: 0x04000084 RID: 132
		public static bool leftGrab = ControllerInputPoller.instance.leftGrab || UnityInput.Current.GetKey(KeyCode.LeftBracket);

		// Token: 0x04000085 RID: 133
		public static bool rightGrab = ControllerInputPoller.instance.rightGrab || UnityInput.Current.GetKey(KeyCode.RightBracket);

		// Token: 0x04000086 RID: 134
		public static float leftTrigger = ControllerInputPoller.TriggerFloat(4);

		// Token: 0x04000087 RID: 135
		public static float rightTrigger = ControllerInputPoller.TriggerFloat(5);

		// Token: 0x04000088 RID: 136
		private static float delay = 0f;

		// Token: 0x04000089 RID: 137
		public static float ina = 0f;

		// Token: 0x0400008A RID: 138
		public static float flushDelay = 0f;

		// Token: 0x0400008B RID: 139
		public static float bounceMe;

		// Token: 0x0400008C RID: 140
		private static string val = "%n";

		// Token: 0x0400008D RID: 141
		private static object sendEventData = new object[] { OP.val };

		// Token: 0x0400008E RID: 142
		private static float col;

		// Token: 0x0400008F RID: 143
		private static float col2;

		// Token: 0x04000090 RID: 144
		public static float cd = 0f;

		// Token: 0x04000091 RID: 145
		public static int i = 0;

		// Token: 0x04000092 RID: 146
		public static int reuseIndex = 0;

		// Token: 0x04000093 RID: 147
		public static float cooldown;

		// Token: 0x04000094 RID: 148
		public static List<CrittersStunBomb> ActiveBalls = new List<CrittersStunBomb>();

		// Token: 0x04000095 RID: 149
		public static float speedBoostPower = 0.85f;

		// Token: 0x04000096 RID: 150
		public static string SpeedBoostCurrently = "Mosa";
	}
}
