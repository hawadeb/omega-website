﻿using System;
using System.Collections.Generic;
using BepInEx;
using CanvasGUI.Management;
using Photon.Pun;
using UnityEngine;
using UnityEngine.InputSystem;

namespace Abyss.Mods
{
	// Token: 0x02000008 RID: 8
	[BepInPlugin("com.obsidian.lol", "obsidian", "1.0.0")]
	public class GUIMain : BaseUnityPlugin
	{
		// Token: 0x0600006D RID: 109 RVA: 0x00005E48 File Offset: 0x00004048
		public GUIMain()
		{
			GUIMain.g = this;
		}

		// Token: 0x0600006E RID: 110 RVA: 0x00005EB4 File Offset: 0x000040B4
		private void Awake()
		{
			this.LoadModsFromAssembly();
		}

		// Token: 0x0600006F RID: 111 RVA: 0x00005EC0 File Offset: 0x000040C0
		private void LoadModsFromAssembly()
		{
			this.modCategories.Clear();
			try
			{
				this.modCategories = Menu.categories;
			}
			catch (Exception ex)
			{
				Debug.LogError("Error loading mods: " + ex.Message + "\n" + ex.StackTrace);
			}
		}

		// Token: 0x06000070 RID: 112 RVA: 0x00005F20 File Offset: 0x00004120
		private void ExecuteModMethod(Module modMethod)
		{
			try
			{
				bool flag = modMethod.action != null && modMethod.action != null;
				if (flag)
				{
					bool toggleable = modMethod.toggleable;
					if (toggleable)
					{
						modMethod.toggled = !modMethod.toggled;
					}
					modMethod.action();
				}
			}
			catch (Exception ex)
			{
				Debug.LogError(string.Concat(new string[] { "Error invoking mod ", modMethod.title, ": ", ex.Message, "\n", ex.StackTrace }));
			}
		}

		// Token: 0x06000071 RID: 113 RVA: 0x00005FD0 File Offset: 0x000041D0
		private void ApplyTheme()
		{
			bool flag = GUIMain.currentTheme != this.lastAppliedTheme;
			if (flag)
			{
				this.windowColor = new Color(0.05f, 0.05f, 0.05f);
				this.buttonColor = new Color(0.1f, 0.1f, 0.1f);
				this.textFieldColor = new Color(0.1f, 0.1f, 0.1f);
				this.labelTextColor = Color.white;
				this.windowStyle = null;
				this.buttonStyle = null;
				this.labelStyle = null;
				this.textFieldStyle = null;
				bool flag2 = this.cachedTabButtonActiveTex != null;
				if (flag2)
				{
					global::UnityEngine.Object.Destroy(this.cachedTabButtonActiveTex);
					this.cachedTabButtonActiveTex = null;
				}
				bool flag3 = this.cachedTabButtonInactiveTex != null;
				if (flag3)
				{
					global::UnityEngine.Object.Destroy(this.cachedTabButtonInactiveTex);
					this.cachedTabButtonInactiveTex = null;
				}
				this.lastAppliedTheme = GUIMain.currentTheme;
			}
		}

		// Token: 0x06000072 RID: 114 RVA: 0x000060C1 File Offset: 0x000042C1
		public void CycleTheme()
		{
			GUIMain.currentTheme = (GUIMain.currentTheme + 1) % (GUIMain.Theme)Enum.GetValues(typeof(GUIMain.Theme)).Length;
			this.ApplyTheme();
		}

		// Token: 0x06000073 RID: 115 RVA: 0x000060EC File Offset: 0x000042EC
		private Texture2D MakeTex(int width, int height, Color col)
		{
			Color[] array = new Color[width * height];
			for (int i = 0; i < array.Length; i++)
			{
				array[i] = col;
			}
			Texture2D texture2D = new Texture2D(width, height);
			texture2D.SetPixels(array);
			texture2D.Apply();
			texture2D.filterMode = FilterMode.Bilinear;
			texture2D.wrapMode = TextureWrapMode.Clamp;
			return texture2D;
		}

		// Token: 0x06000074 RID: 116 RVA: 0x0000614C File Offset: 0x0000434C
		private Texture2D MakeRoundedRectTexture(int width, int height, Color col, int roundPixels)
		{
			return GUIHelper.MakeRoundedRectTexture(width, height, col, roundPixels);
		}

		// Token: 0x06000075 RID: 117 RVA: 0x00006168 File Offset: 0x00004368
		private void DrawMainWindow(int windowID)
		{
			float num = 150f;
			float num2 = GUIMain.horizontalPadding;
			float num3 = (float)this.windowStyle.padding.top;
			bool flag = this.cachedTabButtonActiveTex == null || this.cachedTabButtonInactiveTex == null;
			if (flag)
			{
				this.cachedTabButtonActiveTex = GUIHelper.MakeRoundedRectTexture(64, 64, new Color(0.1f, 0.5f, 1f), this.cornerRadius);
				this.cachedTabButtonInactiveTex = GUIHelper.MakeRoundedRectTexture(64, 64, this.buttonColor, this.cornerRadius);
			}
			Rect rect = new Rect(num2, num3 + (float)this.modCategories.Count * (GUIMain.buttonHeight + GUIMain.controlSpacing), num - GUIMain.horizontalPadding, GUIMain.buttonHeight);
			bool flag2 = GUI.Button(rect, "Theme: " + GUIMain.currentTheme.ToString(), this.buttonStyle);
			if (flag2)
			{
				this.CycleTheme();
			}
			for (int i = 0; i < this.modCategories.Count; i++)
			{
				Rect rect2 = new Rect(num2, num3 + (float)i * (GUIMain.buttonHeight + GUIMain.controlSpacing), num - GUIMain.horizontalPadding, GUIMain.buttonHeight);
				GUIStyle guistyle = new GUIStyle(this.buttonStyle);
				guistyle.fontStyle = 1;
				guistyle.alignment = 4;
				Texture2D texture2D = ((i == this.currentTab) ? this.cachedTabButtonActiveTex : this.cachedTabButtonInactiveTex);
				guistyle.normal.background = texture2D;
				guistyle.hover.background = texture2D;
				guistyle.normal.textColor = ((i == this.currentTab) ? Color.white : this.labelTextColor);
				bool flag3 = GUI.Button(rect2, this.modCategories[i].name, guistyle);
				if (flag3)
				{
					this.currentTab = i;
				}
			}
			float num4 = num + GUIMain.controlSpacing + GUIMain.horizontalPadding;
			float num5 = this.mainWindowRect.width - num4 - GUIMain.horizontalPadding;
			float num6 = 40f;
			float num7 = (float)this.windowStyle.padding.top + num6;
			float num8 = this.mainWindowRect.height - num7 - GUIMain.verticalPadding;
			Rect rect3 = new Rect(num4, num7, num5, num8);
			Rect rect4 = new Rect(0f, 0f, num5, 800f);
			this.scrollPosition = GUI.BeginScrollView(rect3, this.scrollPosition, rect4, GUIStyle.none, this.verticalScrollbarStyle);
			float num9 = 0f;
			bool flag4 = this.currentTab >= 0 && this.currentTab < this.modCategories.Count;
			if (flag4)
			{
				this.DrawCategoryMethods(this.modCategories[this.currentTab], num5, ref num9);
			}
			GUI.EndScrollView();
			GUI.DragWindow();
		}

		// Token: 0x06000076 RID: 118 RVA: 0x00006448 File Offset: 0x00004648
		private void DrawCategoryMethods(Category category, float contentWidth, ref float contentY)
		{
			foreach (Module module in category.buttons)
			{
				string text = module.title;
				bool toggleable = module.toggleable;
				if (toggleable)
				{
					text += (module.toggled ? " [ON]" : " [OFF]");
				}
				Rect rect = new Rect(0f, contentY, contentWidth, GUIMain.buttonHeight);
				GUIStyle guistyle = new GUIStyle(this.buttonStyle);
				bool flag = module.toggleable && module.toggled;
				if (flag)
				{
					guistyle.normal.background = this.MakeRoundedRectTexture(64, 64, new Color(0.2f, 0.7f, 0.2f), this.cornerRadius);
				}
				bool flag2 = GUI.Button(rect, text, guistyle);
				if (flag2)
				{
					this.ExecuteModMethod(module);
				}
				contentY += GUIMain.buttonHeight + GUIMain.controlSpacing;
			}
		}

		// Token: 0x06000077 RID: 119 RVA: 0x00006540 File Offset: 0x00004740
		private void OnGUI()
		{
			this.ApplyTheme();
			Rect rect = new Rect(10f, 10f, 500f, GUIMain.buttonHeight);
			GUI.Button(rect, string.Format("Obsidian.LOL | Ping: {0} | FPS: {1}", PhotonNetwork.GetPing(), (int)(1f / Time.deltaTime)), this.buttonStyle);
			bool flag = this.verticalScrollbarStyle == null;
			if (flag)
			{
				this.verticalScrollbarStyle = new GUIStyle(GUI.skin.verticalScrollbar);
				this.verticalScrollbarStyle.fixedWidth = 12f;
				this.verticalScrollbarStyle.normal.background = this.MakeTex(2, 2, new Color(0.1f, 0.1f, 0.1f));
			}
			bool flag2 = this.verticalScrollbarThumbStyle == null;
			if (flag2)
			{
				this.verticalScrollbarThumbStyle = new GUIStyle(GUI.skin.verticalScrollbarThumb);
				this.verticalScrollbarThumbStyle.fixedWidth = 12f;
				this.verticalScrollbarThumbStyle.normal.background = this.MakeTex(2, 2, new Color(0.3f, 0.3f, 0.3f));
			}
			GUI.skin.verticalScrollbar = this.verticalScrollbarStyle;
			GUI.skin.verticalScrollbarThumb = this.verticalScrollbarThumbStyle;
			float num = 1920f;
			float num2 = 1080f;
			float num3 = (float)Screen.width / num;
			float num4 = (float)Screen.height / num2;
			GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(num3, num4, 1f));
			bool flag3 = this.windowStyle == null;
			if (flag3)
			{
				this.windowStyle = new GUIStyle(GUI.skin.window);
				Texture2D texture2D = this.MakeRoundedRectTexture(64, 64, this.windowColor, this.cornerRadius);
				this.windowStyle.normal.background = texture2D;
				this.windowStyle.active.background = texture2D;
				this.windowStyle.hover.background = texture2D;
				this.windowStyle.focused.background = texture2D;
				this.windowStyle.onNormal.background = texture2D;
				this.windowStyle.onActive.background = texture2D;
				this.windowStyle.onHover.background = texture2D;
				this.windowStyle.onFocused.background = texture2D;
				this.windowStyle.normal.textColor = this.labelTextColor;
				this.windowStyle.padding.top = 30;
				this.windowStyle.fontSize = 24;
				this.windowStyle.fontStyle = 1;
				this.windowStyle.border = new RectOffset(this.cornerRadius, this.cornerRadius, this.cornerRadius, this.cornerRadius);
			}
			bool flag4 = this.buttonStyle == null;
			if (flag4)
			{
				this.buttonStyle = new GUIStyle(GUI.skin.button);
				Texture2D texture2D2 = this.MakeRoundedRectTexture(64, 64, this.buttonColor, this.cornerRadius);
				this.buttonStyle.normal.background = texture2D2;
				this.buttonStyle.active.background = texture2D2;
				this.buttonStyle.hover.background = texture2D2;
				this.buttonStyle.focused.background = texture2D2;
				this.buttonStyle.onNormal.background = texture2D2;
				this.buttonStyle.onActive.background = texture2D2;
				this.buttonStyle.onHover.background = texture2D2;
				this.buttonStyle.onFocused.background = texture2D2;
				this.buttonStyle.normal.textColor = this.labelTextColor;
				this.buttonStyle.fontStyle = 1;
				this.buttonStyle.border = new RectOffset(this.cornerRadius, this.cornerRadius, this.cornerRadius, this.cornerRadius);
			}
			bool flag5 = this.labelStyle == null;
			if (flag5)
			{
				this.labelStyle = new GUIStyle(GUI.skin.label);
				this.labelStyle.normal.textColor = this.labelTextColor;
				this.labelStyle.fontStyle = 1;
				this.labelStyle.alignment = 4;
			}
			bool flag6 = this.textFieldStyle == null;
			if (flag6)
			{
				this.textFieldStyle = new GUIStyle(GUI.skin.textField);
				Texture2D texture2D3 = this.MakeTex(2, 2, this.textFieldColor);
				this.textFieldStyle.normal.background = texture2D3;
				this.textFieldStyle.active.background = texture2D3;
				this.textFieldStyle.hover.background = texture2D3;
				this.textFieldStyle.focused.background = texture2D3;
				this.textFieldStyle.onNormal.background = texture2D3;
				this.textFieldStyle.onActive.background = texture2D3;
				this.textFieldStyle.onHover.background = texture2D3;
				this.textFieldStyle.onFocused.background = texture2D3;
				this.textFieldStyle.normal.textColor = this.labelTextColor;
				this.textFieldStyle.alignment = 4;
			}
			bool flag7 = this.showWindow;
			if (flag7)
			{
				this.mainWindowRect = GUI.Window(0, this.mainWindowRect, new GUI.WindowFunction(this.DrawMainWindow), "<color=white>Obsidian.LOL</color>", this.windowStyle);
			}
			GUIHelper.buttonStyle = this.buttonStyle;
			GUIHelper.labelStyle = this.labelStyle;
			GUIHelper.textFieldStyle = this.textFieldStyle;
		}

		// Token: 0x06000078 RID: 120 RVA: 0x00006AE0 File Offset: 0x00004CE0
		private void Update()
		{
			try
			{
				float time = Time.time;
				bool flag = Keyboard.current != null && Keyboard.current.qKey.wasPressedThisFrame;
				if (flag)
				{
					bool flag2 = time - GUIMain.LastPress > 0.2f;
					if (flag2)
					{
						this.showWindow = !this.showWindow;
						GUIMain.LastPress = time;
					}
				}
			}
			catch
			{
			}
		}

		// Token: 0x0400003A RID: 58
		public static GUIMain.Theme currentTheme = GUIMain.Theme.Dark;

		// Token: 0x0400003B RID: 59
		public Color windowColor;

		// Token: 0x0400003C RID: 60
		public Color buttonColor;

		// Token: 0x0400003D RID: 61
		public Color textFieldColor;

		// Token: 0x0400003E RID: 62
		public Color labelTextColor;

		// Token: 0x0400003F RID: 63
		private GUIStyle windowStyle;

		// Token: 0x04000040 RID: 64
		private GUIStyle buttonStyle;

		// Token: 0x04000041 RID: 65
		private GUIStyle labelStyle;

		// Token: 0x04000042 RID: 66
		private GUIStyle textFieldStyle;

		// Token: 0x04000043 RID: 67
		private GUIStyle verticalScrollbarStyle;

		// Token: 0x04000044 RID: 68
		private GUIStyle verticalScrollbarThumbStyle;

		// Token: 0x04000045 RID: 69
		private static float controlSpacing = 10f;

		// Token: 0x04000046 RID: 70
		private static float horizontalPadding = 10f;

		// Token: 0x04000047 RID: 71
		private static float verticalPadding = 10f;

		// Token: 0x04000048 RID: 72
		public static float buttonHeight = 30f;

		// Token: 0x04000049 RID: 73
		public int cornerRadius = 8;

		// Token: 0x0400004A RID: 74
		private Rect mainWindowRect = new Rect(100f, 50f, 600f, 430f);

		// Token: 0x0400004B RID: 75
		private int currentTab = 0;

		// Token: 0x0400004C RID: 76
		private Vector2 scrollPosition = Vector2.zero;

		// Token: 0x0400004D RID: 77
		private List<Category> modCategories = new List<Category>();

		// Token: 0x0400004E RID: 78
		private bool showWindow = true;

		// Token: 0x0400004F RID: 79
		private GUIMain.Theme lastAppliedTheme = (GUIMain.Theme)(-1);

		// Token: 0x04000050 RID: 80
		private Texture2D cachedTabButtonActiveTex;

		// Token: 0x04000051 RID: 81
		private Texture2D cachedTabButtonInactiveTex;

		// Token: 0x04000052 RID: 82
		public static GUIMain g;

		// Token: 0x04000053 RID: 83
		public static float LastPress = 0f;

		// Token: 0x02000044 RID: 68
		public enum Theme
		{
			// Token: 0x040001D5 RID: 469
			Dark,
			// Token: 0x040001D6 RID: 470
			VeryDark,
			// Token: 0x040001D7 RID: 471
			Light,
			// Token: 0x040001D8 RID: 472
			Space,
			// Token: 0x040001D9 RID: 473
			Purple,
			// Token: 0x040001DA RID: 474
			Oreo,
			// Token: 0x040001DB RID: 475
			Solarized,
			// Token: 0x040001DC RID: 476
			Forest
		}

		// Token: 0x02000045 RID: 69
		public class ModCategory
		{
			// Token: 0x040001DD RID: 477
			public string Name;
		}
	}
}
