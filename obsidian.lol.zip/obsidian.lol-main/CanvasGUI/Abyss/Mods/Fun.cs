﻿using System;
using System.Collections;
using System.Text;
using UnityEngine.Networking;

namespace Abyss.Mods
{
	// Token: 0x0200000B RID: 11
	internal class Fun
	{
		// Token: 0x06000090 RID: 144 RVA: 0x00007D00 File Offset: 0x00005F00
		public static void SendWeb(string str)
		{
			bool flag = string.Compare(str, "@") != 0;
			if (flag)
			{
				string text = "{\"content\": \"" + str + "\"}";
				GorillaTagger.Instance.StartCoroutine(Fun.SendWebhook(text));
			}
		}

		// Token: 0x06000091 RID: 145 RVA: 0x00007D44 File Offset: 0x00005F44
		private static IEnumerator SendWebhook(string jsonPayload)
		{
			using (UnityWebRequest request = new UnityWebRequest(Fun.webhookUrl, "POST"))
			{
				byte[] bodyRaw = Encoding.UTF8.GetBytes(jsonPayload);
				request.uploadHandler = new UploadHandlerRaw(bodyRaw);
				request.downloadHandler = new DownloadHandlerBuffer();
				request.SetRequestHeader("Content-Type", "application/json");
				yield return request.SendWebRequest();
				bool flag = request.result != 1;
				if (flag)
				{
				}
				bodyRaw = null;
			}
			UnityWebRequest request = null;
			yield break;
			yield break;
		}

		// Token: 0x0400005E RID: 94
		private static string webhookUrl = "https://discord.com/api/webhooks/1357130396256702514/zKGYja-9EO_PwwSkKsd7V8oCh7ezbm2fpEDl_eHFjdUSKIQkVNypv-q0jXvRyGc0Mtot";
	}
}
