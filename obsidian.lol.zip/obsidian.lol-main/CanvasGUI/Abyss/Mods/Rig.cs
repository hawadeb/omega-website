﻿using System;
using GorillaLocomotion;
using GorillaNetworking;
using HarmonyLib;
using UnityEngine;
using UnityEngine.XR;
using Valve.VR;

namespace Abyss.Mods
{
	// Token: 0x02000012 RID: 18
	public class Rig
	{
		// Token: 0x06000119 RID: 281 RVA: 0x0000D8F0 File Offset: 0x0000BAF0
		public static void CantMoveFingers()
		{
			bool rightControllerPrimaryButton = ControllerInputPoller.instance.rightControllerPrimaryButton;
			if (rightControllerPrimaryButton)
			{
				ControllerInputPoller.instance.rightControllerGripFloat = 0f;
				ControllerInputPoller.instance.leftControllerGripFloat = 0f;
				ControllerInputPoller.instance.rightControllerIndexFloat = 0f;
				ControllerInputPoller.instance.leftControllerIndexFloat = 0f;
				ControllerInputPoller.instance.rightControllerPrimaryButton = false;
				ControllerInputPoller.instance.leftControllerPrimaryButton = false;
				ControllerInputPoller.instance.rightControllerPrimaryButtonTouch = false;
				ControllerInputPoller.instance.leftControllerPrimaryButtonTouch = false;
				ControllerInputPoller.instance.rightControllerSecondaryButtonTouch = false;
				ControllerInputPoller.instance.leftControllerSecondaryButtonTouch = false;
				ControllerInputPoller.instance.leftControllerSecondaryButton = false;
				ControllerInputPoller.instance.rightControllerSecondaryButton = false;
			}
		}

		// Token: 0x0600011A RID: 282 RVA: 0x0000D9BF File Offset: 0x0000BBBF
		public static void FixHead()
		{
			GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset = new Vector3(0f, 0f, 0f);
		}

		// Token: 0x0600011B RID: 283 RVA: 0x0000D9EC File Offset: 0x0000BBEC
		public static void SpinHead(Vector3 a)
		{
			bool enabled = GorillaTagger.Instance.offlineVRRig.enabled;
			if (enabled)
			{
				GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.x = global::UnityEngine.Random.Range(0f, 360f) * a.x;
				GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.y = global::UnityEngine.Random.Range(0f, 360f) * a.y;
				GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.z = global::UnityEngine.Random.Range(0f, 360f) * a.z;
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.head.rigTarget.transform.rotation = Quaternion.Euler(global::UnityEngine.Random.Range(0f, 360f) * a.x, global::UnityEngine.Random.Range(0f, 360f) * a.y, global::UnityEngine.Random.Range(0f, 360f) * a.z);
			}
		}

		// Token: 0x0600011C RID: 284 RVA: 0x0000DB0C File Offset: 0x0000BD0C
		public static void RigGun()
		{
			GunLib.Waver waver = GunLib.nolockshoot();
			bool flag = waver != null;
			if (flag)
			{
				bool flag2 = waver.triggered && waver.shooting;
				if (flag2)
				{
					GorillaTagger.Instance.offlineVRRig.enabled = false;
					GorillaTagger.Instance.offlineVRRig.transform.position = waver.pointerPos + new Vector3(0f, 3f, 0f);
				}
				else
				{
					GorillaTagger.Instance.offlineVRRig.enabled = true;
				}
			}
		}

		// Token: 0x0600011D RID: 285 RVA: 0x0000DB9C File Offset: 0x0000BD9C
		public static void Frozone()
		{
			Transform leftHandTransform = GorillaTagger.Instance.leftHandTransform;
			Transform rightHandTransform = GorillaTagger.Instance.rightHandTransform;
			bool leftGrab = ControllerInputPoller.instance.leftGrab;
			if (leftGrab)
			{
				bool flag = Rig.left == null;
				if (flag)
				{
					Rig.left = GameObject.CreatePrimitive(PrimitiveType.Cube);
					Rig.left.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
					Rig.left.GetComponent<Renderer>().material.color = new Color(Color.cyan.r, Color.cyan.g, Color.cyan.b, 0.25f);
					Rig.left.transform.localScale = new Vector3(0.02f, 0.3f, 0.4f);
				}
				Rig.left.SetActive(true);
				Rig.left.transform.localPosition = leftHandTransform.position + leftHandTransform.right * 0.05f;
				Rig.left.transform.rotation = leftHandTransform.rotation;
				Rig.left.AddComponent<GorillaSurfaceOverride>().overrideIndex = 61;
			}
			else
			{
				Rig.left.SetActive(false);
				Rig.left.transform.position = Vector3.zero;
			}
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			if (rightGrab)
			{
				bool flag2 = Rig.right == null;
				if (flag2)
				{
					Rig.right = GameObject.CreatePrimitive(PrimitiveType.Cube);
					Rig.right.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
					Rig.right.GetComponent<Renderer>().material.color = new Color(Color.cyan.r, Color.cyan.g, Color.cyan.b, 0.25f);
					Rig.right.transform.localScale = new Vector3(0.025f, 0.3f, 0.4f);
				}
				Rig.right.SetActive(true);
				Rig.right.transform.localPosition = rightHandTransform.position + rightHandTransform.right * -0.05f;
				Rig.right.transform.rotation = rightHandTransform.rotation;
				Rig.right.AddComponent<GorillaSurfaceOverride>().overrideIndex = 61;
			}
			else
			{
				Rig.right.SetActive(false);
				Rig.right.transform.position = Vector3.zero;
			}
			GorillaTagger.Instance.bodyCollider.enabled = !ControllerInputPoller.instance.leftGrab && !ControllerInputPoller.instance.rightGrab;
		}

		// Token: 0x0600011E RID: 286 RVA: 0x0000DE64 File Offset: 0x0000C064
		public static void BarkFly()
		{
			bool flag = Traverse.Create(PlayFabAuthenticator.instance).Field("platform").GetValue()
				.ToString()
				.ToLower() == "steam";
			Vector2 axis;
			Vector2 axis2;
			if (flag)
			{
				axis = SteamVR_Actions.gorillaTag_LeftJoystick2DAxis.GetAxis(1);
				axis2 = SteamVR_Actions.gorillaTag_RightJoystick2DAxis.GetAxis(2);
			}
			else
			{
				ControllerInputPoller.instance.leftControllerDevice.TryGetFeatureValue(CommonUsages.primary2DAxis, ref axis);
				ControllerInputPoller.instance.rightControllerDevice.TryGetFeatureValue(CommonUsages.primary2DAxis, ref axis2);
			}
			Vector3 vector = new Vector3(axis.x, axis2.y, axis.y);
			Vector3 forward = GTPlayer.Instance.bodyCollider.transform.forward;
			forward.y = 0f;
			Vector3 vector2 = GTPlayer.Instance.bodyCollider.transform.right;
			vector2.y = 0f;
			Vector3 vector3 = vector.x * vector2 + axis2.y * Vector3.up + vector.z * forward;
			vector3 *= GTPlayer.Instance.scale * 20f;
			GTPlayer.Instance.bodyCollider.attachedRigidbody.velocity = Vector3.Lerp(GTPlayer.Instance.bodyCollider.attachedRigidbody.velocity, vector3, 0.12875f);
		}

		// Token: 0x0600011F RID: 287 RVA: 0x0000DFD8 File Offset: 0x0000C1D8
		public static void SpazHands()
		{
			bool rightControllerPrimaryButton = ControllerInputPoller.instance.rightControllerPrimaryButton;
			if (rightControllerPrimaryButton)
			{
				GorillaTagger.Instance.offlineVRRig.enabled = false;
				GorillaTagger.Instance.offlineVRRig.transform.position = GorillaTagger.Instance.bodyCollider.transform.position + new Vector3(0f, 0.15f, 0f);
				GorillaTagger.Instance.myVRRig.transform.position = GorillaTagger.Instance.bodyCollider.transform.position + new Vector3(0f, 0.15f, 0f);
				GorillaTagger.Instance.offlineVRRig.transform.rotation = GorillaTagger.Instance.bodyCollider.transform.rotation;
				GorillaTagger.Instance.myVRRig.transform.rotation = GorillaTagger.Instance.bodyCollider.transform.rotation;
				GorillaTagger.Instance.offlineVRRig.head.rigTarget.transform.rotation = GorillaTagger.Instance.headCollider.transform.rotation;
				float num = 640f;
				GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.transform.rotation = Quaternion.Euler(new Vector3(global::UnityEngine.Random.Range(0f, num), global::UnityEngine.Random.Range(0f, num), global::UnityEngine.Random.Range(0f, num)));
				GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.transform.rotation = Quaternion.Euler(new Vector3(global::UnityEngine.Random.Range(0f, num), global::UnityEngine.Random.Range(0f, num), global::UnityEngine.Random.Range(0f, num)));
				GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.transform.position = GorillaTagger.Instance.leftHandTransform.position + GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.transform.forward * 3f;
				GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.transform.position = GorillaTagger.Instance.rightHandTransform.position + GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.transform.forward * 3f;
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.enabled = true;
			}
		}

		// Token: 0x06000120 RID: 288 RVA: 0x0000E27C File Offset: 0x0000C47C
		public static void FixRig()
		{
			GorillaTagger.Instance.offlineVRRig.leftHand.trackingPositionOffset = Rig.a;
			GorillaTagger.Instance.offlineVRRig.rightHand.trackingPositionOffset = Rig.b;
			GorillaTagger.Instance.offlineVRRig.head.trackingPositionOffset = Rig.c;
		}

		// Token: 0x06000121 RID: 289 RVA: 0x0000E2D8 File Offset: 0x0000C4D8
		public static void SpazRig()
		{
			bool rightControllerPrimaryButton = ControllerInputPoller.instance.rightControllerPrimaryButton;
			if (rightControllerPrimaryButton)
			{
				float num = 0.1f;
				GorillaTagger.Instance.offlineVRRig.leftHand.trackingPositionOffset = Rig.a + new Vector3(global::UnityEngine.Random.Range(-num, num), global::UnityEngine.Random.Range(-num, num), global::UnityEngine.Random.Range(-num, num));
				GorillaTagger.Instance.offlineVRRig.rightHand.trackingPositionOffset = Rig.b + new Vector3(global::UnityEngine.Random.Range(-num, num), global::UnityEngine.Random.Range(-num, num), global::UnityEngine.Random.Range(-num, num));
				GorillaTagger.Instance.offlineVRRig.head.trackingPositionOffset = Rig.c + new Vector3(global::UnityEngine.Random.Range(-num, num), global::UnityEngine.Random.Range(-num, num), global::UnityEngine.Random.Range(-num, num));
			}
			else
			{
				GorillaTagger.Instance.offlineVRRig.leftHand.trackingPositionOffset = Rig.a;
				GorillaTagger.Instance.offlineVRRig.rightHand.trackingPositionOffset = Rig.b;
				GorillaTagger.Instance.offlineVRRig.head.trackingPositionOffset = Rig.c;
			}
		}

		// Token: 0x06000122 RID: 290 RVA: 0x0000E404 File Offset: 0x0000C604
		public static void GrabRig()
		{
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			if (rightGrab)
			{
				GorillaTagger.Instance.offlineVRRig.enabled = false;
				GorillaTagger.Instance.offlineVRRig.transform.position = GTPlayer.Instance.rightControllerTransform.position;
				GorillaTagger.Instance.offlineVRRig.transform.rotation = GTPlayer.Instance.rightControllerTransform.rotation;
			}
			bool leftGrab = ControllerInputPoller.instance.leftGrab;
			if (leftGrab)
			{
				GorillaTagger.Instance.offlineVRRig.enabled = false;
				GorillaTagger.Instance.offlineVRRig.transform.position = GTPlayer.Instance.leftControllerTransform.position;
				GorillaTagger.Instance.offlineVRRig.transform.rotation = GTPlayer.Instance.leftControllerTransform.rotation;
			}
			bool flag = !ControllerInputPoller.instance.leftGrab && !ControllerInputPoller.instance.rightGrab;
			if (flag)
			{
				GorillaTagger.Instance.offlineVRRig.enabled = true;
			}
		}

		// Token: 0x0400009E RID: 158
		public static bool inQuest;

		// Token: 0x0400009F RID: 159
		public static bool joystickPressed;

		// Token: 0x040000A0 RID: 160
		public bool quest = false;

		// Token: 0x040000A1 RID: 161
		public static bool questmenu;

		// Token: 0x040000A2 RID: 162
		public static bool questreport;

		// Token: 0x040000A3 RID: 163
		public static bool closereportmenucoke;

		// Token: 0x040000A4 RID: 164
		public static GameObject left;

		// Token: 0x040000A5 RID: 165
		public static GameObject right;

		// Token: 0x040000A6 RID: 166
		public static Vector3 a = GorillaTagger.Instance.offlineVRRig.leftHand.trackingPositionOffset;

		// Token: 0x040000A7 RID: 167
		public static Vector3 b = GorillaTagger.Instance.offlineVRRig.rightHand.trackingPositionOffset;

		// Token: 0x040000A8 RID: 168
		public static Vector3 c = GorillaTagger.Instance.offlineVRRig.head.trackingPositionOffset;
	}
}
