﻿using System;
using TMPro;
using UnityEngine;

namespace Abyss.Mods
{
	// Token: 0x0200000E RID: 14
	public class Loader
	{
		// Token: 0x0600009B RID: 155 RVA: 0x00008040 File Offset: 0x00006240
		public static void AlsoAwake()
		{
			GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/motd (1)").GetComponent<TextMeshPro>().text = "Obsidian.LOL";
			GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/motd (1)").GetComponent<TextMeshPro>().color = Loader.col;
			GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/motdtext").GetComponent<TextMeshPro>().text = "Made by Moe & Cosmic;";
			GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/CodeOfConduct").GetComponent<TextMeshPro>().text = "Obsidian.LOL";
			GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/CodeOfConduct").GetComponent<TextMeshPro>().color = Loader.col;
			GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/COC Text").GetComponent<TextMeshPro>().text = "Thank you for choosing Obsidian.LOL.\nWE ARE NOT RESPONSIBLE FOR ANY BANS!!";
		}

		// Token: 0x04000062 RID: 98
		public static Color col = Color.black;
	}
}
