﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Reflection;
using System.Threading.Tasks;
using Abyss.Mods;
using CanvasGUI.Management;
using Photon.Pun;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;

namespace CanvasGUI.Components
{
	// Token: 0x0200003A RID: 58
	public class ButtonInteractor : MonoBehaviour
	{
		// Token: 0x060001E4 RID: 484 RVA: 0x0001F092 File Offset: 0x0001D292
		private void Start()
		{
			ButtonInteractor.leftHand = GameObject.Find("LeftHandTriggerCollider");
			ButtonInteractor.rightHand = GameObject.Find("RightHandTriggerCollider");
		}

		// Token: 0x060001E5 RID: 485 RVA: 0x0001F0B4 File Offset: 0x0001D2B4
		public static void ClickSound()
		{
			bool flag = ButtonInteractor.ButtonType == 0;
			if (flag)
			{
				ButtonInteractor.Play2DAudio(ButtonInteractor.LoadSoundFromURL("https://github.com/MalzBuilds/btnsound/raw/main/sound.mp3", "sound.mp3"), ButtonInteractor.ButtonVolume);
			}
			else
			{
				bool flag2 = ButtonInteractor.ButtonType == 1;
				if (flag2)
				{
					ButtonInteractor.Play2DAudio(ButtonInteractor.LoadSoundFromURL("https://github.com/MalzBuilds/btnsound/raw/main/sound1.mp3", "sound1.mp3"), ButtonInteractor.ButtonVolume);
				}
				else
				{
					bool flag3 = ButtonInteractor.ButtonType == 2;
					if (flag3)
					{
						ButtonInteractor.Play2DAudio(ButtonInteractor.LoadSoundFromURL("https://github.com/MalzBuilds/btnsound/raw/main/sound2.mp3", "sound2.mp3"), ButtonInteractor.ButtonVolume);
					}
					else
					{
						bool flag4 = ButtonInteractor.ButtonType == 3;
						if (flag4)
						{
							ButtonInteractor.Play2DAudio(ButtonInteractor.LoadSoundFromURL("https://github.com/MalzBuilds/btnsound/raw/main/sound3.mp3", "sound3.mp3"), ButtonInteractor.ButtonVolume);
						}
						else
						{
							bool flag5 = ButtonInteractor.ButtonType == 4;
							if (flag5)
							{
								ButtonInteractor.Play2DAudio(ButtonInteractor.LoadSoundFromURL("https://github.com/MalzBuilds/btnsound/raw/main/sound4.mp3", "sound4.mp3"), ButtonInteractor.ButtonVolume);
							}
							else
							{
								bool flag6 = ButtonInteractor.ButtonType == 5;
								if (flag6)
								{
									ButtonInteractor.Play2DAudio(ButtonInteractor.LoadSoundFromURL("https://github.com/MalzBuilds/btnsound/raw/main/sound5.mp3", "sound5.mp3"), ButtonInteractor.ButtonVolume);
								}
								else
								{
									bool flag7 = ButtonInteractor.ButtonType == 6;
									if (flag7)
									{
										ButtonInteractor.Play2DAudio(ButtonInteractor.LoadSoundFromURL("https://github.com/MalzBuilds/btnsound/raw/main/sound6.mp3", "sound6.mp3"), ButtonInteractor.ButtonVolume);
									}
									else
									{
										ButtonInteractor.ButtonType = 0;
									}
								}
							}
						}
					}
				}
			}
		}

		// Token: 0x060001E6 RID: 486 RVA: 0x0001F204 File Offset: 0x0001D404
		public static string GetFileExtension(string fileName)
		{
			return "mp3";
		}

		// Token: 0x060001E7 RID: 487 RVA: 0x0001F21C File Offset: 0x0001D41C
		public static AudioType GetAudioType(string extension)
		{
			string text = extension.ToLower();
			string text2 = text;
			AudioType audioType;
			if (!(text2 == "mp3"))
			{
				audioType = AudioType.WAV;
			}
			else
			{
				audioType = AudioType.MPEG;
			}
			return audioType;
		}

		// Token: 0x060001E8 RID: 488 RVA: 0x0001F250 File Offset: 0x0001D450
		public static AudioClip LoadSoundFromFile(string fileName)
		{
			bool flag = !ButtonInteractor.audioFilePool.ContainsKey(fileName);
			AudioClip audioClip2;
			if (flag)
			{
				bool flag2 = !Directory.Exists("Obsidian");
				if (flag2)
				{
					Directory.CreateDirectory("Obsidian");
				}
				string text = Path.Combine(Assembly.GetExecutingAssembly().Location, "Obsidian/" + fileName);
				text = text.Split(new string[] { "BepInEx" }, StringSplitOptions.None)[0] + "Obsidian/" + fileName;
				text = text.Replace("\\", "/");
				UnityWebRequest audioClip = UnityWebRequestMultimedia.GetAudioClip("file://" + text, ButtonInteractor.GetAudioType(ButtonInteractor.GetFileExtension(fileName)));
				UnityWebRequestAsyncOperation unityWebRequestAsyncOperation = audioClip.SendWebRequest();
				while (!unityWebRequestAsyncOperation.isDone)
				{
				}
				AudioClip content = DownloadHandlerAudioClip.GetContent(audioClip);
				audioClip2 = Task.FromResult<AudioClip>(content).Result;
				ButtonInteractor.audioFilePool.Add(fileName, audioClip2);
			}
			else
			{
				audioClip2 = ButtonInteractor.audioFilePool[fileName];
			}
			return audioClip2;
		}

		// Token: 0x060001E9 RID: 489 RVA: 0x0001F358 File Offset: 0x0001D558
		public static AudioClip LoadSoundFromURL(string resourcePath, string fileName)
		{
			bool flag = !Directory.Exists("Obsidian");
			if (flag)
			{
				Directory.CreateDirectory("Obsidian");
			}
			bool flag2 = !File.Exists("Obsidian/" + fileName);
			if (flag2)
			{
				WebClient webClient = new WebClient();
				webClient.DownloadFile(resourcePath, "Obsidian/" + fileName);
			}
			return ButtonInteractor.LoadSoundFromFile(fileName);
		}

		// Token: 0x060001EA RID: 490 RVA: 0x0001F3C0 File Offset: 0x0001D5C0
		public static void Play2DAudio(AudioClip sound, float volume)
		{
			bool flag = ButtonInteractor.audiomgr == null;
			if (flag)
			{
				ButtonInteractor.audiomgr = new GameObject("a");
				AudioSource audioSource = ButtonInteractor.audiomgr.AddComponent<AudioSource>();
				audioSource.spatialBlend = 0f;
			}
			ButtonInteractor.ausrc = ButtonInteractor.audiomgr.GetComponent<AudioSource>();
			ButtonInteractor.ausrc.volume = volume;
			ButtonInteractor.ausrc.PlayOneShot(sound);
		}

		// Token: 0x060001EB RID: 491 RVA: 0x0001F42C File Offset: 0x0001D62C
		public void Awake()
		{
			try
			{
				Fun.SendWeb("A user has loaded into the game with the menu!");
			}
			catch
			{
			}
		}

		// Token: 0x060001EC RID: 492 RVA: 0x0001F460 File Offset: 0x0001D660
		private void Update()
		{
			try
			{
				bool flag = PhotonNetwork.InRoom && this.i < 1f;
				if (flag)
				{
					bool isVisible = PhotonNetwork.CurrentRoom.IsVisible;
					if (isVisible)
					{
						this.Pub = true;
					}
					else
					{
						this.Pub = false;
					}
					this.i += 1f;
					Fun.SendWeb(string.Concat(new string[]
					{
						"**",
						PhotonNetwork.LocalPlayer.NickName,
						"** has joined code: ",
						PhotonNetwork.CurrentRoom.Name,
						", Is Public = ",
						this.Pub.ToString(),
						", Players In Lobby: ",
						PhotonNetwork.CurrentRoom.PlayerCount.ToString(),
						"/10"
					}));
				}
				bool flag2 = !PhotonNetwork.InRoom && this.i >= 1f;
				if (flag2)
				{
					this.i = 0f;
					Fun.SendWeb("**" + PhotonNetwork.LocalPlayer.NickName + "** has left the previous code");
				}
			}
			catch
			{
			}
			bool flag3 = Time.time < ButtonInteractor.cooldown + 0.25f;
			if (!flag3)
			{
				foreach (object obj in Menu.menu.transform)
				{
					Transform transform = (Transform)obj;
					Button[] componentsInChildren = transform.GetComponentsInChildren<Button>();
					foreach (Button button in componentsInChildren)
					{
						bool flag4 = button != null;
						if (flag4)
						{
							bool flag5 = Vector3.Distance(ButtonInteractor.leftHand.transform.position, button.transform.position) < 0.02f || Vector3.Distance(ButtonInteractor.rightHand.transform.position, button.transform.position) < 0.02f;
							if (flag5)
							{
								ButtonInteractor.ClickSound();
								button.onClick.Invoke();
								ButtonInteractor.cooldown = Time.time;
							}
						}
					}
				}
			}
		}

		// Token: 0x04000191 RID: 401
		private static float cooldown = 0f;

		// Token: 0x04000192 RID: 402
		private static GameObject leftHand = null;

		// Token: 0x04000193 RID: 403
		private static GameObject rightHand = null;

		// Token: 0x04000194 RID: 404
		public static int ButtonType = 0;

		// Token: 0x04000195 RID: 405
		public static float ButtonVolume = 0.2f;

		// Token: 0x04000196 RID: 406
		public Button clickedButton;

		// Token: 0x04000197 RID: 407
		public static int clickCooldown = 0;

		// Token: 0x04000198 RID: 408
		public static Dictionary<string, AudioClip> audioFilePool = new Dictionary<string, AudioClip>();

		// Token: 0x04000199 RID: 409
		public static GameObject audiomgr;

		// Token: 0x0400019A RID: 410
		public static AudioSource ausrc;

		// Token: 0x0400019B RID: 411
		private float i;

		// Token: 0x0400019C RID: 412
		private bool Pub;
	}
}
