﻿using System;
using System.Collections;
using CanvasGUI.Management;
using UnityEngine;
using UnityEngine.UI;

namespace CanvasGUI.Components
{
	// Token: 0x02000039 RID: 57
	public class ScrollInteractor : MonoBehaviour
	{
		// Token: 0x060001E1 RID: 481 RVA: 0x0001EEB3 File Offset: 0x0001D0B3
		public static IEnumerator Scroll(RectTransform rect, float amount)
		{
			ScrollInteractor.scroll += amount;
			Vector2 position = rect.anchoredPosition + new Vector2(0f, amount);
			float elapsed = 0f;
			while (elapsed < 0.4f)
			{
				elapsed += Time.deltaTime;
				float t = elapsed / 0.4f;
				t = 1f - Mathf.Pow(1f - t, 3f);
				rect.anchoredPosition = Vector2.Lerp(rect.anchoredPosition, position, t);
				yield return null;
			}
			rect.anchoredPosition = position;
			yield break;
		}

		// Token: 0x060001E2 RID: 482 RVA: 0x0001EECC File Offset: 0x0001D0CC
		private void Start()
		{
			RectTransform tabs = Menu.menu.transform.Find("Canvas/Tab Scrolling/Tabs").GetComponent<RectTransform>();
			RectTransform modules = Menu.menu.transform.Find("Canvas/Module Scrolling/Modules").GetComponent<RectTransform>();
			Menu.menu.transform.Find("Canvas/UpTab").GetComponent<Button>().onClick.AddListener(delegate
			{
				this.StartCoroutine(ScrollInteractor.Scroll(tabs, -80f));
			});
			Menu.menu.transform.Find("Canvas/DownTab").GetComponent<Button>().onClick.AddListener(delegate
			{
				this.StartCoroutine(ScrollInteractor.Scroll(tabs, 80f));
			});
			Menu.menu.transform.Find("Canvas/UpModules").GetComponent<Button>().onClick.AddListener(delegate
			{
				this.StartCoroutine(ScrollInteractor.Scroll(modules, -200f));
			});
			Menu.menu.transform.Find("Canvas/DownModules").GetComponent<Button>().onClick.AddListener(delegate
			{
				this.StartCoroutine(ScrollInteractor.Scroll(modules, 200f));
			});
			Menu.GenerateGradient(Menu.menu.transform.Find("Canvas/UpTab").GetComponent<Image>(), Settings.col1, Settings.col2);
			Menu.GenerateGradient(Menu.menu.transform.Find("Canvas/DownTab").GetComponent<Image>(), Settings.col1, Settings.col2);
			Menu.GenerateGradient(Menu.menu.transform.Find("Canvas/UpModules").GetComponent<Image>(), Settings.col1, Settings.col2);
			Menu.GenerateGradient(Menu.menu.transform.Find("Canvas/DownModules").GetComponent<Image>(), Settings.col1, Settings.col2);
		}

		// Token: 0x04000190 RID: 400
		public static float scroll;
	}
}
