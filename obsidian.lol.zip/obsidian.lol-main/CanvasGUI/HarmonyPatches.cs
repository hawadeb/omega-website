﻿using System;
using System.Reflection;
using HarmonyLib;

namespace CanvasGUI
{
	// Token: 0x0200002D RID: 45
	public class HarmonyPatches
	{
		// Token: 0x1700001F RID: 31
		// (get) Token: 0x060001A0 RID: 416 RVA: 0x00019C6B File Offset: 0x00017E6B
		// (set) Token: 0x060001A1 RID: 417 RVA: 0x00019C72 File Offset: 0x00017E72
		public static bool patched { get; private set; }

		// Token: 0x060001A2 RID: 418 RVA: 0x00019C7C File Offset: 0x00017E7C
		public static void Patch(bool toggle)
		{
			if (toggle)
			{
				bool flag = !HarmonyPatches.patched;
				if (flag)
				{
					bool flag2 = HarmonyPatches.instance == null;
					if (flag2)
					{
						HarmonyPatches.instance = new Harmony("com.obs.gorillatag.lol");
					}
				}
				HarmonyPatches.instance.PatchAll(Assembly.GetExecutingAssembly());
				HarmonyPatches.patched = true;
			}
			else
			{
				bool flag3 = HarmonyPatches.instance != null;
				if (flag3)
				{
					bool patched = HarmonyPatches.patched;
					if (patched)
					{
						HarmonyPatches.instance.UnpatchSelf();
					}
				}
				HarmonyPatches.patched = false;
			}
		}

		// Token: 0x04000171 RID: 369
		public static Harmony instance;

		// Token: 0x04000173 RID: 371
		public const string id = "com.obs.gorillatag.lol";
	}
}
