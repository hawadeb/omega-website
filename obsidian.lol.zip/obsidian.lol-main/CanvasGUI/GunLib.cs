﻿using System;
using System.Collections;
using Athrion.Libary;
using BepInEx;
using CanvasGUI.Management;
using GorillaLocomotion;
using Photon.Pun;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x02000002 RID: 2
public static class GunLib
{
	// Token: 0x06000001 RID: 1 RVA: 0x00002050 File Offset: 0x00000250
	public static void DarkenColor()
	{
		Color col = Settings.col1;
		Color col2 = Settings.col2;
		GunLib.col = Color.Lerp(col, col2, Mathf.PingPong(Time.time, 1f));
	}

	// Token: 0x06000002 RID: 2 RVA: 0x00002088 File Offset: 0x00000288
	public static void Clean()
	{
		bool flag = GunLib.pointer != null && GunLib.lr != null;
		bool flag2 = flag;
		if (flag2)
		{
			global::UnityEngine.Object.Destroy(GunLib.pointer);
			GunLib.pointer = null;
			global::UnityEngine.Object.Destroy(GunLib.lr.gameObject);
			GunLib.lr = null;
			GunLib.data = new GunLib.Waver(false, false, false, null, default(Vector3), default(RaycastHit));
		}
	}

	// Token: 0x06000003 RID: 3 RVA: 0x00002100 File Offset: 0x00000300
	public static void Update()
	{
		bool isDeviceActive = XRSettings.isDeviceActive;
		if (isDeviceActive)
		{
			GunLib.data.shooting = ControllerInputPoller.instance.rightGrab;
			GunLib.data.triggered = ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f;
		}
		else
		{
			GunLib.data.shooting = UnityInput.Current.GetMouseButton(0);
			GunLib.data.triggered = UnityInput.Current.GetMouseButton(1);
		}
	}

	// Token: 0x17000001 RID: 1
	// (get) Token: 0x06000004 RID: 4 RVA: 0x0000217E File Offset: 0x0000037E
	// (set) Token: 0x06000005 RID: 5 RVA: 0x00002185 File Offset: 0x00000385
	public static float BoxESPWidth { get; set; } = 1f;

	// Token: 0x17000002 RID: 2
	// (get) Token: 0x06000006 RID: 6 RVA: 0x0000218D File Offset: 0x0000038D
	// (set) Token: 0x06000007 RID: 7 RVA: 0x00002194 File Offset: 0x00000394
	public static float BoxESPHeight { get; set; } = 2f;

	// Token: 0x06000008 RID: 8 RVA: 0x0000219C File Offset: 0x0000039C
	public static void BoxESP(VRRig LockedRigOrPlayerOrwhatever)
	{
		bool flag = PhotonNetwork.InRoom || PhotonNetwork.InLobby;
		if (flag)
		{
			bool flag2 = LockedRigOrPlayerOrwhatever != null && LockedRigOrPlayerOrwhatever != GorillaTagger.Instance.offlineVRRig;
			if (flag2)
			{
				GameObject gameObject = new GameObject();
				LineRenderer lineRenderer = gameObject.AddComponent<LineRenderer>();
				Vector3 position = LockedRigOrPlayerOrwhatever.transform.position;
				Vector3[] array = new Vector3[5];
				float boxESPHeight = GunLib.BoxESPHeight;
				float boxESPWidth = GunLib.BoxESPWidth;
				array[0] = position + LockedRigOrPlayerOrwhatever.transform.right * (-boxESPWidth / 2f) + LockedRigOrPlayerOrwhatever.transform.up * (boxESPHeight / 2f);
				array[1] = position + LockedRigOrPlayerOrwhatever.transform.right * (boxESPWidth / 2f) + LockedRigOrPlayerOrwhatever.transform.up * (boxESPHeight / 2f);
				array[2] = position + LockedRigOrPlayerOrwhatever.transform.right * (boxESPWidth / 2f) + LockedRigOrPlayerOrwhatever.transform.up * (-boxESPHeight / 2f);
				array[3] = position + LockedRigOrPlayerOrwhatever.transform.right * (-boxESPWidth / 2f) + LockedRigOrPlayerOrwhatever.transform.up * (-boxESPHeight / 2f);
				array[4] = array[0];
				lineRenderer.positionCount = array.Length;
				lineRenderer.SetPositions(array);
				lineRenderer.startWidth = 0.007f;
				lineRenderer.endWidth = 0.007f;
				Shader shader = Shader.Find("Sprites/Default");
				bool flag3 = shader != null;
				if (flag3)
				{
					lineRenderer.material = new Material(shader);
				}
				lineRenderer.material.renderQueue = 3000;
				lineRenderer.startColor = Settings.col1;
				lineRenderer.endColor = Settings.col2;
				LineRenderer lineRenderer2 = new GameObject().AddComponent<LineRenderer>();
				lineRenderer2.transform.parent = gameObject.transform;
				Vector3[] array2 = new Vector3[5];
				array2[0] = position + LockedRigOrPlayerOrwhatever.transform.right * (-boxESPWidth / 2f - 0.02f) + LockedRigOrPlayerOrwhatever.transform.up * (boxESPHeight / 2f + 0.02f);
				array2[1] = position + LockedRigOrPlayerOrwhatever.transform.right * (boxESPWidth / 2f + 0.02f) + LockedRigOrPlayerOrwhatever.transform.up * (boxESPHeight / 2f + 0.02f);
				array2[2] = position + LockedRigOrPlayerOrwhatever.transform.right * (boxESPWidth / 2f + 0.02f) + LockedRigOrPlayerOrwhatever.transform.up * (-boxESPHeight / 2f - 0.02f);
				array2[3] = position + LockedRigOrPlayerOrwhatever.transform.right * (-boxESPWidth / 2f - 0.02f) + LockedRigOrPlayerOrwhatever.transform.up * (-boxESPHeight / 2f - 0.02f);
				array2[4] = array2[0];
				lineRenderer2.positionCount = array2.Length;
				lineRenderer2.SetPositions(array2);
				lineRenderer2.startWidth = 0.01f;
				lineRenderer2.endWidth = 0.01f;
				Shader shader2 = Shader.Find("Sprites/Default");
				bool flag4 = shader2 != null;
				if (flag4)
				{
					lineRenderer2.material = new Material(shader2);
				}
				lineRenderer2.material.renderQueue = 3000;
				lineRenderer2.startColor = Settings.col1;
				lineRenderer2.endColor = Settings.col2;
				gameObject.transform.position = LockedRigOrPlayerOrwhatever.transform.position;
				gameObject.transform.rotation = LockedRigOrPlayerOrwhatever.transform.rotation;
				AthrionGunLibrary athrionGunLibrary = gameObject.AddComponent<AthrionGunLibrary>();
				athrionGunLibrary.StartCoroutine(GunLib.AnimateBox(gameObject, lineRenderer2));
				global::UnityEngine.Object.Destroy(gameObject, 0.05f);
			}
		}
	}

	// Token: 0x06000009 RID: 9 RVA: 0x0000260E File Offset: 0x0000080E
	private static IEnumerator AnimateBox(GameObject box, LineRenderer outline)
	{
		Vector3 originalScale = box.transform.localScale;
		while (box != null)
		{
			float scaleFactor = 1f + Mathf.Sin(Time.time * 4f) * 0.04f;
			box.transform.localScale = originalScale * scaleFactor;
			outline.startColor = Color.Lerp(Settings.col1, Settings.col2, Mathf.PingPong(Time.time, 1f));
			outline.endColor = Color.Lerp(Settings.col1, Settings.col2, Mathf.PingPong(Time.time, 1f));
			yield return null;
		}
		yield break;
	}

	// Token: 0x0600000A RID: 10 RVA: 0x00002624 File Offset: 0x00000824
	public static GunLib.Waver lockShoot()
	{
		GunLib.Waver waver;
		try
		{
			bool isDeviceActive = XRSettings.isDeviceActive;
			bool flag = isDeviceActive;
			bool flag2 = flag;
			if (flag2)
			{
				Transform rightControllerTransform = GTPlayer.Instance.rightControllerTransform;
				GunLib.data.shooting = ControllerInputPoller.instance.rightGrab;
				GunLib.data.triggered = ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f;
				bool shooting = GunLib.data.shooting;
				bool flag3 = shooting;
				if (flag3)
				{
					Renderer renderer = ((GunLib.pointer != null) ? GunLib.pointer.GetComponent<Renderer>() : null);
					bool flag4 = GunLib.data.Target == null && !GunLib.data.lockedOn;
					bool flag5 = flag4;
					if (flag5)
					{
						RaycastHit raycastHit;
						bool flag6 = Physics.Raycast(rightControllerTransform.position - rightControllerTransform.up, -rightControllerTransform.up, out raycastHit) && GunLib.pointer == null;
						bool flag7 = flag6;
						if (flag7)
						{
							GunLib.pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
							global::UnityEngine.Object.Destroy(GunLib.pointer.GetComponent<Rigidbody>());
							global::UnityEngine.Object.Destroy(GunLib.pointer.GetComponent<SphereCollider>());
							GunLib.pointer.transform.localScale = new Vector3(0.08f, 0.08f, 0.08f);
							renderer = ((GunLib.pointer != null) ? GunLib.pointer.GetComponent<Renderer>() : null);
							renderer.material.color = GunLib.col;
							renderer.material.shader = Shader.Find("GUI/Text Shader");
						}
						bool flag8 = GunLib.lr == null;
						bool flag9 = flag8;
						if (flag9)
						{
							GameObject gameObject = new GameObject("line");
							GunLib.lr = gameObject.AddComponent<LineRenderer>();
							GunLib.lr.endWidth = 0.014f;
							GunLib.lr.startWidth = 0.014f;
							GunLib.lr.material.shader = Shader.Find("GUI/Text Shader");
						}
						GunLib.SetWaveLine(GunLib.lr, rightControllerTransform.position, raycastHit.point);
						GunLib.data.pointerPos = raycastHit.point;
						GunLib.pointer.transform.position = raycastHit.point;
						VRRig componentInParent = raycastHit.collider.GetComponentInParent<VRRig>();
						bool flag10 = componentInParent != null;
						bool flag11 = flag10;
						if (flag11)
						{
							bool triggered = GunLib.data.triggered;
							bool flag12 = triggered;
							if (flag12)
							{
								GunLib.data.Target = componentInParent;
								GunLib.data.lockedOn = true;
								GunLib.BoxESP(GunLib.data.Target);
								GunLib.lr.startColor = GunLib.col;
								GunLib.lr.endColor = GunLib.col;
								renderer.material.color = GunLib.col;
							}
							else
							{
								GunLib.data.lockedOn = false;
								GunLib.lr.startColor = GunLib.col;
								GunLib.lr.endColor = GunLib.col;
								renderer.material.color = GunLib.col;
								GorillaTagger.Instance.StartVibration(false, GorillaTagger.Instance.tagHapticStrength / 2f, GorillaTagger.Instance.tagHapticDuration / 2f);
							}
						}
						else
						{
							GunLib.data.lockedOn = false;
							GunLib.lr.startColor = GunLib.col;
							GunLib.lr.endColor = GunLib.col;
							renderer.material.color = GunLib.col;
						}
					}
					bool flag13 = GunLib.data.triggered && GunLib.data.Target != null;
					bool flag14 = flag13;
					if (flag14)
					{
						GunLib.data.lockedOn = true;
						GunLib.SetWaveLine(GunLib.lr, rightControllerTransform.position, GunLib.data.Target.transform.position);
						GunLib.BoxESP(GunLib.data.Target);
						GunLib.data.pointerPos = GunLib.data.Target.transform.position;
						GunLib.pointer.transform.position = GunLib.data.Target.transform.position;
						GunLib.lr.startColor = GunLib.col;
						GunLib.lr.endColor = GunLib.col;
						renderer.material.color = GunLib.col;
					}
					else
					{
						bool flag15 = GunLib.data.Target != null;
						bool flag16 = flag15;
						if (flag16)
						{
							GunLib.data.lockedOn = false;
							GunLib.data.Target = null;
							GunLib.lr.startColor = GunLib.col;
							GunLib.lr.endColor = GunLib.col;
							renderer.material.color = GunLib.col;
						}
					}
				}
				else
				{
					GunLib.Clean();
				}
				waver = GunLib.data;
			}
			else
			{
				GunLib.data.shooting = UnityInput.Current.GetMouseButton(1);
				GunLib.data.triggered = UnityInput.Current.GetMouseButton(0);
				bool shooting2 = GunLib.data.shooting;
				bool flag17 = shooting2;
				if (flag17)
				{
					Renderer renderer2 = ((GunLib.pointer != null) ? GunLib.pointer.GetComponent<Renderer>() : null);
					bool flag18 = GunLib.data.Target == null && !GunLib.data.lockedOn;
					bool flag19 = flag18;
					if (flag19)
					{
						Camera component = GameObject.Find("Shoulder Camera").GetComponent<Camera>();
						Ray ray = ((component != null) ? component.ScreenPointToRay(UnityInput.Current.mousePosition) : GorillaTagger.Instance.mainCamera.GetComponent<Camera>().ScreenPointToRay(UnityInput.Current.mousePosition));
						RaycastHit raycastHit2;
						bool flag20 = Physics.Raycast(ray.origin, ray.direction, out raycastHit2) && GunLib.pointer == null;
						bool flag21 = flag20;
						if (flag21)
						{
							GunLib.pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
							global::UnityEngine.Object.Destroy(GunLib.pointer.GetComponent<Rigidbody>());
							global::UnityEngine.Object.Destroy(GunLib.pointer.GetComponent<SphereCollider>());
							GunLib.pointer.transform.localScale = new Vector3(0.08f, 0.08f, 0.08f);
							renderer2 = ((GunLib.pointer != null) ? GunLib.pointer.GetComponent<Renderer>() : null);
							renderer2.material.color = GunLib.col;
							renderer2.material.shader = Shader.Find("GUI/Text Shader");
						}
						bool flag22 = GunLib.lr == null;
						bool flag23 = flag22;
						if (flag23)
						{
							GameObject gameObject2 = new GameObject("line");
							GunLib.lr = gameObject2.AddComponent<LineRenderer>();
							GunLib.lr.endWidth = 0.014f;
							GunLib.lr.startWidth = 0.014f;
							GunLib.lr.material.shader = Shader.Find("GUI/Text Shader");
						}
						GunLib.SetWaveLine(GunLib.lr, GTPlayer.Instance.headCollider.transform.position, raycastHit2.point);
						GunLib.data.pointerPos = raycastHit2.point;
						GunLib.pointer.transform.position = raycastHit2.point;
						VRRig componentInParent2 = raycastHit2.collider.GetComponentInParent<VRRig>();
						bool flag24 = componentInParent2 != null && GunLib.data.Target == null;
						bool flag25 = flag24;
						if (flag25)
						{
							bool triggered2 = GunLib.data.triggered;
							bool flag26 = triggered2;
							if (flag26)
							{
								GunLib.data.Target = componentInParent2;
								GunLib.data.lockedOn = true;
								GunLib.BoxESP(GunLib.data.Target);
							}
							else
							{
								GunLib.data.lockedOn = false;
								GunLib.lr.startColor = GunLib.col;
								GunLib.lr.endColor = GunLib.col;
								renderer2.material.color = GunLib.col;
							}
						}
						else
						{
							GunLib.data.lockedOn = false;
							GunLib.lr.startColor = GunLib.col;
							GunLib.lr.endColor = GunLib.col;
							renderer2.material.color = GunLib.col;
						}
					}
					bool flag27 = renderer2 != null;
					bool flag28 = flag27;
					if (flag28)
					{
						bool flag29 = GunLib.data.triggered && GunLib.data.Target != null;
						bool flag30 = flag29;
						if (flag30)
						{
							GunLib.SetWaveLine(GunLib.lr, GTPlayer.Instance.rightControllerTransform.position, GunLib.data.Target.transform.position);
							GunLib.data.pointerPos = GunLib.data.Target.transform.position;
							GunLib.pointer.transform.position = GunLib.data.Target.transform.position;
							GunLib.data.lockedOn = true;
							GunLib.lr.startColor = GunLib.col;
							GunLib.BoxESP(GunLib.data.Target);
							GunLib.lr.endColor = GunLib.col;
							renderer2.material.color = GunLib.col;
						}
						else
						{
							bool flag31 = GunLib.data.Target != null;
							bool flag32 = flag31;
							if (flag32)
							{
								GunLib.data.lockedOn = false;
								GunLib.data.Target = null;
								GunLib.lr.startColor = GunLib.col;
								GunLib.lr.endColor = GunLib.col;
								renderer2.material.color = GunLib.col;
							}
						}
					}
				}
				else
				{
					GunLib.Clean();
				}
				waver = GunLib.data;
			}
		}
		catch
		{
			waver = null;
		}
		return waver;
	}

	// Token: 0x0600000B RID: 11 RVA: 0x00003024 File Offset: 0x00001224
	public static GunLib.Waver nolockshoot()
	{
		GunLib.Waver waver;
		try
		{
			bool isDeviceActive = XRSettings.isDeviceActive;
			bool flag = isDeviceActive;
			bool flag2 = flag;
			if (flag2)
			{
				Transform rightControllerTransform = GTPlayer.Instance.rightControllerTransform;
				GunLib.data.shooting = ControllerInputPoller.instance.rightGrab;
				GunLib.data.triggered = ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f;
				bool shooting = GunLib.data.shooting;
				bool flag3 = shooting;
				if (flag3)
				{
					Renderer renderer = ((GunLib.pointer != null) ? GunLib.pointer.GetComponent<Renderer>() : null);
					RaycastHit raycastHit;
					bool flag4 = Physics.Raycast(rightControllerTransform.position - rightControllerTransform.up, -rightControllerTransform.up, out raycastHit) && GunLib.pointer == null;
					bool flag5 = flag4;
					if (flag5)
					{
						GunLib.pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
						global::UnityEngine.Object.Destroy(GunLib.pointer.GetComponent<Rigidbody>());
						global::UnityEngine.Object.Destroy(GunLib.pointer.GetComponent<SphereCollider>());
						GunLib.pointer.transform.localScale = new Vector3(0.08f, 0.08f, 0.08f);
						renderer = ((GunLib.pointer != null) ? GunLib.pointer.GetComponent<Renderer>() : null);
						renderer.material.color = GunLib.col;
						renderer.material.shader = Shader.Find("GUI/Text Shader");
					}
					bool flag6 = GunLib.lr == null;
					bool flag7 = flag6;
					if (flag7)
					{
						GameObject gameObject = new GameObject("line");
						GunLib.lr = gameObject.AddComponent<LineRenderer>();
						GunLib.lr.endWidth = 0.014f;
						GunLib.lr.startWidth = 0.014f;
						GunLib.lr.material.shader = Shader.Find("GUI/Text Shader");
					}
					GunLib.SetWaveLine(GunLib.lr, rightControllerTransform.position, raycastHit.point);
					GunLib.data.pointerPos = raycastHit.point;
					GunLib.data.RaycastHit = raycastHit;
					GunLib.pointer.transform.position = raycastHit.point;
					VRRig componentInParent = raycastHit.collider.GetComponentInParent<VRRig>();
					bool flag8 = componentInParent != null;
					bool flag9 = flag8;
					if (flag9)
					{
						bool triggered = GunLib.data.triggered;
						bool flag10 = triggered;
						if (flag10)
						{
							GunLib.data.Target = componentInParent;
							GunLib.data.lockedOn = true;
							GunLib.BoxESP(GunLib.data.Target);
							GunLib.lr.startColor = GunLib.col;
							GunLib.lr.endColor = GunLib.col;
							renderer.material.color = GunLib.col;
						}
						else
						{
							GunLib.lr.startColor = GunLib.col;
							GunLib.lr.endColor = GunLib.col;
							renderer.material.color = GunLib.col;
							GunLib.data.lockedOn = false;
							GorillaTagger.Instance.StartVibration(false, GorillaTagger.Instance.tagHapticStrength / 3f, GorillaTagger.Instance.tagHapticDuration / 2f);
						}
					}
					else
					{
						GunLib.lr.startColor = GunLib.col;
						GunLib.lr.endColor = GunLib.col;
						renderer.material.color = GunLib.col;
						GunLib.data.lockedOn = false;
					}
				}
				else
				{
					GunLib.Clean();
				}
				waver = GunLib.data;
			}
			else
			{
				GunLib.data.shooting = UnityInput.Current.GetMouseButton(1);
				GunLib.data.triggered = UnityInput.Current.GetMouseButton(0);
				Renderer renderer2 = ((GunLib.pointer != null) ? GunLib.pointer.GetComponent<Renderer>() : null);
				Camera component = GameObject.Find("Shoulder Camera").GetComponent<Camera>();
				Ray ray = ((component != null) ? component.ScreenPointToRay(UnityInput.Current.mousePosition) : GorillaTagger.Instance.mainCamera.GetComponent<Camera>().ScreenPointToRay(UnityInput.Current.mousePosition));
				RaycastHit raycastHit2;
				bool flag11 = Physics.Raycast(ray.origin, ray.direction, out raycastHit2) && GunLib.pointer == null;
				bool flag12 = flag11;
				if (flag12)
				{
					GunLib.pointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
					global::UnityEngine.Object.Destroy(GunLib.pointer.GetComponent<Rigidbody>());
					global::UnityEngine.Object.Destroy(GunLib.pointer.GetComponent<SphereCollider>());
					GunLib.pointer.transform.localScale = new Vector3(0.08f, 0.08f, 0.08f);
					renderer2 = ((GunLib.pointer != null) ? GunLib.pointer.GetComponent<Renderer>() : null);
					renderer2.material.color = GunLib.col;
					renderer2.material.shader = Shader.Find("GUI/Text Shader");
				}
				bool flag13 = GunLib.lr == null;
				bool flag14 = flag13;
				if (flag14)
				{
					GameObject gameObject2 = new GameObject("line");
					GunLib.lr = gameObject2.AddComponent<LineRenderer>();
					GunLib.lr.endWidth = 0.014f;
					GunLib.lr.startWidth = 0.014f;
					GunLib.lr.material.shader = Shader.Find("GUI/Text Shader");
				}
				GunLib.SetWaveLine(GunLib.lr, GTPlayer.Instance.headCollider.transform.position, raycastHit2.point);
				GunLib.data.pointerPos = raycastHit2.point;
				GunLib.pointer.transform.position = raycastHit2.point;
				VRRig componentInParent2 = raycastHit2.collider.GetComponentInParent<VRRig>();
				bool flag15 = componentInParent2 != null;
				bool flag16 = flag15;
				if (flag16)
				{
					bool triggered2 = GunLib.data.triggered;
					bool flag17 = triggered2;
					if (flag17)
					{
						GunLib.data.lockedOn = true;
						GunLib.BoxESP(GunLib.data.Target);
						GunLib.lr.startColor = GunLib.col;
						GunLib.lr.endColor = GunLib.col;
						renderer2.material.color = GunLib.col;
					}
					else
					{
						GunLib.data.lockedOn = false;
						GunLib.lr.startColor = GunLib.col;
						GunLib.lr.endColor = GunLib.col;
						renderer2.material.color = GunLib.col;
					}
				}
				else
				{
					GunLib.data.lockedOn = false;
					GunLib.lr.startColor = GunLib.col;
					GunLib.lr.endColor = GunLib.col;
					renderer2.material.color = GunLib.col;
				}
				waver = GunLib.data;
			}
		}
		catch
		{
			waver = null;
		}
		return waver;
	}

	// Token: 0x0600000C RID: 12 RVA: 0x00003700 File Offset: 0x00001900
	private static void SetWaveLine(LineRenderer lr, Vector3 start, Vector3 end)
	{
		GunLib.DarkenColor();
		bool flag = lr == null;
		if (!flag)
		{
			int wavy = GunLib.Wavy;
			lr.positionCount = wavy;
			lr.SetPosition(0, start);
			lr.SetPosition(wavy - 1, end);
			float num = Vector3.Distance(start, end);
			float freq = GunLib.Freq;
			float num2 = Mathf.Clamp(num * 0.05f, 0.02f, 0.25f);
			Vector3 normalized = (end - start).normalized;
			Vector3 vector = Vector3.Cross(normalized, Vector3.up).normalized;
			bool flag2 = vector == Vector3.zero;
			if (flag2)
			{
				vector = Vector3.Cross(normalized, Vector3.forward).normalized;
			}
			float num3 = Time.time * 4f;
			for (int i = 1; i < wavy - 1; i++)
			{
				float num4 = (float)i / (float)(wavy - 1);
				float num5 = Mathf.Sin(num4 * 3.1415927f) * Mathf.Pow(num4, 1f);
				Vector3 vector2 = Vector3.Lerp(start, end, num4);
				float num6 = Mathf.Sin(num4 * freq + num3) * num2 * num5;
				lr.SetPosition(i, vector2 + vector * num6);
			}
		}
	}

	// Token: 0x04000001 RID: 1
	public static Color col = Color.Lerp(Settings.col1, Settings.col2, Mathf.PingPong(Time.time, 1f));

	// Token: 0x04000004 RID: 4
	public static int Wavy = 200;

	// Token: 0x04000005 RID: 5
	public static float Freq = 35f;

	// Token: 0x04000006 RID: 6
	private static GameObject pointer;

	// Token: 0x04000007 RID: 7
	private static LineRenderer lr;

	// Token: 0x04000008 RID: 8
	private static GunLib.Waver data = new GunLib.Waver(false, false, false, null, default(Vector3), default(RaycastHit));

	// Token: 0x0200003C RID: 60
	public class Waver
	{
		// Token: 0x1700002A RID: 42
		// (get) Token: 0x060001EF RID: 495 RVA: 0x0001F721 File Offset: 0x0001D921
		// (set) Token: 0x060001F0 RID: 496 RVA: 0x0001F729 File Offset: 0x0001D929
		public VRRig Target { get; set; }

		// Token: 0x1700002B RID: 43
		// (get) Token: 0x060001F1 RID: 497 RVA: 0x0001F732 File Offset: 0x0001D932
		// (set) Token: 0x060001F2 RID: 498 RVA: 0x0001F73A File Offset: 0x0001D93A
		public bool shooting { get; set; }

		// Token: 0x1700002C RID: 44
		// (get) Token: 0x060001F3 RID: 499 RVA: 0x0001F743 File Offset: 0x0001D943
		// (set) Token: 0x060001F4 RID: 500 RVA: 0x0001F74B File Offset: 0x0001D94B
		public bool lockedOn { get; set; }

		// Token: 0x1700002D RID: 45
		// (get) Token: 0x060001F5 RID: 501 RVA: 0x0001F754 File Offset: 0x0001D954
		// (set) Token: 0x060001F6 RID: 502 RVA: 0x0001F75C File Offset: 0x0001D95C
		public Vector3 pointerPos { get; set; }

		// Token: 0x1700002E RID: 46
		// (get) Token: 0x060001F7 RID: 503 RVA: 0x0001F765 File Offset: 0x0001D965
		// (set) Token: 0x060001F8 RID: 504 RVA: 0x0001F76D File Offset: 0x0001D96D
		public GameObject hitPointer { get; set; }

		// Token: 0x1700002F RID: 47
		// (get) Token: 0x060001F9 RID: 505 RVA: 0x0001F776 File Offset: 0x0001D976
		// (set) Token: 0x060001FA RID: 506 RVA: 0x0001F77E File Offset: 0x0001D97E
		public RaycastHit RaycastHit { get; set; }

		// Token: 0x17000030 RID: 48
		// (get) Token: 0x060001FB RID: 507 RVA: 0x0001F787 File Offset: 0x0001D987
		// (set) Token: 0x060001FC RID: 508 RVA: 0x0001F78F File Offset: 0x0001D98F
		public bool triggered { get; set; }

		// Token: 0x060001FD RID: 509 RVA: 0x0001F798 File Offset: 0x0001D998
		public Waver(bool stateTriggered, bool triggy, bool foundPlayer, VRRig player = null, Vector3 hitpos = default(Vector3), RaycastHit raycastHit = default(RaycastHit))
		{
			this.Target = player;
			this.shooting = stateTriggered;
			this.lockedOn = foundPlayer;
			this.pointerPos = hitpos;
			this.triggered = triggy;
			this.RaycastHit = raycastHit;
		}
	}
}
