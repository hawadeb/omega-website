﻿using System;
using System.Collections;
using System.Collections.Generic;
using BepInEx;
using Photon.Pun;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.XR;

namespace Athrion.Libary
{
	// Token: 0x02000006 RID: 6
	public class AthrionGunLibrary : MonoBehaviour
	{
		// Token: 0x1700001D RID: 29
		// (get) Token: 0x0600004C RID: 76 RVA: 0x000042A3 File Offset: 0x000024A3
		// (set) Token: 0x0600004D RID: 77 RVA: 0x000042AA File Offset: 0x000024AA
		public static AthrionGunLibrary.AnimationMode CurrentAnimationMode
		{
			get
			{
				return AthrionGunLibrary.currentAnimationMode;
			}
			set
			{
				AthrionGunLibrary.currentAnimationMode = value;
			}
		}

		// Token: 0x0600004E RID: 78 RVA: 0x000042B4 File Offset: 0x000024B4
		private static Vector3 CalculateBezierPoint(Vector3 start, Vector3 mid, Vector3 end, float t)
		{
			return Mathf.Pow(1f - t, 2f) * start + 2f * (1f - t) * t * mid + Mathf.Pow(t, 2f) * end;
		}

		// Token: 0x0600004F RID: 79 RVA: 0x00004310 File Offset: 0x00002510
		public static void ChanegeAnimationMode()
		{
			bool flag = AthrionGunLibrary.currentAnimationMode == AthrionGunLibrary.AnimationMode.Wave;
			if (flag)
			{
				AthrionGunLibrary.currentAnimationMode = AthrionGunLibrary.AnimationMode.Pulse;
			}
			else
			{
				bool flag2 = AthrionGunLibrary.currentAnimationMode == AthrionGunLibrary.AnimationMode.Pulse;
				if (flag2)
				{
					AthrionGunLibrary.currentAnimationMode = AthrionGunLibrary.AnimationMode.Zigzag;
				}
				else
				{
					bool flag3 = AthrionGunLibrary.currentAnimationMode == AthrionGunLibrary.AnimationMode.Zigzag;
					if (flag3)
					{
						AthrionGunLibrary.currentAnimationMode = AthrionGunLibrary.AnimationMode.Bouncing;
					}
					else
					{
						bool flag4 = AthrionGunLibrary.currentAnimationMode == AthrionGunLibrary.AnimationMode.Bouncing;
						if (flag4)
						{
							AthrionGunLibrary.currentAnimationMode = AthrionGunLibrary.AnimationMode.Spiral;
						}
						else
						{
							bool flag5 = AthrionGunLibrary.currentAnimationMode == AthrionGunLibrary.AnimationMode.Spiral;
							if (flag5)
							{
								AthrionGunLibrary.currentAnimationMode = AthrionGunLibrary.AnimationMode.SineWave;
							}
							else
							{
								bool flag6 = AthrionGunLibrary.currentAnimationMode == AthrionGunLibrary.AnimationMode.SineWave;
								if (flag6)
								{
									AthrionGunLibrary.currentAnimationMode = AthrionGunLibrary.AnimationMode.Helix;
								}
								else
								{
									bool flag7 = AthrionGunLibrary.currentAnimationMode == AthrionGunLibrary.AnimationMode.Helix;
									if (flag7)
									{
										AthrionGunLibrary.currentAnimationMode = AthrionGunLibrary.AnimationMode.Sawtooth;
									}
									else
									{
										bool flag8 = AthrionGunLibrary.currentAnimationMode == AthrionGunLibrary.AnimationMode.Sawtooth;
										if (flag8)
										{
											AthrionGunLibrary.currentAnimationMode = AthrionGunLibrary.AnimationMode.TriangleWave;
										}
										else
										{
											bool flag9 = AthrionGunLibrary.currentAnimationMode == AthrionGunLibrary.AnimationMode.TriangleWave;
											if (flag9)
											{
												AthrionGunLibrary.currentAnimationMode = AthrionGunLibrary.AnimationMode.DefaultBezier;
											}
											else
											{
												bool flag10 = AthrionGunLibrary.currentAnimationMode == AthrionGunLibrary.AnimationMode.DefaultBezier;
												if (flag10)
												{
													AthrionGunLibrary.currentAnimationMode = AthrionGunLibrary.AnimationMode.Wave;
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}

		// Token: 0x06000050 RID: 80 RVA: 0x00004414 File Offset: 0x00002614
		private static void CurveLineRenderer(LineRenderer lineRenderer, Vector3 start, Vector3 mid, Vector3 end)
		{
			lineRenderer.positionCount = AthrionGunLibrary.GunConfig.LineCurve;
			AthrionGunLibrary.waveTimeOffset += Time.deltaTime * 2f;
			int i = 0;
			while (i < AthrionGunLibrary.GunConfig.LineCurve)
			{
				float num = (float)i / (float)(AthrionGunLibrary.GunConfig.LineCurve - 1);
				Vector3 vector;
				switch (AthrionGunLibrary.currentAnimationMode)
				{
				case AthrionGunLibrary.AnimationMode.Wave:
					vector = Vector3.Lerp(start, end, num);
					vector.x += Mathf.Sin(num * AthrionGunLibrary.GunConfig.WaveFrequency + AthrionGunLibrary.waveTimeOffset) * AthrionGunLibrary.GunConfig.WaveAmplitude;
					break;
				case AthrionGunLibrary.AnimationMode.Pulse:
					vector = Vector3.Lerp(start, end, num + Mathf.Sin(Time.time * AthrionGunLibrary.GunConfig.WaveFrequency) * 0.02f);
					break;
				case AthrionGunLibrary.AnimationMode.Zigzag:
					vector = Vector3.Lerp(start, end, num);
					vector.x += (float)((i % 2 == 0) ? 1 : (-1)) * AthrionGunLibrary.GunConfig.WaveAmplitude * Mathf.Sin(AthrionGunLibrary.waveTimeOffset);
					break;
				case AthrionGunLibrary.AnimationMode.Bouncing:
					vector = Vector3.Lerp(start, end, num);
					vector.y += Mathf.Abs(Mathf.Sin(num * AthrionGunLibrary.GunConfig.WaveFrequency + AthrionGunLibrary.waveTimeOffset) * AthrionGunLibrary.GunConfig.WaveAmplitude);
					break;
				case AthrionGunLibrary.AnimationMode.Spiral:
					vector = Vector3.Lerp(start, end, num);
					vector.x += Mathf.Sin(num * AthrionGunLibrary.GunConfig.WaveFrequency + AthrionGunLibrary.waveTimeOffset) * AthrionGunLibrary.GunConfig.WaveAmplitude;
					vector.y += Mathf.Cos(num * AthrionGunLibrary.GunConfig.WaveFrequency + AthrionGunLibrary.waveTimeOffset) * AthrionGunLibrary.GunConfig.WaveAmplitude;
					break;
				case AthrionGunLibrary.AnimationMode.SineWave:
					vector = Vector3.Lerp(start, end, num);
					vector.z += Mathf.Sin(num * AthrionGunLibrary.GunConfig.WaveFrequency + AthrionGunLibrary.waveTimeOffset) * AthrionGunLibrary.GunConfig.WaveAmplitude;
					break;
				case AthrionGunLibrary.AnimationMode.Helix:
					vector = Vector3.Lerp(start, end, num);
					vector.x += Mathf.Sin(6.2831855f * AthrionGunLibrary.GunConfig.WaveFrequency * num + AthrionGunLibrary.waveTimeOffset) * AthrionGunLibrary.GunConfig.WaveAmplitude;
					vector.z += Mathf.Cos(6.2831855f * AthrionGunLibrary.GunConfig.WaveFrequency * num + AthrionGunLibrary.waveTimeOffset) * AthrionGunLibrary.GunConfig.WaveAmplitude;
					break;
				case AthrionGunLibrary.AnimationMode.Sawtooth:
					vector = Vector3.Lerp(start, end, num);
					vector.z += AthrionGunLibrary.GunConfig.WaveAmplitude * (2f * (num * AthrionGunLibrary.GunConfig.WaveFrequency - Mathf.Floor(num * AthrionGunLibrary.GunConfig.WaveFrequency + 0.5f)));
					break;
				case AthrionGunLibrary.AnimationMode.TriangleWave:
					vector = Vector3.Lerp(start, end, num);
					vector.y += AthrionGunLibrary.GunConfig.WaveAmplitude * (2f * Mathf.Abs(2f * (num * AthrionGunLibrary.GunConfig.WaveFrequency - Mathf.Floor(num * AthrionGunLibrary.GunConfig.WaveFrequency + 0.5f))) - 1f);
					break;
				case AthrionGunLibrary.AnimationMode.DefaultBezier:
					goto IL_031C;
				default:
					goto IL_031C;
				}
				IL_0328:
				lineRenderer.SetPosition(i, vector);
				i++;
				continue;
				IL_031C:
				vector = AthrionGunLibrary.CalculateBezierPoint(start, mid, end, num);
				goto IL_0328;
			}
		}

		// Token: 0x06000051 RID: 81 RVA: 0x0000476D File Offset: 0x0000296D
		private static IEnumerator AnimateLineGradient(LineRenderer lineRenderer, Color32 startColor, Color32 endColor)
		{
			float t = 0f;
			for (;;)
			{
				t += Time.deltaTime;
				lineRenderer.startColor = Color.Lerp(startColor, endColor, Mathf.PingPong(t, 1f));
				lineRenderer.endColor = Color.Lerp(endColor, startColor, Mathf.PingPong(t, 1f));
				yield return null;
			}
			yield break;
		}

		// Token: 0x06000052 RID: 82 RVA: 0x0000478A File Offset: 0x0000298A
		private static IEnumerator StartCurvyLineRenderer(LineRenderer lineRenderer, Vector3 start, Vector3 mid, Vector3 end, Color32 startColor, Color32 endColor)
		{
			lineRenderer.startColor = startColor;
			lineRenderer.endColor = endColor;
			lineRenderer.positionCount = AthrionGunLibrary.GunConfig.LineCurve;
			for (;;)
			{
				AthrionGunLibrary.CurveLineRenderer(lineRenderer, start, mid, end);
				yield return null;
			}
			yield break;
		}

		// Token: 0x06000053 RID: 83 RVA: 0x000047BE File Offset: 0x000029BE
		private static IEnumerator PulsePointer(GameObject pointer)
		{
			Vector3 originalScale = pointer.transform.localScale;
			for (;;)
			{
				float scaleFactor = 1f + Mathf.Sin(Time.time * AthrionGunLibrary.GunConfig.PulseSpeed) * AthrionGunLibrary.GunConfig.PulseAmplitude;
				pointer.transform.localScale = originalScale * scaleFactor;
				yield return null;
			}
			yield break;
		}

		// Token: 0x06000054 RID: 84 RVA: 0x000047D0 File Offset: 0x000029D0
		private static void AddPointerParticles(GameObject pointer)
		{
			bool flag = !AthrionGunLibrary.GunConfig.EnableParticles;
			if (!flag)
			{
				AthrionGunLibrary.particleSystem = pointer.AddComponent<ParticleSystem>();
				ParticleSystem.MainModule main = AthrionGunLibrary.particleSystem.main;
				main.startColor = new ParticleSystem.MinMaxGradient(AthrionGunLibrary.GunConfig.PointerColorStart, AthrionGunLibrary.GunConfig.PointerColorEnd);
				main.startSize = AthrionGunLibrary.GunConfig.ParticleStartSize;
				main.startSpeed = AthrionGunLibrary.GunConfig.ParticleStartSpeed;
				main.maxParticles = AthrionGunLibrary.GunConfig.ParticleMaxCount;
				main.duration = 1f;
				main.loop = true;
				main.simulationSpace = 1;
				AthrionGunLibrary.particleSystem.emission.rateOverTime = AthrionGunLibrary.GunConfig.ParticleEmissionRate;
				ParticleSystem.ShapeModule shape = AthrionGunLibrary.particleSystem.shape;
				shape.shapeType = 0;
				shape.radius = 0.05f;
				ParticleSystemRenderer component = AthrionGunLibrary.particleSystem.GetComponent<ParticleSystemRenderer>();
				component.material = new Material(Shader.Find("Sprites/Default"));
			}
		}

		// Token: 0x06000055 RID: 85 RVA: 0x000048FA File Offset: 0x00002AFA
		private static IEnumerator SmoothStopParticles()
		{
			ParticleSystem.EmissionModule emission = AthrionGunLibrary.particleSystem.emission;
			float initialRate = emission.rateOverTime.constant;
			emission.rateOverTime = Mathf.Lerp(initialRate, 0f, Time.deltaTime * 2f);
			yield return null;
			AthrionGunLibrary.particleSystem.Stop();
			yield break;
		}

		// Token: 0x06000056 RID: 86 RVA: 0x00004904 File Offset: 0x00002B04
		public static void StartVrGun(Action action, bool LockOn)
		{
			bool rightGrab = ControllerInputPoller.instance.rightGrab;
			if (rightGrab)
			{
				RaycastHit raycastHit;
				bool flag = Physics.Raycast(GorillaTagger.Instance.rightHandTransform.position, -GorillaTagger.Instance.rightHandTransform.up, out raycastHit, float.MaxValue);
				bool flag2 = AthrionGunLibrary.spherepointer == null;
				if (flag2)
				{
					AthrionGunLibrary.CreatePointer();
				}
				bool flag3 = flag;
				if (flag3)
				{
					bool flag4 = AthrionGunLibrary.LockedRigOrPlayerOrwhatever == null;
					if (flag4)
					{
						AthrionGunLibrary.spherepointer.transform.position = raycastHit.point;
						AthrionGunLibrary.spherepointer.GetComponent<Renderer>().material.color = AthrionGunLibrary.GunConfig.PointerColorStart;
						bool flag5 = LockOn && raycastHit.collider.GetComponentInParent<VRRig>() != null;
						if (flag5)
						{
							AthrionGunLibrary.LockedRigOrPlayerOrwhatever = raycastHit.collider.GetComponentInParent<VRRig>();
							bool flag6 = AthrionGunLibrary.LockedRigOrPlayerOrwhatever == GorillaTagger.Instance.offlineVRRig;
							if (flag6)
							{
								AthrionGunLibrary.LockedRigOrPlayerOrwhatever = null;
								return;
							}
						}
					}
					else
					{
						AthrionGunLibrary.spherepointer.transform.position = AthrionGunLibrary.LockedRigOrPlayerOrwhatever.transform.position;
					}
				}
				AthrionGunLibrary.HandleLineRendering();
				bool flag7 = ControllerInputPoller.instance.rightControllerIndexFloat > 0.5f;
				if (flag7)
				{
					AthrionGunLibrary.spherepointer.GetComponent<Renderer>().material.color = AthrionGunLibrary.GunConfig.TriggeredPointerColorStart;
					bool flag8 = LockOn && AthrionGunLibrary.LockedRigOrPlayerOrwhatever != null;
					if (flag8)
					{
						action();
						bool enableBoxESP = AthrionGunLibrary.GunConfig.EnableBoxESP;
						if (enableBoxESP)
						{
							AthrionGunLibrary.BoxESP();
						}
					}
					else
					{
						bool flag9 = !LockOn;
						if (flag9)
						{
							action();
						}
					}
				}
				else
				{
					bool flag10 = AthrionGunLibrary.LockedRigOrPlayerOrwhatever != null;
					if (flag10)
					{
						AthrionGunLibrary.LockedRigOrPlayerOrwhatever = null;
					}
				}
			}
			else
			{
				bool flag11 = AthrionGunLibrary.spherepointer != null;
				if (flag11)
				{
					AthrionGunLibrary.CleanupPointer();
				}
			}
		}

		// Token: 0x06000057 RID: 87 RVA: 0x00004B0C File Offset: 0x00002D0C
		public static void StartPcGun(Action action, bool LockOn)
		{
			Ray ray = (GameObject.Find("Shoulder Camera").activeSelf ? GameObject.Find("Shoulder Camera").GetComponent<Camera>().ScreenPointToRay(UnityInput.Current.mousePosition) : GorillaTagger.Instance.mainCamera.GetComponent<Camera>().ScreenPointToRay(UnityInput.Current.mousePosition));
			bool isPressed = Mouse.current.rightButton.isPressed;
			if (isPressed)
			{
				RaycastHit raycastHit;
				bool flag = Physics.Raycast(ray.origin, ray.direction, out raycastHit, float.PositiveInfinity, -32777) && AthrionGunLibrary.spherepointer == null;
				if (flag)
				{
					bool flag2 = AthrionGunLibrary.spherepointer == null;
					if (flag2)
					{
						AthrionGunLibrary.spherepointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
						AthrionGunLibrary.spherepointer.AddComponent<Renderer>();
						AthrionGunLibrary.spherepointer.transform.localScale = AthrionGunLibrary.GunConfig.PointerScale;
						AthrionGunLibrary.spherepointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
						global::UnityEngine.Object.Destroy(AthrionGunLibrary.spherepointer.GetComponent<BoxCollider>());
						global::UnityEngine.Object.Destroy(AthrionGunLibrary.spherepointer.GetComponent<Rigidbody>());
						global::UnityEngine.Object.Destroy(AthrionGunLibrary.spherepointer.GetComponent<Collider>());
						AthrionGunLibrary.lr = GorillaTagger.Instance.offlineVRRig.rightHandTransform.position;
						AthrionGunLibrary athrionGunLibrary = AthrionGunLibrary.spherepointer.AddComponent<AthrionGunLibrary>();
						athrionGunLibrary.StartCoroutine(AthrionGunLibrary.PulsePointer(AthrionGunLibrary.spherepointer));
						AthrionGunLibrary.AddPointerParticles(AthrionGunLibrary.spherepointer);
					}
				}
				bool flag3 = AthrionGunLibrary.LockedRigOrPlayerOrwhatever == null;
				if (flag3)
				{
					AthrionGunLibrary.spherepointer.transform.position = raycastHit.point;
					AthrionGunLibrary.spherepointer.GetComponent<Renderer>().material.color = AthrionGunLibrary.GunConfig.PointerColorStart;
				}
				else
				{
					AthrionGunLibrary.spherepointer.transform.position = AthrionGunLibrary.LockedRigOrPlayerOrwhatever.transform.position;
				}
				AthrionGunLibrary.lr = Vector3.Lerp(AthrionGunLibrary.lr, (GorillaTagger.Instance.rightHandTransform.position + AthrionGunLibrary.spherepointer.transform.position) / 2f, Time.deltaTime * 6f);
				GameObject gameObject = new GameObject("Line");
				LineRenderer lineRenderer = gameObject.AddComponent<LineRenderer>();
				lineRenderer.startWidth = AthrionGunLibrary.GunConfig.LineWidth;
				lineRenderer.endWidth = AthrionGunLibrary.GunConfig.LineWidth;
				Shader shader = Shader.Find("Sprites/Default");
				bool flag4 = shader != null;
				if (flag4)
				{
					lineRenderer.material = new Material(shader);
				}
				AthrionGunLibrary athrionGunLibrary2 = gameObject.AddComponent<AthrionGunLibrary>();
				athrionGunLibrary2.StartCoroutine(AthrionGunLibrary.StartCurvyLineRenderer(lineRenderer, GorillaTagger.Instance.rightHandTransform.position, AthrionGunLibrary.lr, AthrionGunLibrary.spherepointer.transform.position, AthrionGunLibrary.GunConfig.LineColorStart, AthrionGunLibrary.GunConfig.LineColorEnd));
				athrionGunLibrary2.StartCoroutine(AthrionGunLibrary.AnimateLineGradient(lineRenderer, AthrionGunLibrary.GunConfig.LineColorStart, AthrionGunLibrary.GunConfig.LineColorEnd));
				bool hasChanged = AthrionGunLibrary.spherepointer.transform.hasChanged;
				if (hasChanged)
				{
					bool flag5 = AthrionGunLibrary.GunConfig.EnableParticles && !AthrionGunLibrary.particleSystem.isPlaying;
					if (flag5)
					{
						AthrionGunLibrary.particleSystem.Play();
					}
				}
				else
				{
					bool enableParticles = AthrionGunLibrary.GunConfig.EnableParticles;
					if (enableParticles)
					{
						AthrionGunLibrary.particleSystem.Stop();
					}
				}
				global::UnityEngine.Object.Destroy(lineRenderer, Time.deltaTime);
				bool isPressed2 = Mouse.current.leftButton.isPressed;
				if (isPressed2)
				{
					AthrionGunLibrary.spherepointer.GetComponent<Renderer>().material.color = AthrionGunLibrary.GunConfig.TriggeredPointerColorStart;
					if (LockOn)
					{
						bool flag6 = AthrionGunLibrary.LockedRigOrPlayerOrwhatever == null;
						if (flag6)
						{
							AthrionGunLibrary.LockedRigOrPlayerOrwhatever = raycastHit.collider.GetComponentInParent<VRRig>();
							bool flag7 = AthrionGunLibrary.LockedRigOrPlayerOrwhatever == GorillaTagger.Instance.offlineVRRig;
							if (flag7)
							{
								AthrionGunLibrary.LockedRigOrPlayerOrwhatever = null;
								return;
							}
						}
						bool flag8 = AthrionGunLibrary.LockedRigOrPlayerOrwhatever != null;
						if (flag8)
						{
							AthrionGunLibrary.spherepointer.transform.position = AthrionGunLibrary.LockedRigOrPlayerOrwhatever.transform.position;
							action();
							bool enableBoxESP = AthrionGunLibrary.GunConfig.EnableBoxESP;
							if (enableBoxESP)
							{
								AthrionGunLibrary.BoxESP();
							}
						}
					}
					else
					{
						action();
					}
				}
				else
				{
					bool flag9 = AthrionGunLibrary.LockedRigOrPlayerOrwhatever != null;
					if (flag9)
					{
						AthrionGunLibrary.LockedRigOrPlayerOrwhatever = null;
					}
				}
			}
			else
			{
				bool flag10 = AthrionGunLibrary.spherepointer != null;
				if (flag10)
				{
					global::UnityEngine.Object.Destroy(AthrionGunLibrary.spherepointer);
					AthrionGunLibrary.spherepointer = null;
					AthrionGunLibrary.LockedRigOrPlayerOrwhatever = null;
				}
			}
		}

		// Token: 0x06000058 RID: 88 RVA: 0x00004FC4 File Offset: 0x000031C4
		private static void CreatePointer()
		{
			AthrionGunLibrary.spherepointer = GameObject.CreatePrimitive(PrimitiveType.Sphere);
			AthrionGunLibrary.spherepointer.AddComponent<Renderer>();
			AthrionGunLibrary.spherepointer.transform.localScale = AthrionGunLibrary.GunConfig.PointerScale;
			AthrionGunLibrary.spherepointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
			global::UnityEngine.Object.Destroy(AthrionGunLibrary.spherepointer.GetComponent<BoxCollider>());
			global::UnityEngine.Object.Destroy(AthrionGunLibrary.spherepointer.GetComponent<Rigidbody>());
			global::UnityEngine.Object.Destroy(AthrionGunLibrary.spherepointer.GetComponent<Collider>());
			AthrionGunLibrary.lr = GorillaTagger.Instance.offlineVRRig.rightHandTransform.position;
			AthrionGunLibrary athrionGunLibrary = AthrionGunLibrary.spherepointer.AddComponent<AthrionGunLibrary>();
			athrionGunLibrary.StartCoroutine(AthrionGunLibrary.PulsePointer(AthrionGunLibrary.spherepointer));
			AthrionGunLibrary.AddPointerParticles(AthrionGunLibrary.spherepointer);
		}

		// Token: 0x06000059 RID: 89 RVA: 0x00005091 File Offset: 0x00003291
		private static void CleanupPointer()
		{
			global::UnityEngine.Object.Destroy(AthrionGunLibrary.spherepointer);
			AthrionGunLibrary.spherepointer = null;
			AthrionGunLibrary.LockedRigOrPlayerOrwhatever = null;
		}

		// Token: 0x0600005A RID: 90 RVA: 0x000050AC File Offset: 0x000032AC
		private static void HandleLineRendering()
		{
			AthrionGunLibrary.lr = Vector3.Lerp(AthrionGunLibrary.lr, (GorillaTagger.Instance.rightHandTransform.position + AthrionGunLibrary.spherepointer.transform.position) / 2f, Time.deltaTime * 6f);
			GameObject gameObject = new GameObject("Line");
			LineRenderer lineRenderer = gameObject.AddComponent<LineRenderer>();
			lineRenderer.startWidth = AthrionGunLibrary.GunConfig.LineWidth;
			lineRenderer.endWidth = AthrionGunLibrary.GunConfig.LineWidth;
			Shader shader = Shader.Find("Sprites/Default");
			bool flag = shader != null;
			if (flag)
			{
				lineRenderer.material = new Material(shader);
			}
			AthrionGunLibrary athrionGunLibrary = gameObject.AddComponent<AthrionGunLibrary>();
			athrionGunLibrary.StartCoroutine(AthrionGunLibrary.StartCurvyLineRenderer(lineRenderer, GorillaTagger.Instance.rightHandTransform.position, AthrionGunLibrary.lr, AthrionGunLibrary.spherepointer.transform.position, AthrionGunLibrary.GunConfig.LineColorStart, AthrionGunLibrary.GunConfig.LineColorEnd));
			athrionGunLibrary.StartCoroutine(AthrionGunLibrary.AnimateLineGradient(lineRenderer, AthrionGunLibrary.GunConfig.LineColorStart, AthrionGunLibrary.GunConfig.LineColorEnd));
			global::UnityEngine.Object.Destroy(lineRenderer, Time.deltaTime);
		}

		// Token: 0x0600005B RID: 91 RVA: 0x000051D4 File Offset: 0x000033D4
		public static void ToggleParticles()
		{
			AthrionGunLibrary.GunConfig.EnableParticles = !AthrionGunLibrary.GunConfig.EnableParticles;
			bool flag = !AthrionGunLibrary.GunConfig.EnableParticles && AthrionGunLibrary.particleSystem != null;
			if (flag)
			{
				AthrionGunLibrary athrionGunLibrary = AthrionGunLibrary.spherepointer.AddComponent<AthrionGunLibrary>();
				athrionGunLibrary.StartCoroutine(AthrionGunLibrary.SmoothStopParticles());
			}
		}

		// Token: 0x0600005C RID: 92 RVA: 0x00005234 File Offset: 0x00003434
		public static void start2guns(Action action, bool lockOn)
		{
			bool flag = AthrionGunLibrary.IsXRDeviceActive();
			if (flag)
			{
				AthrionGunLibrary.StartVrGun(action, lockOn);
			}
			else
			{
				AthrionGunLibrary.StartPcGun(action, lockOn);
			}
		}

		// Token: 0x0600005D RID: 93 RVA: 0x00005264 File Offset: 0x00003464
		public static bool IsXRDeviceActive()
		{
			List<XRDisplaySubsystem> list = new List<XRDisplaySubsystem>();
			SubsystemManager.GetInstances<XRDisplaySubsystem>(list);
			foreach (XRDisplaySubsystem xrdisplaySubsystem in list)
			{
				bool running = xrdisplaySubsystem.running;
				if (running)
				{
					return true;
				}
			}
			return false;
		}

		// Token: 0x0600005E RID: 94 RVA: 0x000052D4 File Offset: 0x000034D4
		public static void ChangePointerColor()
		{
			Color32[] array = new Color32[]
			{
				new Color32(0, byte.MaxValue, 100, byte.MaxValue),
				new Color32(0, 200, byte.MaxValue, byte.MaxValue),
				new Color32(byte.MaxValue, 215, 0, byte.MaxValue),
				new Color32(byte.MaxValue, 165, 0, byte.MaxValue),
				new Color32(128, 0, 128, byte.MaxValue),
				new Color32(byte.MaxValue, 0, byte.MaxValue, byte.MaxValue),
				new Color32(0, 0, 128, byte.MaxValue),
				new Color32(byte.MaxValue, 69, 0, byte.MaxValue),
				new Color32(50, 205, 50, byte.MaxValue),
				new Color32(240, 128, 128, byte.MaxValue),
				new Color32(173, 216, 230, byte.MaxValue),
				new Color32(64, 224, 208, byte.MaxValue),
				new Color32(byte.MaxValue, 20, 147, byte.MaxValue),
				new Color32(123, 104, 238, byte.MaxValue),
				new Color32(byte.MaxValue, 99, 71, byte.MaxValue),
				new Color32(0, 191, byte.MaxValue, byte.MaxValue),
				new Color32(byte.MaxValue, 140, 0, byte.MaxValue),
				new Color32(75, 0, 130, byte.MaxValue),
				new Color32(60, 179, 113, byte.MaxValue),
				new Color32(244, 164, 96, byte.MaxValue),
				new Color32(138, 43, 226, byte.MaxValue),
				new Color32(byte.MaxValue, 105, 180, byte.MaxValue),
				new Color32(byte.MaxValue, 250, 205, byte.MaxValue),
				new Color32(139, 0, 0, byte.MaxValue)
			};
			bool flag = !AthrionGunLibrary.colorIndexInitialized;
			if (flag)
			{
				AthrionGunLibrary.ColorIndex = 0;
				AthrionGunLibrary.colorIndexInitialized = true;
			}
			AthrionGunLibrary.ColorIndex = (AthrionGunLibrary.ColorIndex + 1) % array.Length;
			Color32 color = array[AthrionGunLibrary.ColorIndex];
			Color32 color2 = Color.Lerp(color, new Color32(byte.MaxValue, byte.MaxValue, byte.MaxValue, byte.MaxValue), 0.5f);
			AthrionGunLibrary.GunConfig.PointerColorStart = color;
			AthrionGunLibrary.GunConfig.PointerColorEnd = color2;
			bool flag2 = AthrionGunLibrary.spherepointer != null;
			if (flag2)
			{
				AthrionGunLibrary.spherepointer.GetComponent<Renderer>().material.color = color;
			}
			bool flag3 = AthrionGunLibrary.particleSystem != null;
			if (flag3)
			{
				AthrionGunLibrary.particleSystem.main.startColor = new ParticleSystem.MinMaxGradient(color, color2);
			}
		}

		// Token: 0x0600005F RID: 95 RVA: 0x00005679 File Offset: 0x00003879
		private static IEnumerator AnimateBox(GameObject box, LineRenderer outline)
		{
			Vector3 originalScale = box.transform.localScale;
			while (box != null)
			{
				float scaleFactor = 1f + Mathf.Sin(Time.time * AthrionGunLibrary.GunConfig.PulseSpeed) * AthrionGunLibrary.GunConfig.PulseAmplitude;
				box.transform.localScale = originalScale * scaleFactor;
				outline.startColor = Color.Lerp(AthrionGunLibrary.GunConfig.BoxESPColor, AthrionGunLibrary.GunConfig.BoxESPOuterColor, Mathf.PingPong(Time.time, 1f));
				outline.endColor = Color.Lerp(AthrionGunLibrary.GunConfig.BoxESPColor, AthrionGunLibrary.GunConfig.BoxESPOuterColor, Mathf.PingPong(Time.time, 1f));
				yield return null;
			}
			yield break;
		}

		// Token: 0x06000060 RID: 96 RVA: 0x00005690 File Offset: 0x00003890
		public static void BoxESP()
		{
			bool flag = PhotonNetwork.InRoom || PhotonNetwork.InLobby;
			if (flag)
			{
				bool flag2 = AthrionGunLibrary.LockedRigOrPlayerOrwhatever != null && AthrionGunLibrary.LockedRigOrPlayerOrwhatever != GorillaTagger.Instance.offlineVRRig;
				if (flag2)
				{
					GameObject gameObject = new GameObject();
					LineRenderer lineRenderer = gameObject.AddComponent<LineRenderer>();
					Vector3 position = AthrionGunLibrary.LockedRigOrPlayerOrwhatever.transform.position;
					Vector3[] array = new Vector3[5];
					float boxESPHeight = AthrionGunLibrary.GunConfig.BoxESPHeight;
					float boxESPWidth = AthrionGunLibrary.GunConfig.BoxESPWidth;
					array[0] = position + AthrionGunLibrary.LockedRigOrPlayerOrwhatever.transform.right * (-boxESPWidth / 2f) + AthrionGunLibrary.LockedRigOrPlayerOrwhatever.transform.up * (boxESPHeight / 2f);
					array[1] = position + AthrionGunLibrary.LockedRigOrPlayerOrwhatever.transform.right * (boxESPWidth / 2f) + AthrionGunLibrary.LockedRigOrPlayerOrwhatever.transform.up * (boxESPHeight / 2f);
					array[2] = position + AthrionGunLibrary.LockedRigOrPlayerOrwhatever.transform.right * (boxESPWidth / 2f) + AthrionGunLibrary.LockedRigOrPlayerOrwhatever.transform.up * (-boxESPHeight / 2f);
					array[3] = position + AthrionGunLibrary.LockedRigOrPlayerOrwhatever.transform.right * (-boxESPWidth / 2f) + AthrionGunLibrary.LockedRigOrPlayerOrwhatever.transform.up * (-boxESPHeight / 2f);
					array[4] = array[0];
					lineRenderer.positionCount = array.Length;
					lineRenderer.SetPositions(array);
					lineRenderer.startWidth = 0.007f;
					lineRenderer.endWidth = 0.007f;
					Shader shader = Shader.Find("Sprites/Default");
					bool flag3 = shader != null;
					if (flag3)
					{
						lineRenderer.material = new Material(shader);
					}
					lineRenderer.material.renderQueue = 3000;
					lineRenderer.startColor = AthrionGunLibrary.GunConfig.BoxESPColor;
					lineRenderer.endColor = AthrionGunLibrary.GunConfig.BoxESPColor;
					LineRenderer lineRenderer2 = new GameObject().AddComponent<LineRenderer>();
					lineRenderer2.transform.parent = gameObject.transform;
					Vector3[] array2 = new Vector3[5];
					array2[0] = position + AthrionGunLibrary.LockedRigOrPlayerOrwhatever.transform.right * (-boxESPWidth / 2f - 0.02f) + AthrionGunLibrary.LockedRigOrPlayerOrwhatever.transform.up * (boxESPHeight / 2f + 0.02f);
					array2[1] = position + AthrionGunLibrary.LockedRigOrPlayerOrwhatever.transform.right * (boxESPWidth / 2f + 0.02f) + AthrionGunLibrary.LockedRigOrPlayerOrwhatever.transform.up * (boxESPHeight / 2f + 0.02f);
					array2[2] = position + AthrionGunLibrary.LockedRigOrPlayerOrwhatever.transform.right * (boxESPWidth / 2f + 0.02f) + AthrionGunLibrary.LockedRigOrPlayerOrwhatever.transform.up * (-boxESPHeight / 2f - 0.02f);
					array2[3] = position + AthrionGunLibrary.LockedRigOrPlayerOrwhatever.transform.right * (-boxESPWidth / 2f - 0.02f) + AthrionGunLibrary.LockedRigOrPlayerOrwhatever.transform.up * (-boxESPHeight / 2f - 0.02f);
					array2[4] = array2[0];
					lineRenderer2.positionCount = array2.Length;
					lineRenderer2.SetPositions(array2);
					lineRenderer2.startWidth = 0.01f;
					lineRenderer2.endWidth = 0.01f;
					Shader shader2 = Shader.Find("Sprites/Default");
					bool flag4 = shader2 != null;
					if (flag4)
					{
						lineRenderer2.material = new Material(shader2);
					}
					lineRenderer2.material.renderQueue = 3000;
					lineRenderer2.startColor = AthrionGunLibrary.GunConfig.BoxESPOuterColor;
					lineRenderer2.endColor = AthrionGunLibrary.GunConfig.BoxESPOuterColor;
					gameObject.transform.position = AthrionGunLibrary.LockedRigOrPlayerOrwhatever.transform.position;
					gameObject.transform.rotation = AthrionGunLibrary.LockedRigOrPlayerOrwhatever.transform.rotation;
					AthrionGunLibrary athrionGunLibrary = gameObject.AddComponent<AthrionGunLibrary>();
					athrionGunLibrary.StartCoroutine(AthrionGunLibrary.AnimateBox(gameObject, lineRenderer2));
					global::UnityEngine.Object.Destroy(gameObject, 0.05f);
				}
			}
		}

		// Token: 0x06000061 RID: 97 RVA: 0x00005B88 File Offset: 0x00003D88
		public static void ToggleAnimationMode()
		{
			AthrionGunLibrary.currentAnimationMode = (AthrionGunLibrary.currentAnimationMode + 1) % (AthrionGunLibrary.AnimationMode)Enum.GetValues(typeof(AthrionGunLibrary.AnimationMode)).Length;
		}

		// Token: 0x06000062 RID: 98 RVA: 0x00005BAC File Offset: 0x00003DAC
		public static Vector3 GetPointerPos()
		{
			bool flag = AthrionGunLibrary.spherepointer != null;
			Vector3 vector;
			if (flag)
			{
				vector = AthrionGunLibrary.spherepointer.transform.position;
			}
			else
			{
				vector = Vector3.zero;
			}
			return vector;
		}

		// Token: 0x04000031 RID: 49
		public static Config GunConfig = new Config();

		// Token: 0x04000032 RID: 50
		public static GameObject spherepointer;

		// Token: 0x04000033 RID: 51
		public static VRRig LockedRigOrPlayerOrwhatever;

		// Token: 0x04000034 RID: 52
		public static Vector3 lr;

		// Token: 0x04000035 RID: 53
		public static ParticleSystem particleSystem;

		// Token: 0x04000036 RID: 54
		private static float waveTimeOffset = 0f;

		// Token: 0x04000037 RID: 55
		private static bool colorIndexInitialized = false;

		// Token: 0x04000038 RID: 56
		private static int ColorIndex = 0;

		// Token: 0x04000039 RID: 57
		private static AthrionGunLibrary.AnimationMode currentAnimationMode = AthrionGunLibrary.AnimationMode.DefaultBezier;

		// Token: 0x0200003E RID: 62
		public enum AnimationMode
		{
			// Token: 0x040001AC RID: 428
			None,
			// Token: 0x040001AD RID: 429
			Wave,
			// Token: 0x040001AE RID: 430
			Pulse,
			// Token: 0x040001AF RID: 431
			Zigzag,
			// Token: 0x040001B0 RID: 432
			Bouncing,
			// Token: 0x040001B1 RID: 433
			Spiral,
			// Token: 0x040001B2 RID: 434
			SineWave,
			// Token: 0x040001B3 RID: 435
			Helix,
			// Token: 0x040001B4 RID: 436
			Sawtooth,
			// Token: 0x040001B5 RID: 437
			TriangleWave,
			// Token: 0x040001B6 RID: 438
			DefaultBezier
		}
	}
}
