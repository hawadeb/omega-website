﻿using System;
using UnityEngine;

namespace Athrion.Libary
{
	// Token: 0x02000005 RID: 5
	public class Config
	{
		// Token: 0x17000003 RID: 3
		// (get) Token: 0x06000017 RID: 23 RVA: 0x00003F1B File Offset: 0x0000211B
		// (set) Token: 0x06000018 RID: 24 RVA: 0x00003F23 File Offset: 0x00002123
		public Vector3 PointerScale { get; set; } = new Vector3(0.2f, 0.2f, 0.2f);

		// Token: 0x17000004 RID: 4
		// (get) Token: 0x06000019 RID: 25 RVA: 0x00003F2C File Offset: 0x0000212C
		// (set) Token: 0x0600001A RID: 26 RVA: 0x00003F34 File Offset: 0x00002134
		public Color32 PointerColorStart { get; set; } = new Color32(0, byte.MaxValue, 100, byte.MaxValue);

		// Token: 0x17000005 RID: 5
		// (get) Token: 0x0600001B RID: 27 RVA: 0x00003F3D File Offset: 0x0000213D
		// (set) Token: 0x0600001C RID: 28 RVA: 0x00003F45 File Offset: 0x00002145
		public Color32 PointerColorEnd { get; set; } = new Color32(0, 200, byte.MaxValue, byte.MaxValue);

		// Token: 0x17000006 RID: 6
		// (get) Token: 0x0600001D RID: 29 RVA: 0x00003F4E File Offset: 0x0000214E
		// (set) Token: 0x0600001E RID: 30 RVA: 0x00003F56 File Offset: 0x00002156
		public Color32 TriggeredPointerColorStart { get; set; } = new Color32(byte.MaxValue, 100, 50, byte.MaxValue);

		// Token: 0x17000007 RID: 7
		// (get) Token: 0x0600001F RID: 31 RVA: 0x00003F5F File Offset: 0x0000215F
		// (set) Token: 0x06000020 RID: 32 RVA: 0x00003F67 File Offset: 0x00002167
		public Color32 TriggeredPointerColorEnd { get; set; } = new Color32(byte.MaxValue, 150, 0, byte.MaxValue);

		// Token: 0x17000008 RID: 8
		// (get) Token: 0x06000021 RID: 33 RVA: 0x00003F70 File Offset: 0x00002170
		// (set) Token: 0x06000022 RID: 34 RVA: 0x00003F78 File Offset: 0x00002178
		public float LineWidth { get; set; } = 0.025f;

		// Token: 0x17000009 RID: 9
		// (get) Token: 0x06000023 RID: 35 RVA: 0x00003F81 File Offset: 0x00002181
		// (set) Token: 0x06000024 RID: 36 RVA: 0x00003F89 File Offset: 0x00002189
		public Color32 LineColorStart { get; set; } = new Color32(0, byte.MaxValue, 150, byte.MaxValue);

		// Token: 0x1700000A RID: 10
		// (get) Token: 0x06000025 RID: 37 RVA: 0x00003F92 File Offset: 0x00002192
		// (set) Token: 0x06000026 RID: 38 RVA: 0x00003F9A File Offset: 0x0000219A
		public Color32 LineColorEnd { get; set; } = new Color32(0, 180, byte.MaxValue, byte.MaxValue);

		// Token: 0x1700000B RID: 11
		// (get) Token: 0x06000027 RID: 39 RVA: 0x00003FA3 File Offset: 0x000021A3
		// (set) Token: 0x06000028 RID: 40 RVA: 0x00003FAB File Offset: 0x000021AB
		public Color32 TriggeredLineColorStart { get; set; } = new Color32(byte.MaxValue, 100, 50, byte.MaxValue);

		// Token: 0x1700000C RID: 12
		// (get) Token: 0x06000029 RID: 41 RVA: 0x00003FB4 File Offset: 0x000021B4
		// (set) Token: 0x0600002A RID: 42 RVA: 0x00003FBC File Offset: 0x000021BC
		public Color32 TriggeredLineColorEnd { get; set; } = new Color32(byte.MaxValue, 150, 0, byte.MaxValue);

		// Token: 0x1700000D RID: 13
		// (get) Token: 0x0600002B RID: 43 RVA: 0x00003FC5 File Offset: 0x000021C5
		// (set) Token: 0x0600002C RID: 44 RVA: 0x00003FCD File Offset: 0x000021CD
		public bool EnableAnimations { get; set; } = true;

		// Token: 0x1700000E RID: 14
		// (get) Token: 0x0600002D RID: 45 RVA: 0x00003FD6 File Offset: 0x000021D6
		// (set) Token: 0x0600002E RID: 46 RVA: 0x00003FDE File Offset: 0x000021DE
		public float PulseSpeed { get; set; } = 4f;

		// Token: 0x1700000F RID: 15
		// (get) Token: 0x0600002F RID: 47 RVA: 0x00003FE7 File Offset: 0x000021E7
		// (set) Token: 0x06000030 RID: 48 RVA: 0x00003FEF File Offset: 0x000021EF
		public float PulseAmplitude { get; set; } = 0.04f;

		// Token: 0x17000010 RID: 16
		// (get) Token: 0x06000031 RID: 49 RVA: 0x00003FF8 File Offset: 0x000021F8
		// (set) Token: 0x06000032 RID: 50 RVA: 0x00004000 File Offset: 0x00002200
		public bool EnableParticles { get; set; } = true;

		// Token: 0x17000011 RID: 17
		// (get) Token: 0x06000033 RID: 51 RVA: 0x00004009 File Offset: 0x00002209
		// (set) Token: 0x06000034 RID: 52 RVA: 0x00004011 File Offset: 0x00002211
		public float ParticleStartSize { get; set; } = 0.1f;

		// Token: 0x17000012 RID: 18
		// (get) Token: 0x06000035 RID: 53 RVA: 0x0000401A File Offset: 0x0000221A
		// (set) Token: 0x06000036 RID: 54 RVA: 0x00004022 File Offset: 0x00002222
		public float ParticleStartSpeed { get; set; } = 0.5f;

		// Token: 0x17000013 RID: 19
		// (get) Token: 0x06000037 RID: 55 RVA: 0x0000402B File Offset: 0x0000222B
		// (set) Token: 0x06000038 RID: 56 RVA: 0x00004033 File Offset: 0x00002233
		public int ParticleMaxCount { get; set; } = 200;

		// Token: 0x17000014 RID: 20
		// (get) Token: 0x06000039 RID: 57 RVA: 0x0000403C File Offset: 0x0000223C
		// (set) Token: 0x0600003A RID: 58 RVA: 0x00004044 File Offset: 0x00002244
		public float ParticleEmissionRate { get; set; } = 20f;

		// Token: 0x17000015 RID: 21
		// (get) Token: 0x0600003B RID: 59 RVA: 0x0000404D File Offset: 0x0000224D
		// (set) Token: 0x0600003C RID: 60 RVA: 0x00004055 File Offset: 0x00002255
		public bool EnableBoxESP { get; set; } = true;

		// Token: 0x17000016 RID: 22
		// (get) Token: 0x0600003D RID: 61 RVA: 0x0000405E File Offset: 0x0000225E
		// (set) Token: 0x0600003E RID: 62 RVA: 0x00004066 File Offset: 0x00002266
		public float BoxESPWidth { get; set; } = 1f;

		// Token: 0x17000017 RID: 23
		// (get) Token: 0x0600003F RID: 63 RVA: 0x0000406F File Offset: 0x0000226F
		// (set) Token: 0x06000040 RID: 64 RVA: 0x00004077 File Offset: 0x00002277
		public float BoxESPHeight { get; set; } = 2f;

		// Token: 0x17000018 RID: 24
		// (get) Token: 0x06000041 RID: 65 RVA: 0x00004080 File Offset: 0x00002280
		// (set) Token: 0x06000042 RID: 66 RVA: 0x00004088 File Offset: 0x00002288
		public Color32 BoxESPColor { get; set; } = new Color32(0, byte.MaxValue, 100, byte.MaxValue);

		// Token: 0x17000019 RID: 25
		// (get) Token: 0x06000043 RID: 67 RVA: 0x00004091 File Offset: 0x00002291
		// (set) Token: 0x06000044 RID: 68 RVA: 0x00004099 File Offset: 0x00002299
		public Color32 BoxESPOuterColor { get; set; } = new Color32(byte.MaxValue, 150, 0, byte.MaxValue);

		// Token: 0x1700001A RID: 26
		// (get) Token: 0x06000045 RID: 69 RVA: 0x000040A2 File Offset: 0x000022A2
		// (set) Token: 0x06000046 RID: 70 RVA: 0x000040AA File Offset: 0x000022AA
		public int LineCurve { get; set; } = 1000;

		// Token: 0x1700001B RID: 27
		// (get) Token: 0x06000047 RID: 71 RVA: 0x000040B3 File Offset: 0x000022B3
		// (set) Token: 0x06000048 RID: 72 RVA: 0x000040BB File Offset: 0x000022BB
		public float WaveFrequency { get; set; } = 5f;

		// Token: 0x1700001C RID: 28
		// (get) Token: 0x06000049 RID: 73 RVA: 0x000040C4 File Offset: 0x000022C4
		// (set) Token: 0x0600004A RID: 74 RVA: 0x000040CC File Offset: 0x000022CC
		public float WaveAmplitude { get; set; } = 0.05f;
	}
}
