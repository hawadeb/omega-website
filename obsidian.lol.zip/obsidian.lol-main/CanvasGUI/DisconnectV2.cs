﻿using System;
using HarmonyLib;
using Photon.Realtime;

namespace CanvasGUI
{
	// Token: 0x0200002E RID: 46
	[HarmonyPatch(typeof(LoadBalancingClient), "Disconnect")]
	internal class DisconnectV2
	{
		// Token: 0x060001A4 RID: 420 RVA: 0x00019D0C File Offset: 0x00017F0C
		private static bool Prefix(DisconnectCause cause)
		{
			bool flag = cause != DisconnectCause.DisconnectByClientLogic;
			return !flag;
		}
	}
}
