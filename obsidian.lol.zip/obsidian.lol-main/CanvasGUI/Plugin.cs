﻿using System;
using BepInEx;
using CanvasGUI.Management;

namespace CanvasGUI
{
	// Token: 0x02000031 RID: 49
	[BepInPlugin("com.obs.gorillatag.lol", "Obsidian.LOL", "1.5.0")]
	public class Plugin : BaseUnityPlugin
	{
		// Token: 0x060001AA RID: 426 RVA: 0x00019D70 File Offset: 0x00017F70
		public void OnEnable()
		{
			HarmonyPatches.Patch(true);
		}

		// Token: 0x060001AB RID: 427 RVA: 0x00019D79 File Offset: 0x00017F79
		public void OnDisable()
		{
			HarmonyPatches.Patch(false);
		}

		// Token: 0x060001AC RID: 428 RVA: 0x00019D82 File Offset: 0x00017F82
		public void Start()
		{
			Menu.Start();
		}

		// Token: 0x060001AD RID: 429 RVA: 0x00019D8A File Offset: 0x00017F8A
		public void Update()
		{
			Menu.Update();
		}
	}
}
