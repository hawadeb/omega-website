﻿// Decompiled with JetBrains decompiler
// Type: UniV.Form123
// Assembly: Iris Menu, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 59E363CE-0CA7-48B3-B0E5-3149212D78E4
// Assembly location: Iris Menu.dll inside C:\Users\Admin\Downloads\Iris Menu.dll)

using Guna.UI2.WinForms;
using Guna.UI2.WinForms.Enums;
using Guna.UI2.WinForms.Suite;
using KeyAuth.LoginFR;
using SharpMonoInjector;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.IO.Compression;
using System.Net.Http;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

#nullable enable
namespace UniV
{
  public class Form123 : Form
  {
    public const int WM_NCLBUTTONDOWN = 161;
    public const int HT_CAPTION = 2;
    private 
    #nullable disable
    IContainer components;
    private Guna2ControlBox btnExit;
    private Guna2ControlBox btnMinimize;
    private Label label1;
    private Guna2Button guna2Button1;
    private Label label2;
    private Label label3;
    private Label label4;
    private Label label5;
    private Label label6;
    private Guna2TextBox ConsoleBox;
    private Guna2Button guna2Button2;
    private Panel backgroundPanel;
    private Timer animationTimer;
    private List<Form123.Star> stars;
    private float blackHoleAngle;
    private bool isDragging;
    private Point dragStartPosition;
    private Guna2Button btnLogout;

    public Form123()
    {
      this.InitializeComponent();
      this.MouseDown += new MouseEventHandler(this.Form123_MouseDown);
    }

    [DllImport("User32.dll")]
    public static extern bool ReleaseCapture();

    [DllImport("User32.dll")]
    public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

    private void Form123_MouseDown(
    #nullable enable
    object sender, MouseEventArgs e)
    {
      if (e.Button != MouseButtons.Left)
        return;
      Form123.ReleaseCapture();
      Form123.SendMessage(this.Handle, 161, 2, 0);
    }

    private void CheckAdminPrivileges()
    {
      bool flag;
      using (WindowsIdentity current = WindowsIdentity.GetCurrent())
        flag = new WindowsPrincipal(current).IsInRole((WindowsBuiltInRole) 544);
      int num = flag ? 1 : 0;
    }

    private bool IsProcessRunning(string processName)
    {
      return Process.GetProcessesByName(processName).Length != 0;
    }

    private void LogToConsole(string message)
    {
      if (this.InvokeRequired)
        this.Invoke((Action) (() => this.LogToConsoleInternal(message)));
      else
        this.LogToConsoleInternal(message);
    }

    private void LogToConsoleInternal(string message)
    {
      DefaultInterpolatedStringHandler interpolatedStringHandler = new DefaultInterpolatedStringHandler(3, 2);
      interpolatedStringHandler.AppendLiteral("+ ");
      interpolatedStringHandler.AppendFormatted<DateTime>(DateTime.Now, "HH:mm:ss");
      interpolatedStringHandler.AppendLiteral(" ");
      interpolatedStringHandler.AppendFormatted(message);
      this.ConsoleBox.AppendText(interpolatedStringHandler.ToStringAndClear() + Environment.NewLine);
      using (Graphics graphics = ((Control) this.ConsoleBox).CreateGraphics())
      {
        string[] lines = this.ConsoleBox.Lines;
        int num1 = ((Control) this.ConsoleBox).Width;
        foreach (string str in lines)
        {
          if (!string.IsNullOrEmpty(str))
          {
            int width = (int) graphics.MeasureString(str, ((Control) this.ConsoleBox).Font).Width;
            if (width > num1)
              num1 = width;
          }
        }
        int num2 = num1 + 20;
        if (num2 > this.ClientSize.Width - ((Control) this.ConsoleBox).Location.X - 10)
          num2 = this.ClientSize.Width - ((Control) this.ConsoleBox).Location.X - 10;
        ((Control) this.ConsoleBox).Width = num2;
      }
    }

    public async Task InjectDLL()
    {
      try
      {
        using (Injector injector = new Injector("Gorilla Tag"))
        {
          byte[] data = ByteArrayStorage.Data;
          if (data == null || data.Length == 0)
          {
            this.LogToConsole("Injection failed: DLL bytes are null or empty.");
          }
          else
          {
            this.LogToConsole("Starting injection...");
            if (injector.Inject(data, "HydrLC", "Injection", "StartInjection") == IntPtr.Zero)
              this.LogToConsole("Injection failed: Could not retrieve method pointer.");
            else
              this.LogToConsole("Injection successful!");
          }
        }
      }
      catch (Exception ex)
      {
        this.LogToConsole("Injection failed: " + ex.Message);
      }
    }

    private async Task UnInjectDLL()
    {
      try
      {
        using (Injector injector = new Injector("Gorilla Tag"))
        {
          byte[] data = ByteArrayStorage.Data;
          if (data == null || data.Length == 0)
            this.LogToConsole("UnInjection failed: DLL bytes are null or empty.");
          else if (injector.Inject(data, "RemoveHydrLC", "UnInjection", "StartUnInjection") == IntPtr.Zero)
            this.LogToConsole("UnInjection failed: Could not retrieve method pointer.");
          else
            this.LogToConsole("UnInjection successful!");
        }
      }
      catch (Exception ex)
      {
        this.LogToConsole("UnInjection failed: " + ex.Message);
      }
    }

    public async Task RunDLL()
    {
      string url = "https://github.com/FTTSyxcal/FortniteSkibikasidkao-s-f/releases/download/IrisGUI/IrisTemplate.zip";
      string tempZipPath = Path.Combine(Path.GetTempPath(), "IrisTemplate.zip");
      try
      {
        this.LogToConsole("Starting Requirements...");
        await this.DownloadFileAsync(url, tempZipPath);
        this.UnzipFile(tempZipPath, Path.GetTempPath());
        this.LogToConsole("Requirements completed successfully!");
        this.CopyDllToPluginPaths(Path.Combine(Path.GetTempPath(), "IrisTemplate.dll"));
        tempZipPath = (string) null;
      }
      catch (Exception ex)
      {
        this.LogToConsole("Requirements failed: " + ex.Message);
        tempZipPath = (string) null;
      }
      finally
      {
        if (File.Exists(tempZipPath))
          File.Delete(tempZipPath);
      }
    }

    private async Task DownloadFileAsync(string url, string destinationPath)
    {
      if (File.Exists(destinationPath))
        File.Delete(destinationPath);
      using (HttpClient client = new HttpClient())
        await File.WriteAllBytesAsync(destinationPath, await client.GetByteArrayAsync(url), new CancellationToken());
    }

    private void UnzipFile(string zipFilePath, string extractPath)
    {
      if (!Directory.Exists(extractPath))
      {
        try
        {
          Directory.CreateDirectory(extractPath);
        }
        catch (Exception ex)
        {
          this.LogToConsole("Failed to create extraction directory " + extractPath + ": " + ex.Message);
          throw;
        }
      }
      try
      {
        using (ZipArchive zipArchive = ZipFile.OpenRead(zipFilePath))
        {
          foreach (ZipArchiveEntry entry in zipArchive.Entries)
          {
            string str = Path.Combine(extractPath, entry.FullName);
            string directoryName = Path.GetDirectoryName(str);
            if (!Directory.Exists(directoryName))
            {
              try
              {
                Directory.CreateDirectory(directoryName);
              }
              catch (Exception ex)
              {
                this.LogToConsole("Failed to create directory " + directoryName + ": " + ex.Message);
                throw;
              }
            }
            if (string.op_Inequality(entry.Name, ""))
            {
              if (File.Exists(str))
              {
                try
                {
                  FileAttributes attributes = File.GetAttributes(str);
                  if ((attributes & 1) == 1)
                    File.SetAttributes(str, attributes & -2);
                  File.Delete(str);
                }
                catch (UnauthorizedAccessException ex)
                {
                  DefaultInterpolatedStringHandler interpolatedStringHandler = new DefaultInterpolatedStringHandler(62, 2);
                  interpolatedStringHandler.AppendLiteral("Access denied while deleting ");
                  interpolatedStringHandler.AppendFormatted(str);
                  interpolatedStringHandler.AppendLiteral(": ");
                  interpolatedStringHandler.AppendFormatted(((Exception) ex).Message);
                  interpolatedStringHandler.AppendLiteral(". Try running as administrator.");
                  this.LogToConsole(interpolatedStringHandler.ToStringAndClear());
                  throw;
                }
                catch (IOException ex)
                {
                  DefaultInterpolatedStringHandler interpolatedStringHandler = new DefaultInterpolatedStringHandler(51, 2);
                  interpolatedStringHandler.AppendLiteral("IO error while deleting ");
                  interpolatedStringHandler.AppendFormatted(str);
                  interpolatedStringHandler.AppendLiteral(": ");
                  interpolatedStringHandler.AppendFormatted(((Exception) ex).Message);
                  interpolatedStringHandler.AppendLiteral(". The file may be in use.");
                  this.LogToConsole(interpolatedStringHandler.ToStringAndClear());
                  throw;
                }
                catch (Exception ex)
                {
                  this.LogToConsole("Failed to delete " + str + ": " + ex.Message);
                  throw;
                }
              }
              try
              {
                ZipFileExtensions.ExtractToFile(entry, str, true);
              }
              catch (UnauthorizedAccessException ex)
              {
                DefaultInterpolatedStringHandler interpolatedStringHandler = new DefaultInterpolatedStringHandler(68, 3);
                interpolatedStringHandler.AppendLiteral("Access denied while extracting ");
                interpolatedStringHandler.AppendFormatted(entry.FullName);
                interpolatedStringHandler.AppendLiteral(" to ");
                interpolatedStringHandler.AppendFormatted(str);
                interpolatedStringHandler.AppendLiteral(": ");
                interpolatedStringHandler.AppendFormatted(((Exception) ex).Message);
                interpolatedStringHandler.AppendLiteral(". Try running as administrator.");
                this.LogToConsole(interpolatedStringHandler.ToStringAndClear());
                throw;
              }
              catch (IOException ex)
              {
                DefaultInterpolatedStringHandler interpolatedStringHandler = new DefaultInterpolatedStringHandler(57, 3);
                interpolatedStringHandler.AppendLiteral("IO error while extracting ");
                interpolatedStringHandler.AppendFormatted(entry.FullName);
                interpolatedStringHandler.AppendLiteral(" to ");
                interpolatedStringHandler.AppendFormatted(str);
                interpolatedStringHandler.AppendLiteral(": ");
                interpolatedStringHandler.AppendFormatted(((Exception) ex).Message);
                interpolatedStringHandler.AppendLiteral(". The file may be in use.");
                this.LogToConsole(interpolatedStringHandler.ToStringAndClear());
                throw;
              }
              catch (Exception ex)
              {
                DefaultInterpolatedStringHandler interpolatedStringHandler = new DefaultInterpolatedStringHandler(24, 3);
                interpolatedStringHandler.AppendLiteral("Failed to extract ");
                interpolatedStringHandler.AppendFormatted(entry.FullName);
                interpolatedStringHandler.AppendLiteral(" to ");
                interpolatedStringHandler.AppendFormatted(str);
                interpolatedStringHandler.AppendLiteral(": ");
                interpolatedStringHandler.AppendFormatted(ex.Message);
                this.LogToConsole(interpolatedStringHandler.ToStringAndClear());
                throw;
              }
            }
          }
        }
      }
      catch (Exception ex)
      {
        this.LogToConsole("Failed to extract ZIP file: " + ex.Message);
        throw;
      }
      foreach (string file in Directory.GetFiles(extractPath, "*.dll", (SearchOption) 1))
      {
        try
        {
          File.SetAttributes(file, (FileAttributes) 6);
        }
        catch (Exception ex)
        {
          this.LogToConsole("Failed to hide file " + Path.GetFileName(file) + ": " + ex.Message);
        }
      }
    }

    private async Task CopyDllToPluginPaths(string dllPath)
    {
      string url = "https://github.com/FTTSyxcal/FortniteSkibikasidkao-s-f/releases/download/IrisGUI/IrisTemplate.zip";
      string tempZipPath = Path.Combine(Path.GetTempPath(), "IrisTemplate.zip");
      string[] pluginsDirectories = new string[2]
      {
        "C:\\Program Files\\Oculus\\Software\\Software\\another-axiom-gorilla-tag\\BepInEx\\plugins",
        "C:\\Program Files (x86)\\Steam\\steamapps\\common\\Gorilla Tag\\BepInEx\\plugins"
      };
      try
      {
        if (this.IsProcessRunning("Gorilla Tag"))
        {
          this.LogToConsole("Error: Gorilla Tag is running. Please close the game before proceeding.");
          tempZipPath = (string) null;
          pluginsDirectories = (string[]) null;
        }
        else
        {
          this.LogToConsole("Starting requirements...");
          await this.DownloadFileAsync(url, tempZipPath);
          foreach (string extractPath in pluginsDirectories)
          {
            if (!Directory.Exists(extractPath))
            {
              try
              {
                Directory.CreateDirectory(extractPath);
              }
              catch (Exception ex)
              {
                this.LogToConsole("Failed to create plugin directory: " + ex.Message);
                continue;
              }
            }
            this.UnzipFile(tempZipPath, extractPath);
            this.LogToConsole("Requirements Done for " + (extractPath.Contains("Steam") ? "Steam" : "Oculus"));
          }
          tempZipPath = (string) null;
          pluginsDirectories = (string[]) null;
        }
      }
      catch (Exception ex)
      {
        this.LogToConsole("An error occurred: " + ex.Message + " Please Contact Support In The Discord");
        tempZipPath = (string) null;
        pluginsDirectories = (string[]) null;
      }
      finally
      {
        if (File.Exists(tempZipPath))
          File.Delete(tempZipPath);
      }
    }

    private void InitializeComponent()
    {
      this.components = (IContainer) new Container();
      CustomizableEdges customizableEdges1 = new CustomizableEdges();
      CustomizableEdges customizableEdges2 = new CustomizableEdges();
      CustomizableEdges customizableEdges3 = new CustomizableEdges();
      CustomizableEdges customizableEdges4 = new CustomizableEdges();
      CustomizableEdges customizableEdges5 = new CustomizableEdges();
      CustomizableEdges customizableEdges6 = new CustomizableEdges();
      CustomizableEdges customizableEdges7 = new CustomizableEdges();
      CustomizableEdges customizableEdges8 = new CustomizableEdges();
      CustomizableEdges customizableEdges9 = new CustomizableEdges();
      CustomizableEdges customizableEdges10 = new CustomizableEdges();
      CustomizableEdges customizableEdges11 = new CustomizableEdges();
      CustomizableEdges customizableEdges12 = new CustomizableEdges();
      this.btnExit = new Guna2ControlBox();
      this.btnMinimize = new Guna2ControlBox();
      this.label1 = new Label();
      this.guna2Button1 = new Guna2Button();
      this.label2 = new Label();
      this.label3 = new Label();
      this.label4 = new Label();
      this.label5 = new Label();
      this.label6 = new Label();
      this.ConsoleBox = new Guna2TextBox();
      this.guna2Button2 = new Guna2Button();
      this.backgroundPanel = new Panel();
      this.animationTimer = new Timer();
      this.stars = new List<Form123.Star>();
      this.btnLogout = new Guna2Button();
      this.SuspendLayout();
      this.backgroundPanel.Location = new Point(0, 0);
      this.backgroundPanel.Name = "backgroundPanel";
      this.backgroundPanel.Size = new Size(500, 579);
      this.backgroundPanel.BackColor = Color.Black;
      this.backgroundPanel.Paint += new PaintEventHandler(this.BackgroundPanel_Paint);
      this.backgroundPanel.MouseDown += new MouseEventHandler(this.BackgroundPanel_MouseDown);
      this.backgroundPanel.MouseMove += new MouseEventHandler(this.BackgroundPanel_MouseMove);
      this.backgroundPanel.MouseUp += new MouseEventHandler(this.BackgroundPanel_MouseUp);
      Random random = new Random();
      for (int index = 0; index < 210; ++index)
        this.stars.Add(new Form123.Star()
        {
          X = (float) random.Next(0, 500),
          Y = (float) random.Next(0, 579),
          SpeedX = (float) (random.NextDouble() * 2.0 - 1.0),
          SpeedY = (float) (random.NextDouble() * 2.0 - 1.0),
          Size = (float) (random.NextDouble() * 3.0 + 1.0)
        });
      this.animationTimer.Interval = 50;
      this.animationTimer.Tick += new EventHandler(this.AnimationTimer_Tick);
      this.animationTimer.Start();
      ((Control) this.btnExit).Anchor = AnchorStyles.Top | AnchorStyles.Right;
      this.btnExit.CustomizableEdges = customizableEdges1;
      this.btnExit.FillColor = Color.Black;
      this.btnExit.HoverState.FillColor = Color.FromArgb(60, 60, 60);
      this.btnExit.IconColor = Color.White;
      ((Control) this.btnExit).Location = new Point(460, 10);
      ((Control) this.btnExit).Name = "btnExit";
      this.btnExit.ShadowDecoration.CustomizableEdges = customizableEdges2;
      ((Control) this.btnExit).Size = new Size(30, 30);
      ((Control) this.btnExit).TabIndex = 1;
      ((Control) this.btnExit).Click += new EventHandler(this.btnExit_Click);
      ((Control) this.btnMinimize).Anchor = AnchorStyles.Top | AnchorStyles.Right;
      this.btnMinimize.ControlBoxType = ControlBoxType.MinimizeBox;
      this.btnMinimize.CustomizableEdges = customizableEdges3;
      this.btnMinimize.FillColor = Color.Black;
      this.btnMinimize.HoverState.FillColor = Color.FromArgb(60, 60, 60);
      this.btnMinimize.IconColor = Color.White;
      ((Control) this.btnMinimize).Location = new Point(420, 10);
      ((Control) this.btnMinimize).Name = "btnMinimize";
      this.btnMinimize.ShadowDecoration.CustomizableEdges = customizableEdges4;
      ((Control) this.btnMinimize).Size = new Size(30, 30);
      ((Control) this.btnMinimize).TabIndex = 2;
      ((Control) this.btnMinimize).Click += new EventHandler(this.btnMinimize_Click);
      this.label1.AutoSize = true;
      this.label1.Font = new Font("Segoe UI", 16f, (FontStyle) 1);
      this.label1.ForeColor = Color.White;
      this.label1.Location = new Point(168, 10);
      this.label1.Name = "label1";
      this.label1.Size = new Size(172, 30);
      this.label1.TabIndex = 3;
      this.label1.Text = "Iris Menu Injector";
      this.label1.TextAlign = (ContentAlignment) 32;
      this.guna2Button1.BorderRadius = 10;
      this.guna2Button1.CustomizableEdges = customizableEdges9;
      this.guna2Button1.FillColor = Color.Black;
      this.guna2Button1.BorderColor = Color.White;
      this.guna2Button1.BorderThickness = 1;
      ((Control) this.guna2Button1).Font = new Font("Segoe UI", 10f, (FontStyle) 1);
      ((Control) this.guna2Button1).ForeColor = Color.White;
      this.guna2Button1.HoverState.FillColor = Color.FromArgb(30, 30, 30);
      this.guna2Button1.HoverState.BorderColor = Color.White;
      this.guna2Button1.PressedColor = Color.FromArgb(50, 50, 50);
      ((Control) this.guna2Button1).Location = new Point(181, 126);
      ((Control) this.guna2Button1).Name = "guna2Button1";
      this.guna2Button1.ShadowDecoration.CustomizableEdges = customizableEdges10;
      ((Control) this.guna2Button1).Size = new Size(140, 50);
      ((Control) this.guna2Button1).TabIndex = 4;
      ((Control) this.guna2Button1).Text = "Inject";
      ((Control) this.guna2Button1).Click += new EventHandler(this.guna2Button1_Click);
      this.label2.AutoSize = true;
      this.label2.Font = new Font("Segoe UI", 16f, (FontStyle) 1);
      this.label2.ForeColor = Color.Red;
      this.label2.Location = new Point(181, 446);
      this.label2.Name = "label2";
      this.label2.Size = new Size(148, 30);
      this.label2.TabIndex = 5;
      this.label2.Text = "DISCLAIMER:";
      this.label3.AutoSize = true;
      this.label3.Font = new Font("Segoe UI", 8.25f, (FontStyle) 1, (GraphicsUnit) 3, (byte) 0);
      this.label3.ForeColor = Color.Red;
      this.label3.Location = new Point(12, 486);
      this.label3.Name = "label3";
      this.label3.Size = new Size(462, 13);
      this.label3.TabIndex = 6;
      this.label3.Text = "For the menu to work correctly, If this is your first time you must press the requirements";
      this.label3.TextAlign = (ContentAlignment) 512;
      this.label4.AutoSize = true;
      this.label4.Font = new Font("Segoe UI", 8.25f, (FontStyle) 1, (GraphicsUnit) 3, (byte) 0);
      this.label4.ForeColor = Color.Red;
      this.label4.Location = new Point(54, 499);
      this.label4.Name = "label4";
      this.label4.Size = new Size(409, 13);
      this.label4.TabIndex = 7;
      this.label4.Text = "Please enter your credentials to continue. If you have lost your account login ";
      this.label4.TextAlign = (ContentAlignment) 512;
      this.label4.Click += new EventHandler(this.label4_Click);
      this.label5.AutoSize = true;
      this.label5.Font = new Font("Segoe UI", 8.25f, (FontStyle) 1, (GraphicsUnit) 3, (byte) 0);
      this.label5.ForeColor = Color.Red;
      this.label5.Location = new Point(156, 512);
      this.label5.Name = "label5";
      this.label5.Size = new Size(184, 13);
      this.label5.TabIndex = 8;
      this.label5.Text = "please open a ticket in the discord";
      this.label5.TextAlign = (ContentAlignment) 512;
      this.label6.AutoSize = true;
      this.label6.Font = new Font("Segoe UI", 8.25f, (FontStyle) 1, (GraphicsUnit) 3, (byte) 0);
      this.label6.ForeColor = Color.Red;
      this.label6.Location = new Point(12, 499);
      this.label6.Name = "label6";
      this.label6.Size = new Size(46, 13);
      this.label6.TabIndex = 10;
      this.label6.Text = "button ";
      this.label6.TextAlign = (ContentAlignment) 512;
      this.ConsoleBox.BorderRadius = 10;
      ((Control) this.ConsoleBox).BackColor = Color.Black;
      this.ConsoleBox.BorderColor = Color.White;
      this.ConsoleBox.BorderThickness = 2;
      this.ConsoleBox.CustomizableEdges = customizableEdges7;
      this.ConsoleBox.DefaultText = "";
      this.ConsoleBox.FillColor = Color.Black;
      this.ConsoleBox.FocusedState.BorderColor = Color.White;
      ((Control) this.ConsoleBox).Font = new Font("Segoe UI", 9f);
      ((Control) this.ConsoleBox).ForeColor = Color.White;
      this.ConsoleBox.HoverState.BorderColor = Color.White;
      ((Control) this.ConsoleBox).Location = new Point(41, 246);
      this.ConsoleBox.Multiline = true;
      ((Control) this.ConsoleBox).Name = "ConsoleBox";
      this.ConsoleBox.PlaceholderText = "";
      this.ConsoleBox.ReadOnly = true;
      this.ConsoleBox.SelectedText = "";
      this.ConsoleBox.ShadowDecoration.CustomizableEdges = customizableEdges8;
      ((Control) this.ConsoleBox).Size = new Size(409, 197);
      ((Control) this.ConsoleBox).TabIndex = 11;
      this.ConsoleBox.TextChanged += new EventHandler(this.ConsoleBox_TextChanged);
      this.guna2Button2.BorderRadius = 10;
      this.guna2Button2.CustomizableEdges = customizableEdges5;
      this.guna2Button2.FillColor = Color.Black;
      this.guna2Button2.BorderColor = Color.White;
      this.guna2Button2.BorderThickness = 1;
      ((Control) this.guna2Button2).Font = new Font("Segoe UI", 10f, (FontStyle) 1);
      ((Control) this.guna2Button2).ForeColor = Color.White;
      this.guna2Button2.HoverState.FillColor = Color.FromArgb(30, 30, 30);
      this.guna2Button2.HoverState.BorderColor = Color.White;
      this.guna2Button2.PressedColor = Color.FromArgb(50, 50, 50);
      ((Control) this.guna2Button2).Location = new Point(181, 190);
      ((Control) this.guna2Button2).Name = "guna2Button2";
      this.guna2Button2.ShadowDecoration.CustomizableEdges = customizableEdges6;
      ((Control) this.guna2Button2).Size = new Size(140, 50);
      ((Control) this.guna2Button2).TabIndex = 12;
      ((Control) this.guna2Button2).Text = "Click Before Running Game";
      ((Control) this.guna2Button2).Click += new EventHandler(this.guna2Button2_Click);
      this.btnLogout.BorderRadius = 10;
      this.btnLogout.CustomizableEdges = customizableEdges11;
      this.btnLogout.FillColor = Color.Black;
      this.btnLogout.BorderColor = Color.White;
      this.btnLogout.BorderThickness = 1;
      ((Control) this.btnLogout).Font = new Font("Segoe UI", 8f, (FontStyle) 1);
      ((Control) this.btnLogout).ForeColor = Color.White;
      this.btnLogout.HoverState.FillColor = Color.FromArgb(30, 30, 30);
      this.btnLogout.HoverState.BorderColor = Color.White;
      this.btnLogout.PressedColor = Color.FromArgb(50, 50, 50);
      ((Control) this.btnLogout).Location = new Point(10, 10);
      ((Control) this.btnLogout).Name = "btnLogout";
      this.btnLogout.ShadowDecoration.CustomizableEdges = customizableEdges12;
      ((Control) this.btnLogout).Size = new Size(80, 30);
      ((Control) this.btnLogout).TabIndex = 13;
      ((Control) this.btnLogout).Text = "Logout";
      ((Control) this.btnLogout).Click += new EventHandler(this.btnLogout_Click);
      this.BackColor = Color.Black;
      this.ClientSize = new Size(500, 579);
      this.Controls.Add((Control) this.backgroundPanel);
      this.Controls.Add((Control) this.guna2Button2);
      this.Controls.Add((Control) this.ConsoleBox);
      this.Controls.Add((Control) this.label6);
      this.Controls.Add((Control) this.label5);
      this.Controls.Add((Control) this.label4);
      this.Controls.Add((Control) this.label3);
      this.Controls.Add((Control) this.label2);
      this.Controls.Add((Control) this.guna2Button1);
      this.Controls.Add((Control) this.btnExit);
      this.Controls.Add((Control) this.btnMinimize);
      this.Controls.Add((Control) this.label1);
      this.Controls.Add((Control) this.btnLogout);
      this.FormBorderStyle = FormBorderStyle.None;
      this.Name = nameof (Form123);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Load += new EventHandler(this.Form123_Load);
      ((Control) this.guna2Button2).BringToFront();
      ((Control) this.ConsoleBox).BringToFront();
      this.label6.BringToFront();
      this.label5.BringToFront();
      this.label4.BringToFront();
      this.label3.BringToFront();
      this.label2.BringToFront();
      ((Control) this.guna2Button1).BringToFront();
      ((Control) this.btnExit).BringToFront();
      ((Control) this.btnMinimize).BringToFront();
      this.label1.BringToFront();
      ((Control) this.btnLogout).BringToFront();
      this.ResumeLayout(false);
      this.PerformLayout();
    }

    protected virtual void OnLoad(
    #nullable disable
    EventArgs e)
    {
      base.OnLoad(e);
      int num = 20;
      GraphicsPath graphicsPath = new GraphicsPath();
      graphicsPath.AddArc(0, 0, num, num, 180f, 90f);
      graphicsPath.AddArc(this.Width - num, 0, num, num, 270f, 90f);
      graphicsPath.AddArc(this.Width - num, this.Height - num, num, num, 0.0f, 90f);
      graphicsPath.AddArc(0, this.Height - num, num, num, 90f, 90f);
      graphicsPath.CloseFigure();
      this.Region = new Region(graphicsPath);
    }

    private void BackgroundPanel_Paint(object sender, PaintEventArgs e)
    {
      Graphics graphics = e.Graphics;
      graphics.SmoothingMode = (SmoothingMode) 4;
      float num1 = 250f;
      float num2 = 300f;
      float num3 = 200f;
      float num4 = 100f;
      RectangleF rectangleF = new RectangleF(num1 - num3 / 2f, num2 - num4 / 2f, num3, num4);
      using (SolidBrush solidBrush = new SolidBrush(Color.White))
        graphics.FillEllipse((Brush) solidBrush, rectangleF);
      using (Pen pen = new Pen(Color.Black, 2f))
        graphics.DrawEllipse(pen, rectangleF);
      float num5 = 30f;
      float num6 = num1;
      float num7 = num2;
      graphics.FillEllipse(Brushes.Black, num6 - num5, num7 - num5, num5 * 2f, num5 * 2f);
      using (Pen pen = new Pen(Color.White, 3f))
      {
        pen.DashStyle = (DashStyle) 1;
        float num8 = num5 + 20f;
        float num9 = 5f;
        for (int index = 0; index < 3; ++index)
        {
          float num10 = this.blackHoleAngle + (float) (index * 120);
          float num11 = num6 + (float) Math.Cos((double) num10 * Math.PI / 180.0) * num8;
          float num12 = num7 + (float) Math.Sin((double) num10 * Math.PI / 180.0) * num8;
          graphics.FillEllipse(Brushes.White, num11 - num9, num12 - num9, num9 * 2f, num9 * 2f);
        }
      }
      foreach (Form123.Star star in this.stars)
        graphics.FillEllipse(Brushes.White, star.X, star.Y, star.Size, star.Size);
      using (Pen pen = new Pen(Color.FromArgb(50, 50, 50), 3f))
      {
        graphics.DrawArc(pen, num1 - num3 / 2f, (float) ((double) num2 - (double) num4 / 2.0 - 10.0), num3, num4, 180f, 180f);
        graphics.DrawArc(pen, num1 - num3 / 2f, (float) ((double) num2 - (double) num4 / 2.0 + 10.0), num3, num4, 0.0f, 180f);
      }
      Random random = new Random(123);
      using (Pen pen = new Pen(Color.FromArgb(100, (int) byte.MaxValue, 200, 200), 1f))
      {
        for (int index = 0; index < 5; ++index)
        {
          float num13 = num1 + (float) (random.NextDouble() * (double) num3 / 2.0 - (double) num3 / 4.0);
          float num14 = num2 + (float) (random.NextDouble() * (double) num4 / 2.0 - (double) num4 / 4.0);
          float num15 = num13 + (float) (random.NextDouble() * 20.0 - 10.0);
          float num16 = num14 + (float) (random.NextDouble() * 20.0 - 10.0);
          graphics.DrawLine(pen, num13, num14, num15, num16);
        }
      }
    }

    private void AnimationTimer_Tick(object sender, EventArgs e)
    {
      float num1 = 250f;
      float num2 = 289.5f;
      foreach (Form123.Star star in this.stars)
      {
        float num3 = num1 - star.X;
        float num4 = num2 - star.Y;
        float num5 = (float) Math.Sqrt((double) num3 * (double) num3 + (double) num4 * (double) num4);
        if ((double) num5 > 50.0)
        {
          float num6 = (float) (1000.0 / ((double) num5 * (double) num5));
          star.SpeedX += num3 / num5 * num6;
          star.SpeedY += num4 / num5 * num6;
        }
        star.X += star.SpeedX;
        star.Y += star.SpeedY;
        if ((double) star.X < 0.0 || (double) star.X > 500.0)
          star.SpeedX *= -1f;
        if ((double) star.Y < 0.0 || (double) star.Y > 579.0)
          star.SpeedY *= -1f;
      }
      this.blackHoleAngle += 5f;
      if ((double) this.blackHoleAngle >= 360.0)
        this.blackHoleAngle = 0.0f;
      this.backgroundPanel.Invalidate();
    }

    private void BackgroundPanel_MouseDown(object sender, MouseEventArgs e)
    {
      if (e.Button != MouseButtons.Left)
        return;
      this.isDragging = true;
      this.dragStartPosition = new Point(e.X, e.Y);
    }

    private void BackgroundPanel_MouseMove(object sender, MouseEventArgs e)
    {
      if (!this.isDragging)
        return;
      Point screen = this.PointToScreen(new Point(e.X, e.Y));
      this.Location = new Point(screen.X - this.dragStartPosition.X, screen.Y - this.dragStartPosition.Y);
    }

    private void BackgroundPanel_MouseUp(object sender, MouseEventArgs e)
    {
      if (e.Button != MouseButtons.Left)
        return;
      this.isDragging = false;
    }

    private void label4_Click(object sender, EventArgs e)
    {
    }

    private void btnLogout_Click(object sender, EventArgs e)
    {
      new Login().Show();
      this.Close();
    }

    private async void guna2Button2_Click(object sender, EventArgs e)
    {
      string url = "https://github.com/FTTSyxcal/FortniteSkibikasidkao-s-f/releases/download/IrisGUI/IrisTemplate.zip";
      string tempZipPath = Path.Combine(Path.GetTempPath(), "IrisTemplate.zip");
      try
      {
        this.LogToConsole("Starting Requirements...");
        await this.DownloadFileAsync(url, tempZipPath);
        this.UnzipFile(tempZipPath, Path.GetTempPath());
        this.LogToConsole("Requirements completed successfully!");
        this.CopyDllToPluginPaths(Path.Combine(Path.GetTempPath(), "IrisTemplate.dll"));
        tempZipPath = (string) null;
      }
      catch (Exception ex)
      {
        this.LogToConsole("Requirements failed: " + ex.Message);
        tempZipPath = (string) null;
      }
      finally
      {
        if (File.Exists(tempZipPath))
          File.Delete(tempZipPath);
      }
    }

    private void guna2Button1_Click(object sender, EventArgs e)
    {
      try
      {
        using (Injector injector = new Injector("Gorilla Tag"))
        {
          byte[] data = ByteArrayStorage.Data;
          if (data == null || data.Length == 0)
          {
            this.LogToConsole("Injection failed: DLL bytes are null or empty.");
          }
          else
          {
            this.LogToConsole("Starting injection...");
            if (injector.Inject(data, "HydrLC", "Injection", "StartInjection") == IntPtr.Zero)
              this.LogToConsole("Injection failed: Could not retrieve method pointer.");
            else
              this.LogToConsole("Injection successful!");
          }
        }
      }
      catch (Exception ex)
      {
        this.LogToConsole("Injection failed: " + ex.Message);
      }
    }

    private void btnExit_Click(object sender, EventArgs e)
    {
    }

    private void btnMinimize_Click(object sender, EventArgs e)
    {
    }

    private void ConsoleBox_TextChanged(object sender, EventArgs e)
    {
    }

    private void Form123_Load(object sender, EventArgs e)
    {
    }

    private class Star
    {
      public float X { get; set; }

      public float Y { get; set; }

      public float SpeedX { get; set; }

      public float SpeedY { get; set; }

      public float Size { get; set; }
    }
  }
}
