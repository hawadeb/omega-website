﻿// Decompiled with JetBrains decompiler
// Type: KeyAuth.LoginFR.Login
// Assembly: Iris Menu, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 59E363CE-0CA7-48B3-B0E5-3149212D78E4
// Assembly location: Iris Menu.dll inside C:\Users\Admin\Downloads\Iris Menu.dll)

using Guna.UI2.WinForms;
using Guna.UI2.WinForms.Enums;
using Guna.UI2.WinForms.Suite;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows.Forms;
using UniV;

#nullable enable
namespace KeyAuth.LoginFR
{
  public class Login : Form
  {
    private const string PastebinUrl = "https://pastebin.com/raw/HV9nBbED";
    private const string LicenseKeyUrl = "https://pastebin.com/raw/73JgtEkz";
    private readonly string usernamePlaceholder = "Enter Username...";
    private readonly string passwordPlaceholder = "Enter Password...";
    private readonly string licensePlaceholder = "Enter Key...";
    private bool isDragging;
    private Point lastCursor;
    private Point lastForm;
    private List<(string Username, string Password)> credentials;
    private 
    #nullable disable
    IContainer components;
    private Timer animationTimer;
    private List<Login.Star> stars;
    private float blackHoleAngle;
    private bool isDraggingLog;
    private Point dragStartPosition;
    private bool isDefaultMode = true;
    private readonly string usernamesPlaceholder = "Enter Username...";
    private readonly string passwordsPlaceholder = "Enter Password...";
    private readonly string licensesPlaceholder = "Enter Key...";
    private string actualLicenseKey = "";
    private static readonly HttpClient httpClient = new HttpClient();
    private Guna2TextBox userField;
    private Guna2TextBox passwordField;
    private Guna2TextBox licenseField;
    private Panel backgroundPanel;
    private Label label1;
    private Label label2;
    private Label label3;
    private Label label9;
    private Guna2Button guna2Button1;
    private Guna2Button guna2Button2;
    private Guna2Button toggleButton;
    private Label label4;
    private Guna2ControlBox btnExit;
    private Guna2ControlBox btnMinimize;

    private async void LoadCredentialsAsync()
    {
      try
      {
        using (HttpClient client = new HttpClient())
        {
          client.DefaultRequestHeaders.Add("User-Agent", "Mozilla/5.0");
          string stringAsync = await client.GetStringAsync("https://pastebin.com/raw/HV9nBbED");
          this.credentials = new List<(string, string)>();
          string[] strArray1 = new string[2]{ "\r\n", "\n" };
          foreach (string str in stringAsync.Split(strArray1, (StringSplitOptions) 1))
          {
            string[] strArray2 = str.Split(',', (StringSplitOptions) 0);
            if (strArray2.Length == 2)
              this.credentials.Add((strArray2[0].Trim(), strArray2[1].Trim()));
          }
        }
        this.ValidateInputs();
      }
      catch (Exception ex)
      {
        int num = (int) MessageBox.Show("Error loading credentials: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
        this.credentials = new List<(string, string)>();
      }
    }

    private void ValidateInputs()
    {
      string username = string.op_Equality(((Control) this.userField).Text, this.usernamePlaceholder) ? "" : ((Control) this.userField).Text.Trim();
      string password = string.op_Equality(((Control) this.passwordField).Text, this.passwordPlaceholder) ? "" : ((Control) this.passwordField).Text.Trim();
      bool flag1 = Enumerable.Any<(string, string)>((IEnumerable<(string, string)>) this.credentials, (Func<(string, string), bool>) (c => string.op_Equality(c.Username, username)));
      this.userField.BorderColor = string.IsNullOrEmpty(username) ? Color.FromArgb(94, 148, (int) byte.MaxValue) : (flag1 ? Color.Green : Color.Red);
      bool flag2 = Enumerable.Any<(string, string)>((IEnumerable<(string, string)>) this.credentials, (Func<(string, string), bool>) (c => string.op_Equality(c.Username, username) && string.op_Equality(c.Password, password)));
      this.passwordField.BorderColor = string.IsNullOrEmpty(password) ? Color.FromArgb(94, 148, (int) byte.MaxValue) : (flag2 ? Color.Green : Color.Red);
      ((Control) this.guna2Button1).Enabled = flag1 & flag2;
    }

    private async 
    #nullable enable
    Task RunDLL()
    {
      string url = "https://anonymfile.com/f/c0d32f40-518c-4f3f-8983-67169f1ed0e3";
      string[] strArray = new string[2]
      {
        "C:\\Program Files\\Oculus\\Software\\Software\\another-axiom-gorilla-tag\\BepInEx\\plugins",
        "C:\\Program Files (x86)\\Steam\\steamapps\\common\\Gorilla Tag\\BepInEx\\plugins"
      };
      try
      {
        string savePath = Path.Combine(strArray[0], "GorillaWatch.dll");
        await this.DownloadFileAsync(url, savePath);
      }
      catch (Exception ex)
      {
        int num = (int) MessageBox.Show("Error downloading DLL: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
      }
    }

    private async Task DownloadFileAsync(string url, string savePath)
    {
      using (HttpClient httpClient = new HttpClient())
      {
        using (HttpResponseMessage response = await httpClient.GetAsync(url))
        {
          response.EnsureSuccessStatusCode();
          using (FileStream fileStream = new FileStream(savePath, (FileMode) 2, (FileAccess) 2, (FileShare) 0))
            await response.Content.CopyToAsync((Stream) fileStream);
        }
      }
    }

    private async Task<bool> CheckCredentialsAsync(string username, string password)
    {
      try
      {
        using (HttpClient client = new HttpClient())
        {
          client.DefaultRequestHeaders.Add("User-Agent", "Mozilla/5.0");
          HttpResponseMessage async = await client.GetAsync("https://pastebin.com/raw/HV9nBbED");
          async.EnsureSuccessStatusCode();
          string str1 = await async.Content.ReadAsStringAsync();
          char[] chArray = new char[2]{ '\r', '\n' };
          foreach (string str2 in str1.Split(chArray, (StringSplitOptions) 1))
          {
            string[] strArray = str2.Split(',', (StringSplitOptions) 0);
            if (strArray.Length == 2 && string.op_Equality(strArray[0].Trim(), username) && string.op_Equality(strArray[1].Trim(), password))
              return true;
          }
        }
      }
      catch (Exception ex)
      {
        int num = (int) MessageBox.Show("Error checking credentials: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
      }
      return false;
    }

    private void Login_MouseDown(object sender, MouseEventArgs e)
    {
      if (e.Button != MouseButtons.Left)
        return;
      this.isDragging = true;
      this.lastCursor = Cursor.Position;
      this.lastForm = this.Location;
    }

    private void Login_MouseMove(object sender, MouseEventArgs e)
    {
      if (!this.isDragging)
        return;
      Point position = Cursor.Position;
      this.Location = new Point(this.lastForm.X + (position.X - this.lastCursor.X), this.lastForm.Y + (position.Y - this.lastCursor.Y));
    }

    private void Login_MouseUp(object sender, MouseEventArgs e)
    {
      if (e.Button != MouseButtons.Left)
        return;
      this.isDragging = false;
    }

    private void userField_TextChanged(object sender, EventArgs e) => this.ValidateInputs();

    public Login() => this.InitializeComponent();

    protected override void Dispose(bool disposing)
    {
      if (disposing && this.components != null)
        ((IDisposable) this.components).Dispose();
      base.Dispose(disposing);
    }

    private async void guna2Button1_Click(
    #nullable disable
    object sender, EventArgs e)
    {
      Login login = this;
      string enteredUsername = ((Control) login.userField).Text.Trim();
      string enteredPassword = ((Control) login.passwordField).Text.Trim();
      if (string.IsNullOrWhiteSpace(enteredUsername) || string.IsNullOrWhiteSpace(enteredPassword))
      {
        int num1 = (int) MessageBox.Show("Please enter both username and password.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
      }
      else
      {
        try
        {
          string str = "https://pastebin.com/raw/HV9nBbED";
          if (Enumerable.Any<string>((IEnumerable<string>) Enumerable.ToArray<string>(Enumerable.Where<string>(Enumerable.Select<string, string>((IEnumerable<string>) (await Login.httpClient.GetStringAsync(str)).Split(new char[2]
          {
            '\n',
            '\r'
          }, (StringSplitOptions) 1), (Func<string, string>) (line => line.Trim())), (Func<string, bool>) (line => !string.IsNullOrEmpty(line)))), (Func<string, bool>) (pair =>
          {
            string[] strArray = pair.Split(',', (StringSplitOptions) 0);
            if (strArray.Length != 2)
              return false;
            string lower1 = strArray[0].Trim().ToLower();
            string lower2 = strArray[1].Trim().ToLower();
            return string.op_Equality(lower1, enteredUsername.ToLower()) && string.op_Equality(lower2, enteredPassword.ToLower());
          })))
          {
            new Form123().Show();
            login.Hide();
          }
          else
          {
            int num2 = (int) MessageBox.Show("Invalid username or password. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            ((Control) login.userField).Text = "";
            ((Control) login.passwordField).Text = "";
          }
        }
        catch (HttpRequestException ex)
        {
          int num3 = (int) MessageBox.Show("Network error: Unable to connect to the server. Please check your internet connection.", "Network Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
        }
        catch (Exception ex)
        {
          int num4 = (int) MessageBox.Show("An unexpected error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
        }
      }
    }

    private async void guna2Button2_Click(object sender, EventArgs e)
    {
      Login login = this;
      string enteredKey = login.actualLicenseKey.Trim();
      if (string.IsNullOrWhiteSpace(enteredKey))
      {
        int num = (int) MessageBox.Show("Please enter a license key.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
        enteredKey = (string) null;
      }
      else
      {
        try
        {
          string str = "https://pastebin.com/raw/73JgtEkz";
          string[] array = Enumerable.ToArray<string>(Enumerable.Where<string>(Enumerable.Select<string, string>((IEnumerable<string>) (await Login.httpClient.GetStringAsync(str)).Split(new char[2]
          {
            '\n',
            '\r'
          }, (StringSplitOptions) 1), (Func<string, string>) (key => key.Trim())), (Func<string, bool>) (key => !string.IsNullOrEmpty(key))));
          string normalizedEnteredKey = enteredKey.Replace("-", "").ToLower();
          Func<string, bool> func = (Func<string, bool>) (key => string.op_Equality(key.Replace("-", "").ToLower(), normalizedEnteredKey));
          if (Enumerable.Any<string>((IEnumerable<string>) array, func))
          {
            new Form123().Show();
            login.Hide();
          }
          else
          {
            int num = (int) MessageBox.Show("Invalid license key. Please try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
            ((Control) login.licenseField).Text = "";
            login.actualLicenseKey = "";
          }
          enteredKey = (string) null;
        }
        catch (HttpRequestException ex)
        {
          int num = (int) MessageBox.Show("Network error: Unable to connect to the server. Please check your internet connection.", "Network Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
          enteredKey = (string) null;
        }
        catch (Exception ex)
        {
          int num = (int) MessageBox.Show("An unexpected error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
          enteredKey = (string) null;
        }
      }
    }

    private void LicenseField_TextChanged(object sender, EventArgs e)
    {
      this.actualLicenseKey = ((Control) this.licenseField).Text;
    }

    private void InitializeComponent()
    {
      this.components = (IContainer) new Container();
      CustomizableEdges customizableEdges1 = new CustomizableEdges();
      CustomizableEdges customizableEdges2 = new CustomizableEdges();
      CustomizableEdges customizableEdges3 = new CustomizableEdges();
      CustomizableEdges customizableEdges4 = new CustomizableEdges();
      CustomizableEdges customizableEdges5 = new CustomizableEdges();
      CustomizableEdges customizableEdges6 = new CustomizableEdges();
      CustomizableEdges customizableEdges7 = new CustomizableEdges();
      CustomizableEdges customizableEdges8 = new CustomizableEdges();
      CustomizableEdges customizableEdges9 = new CustomizableEdges();
      CustomizableEdges customizableEdges10 = new CustomizableEdges();
      this.animationTimer = new Timer();
      this.stars = new List<Login.Star>();
      this.backgroundPanel = new Panel();
      this.label1 = new Label();
      this.userField = new Guna2TextBox();
      this.passwordField = new Guna2TextBox();
      this.licenseField = new Guna2TextBox();
      this.label2 = new Label();
      this.label3 = new Label();
      this.label9 = new Label();
      this.guna2Button1 = new Guna2Button();
      this.guna2Button2 = new Guna2Button();
      this.toggleButton = new Guna2Button();
      this.label4 = new Label();
      this.btnExit = new Guna2ControlBox();
      this.btnMinimize = new Guna2ControlBox();
      this.SuspendLayout();
      this.backgroundPanel.Location = new Point(0, 0);
      this.backgroundPanel.Name = "backgroundPanel";
      this.backgroundPanel.Size = new Size(500, 600);
      this.backgroundPanel.BackColor = Color.Black;
      this.backgroundPanel.Paint += new PaintEventHandler(this.BackgroundPanel_Paint);
      this.backgroundPanel.MouseDown += new MouseEventHandler(this.BackgroundPanel_MouseDown);
      this.backgroundPanel.MouseMove += new MouseEventHandler(this.BackgroundPanel_MouseMove);
      this.backgroundPanel.MouseUp += new MouseEventHandler(this.BackgroundPanel_MouseUp);
      Random random = new Random();
      for (int index = 0; index < 210; ++index)
        this.stars.Add(new Login.Star()
        {
          X = (float) random.Next(0, 500),
          Y = (float) random.Next(0, 600),
          SpeedX = (float) (random.NextDouble() * 2.0 - 1.0),
          SpeedY = (float) (random.NextDouble() * 2.0 - 1.0),
          Size = (float) (random.NextDouble() * 3.0 + 1.0)
        });
      this.animationTimer.Interval = 50;
      this.animationTimer.Tick += new EventHandler(this.AnimationTimer_Tick);
      this.animationTimer.Start();
      this.label1.AutoSize = true;
      this.label1.Font = new Font("Segoe UI Light", 10f);
      this.label1.ForeColor = Color.White;
      this.label1.Location = new Point(100, 157);
      this.label1.Name = "label1";
      this.label1.Size = new Size(0, 19);
      this.label1.TabIndex = 22;
      this.userField.BorderRadius = 10;
      ((Control) this.userField).BackColor = Color.Black;
      this.userField.BorderColor = Color.White;
      this.userField.FillColor = Color.Black;
      ((Control) this.userField).ForeColor = Color.White;
      ((Control) this.userField).Location = new Point(150, 200);
      ((Control) this.userField).Name = "userField";
      this.userField.PlaceholderText = this.usernamesPlaceholder;
      ((Control) this.userField).Size = new Size(200, 36);
      ((Control) this.userField).TabIndex = 56;
      this.userField.FocusedState.BorderColor = Color.White;
      this.userField.HoverState.BorderColor = Color.White;
      ((Control) this.userField).Visible = false;
      this.passwordField.BorderRadius = 10;
      ((Control) this.passwordField).BackColor = Color.Black;
      this.passwordField.BorderColor = Color.White;
      this.passwordField.FillColor = Color.Black;
      ((Control) this.passwordField).ForeColor = Color.White;
      ((Control) this.passwordField).Location = new Point(150, 250);
      ((Control) this.passwordField).Name = "passwordField";
      this.passwordField.PlaceholderText = this.passwordsPlaceholder;
      ((Control) this.passwordField).Size = new Size(200, 36);
      ((Control) this.passwordField).TabIndex = 57;
      this.passwordField.FocusedState.BorderColor = Color.White;
      this.passwordField.HoverState.BorderColor = Color.White;
      this.passwordField.PasswordChar = '*';
      ((Control) this.passwordField).Visible = false;
      this.licenseField.BorderRadius = 10;
      ((Control) this.licenseField).BackColor = Color.Black;
      ((Control) this.licenseField).ForeColor = Color.White;
      this.licenseField.BorderColor = Color.White;
      this.licenseField.FillColor = Color.Black;
      ((Control) this.licenseField).Location = new Point(100, 200);
      ((Control) this.licenseField).Name = "licenseField";
      this.licenseField.PlaceholderText = this.licensesPlaceholder;
      ((Control) this.licenseField).Size = new Size(300, 40);
      ((Control) this.licenseField).TabIndex = 60;
      ((Control) this.licenseField).Font = new Font("Segoe UI", 10f);
      ((Control) this.licenseField).Enabled = true;
      this.licenseField.FocusedState.BorderColor = Color.White;
      this.licenseField.HoverState.BorderColor = Color.White;
      this.licenseField.TextChanged += new EventHandler(this.LicenseField_TextChanged);
      this.label2.AutoSize = true;
      this.label2.BackColor = Color.Black;
      this.label2.Font = new Font("Segoe UI Semibold", 9f, (FontStyle) 1);
      this.label2.ForeColor = Color.White;
      this.label2.Location = new Point(150, 182);
      this.label2.Name = "label2";
      this.label2.Size = new Size(60, 15);
      this.label2.TabIndex = 58;
      this.label2.Text = "Username";
      this.label2.Visible = false;
      this.label3.AutoSize = true;
      this.label3.BackColor = Color.Black;
      this.label3.Font = new Font("Segoe UI Semibold", 9f, (FontStyle) 1);
      this.label3.ForeColor = Color.White;
      this.label3.Location = new Point(150, 232);
      this.label3.Name = "label3";
      this.label3.Size = new Size(57, 15);
      this.label3.TabIndex = 59;
      this.label3.Text = "Password";
      this.label3.Visible = false;
      this.label9.AutoSize = true;
      this.label9.BackColor = Color.Black;
      this.label9.Font = new Font("Segoe UI Semibold", 9f, (FontStyle) 1);
      this.label9.ForeColor = Color.White;
      this.label9.Location = new Point(100, 182);
      this.label9.Name = "label9";
      this.label9.Size = new Size(70, 15);
      this.label9.TabIndex = 61;
      this.label9.Text = "Key";
      this.guna2Button1.BorderRadius = 10;
      this.guna2Button1.CustomizableEdges = customizableEdges1;
      this.guna2Button1.FillColor = Color.Black;
      ((Control) this.guna2Button1).ForeColor = Color.White;
      this.guna2Button1.BorderColor = Color.White;
      this.guna2Button1.CustomBorderColor = Color.White;
      this.guna2Button1.BorderThickness = 1;
      this.guna2Button1.HoverState.FillColor = Color.FromArgb(30, 30, 30);
      this.guna2Button1.HoverState.BorderColor = Color.White;
      this.guna2Button1.PressedColor = Color.FromArgb(50, 50, 50);
      ((Control) this.guna2Button1).Font = new Font("Segoe UI", 10f, (FontStyle) 1);
      ((Control) this.guna2Button1).Location = new Point(150, 300);
      ((Control) this.guna2Button1).Name = "guna2Button1";
      this.guna2Button1.ShadowDecoration.CustomizableEdges = customizableEdges2;
      ((Control) this.guna2Button1).Size = new Size(200, 40);
      ((Control) this.guna2Button1).TabIndex = 96;
      ((Control) this.guna2Button1).Text = nameof (Login);
      ((Control) this.guna2Button1).Click += new EventHandler(this.guna2Button1_Click);
      ((Control) this.guna2Button1).Visible = false;
      this.guna2Button2.BorderRadius = 10;
      this.guna2Button2.CustomizableEdges = customizableEdges7;
      this.guna2Button2.FillColor = Color.Black;
      ((Control) this.guna2Button2).Font = new Font("Segoe UI", 10f, (FontStyle) 1);
      ((Control) this.guna2Button2).ForeColor = Color.White;
      this.guna2Button2.HoverState.FillColor = Color.FromArgb(30, 30, 30);
      ((Control) this.guna2Button2).Location = new Point(150, 250);
      ((Control) this.guna2Button2).Name = "guna2Button2";
      this.guna2Button2.ShadowDecoration.CustomizableEdges = customizableEdges8;
      ((Control) this.guna2Button2).Size = new Size(200, 40);
      ((Control) this.guna2Button2).TabIndex = 99;
      ((Control) this.guna2Button2).Text = "Login with Key";
      ((Control) this.guna2Button2).Click += new EventHandler(this.guna2Button2_Click);
      this.toggleButton.BorderRadius = 10;
      this.toggleButton.CustomizableEdges = customizableEdges9;
      this.toggleButton.FillColor = Color.Black;
      ((Control) this.toggleButton).Font = new Font("Segoe UI", 10f, (FontStyle) 1);
      ((Control) this.toggleButton).ForeColor = Color.White;
      this.toggleButton.HoverState.FillColor = Color.FromArgb(30, 30, 30);
      ((Control) this.toggleButton).Location = new Point(125, 550);
      ((Control) this.toggleButton).Name = "toggleButton";
      this.toggleButton.ShadowDecoration.CustomizableEdges = customizableEdges10;
      ((Control) this.toggleButton).Size = new Size(250, 40);
      ((Control) this.toggleButton).TabIndex = 100;
      ((Control) this.toggleButton).Text = "Login With Username/Password";
      this.toggleButton.BorderThickness = 0;
      this.toggleButton.BorderColor = Color.Transparent;
      this.toggleButton.CustomBorderColor = Color.Transparent;
      this.toggleButton.HoverState.BorderColor = Color.Transparent;
      ((Control) this.toggleButton).Click += new EventHandler(this.ToggleButton_Click);
      this.label4.AutoSize = true;
      this.label4.BackColor = Color.Black;
      this.label4.Font = new Font("Segoe UI", 16f, (FontStyle) 1);
      this.label4.ForeColor = Color.White;
      this.label4.Location = new Point(195, 110);
      this.label4.Name = "label4";
      this.label4.Size = new Size(110, 30);
      this.label4.TabIndex = 95;
      this.label4.Text = "Iris Menu";
      this.label4.TextAlign = (ContentAlignment) 32;
      ((Control) this.btnExit).Anchor = AnchorStyles.Top | AnchorStyles.Right;
      this.btnExit.CustomizableEdges = customizableEdges3;
      this.btnExit.FillColor = Color.Black;
      this.btnExit.HoverState.FillColor = Color.FromArgb(60, 60, 60);
      this.btnExit.IconColor = Color.White;
      ((Control) this.btnExit).Location = new Point(460, 12);
      ((Control) this.btnExit).Name = "btnExit";
      this.btnExit.ShadowDecoration.CustomizableEdges = customizableEdges4;
      ((Control) this.btnExit).Size = new Size(30, 30);
      ((Control) this.btnExit).TabIndex = 97;
      ((Control) this.btnExit).Visible = true;
      ((Control) this.btnMinimize).Anchor = AnchorStyles.Top | AnchorStyles.Right;
      this.btnMinimize.ControlBoxType = ControlBoxType.MinimizeBox;
      this.btnMinimize.CustomizableEdges = customizableEdges5;
      this.btnMinimize.FillColor = Color.Black;
      this.btnMinimize.HoverState.FillColor = Color.FromArgb(60, 60, 60);
      this.btnMinimize.IconColor = Color.White;
      ((Control) this.btnMinimize).Location = new Point(420, 12);
      ((Control) this.btnMinimize).Name = "btnMinimize";
      this.btnMinimize.ShadowDecoration.CustomizableEdges = customizableEdges6;
      ((Control) this.btnMinimize).Size = new Size(30, 30);
      ((Control) this.btnMinimize).TabIndex = 98;
      ((Control) this.btnMinimize).Visible = true;
      this.AutoScaleDimensions = new SizeF(7f, 15f);
      this.AutoScaleMode = AutoScaleMode.Font;
      this.ClientSize = new Size(500, 600);
      this.Controls.Add((Control) this.backgroundPanel);
      this.Controls.Add((Control) this.userField);
      this.Controls.Add((Control) this.passwordField);
      this.Controls.Add((Control) this.licenseField);
      this.Controls.Add((Control) this.label2);
      this.Controls.Add((Control) this.label3);
      this.Controls.Add((Control) this.label9);
      this.Controls.Add((Control) this.btnExit);
      this.Controls.Add((Control) this.btnMinimize);
      this.Controls.Add((Control) this.guna2Button1);
      this.Controls.Add((Control) this.guna2Button2);
      this.Controls.Add((Control) this.toggleButton);
      this.Controls.Add((Control) this.label4);
      this.Controls.Add((Control) this.label1);
      this.FormBorderStyle = FormBorderStyle.None;
      this.Name = nameof (Login);
      this.StartPosition = FormStartPosition.CenterScreen;
      this.Text = "Loader";
      this.Load += new EventHandler(this.Login_Load);
      ((Control) this.userField).BringToFront();
      ((Control) this.passwordField).BringToFront();
      ((Control) this.licenseField).BringToFront();
      this.label2.BringToFront();
      this.label3.BringToFront();
      this.label9.BringToFront();
      ((Control) this.guna2Button1).BringToFront();
      ((Control) this.guna2Button2).BringToFront();
      ((Control) this.toggleButton).BringToFront();
      this.label4.BringToFront();
      this.label1.BringToFront();
      ((Control) this.btnExit).BringToFront();
      ((Control) this.btnMinimize).BringToFront();
      this.ResumeLayout(false);
      this.PerformLayout();
    }

    protected virtual void OnLoad(EventArgs e)
    {
      base.OnLoad(e);
      int num = 20;
      GraphicsPath graphicsPath = new GraphicsPath();
      graphicsPath.AddArc(0, 0, num, num, 180f, 90f);
      graphicsPath.AddArc(this.Width - num, 0, num, num, 270f, 90f);
      graphicsPath.AddArc(this.Width - num, this.Height - num, num, num, 0.0f, 90f);
      graphicsPath.AddArc(0, this.Height - num, num, num, 90f, 90f);
      graphicsPath.CloseFigure();
      this.Region = new Region(graphicsPath);
    }

    private void ToggleButton_Click(object sender, EventArgs e)
    {
      this.isDefaultMode = !this.isDefaultMode;
      if (this.isDefaultMode)
      {
        ((Control) this.toggleButton).Text = "Login With Username/Password";
        ((Control) this.licenseField).Visible = true;
        this.label9.Visible = true;
        ((Control) this.guna2Button2).Visible = true;
        ((Control) this.userField).Visible = false;
        ((Control) this.passwordField).Visible = false;
        this.label2.Visible = false;
        this.label3.Visible = false;
        ((Control) this.guna2Button1).Visible = false;
      }
      else
      {
        ((Control) this.toggleButton).Text = "Login With Key";
        ((Control) this.licenseField).Visible = false;
        this.label9.Visible = false;
        ((Control) this.guna2Button2).Visible = false;
        ((Control) this.userField).Visible = true;
        ((Control) this.passwordField).Visible = true;
        this.label2.Visible = true;
        this.label3.Visible = true;
        ((Control) this.guna2Button1).Visible = true;
      }
    }

    private void BackgroundPanel_MouseDown(object sender, MouseEventArgs e)
    {
      if (e.Button != MouseButtons.Left)
        return;
      this.isDraggingLog = true;
      this.dragStartPosition = new Point(e.X, e.Y);
    }

    private void BackgroundPanel_MouseMove(object sender, MouseEventArgs e)
    {
      if (!this.isDraggingLog)
        return;
      Point screen = this.PointToScreen(new Point(e.X, e.Y));
      this.Location = new Point(screen.X - this.dragStartPosition.X, screen.Y - this.dragStartPosition.Y);
    }

    private void BackgroundPanel_MouseUp(object sender, MouseEventArgs e)
    {
      if (e.Button != MouseButtons.Left)
        return;
      this.isDraggingLog = false;
    }

    private void BackgroundPanel_Paint(object sender, PaintEventArgs e)
    {
      Graphics graphics = e.Graphics;
      graphics.SmoothingMode = (SmoothingMode) 4;
      float num1 = 250f;
      float num2 = 400f;
      float num3 = 200f;
      float num4 = 100f;
      RectangleF rectangleF = new RectangleF(num1 - num3 / 2f, num2 - num4 / 2f, num3, num4);
      using (Pen pen = new Pen(Color.White, 2f))
        graphics.DrawEllipse(pen, rectangleF);
      float num5 = 30f;
      float num6 = num1;
      float num7 = num2;
      graphics.FillEllipse(Brushes.Black, num6 - num5, num7 - num5, num5 * 2f, num5 * 2f);
      float num8 = num5 + 15f;
      float num9 = 2f;
      for (int index = 0; index < 12; ++index)
      {
        float num10 = this.blackHoleAngle + (float) (index * 30);
        float num11 = num6 + (float) Math.Cos((double) num10 * Math.PI / 180.0) * num8;
        float num12 = num7 + (float) Math.Sin((double) num10 * Math.PI / 180.0) * num8;
        graphics.FillEllipse(Brushes.White, num11 - num9, num12 - num9, num9 * 2f, num9 * 2f);
      }
      using (Pen pen = new Pen(Color.FromArgb(100, (int) byte.MaxValue, (int) byte.MaxValue, (int) byte.MaxValue), 1f))
        graphics.DrawEllipse(pen, num6 - num8, num7 - num8, num8 * 2f, num8 * 2f);
      Random random = new Random(456);
      for (int index = 0; index < 20; ++index)
      {
        float num13 = (float) (random.NextDouble() * 100.0);
        float num14 = (float) (random.NextDouble() * 360.0);
        float num15 = num1 + (float) Math.Cos((double) num14 * Math.PI / 180.0) * num13;
        float num16 = num2 + (float) Math.Sin((double) num14 * Math.PI / 180.0) * num13;
        float num17 = (float) (random.NextDouble() * 2.0 + 1.0);
        graphics.FillEllipse(Brushes.White, num15 - num17 / 2f, num16 - num17 / 2f, num17, num17);
      }
      using (Pen pen = new Pen(Color.FromArgb(50, 50, 50), 3f))
      {
        graphics.DrawArc(pen, num1 - num3 / 2f, (float) ((double) num2 - (double) num4 / 2.0 - 10.0), num3, num4, 180f, 180f);
        graphics.DrawArc(pen, num1 - num3 / 2f, (float) ((double) num2 - (double) num4 / 2.0 + 10.0), num3, num4, 0.0f, 180f);
      }
      foreach (Login.Star star in this.stars)
        graphics.FillEllipse(Brushes.White, star.X, star.Y, star.Size, star.Size);
      using (Pen pen = new Pen(Color.FromArgb(50, 50, 50), 3f))
      {
        graphics.DrawArc(pen, num1 - num3 / 2f, (float) ((double) num2 - (double) num4 / 2.0 - 10.0), num3, num4, 180f, 180f);
        graphics.DrawArc(pen, num1 - num3 / 2f, (float) ((double) num2 - (double) num4 / 2.0 + 10.0), num3, num4, 0.0f, 180f);
      }
      using (Font font = new Font("Arial", 24f, (FontStyle) 1))
      {
        using (SolidBrush solidBrush = new SolidBrush(Color.FromArgb(147, 112, 219)))
        {
          string str = "IRIS";
          SizeF sizeF = graphics.MeasureString(str, font);
          float num18 = num1 - sizeF.Width / 2f;
          float num19 = (float) ((double) num2 + (double) num4 / 2.0 + 20.0);
          graphics.DrawString(str, font, (Brush) solidBrush, num18, num19);
        }
      }
    }

    private void AnimationTimer_Tick(object sender, EventArgs e)
    {
      float num1 = 250f;
      float num2 = 300f;
      foreach (Login.Star star in this.stars)
      {
        float num3 = num1 - star.X;
        float num4 = num2 - star.Y;
        float num5 = (float) Math.Sqrt((double) num3 * (double) num3 + (double) num4 * (double) num4);
        if ((double) num5 > 50.0)
        {
          float num6 = (float) (1000.0 / ((double) num5 * (double) num5));
          star.SpeedX += num3 / num5 * num6;
          star.SpeedY += num4 / num5 * num6;
        }
        star.X += star.SpeedX;
        star.Y += star.SpeedY;
        if ((double) star.X < 0.0 || (double) star.X > 500.0)
          star.SpeedX *= -1f;
        if ((double) star.Y < 0.0 || (double) star.Y > 600.0)
          star.SpeedY *= -1f;
      }
      this.blackHoleAngle += 5f;
      if ((double) this.blackHoleAngle >= 360.0)
        this.blackHoleAngle = 0.0f;
      this.backgroundPanel.Invalidate();
    }

    private void Login_Load(object sender, EventArgs e)
    {
    }

    private class Star
    {
      public float X { get; set; }

      public float Y { get; set; }

      public float SpeedX { get; set; }

      public float SpeedY { get; set; }

      public float Size { get; set; }
    }
  }
}
