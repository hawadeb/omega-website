﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;

[assembly: Extension]
[assembly: AssemblyCompany("Iris Menu")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0")]
[assembly: AssemblyProduct("Iris Menu")]
[assembly: AssemblyTitle("Iris Menu")]
[assembly: TargetPlatform("Windows7.0")]
[assembly: SupportedOSPlatform("Windows7.0")]
[assembly: AssemblyVersion("1.0.0.0")]
