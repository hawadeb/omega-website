﻿// Decompiled with JetBrains decompiler
// Type: WinFormsApp1.json_wrapper
// Assembly: Iris Menu, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 59E363CE-0CA7-48B3-B0E5-3149212D78E4
// Assembly location: Iris Menu.dll inside C:\Users\Admin\Downloads\Iris Menu.dll)

using System;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;

#nullable enable
namespace WinFormsApp1
{
  public class json_wrapper
  {
    private DataContractJsonSerializer serializer;
    private object current_object;

    public static bool is_serializable(Type to_check)
    {
      return to_check.IsSerializable || ((MemberInfo) to_check).IsDefined(typeof (DataContractAttribute), true);
    }

    public json_wrapper(object obj_to_work_with)
    {
      this.current_object = obj_to_work_with;
      Type type = this.current_object.GetType();
      this.serializer = new DataContractJsonSerializer(type);
      if (!json_wrapper.is_serializable(type))
      {
        DefaultInterpolatedStringHandler interpolatedStringHandler = new DefaultInterpolatedStringHandler(32, 1);
        interpolatedStringHandler.AppendLiteral("the object ");
        interpolatedStringHandler.AppendFormatted<object>(this.current_object);
        interpolatedStringHandler.AppendLiteral(" isn't a serializable");
        throw new Exception(interpolatedStringHandler.ToStringAndClear());
      }
    }

    public object string_to_object(string json)
    {
      using (MemoryStream memoryStream = new MemoryStream(Encoding.Default.GetBytes(json)))
        return ((XmlObjectSerializer) this.serializer).ReadObject((Stream) memoryStream);
    }

    public T string_to_generic<T>(string json) => (T) this.string_to_object(json);
  }
}
