﻿// Decompiled with JetBrains decompiler
// Type: WinFormsApp1.Ed25519
// Assembly: Iris Menu, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 59E363CE-0CA7-48B3-B0E5-3149212D78E4
// Assembly location: Iris Menu.dll inside C:\Users\Admin\Downloads\Iris Menu.dll)

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Security.Cryptography;

#nullable enable
namespace WinFormsApp1
{
  public class Ed25519
  {
    private static readonly Dictionary<BigInteger, BigInteger> InverseCache = new Dictionary<BigInteger, BigInteger>();
    private const int BitLength = 256;
    private static readonly BigInteger TwoPowBitLengthMinusTwo = BigInteger.Pow(BigInteger.op_Implicit(2), 254);
    private static readonly BigInteger[] TwoPowCache = Enumerable.ToArray<BigInteger>(Enumerable.Select<int, BigInteger>(Enumerable.Range(0, 512), (Func<int, BigInteger>) (i => BigInteger.Pow(BigInteger.op_Implicit(2), i))));
    private static readonly BigInteger Q = BigInteger.Parse("57896044618658097711785492504343953926634992332820282019728792003956564819949");
    private static readonly BigInteger Qm2 = BigInteger.Parse("57896044618658097711785492504343953926634992332820282019728792003956564819947");
    private static readonly BigInteger Qp3 = BigInteger.Parse("57896044618658097711785492504343953926634992332820282019728792003956564819952");
    private static readonly BigInteger L = BigInteger.Parse("7237005577332262213973186563042994240857116359379907606001950938285454250989");
    private static readonly BigInteger D = BigInteger.Parse("-4513249062541557337682894930092624173785641285191125241628941591882900924598840740");
    private static readonly BigInteger I = BigInteger.Parse("19681161376707505956807079304988542015446066515923890162744021073123829784752");
    private static readonly BigInteger By = BigInteger.Parse("46316835694926478169428394003475163141307993866256225615783033603165251855960");
    private static readonly BigInteger Bx = BigInteger.Parse("15112221349535400772501151409588531511454012693041857206046113283949847762202");
    private static readonly Tuple<BigInteger, BigInteger> B = new Tuple<BigInteger, BigInteger>(Ed25519.Bx.Mod(Ed25519.Q), Ed25519.By.Mod(Ed25519.Q));
    private static readonly BigInteger Un = BigInteger.Parse("57896044618658097711785492504343953926634992332820282019728792003956564819967");
    private static readonly BigInteger Two = new BigInteger(2);
    private static readonly BigInteger Eight = new BigInteger(8);

    private static byte[] ComputeHash(byte[] m)
    {
      using (SHA512 shA512 = SHA512.Create())
        return ((HashAlgorithm) shA512).ComputeHash(m);
    }

    private static BigInteger ExpMod(BigInteger number, BigInteger exponent, BigInteger modulo)
    {
      BigInteger bigInteger1 = BigInteger.One;
      BigInteger bigInteger2 = number.Mod(modulo);
      for (; BigInteger.op_GreaterThan(exponent, 0L); exponent = BigInteger.op_Division(exponent, BigInteger.op_Implicit(2)))
      {
        if (!exponent.IsEven)
          bigInteger1 = BigInteger.op_Multiply(bigInteger1, bigInteger2).Mod(modulo);
        bigInteger2 = BigInteger.op_Multiply(bigInteger2, bigInteger2).Mod(modulo);
      }
      return bigInteger1;
    }

    private static BigInteger Inv(BigInteger x)
    {
      if (!Ed25519.InverseCache.ContainsKey(x))
        Ed25519.InverseCache[x] = Ed25519.ExpMod(x, Ed25519.Qm2, Ed25519.Q);
      return Ed25519.InverseCache[x];
    }

    private static BigInteger RecoverX(BigInteger y)
    {
      BigInteger bigInteger1 = BigInteger.op_Multiply(y, y);
      BigInteger number = BigInteger.op_Multiply(BigInteger.op_Subtraction(bigInteger1, BigInteger.op_Implicit(1)), Ed25519.Inv(BigInteger.op_Addition(BigInteger.op_Multiply(Ed25519.D, bigInteger1), BigInteger.op_Implicit(1))));
      BigInteger bigInteger2 = Ed25519.ExpMod(number, BigInteger.op_Division(Ed25519.Qp3, Ed25519.Eight), Ed25519.Q);
      if (!BigInteger.op_Subtraction(BigInteger.op_Multiply(bigInteger2, bigInteger2), number).Mod(Ed25519.Q).Equals(BigInteger.Zero))
        bigInteger2 = BigInteger.op_Multiply(bigInteger2, Ed25519.I).Mod(Ed25519.Q);
      if (!bigInteger2.IsEven)
        bigInteger2 = BigInteger.op_Subtraction(Ed25519.Q, bigInteger2);
      return bigInteger2;
    }

    private static Tuple<BigInteger, BigInteger> Edwards(
      BigInteger px,
      BigInteger py,
      BigInteger qx,
      BigInteger qy)
    {
      BigInteger bigInteger1 = BigInteger.op_Multiply(px, qx);
      BigInteger bigInteger2 = BigInteger.op_Multiply(py, qy);
      BigInteger bigInteger3 = BigInteger.op_Multiply(BigInteger.op_Multiply(Ed25519.D, bigInteger1), bigInteger2);
      BigInteger num1 = BigInteger.op_Multiply(BigInteger.op_Addition(BigInteger.op_Multiply(px, qy), BigInteger.op_Multiply(qx, py)), Ed25519.Inv(BigInteger.op_Addition(BigInteger.op_Implicit(1), bigInteger3)));
      BigInteger num2 = BigInteger.op_Multiply(BigInteger.op_Addition(BigInteger.op_Multiply(py, qy), bigInteger1), Ed25519.Inv(BigInteger.op_Subtraction(BigInteger.op_Implicit(1), bigInteger3)));
      BigInteger q = Ed25519.Q;
      return new Tuple<BigInteger, BigInteger>(num1.Mod(q), num2.Mod(Ed25519.Q));
    }

    private static Tuple<BigInteger, BigInteger> EdwardsSquare(BigInteger x, BigInteger y)
    {
      BigInteger bigInteger1 = BigInteger.op_Multiply(x, x);
      BigInteger bigInteger2 = BigInteger.op_Multiply(y, y);
      BigInteger bigInteger3 = BigInteger.op_Multiply(BigInteger.op_Multiply(Ed25519.D, bigInteger1), bigInteger2);
      BigInteger num1 = BigInteger.op_Multiply(BigInteger.op_Multiply(BigInteger.op_Multiply(BigInteger.op_Implicit(2), x), y), Ed25519.Inv(BigInteger.op_Addition(BigInteger.op_Implicit(1), bigInteger3)));
      BigInteger num2 = BigInteger.op_Multiply(BigInteger.op_Addition(bigInteger2, bigInteger1), Ed25519.Inv(BigInteger.op_Subtraction(BigInteger.op_Implicit(1), bigInteger3)));
      BigInteger q = Ed25519.Q;
      return new Tuple<BigInteger, BigInteger>(num1.Mod(q), num2.Mod(Ed25519.Q));
    }

    private static Tuple<BigInteger, BigInteger> ScalarMul(
      Tuple<BigInteger, BigInteger> point,
      BigInteger scalar)
    {
      Tuple<BigInteger, BigInteger> tuple1 = new Tuple<BigInteger, BigInteger>(BigInteger.Zero, BigInteger.One);
      Tuple<BigInteger, BigInteger> tuple2 = point;
      for (; BigInteger.op_GreaterThan(scalar, 0L); scalar = BigInteger.op_RightShift(scalar, 1))
      {
        if (!scalar.IsEven)
          tuple1 = Ed25519.Edwards(tuple1.Item1, tuple1.Item2, tuple2.Item1, tuple2.Item2);
        tuple2 = Ed25519.EdwardsSquare(tuple2.Item1, tuple2.Item2);
      }
      return tuple1;
    }

    public static byte[] EncodeInt(BigInteger y)
    {
      byte[] byteArray = y.ToByteArray();
      byte[] numArray = new byte[Math.Max(byteArray.Length, 32)];
      Array.Copy((Array) byteArray, (Array) numArray, byteArray.Length);
      return numArray;
    }

    public static byte[] EncodePoint(BigInteger x, BigInteger y)
    {
      byte[] numArray = Ed25519.EncodeInt(y);
      numArray[numArray.Length - 1] |= x.IsEven ? (byte) 0 : (byte) 128;
      return numArray;
    }

    private static int GetBit(byte[] h, int i) => (int) h[i / 8] >> i % 8 & 1;

    public static byte[] PublicKey(byte[] signingKey)
    {
      byte[] hash = Ed25519.ComputeHash(signingKey);
      BigInteger scalar = Ed25519.TwoPowBitLengthMinusTwo;
      for (int i = 3; i < 254; ++i)
      {
        if (Ed25519.GetBit(hash, i) != 0)
          scalar = BigInteger.op_Addition(scalar, Ed25519.TwoPowCache[i]);
      }
      Tuple<BigInteger, BigInteger> tuple = Ed25519.ScalarMul(Ed25519.B, scalar);
      return Ed25519.EncodePoint(tuple.Item1, tuple.Item2);
    }

    private static BigInteger HashInt(byte[] m)
    {
      byte[] hash = Ed25519.ComputeHash(m);
      BigInteger bigInteger = BigInteger.Zero;
      for (int i = 0; i < 512; ++i)
      {
        if (Ed25519.GetBit(hash, i) != 0)
          bigInteger = BigInteger.op_Addition(bigInteger, Ed25519.TwoPowCache[i]);
      }
      return bigInteger;
    }

    public static byte[] Signature(byte[] message, byte[] signingKey, byte[] publicKey)
    {
      byte[] hash = Ed25519.ComputeHash(signingKey);
      BigInteger bigInteger = Ed25519.TwoPowBitLengthMinusTwo;
      for (int i = 3; i < 254; ++i)
      {
        if (Ed25519.GetBit(hash, i) != 0)
          bigInteger = BigInteger.op_Addition(bigInteger, Ed25519.TwoPowCache[i]);
      }
      BigInteger scalar;
      using (MemoryStream memoryStream = new MemoryStream(32 + message.Length))
      {
        ((Stream) memoryStream).Write(hash, 32, 32);
        ((Stream) memoryStream).Write(message, 0, message.Length);
        scalar = Ed25519.HashInt(memoryStream.ToArray());
      }
      Tuple<BigInteger, BigInteger> tuple = Ed25519.ScalarMul(Ed25519.B, scalar);
      byte[] numArray1 = Ed25519.EncodePoint(tuple.Item1, tuple.Item2);
      BigInteger y;
      using (MemoryStream memoryStream = new MemoryStream(32 + publicKey.Length + message.Length))
      {
        ((Stream) memoryStream).Write(numArray1, 0, numArray1.Length);
        ((Stream) memoryStream).Write(publicKey, 0, publicKey.Length);
        ((Stream) memoryStream).Write(message, 0, message.Length);
        y = BigInteger.op_Addition(scalar, BigInteger.op_Multiply(Ed25519.HashInt(memoryStream.ToArray()), bigInteger)).Mod(Ed25519.L);
      }
      using (MemoryStream memoryStream = new MemoryStream(64))
      {
        ((Stream) memoryStream).Write(numArray1, 0, numArray1.Length);
        byte[] numArray2 = Ed25519.EncodeInt(y);
        ((Stream) memoryStream).Write(numArray2, 0, numArray2.Length);
        return memoryStream.ToArray();
      }
    }

    private static bool IsOnCurve(BigInteger x, BigInteger y)
    {
      BigInteger bigInteger1 = BigInteger.op_Multiply(x, x);
      BigInteger bigInteger2 = BigInteger.op_Multiply(y, y);
      BigInteger bigInteger3 = BigInteger.op_Multiply(BigInteger.op_Multiply(Ed25519.D, bigInteger2), bigInteger1);
      return BigInteger.op_Subtraction(BigInteger.op_Subtraction(BigInteger.op_Subtraction(bigInteger2, bigInteger1), bigInteger3), BigInteger.op_Implicit(1)).Mod(Ed25519.Q).Equals(BigInteger.Zero);
    }

    private static BigInteger DecodeInt(byte[] s)
    {
      return BigInteger.op_BitwiseAnd(new BigInteger(s), Ed25519.Un);
    }

    private static Tuple<BigInteger, BigInteger> DecodePoint(byte[] pointBytes)
    {
      BigInteger y = BigInteger.op_BitwiseAnd(new BigInteger(pointBytes), Ed25519.Un);
      BigInteger x = Ed25519.RecoverX(y);
      if ((!x.IsEven ? 1 : 0) != Ed25519.GetBit(pointBytes, (int) byte.MaxValue))
        x = BigInteger.op_Subtraction(Ed25519.Q, x);
      Tuple<BigInteger, BigInteger> tuple = new Tuple<BigInteger, BigInteger>(x, y);
      if (Ed25519.IsOnCurve(x, y))
        return tuple;
      throw new ArgumentException("Decoding point that is not on curve");
    }

    public static bool CheckValid(byte[] signature, byte[] message, byte[] publicKey)
    {
      Console.Write(".");
      if (signature.Length != 64)
        throw new ArgumentException("Signature length is wrong");
      if (publicKey.Length != 32)
        throw new ArgumentException("Public key length is wrong");
      Tuple<BigInteger, BigInteger> tuple1 = Ed25519.DecodePoint(Arrays.CopyOfRange(signature, 0, 32));
      Tuple<BigInteger, BigInteger> point = Ed25519.DecodePoint(publicKey);
      BigInteger scalar1 = Ed25519.DecodeInt(Arrays.CopyOfRange(signature, 32, 64));
      BigInteger scalar2;
      using (MemoryStream memoryStream = new MemoryStream(32 + publicKey.Length + message.Length))
      {
        byte[] numArray = Ed25519.EncodePoint(tuple1.Item1, tuple1.Item2);
        ((Stream) memoryStream).Write(numArray, 0, numArray.Length);
        ((Stream) memoryStream).Write(publicKey, 0, publicKey.Length);
        ((Stream) memoryStream).Write(message, 0, message.Length);
        scalar2 = Ed25519.HashInt(memoryStream.ToArray());
      }
      Console.Write(".");
      Tuple<BigInteger, BigInteger> tuple2 = Ed25519.ScalarMul(Ed25519.B, scalar1);
      Console.Write(".");
      Tuple<BigInteger, BigInteger> tuple3 = Ed25519.ScalarMul(point, scalar2);
      Tuple<BigInteger, BigInteger> tuple4 = Ed25519.Edwards(tuple1.Item1, tuple1.Item2, tuple3.Item1, tuple3.Item2);
      return tuple2.Item1.Equals(tuple4.Item1) && tuple2.Item2.Equals(tuple4.Item2);
    }
  }
}
