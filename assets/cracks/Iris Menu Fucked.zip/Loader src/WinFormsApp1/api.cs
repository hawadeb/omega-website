﻿// Decompiled with JetBrains decompiler
// Type: WinFormsApp1.api
// Assembly: Iris Menu, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 59E363CE-0CA7-48B3-B0E5-3149212D78E4
// Assembly location: Iris Menu.dll inside C:\Users\Admin\Downloads\Iris Menu.dll)

using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Security;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

#nullable enable
namespace WinFormsApp1
{
  public class api
  {
    public string name;
    public string ownerid;
    public string version;
    public string path;
    public string seed;
    private static string sessionid;
    private static string enckey;
    private bool initialized;
    private Timer atomTimer;
    public api.app_data_class app_data = new api.app_data_class();
    public api.user_data_class user_data = new api.user_data_class();
    public api.response_class response = new api.response_class();
    private json_wrapper response_decoder = new json_wrapper((object) new api.response_structure());

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool TerminateProcess(IntPtr hProcess, uint uExitCode);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern IntPtr GetCurrentProcess();

    [DllImport("kernel32.dll", CharSet = (CharSet) 4, SetLastError = true)]
    private static extern ushort GlobalAddAtom(string lpString);

    [DllImport("kernel32.dll", CharSet = (CharSet) 4, SetLastError = true)]
    private static extern ushort GlobalFindAtom(string lpString);

    public api(string name, string ownerid, string version, string path = null)
    {
      if (ownerid.Length != 10)
      {
        Process.Start("https://youtube.com/watch?v=RfDTdiBq4_o");
        Process.Start("https://keyauth.cc/app/");
        Thread.Sleep(2000);
        api.error("Application not setup correctly. Please watch the YouTube video for setup.");
        api.TerminateProcess(api.GetCurrentProcess(), 1U);
      }
      this.name = name;
      this.ownerid = ownerid;
      this.version = version;
      this.path = path;
    }

    public async Task init()
    {
      Random random = new Random();
      int num = random.Next(5, 51);
      StringBuilder stringBuilder = new StringBuilder(num);
      for (int index = 0; index < num; ++index)
      {
        char ch = (char) random.Next(32, (int) sbyte.MaxValue);
        stringBuilder.Append(ch);
      }
      this.seed = stringBuilder.ToString();
      this.checkAtom();
      NameValueCollection post_data = new NameValueCollection()
      {
        ["type"] = nameof (init),
        ["ver"] = this.version,
        ["hash"] = api.checksum(Process.GetCurrentProcess().MainModule.FileName),
        ["name"] = this.name,
        ["ownerid"] = this.ownerid
      };
      if (!string.IsNullOrEmpty(this.path))
      {
        post_data.Add("token", File.ReadAllText(this.path));
        post_data.Add("thash", api.TokenHash(this.path));
      }
      string json = await api.req(post_data);
      if (string.op_Equality(json, "KeyAuth_Invalid"))
      {
        api.error("Application not found");
        api.TerminateProcess(api.GetCurrentProcess(), 1U);
      }
      api.response_structure generic = this.response_decoder.string_to_generic<api.response_structure>(json);
      if (string.op_Equality(generic.ownerid, this.ownerid))
      {
        this.load_response_struct(generic);
        if (generic.success)
        {
          api.sessionid = generic.sessionid;
          this.initialized = true;
        }
        else
        {
          if (!string.op_Equality(generic.message, "invalidver"))
            return;
          this.app_data.downloadLink = generic.download;
        }
      }
      else
        api.TerminateProcess(api.GetCurrentProcess(), 1U);
    }

    private void checkAtom()
    {
      this.atomTimer = new Timer((TimerCallback) (_ =>
      {
        if (api.GlobalFindAtom(this.seed) != (ushort) 0)
          return;
        api.TerminateProcess(api.GetCurrentProcess(), 1U);
      }), (object) null, TimeSpan.FromMinutes(1.0), TimeSpan.FromMinutes(1.0));
    }

    public static string TokenHash(string tokenPath)
    {
      using (SHA256 shA256 = SHA256.Create())
      {
        using (FileStream fileStream = File.OpenRead(tokenPath))
          return BitConverter.ToString(((HashAlgorithm) shA256).ComputeHash((Stream) fileStream)).Replace("-", string.Empty);
      }
    }

    public void CheckInit()
    {
      if (this.initialized)
        return;
      api.error("You must run the function KeyAuthApp.init(); first");
      api.TerminateProcess(api.GetCurrentProcess(), 1U);
    }

    public string expirydaysleft()
    {
      TimeSpan timeSpan = DateTime.op_Subtraction(new DateTime(1970, 1, 1, 0, 0, 0, 0, (DateTimeKind) 2).AddSeconds((double) long.Parse(this.user_data.subscriptions[0].expiry)).ToLocalTime(), DateTime.Now);
      int num = timeSpan.Days;
      string str1 = num.ToString();
      num = timeSpan.Hours;
      string str2 = num.ToString();
      return Convert.ToString(str1 + " Days " + str2 + " Hours Left");
    }

    public static DateTime UnixTimeToDateTime(long unixtime)
    {
      DateTime dateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, (DateTimeKind) 2);
      try
      {
        dateTime = dateTime.AddSeconds((double) unixtime).ToLocalTime();
        return dateTime;
      }
      catch
      {
        return DateTime.MaxValue;
      }
    }

    public async Task register(string username, string pass, string key, string email = "")
    {
      this.CheckInit();
      string str = ((IdentityReference) WindowsIdentity.GetCurrent().User).Value;
      api.response_structure generic = this.response_decoder.string_to_generic<api.response_structure>(await api.req(new NameValueCollection()
      {
        ["type"] = nameof (register),
        [nameof (username)] = username,
        [nameof (pass)] = pass,
        [nameof (key)] = key,
        [nameof (email)] = email,
        ["hwid"] = str,
        ["sessionid"] = api.sessionid,
        ["name"] = this.name,
        ["ownerid"] = this.ownerid
      }));
      if (string.op_Equality(generic.ownerid, this.ownerid))
      {
        int num1 = (int) api.GlobalAddAtom(this.seed);
        int num2 = (int) api.GlobalAddAtom(this.ownerid);
        this.load_response_struct(generic);
        if (!generic.success)
          return;
        this.load_user_data(generic.info);
      }
      else
        api.TerminateProcess(api.GetCurrentProcess(), 1U);
    }

    public async Task forgot(string username, string email)
    {
      this.CheckInit();
      this.load_response_struct(this.response_decoder.string_to_generic<api.response_structure>(await api.req(new NameValueCollection()
      {
        ["type"] = nameof (forgot),
        [nameof (username)] = username,
        [nameof (email)] = email,
        ["sessionid"] = api.sessionid,
        ["name"] = this.name,
        ["ownerid"] = this.ownerid
      })));
    }

    public async Task login(string username, string pass, string code = null)
    {
      this.CheckInit();
      string str = ((IdentityReference) WindowsIdentity.GetCurrent().User).Value;
      api.response_structure generic = this.response_decoder.string_to_generic<api.response_structure>(await api.req(new NameValueCollection()
      {
        ["type"] = nameof (login),
        [nameof (username)] = username,
        [nameof (pass)] = pass,
        ["hwid"] = str,
        ["sessionid"] = api.sessionid,
        ["name"] = this.name,
        ["ownerid"] = this.ownerid,
        [nameof (code)] = code ?? (string) null
      }));
      if (string.op_Equality(generic.ownerid, this.ownerid))
      {
        int num1 = (int) api.GlobalAddAtom(this.seed);
        int num2 = (int) api.GlobalAddAtom(this.ownerid);
        this.load_response_struct(generic);
        if (!generic.success)
          return;
        this.load_user_data(generic.info);
      }
      else
        api.TerminateProcess(api.GetCurrentProcess(), 1U);
    }

    public async Task logout()
    {
      this.CheckInit();
      api.response_structure generic = this.response_decoder.string_to_generic<api.response_structure>(await api.req(new NameValueCollection()
      {
        ["type"] = nameof (logout),
        ["sessionid"] = api.sessionid,
        ["name"] = this.name,
        ["ownerid"] = this.ownerid
      }));
      if (string.op_Equality(generic.ownerid, this.ownerid))
        this.load_response_struct(generic);
      else
        api.TerminateProcess(api.GetCurrentProcess(), 1U);
    }

    public async Task web_login()
    {
      this.CheckInit();
      string str1 = ((IdentityReference) WindowsIdentity.GetCurrent().User).Value;
      HttpListener listener;
      HttpListenerResponse responsepp;
      HttpListenerRequest request;
      while (true)
      {
        listener = new HttpListener();
        listener.Prefixes.Add("http://localhost:1337/" + "handshake" + "/");
        listener.Start();
        HttpListenerContext context = listener.GetContext();
        request = context.Request;
        responsepp = context.Response;
        responsepp.AddHeader("Access-Control-Allow-Methods", "GET, POST");
        responsepp.AddHeader("Access-Control-Allow-Origin", "*");
        responsepp.AddHeader("Via", "hugzho's big brain");
        responsepp.AddHeader("Location", "your kernel ;)");
        responsepp.AddHeader("Retry-After", "never lmao");
        ((NameValueCollection) responsepp.Headers).Add("Server", "\r\n\r\n");
        if (string.op_Equality(request.HttpMethod, "OPTIONS"))
        {
          responsepp.StatusCode = 200;
          Thread.Sleep(1);
          listener.Stop();
        }
        else
          break;
      }
      listener.AuthenticationSchemes = (AuthenticationSchemes) 2;
      listener.UnsafeConnectionNtlmAuthentication = true;
      listener.IgnoreWriteExceptions = true;
      string str2 = request.RawUrl.Replace("/handshake?user=", "").Replace("&token=", " ");
      string str3 = str2.Split(Array.Empty<char>())[0];
      string str4 = str2.Split(' ', (StringSplitOptions) 0)[1];
      api.response_structure generic = this.response_decoder.string_to_generic<api.response_structure>(await api.req(new NameValueCollection()
      {
        ["type"] = "login",
        ["username"] = str3,
        ["token"] = str4,
        ["hwid"] = str1,
        ["sessionid"] = api.sessionid,
        ["name"] = this.name,
        ["ownerid"] = this.ownerid
      }));
      bool flag = true;
      if (string.op_Equality(generic.ownerid, this.ownerid))
      {
        int num1 = (int) api.GlobalAddAtom(this.seed);
        int num2 = (int) api.GlobalAddAtom(this.ownerid);
        this.load_response_struct(generic);
        if (generic.success)
        {
          this.load_user_data(generic.info);
          responsepp.StatusCode = 420;
          responsepp.StatusDescription = "SHEESH";
        }
        else
        {
          Console.WriteLine(generic.message);
          responsepp.StatusCode = 200;
          responsepp.StatusDescription = generic.message;
          flag = false;
        }
      }
      else
        api.TerminateProcess(api.GetCurrentProcess(), 1U);
      byte[] bytes = Encoding.UTF8.GetBytes("Complete");
      responsepp.ContentLength64 = (long) bytes.Length;
      responsepp.OutputStream.Write(bytes, 0, bytes.Length);
      Thread.Sleep(1);
      listener.Stop();
      if (flag)
      {
        listener = (HttpListener) null;
        responsepp = (HttpListenerResponse) null;
      }
      else
      {
        api.TerminateProcess(api.GetCurrentProcess(), 1U);
        listener = (HttpListener) null;
        responsepp = (HttpListenerResponse) null;
      }
    }

    public void button(string button)
    {
      this.CheckInit();
      HttpListener httpListener = new HttpListener();
      httpListener.Prefixes.Add("http://localhost:1337/" + button + "/");
      httpListener.Start();
      HttpListenerContext context = httpListener.GetContext();
      HttpListenerRequest request = context.Request;
      HttpListenerResponse response = context.Response;
      response.AddHeader("Access-Control-Allow-Methods", "GET, POST");
      response.AddHeader("Access-Control-Allow-Origin", "*");
      response.AddHeader("Via", "hugzho's big brain");
      response.AddHeader("Location", "your kernel ;)");
      response.AddHeader("Retry-After", "never lmao");
      ((NameValueCollection) response.Headers).Add("Server", "\r\n\r\n");
      response.StatusCode = 420;
      response.StatusDescription = "SHEESH";
      httpListener.AuthenticationSchemes = (AuthenticationSchemes) 2;
      httpListener.UnsafeConnectionNtlmAuthentication = true;
      httpListener.IgnoreWriteExceptions = true;
      httpListener.Stop();
    }

    public async Task upgrade(string username, string key)
    {
      this.CheckInit();
      api.response_structure generic = this.response_decoder.string_to_generic<api.response_structure>(await api.req(new NameValueCollection()
      {
        ["type"] = nameof (upgrade),
        [nameof (username)] = username,
        [nameof (key)] = key,
        ["sessionid"] = api.sessionid,
        ["name"] = this.name,
        ["ownerid"] = this.ownerid
      }));
      if (string.op_Equality(generic.ownerid, this.ownerid))
      {
        generic.success = false;
        this.load_response_struct(generic);
      }
      else
        api.TerminateProcess(api.GetCurrentProcess(), 1U);
    }

    public async Task license(string key, string code = null)
    {
      this.CheckInit();
      string str = ((IdentityReference) WindowsIdentity.GetCurrent().User).Value;
      api.response_structure generic = this.response_decoder.string_to_generic<api.response_structure>(await api.req(new NameValueCollection()
      {
        ["type"] = nameof (license),
        [nameof (key)] = key,
        ["hwid"] = str,
        ["sessionid"] = api.sessionid,
        ["name"] = this.name,
        ["ownerid"] = this.ownerid,
        [nameof (code)] = code ?? (string) null
      }));
      if (string.op_Equality(generic.ownerid, this.ownerid))
      {
        int num1 = (int) api.GlobalAddAtom(this.seed);
        int num2 = (int) api.GlobalAddAtom(this.ownerid);
        this.load_response_struct(generic);
        if (!generic.success)
          return;
        this.load_user_data(generic.info);
      }
      else
        api.TerminateProcess(api.GetCurrentProcess(), 1U);
    }

    public async Task check()
    {
      this.CheckInit();
      api.response_structure generic = this.response_decoder.string_to_generic<api.response_structure>(await api.req(new NameValueCollection()
      {
        ["type"] = nameof (check),
        ["sessionid"] = api.sessionid,
        ["name"] = this.name,
        ["ownerid"] = this.ownerid
      }));
      if (string.op_Equality(generic.ownerid, this.ownerid))
        this.load_response_struct(generic);
      else
        api.TerminateProcess(api.GetCurrentProcess(), 1U);
    }

    public async Task setvar(string var, string data)
    {
      this.CheckInit();
      api.response_structure generic = this.response_decoder.string_to_generic<api.response_structure>(await api.req(new NameValueCollection()
      {
        ["type"] = nameof (setvar),
        [nameof (var)] = var,
        [nameof (data)] = data,
        ["sessionid"] = api.sessionid,
        ["name"] = this.name,
        ["ownerid"] = this.ownerid
      }));
      if (string.op_Equality(generic.ownerid, this.ownerid))
        this.load_response_struct(generic);
      else
        api.TerminateProcess(api.GetCurrentProcess(), 1U);
    }

    public async Task<string> getvar(string var)
    {
      this.CheckInit();
      api.response_structure generic = this.response_decoder.string_to_generic<api.response_structure>(await api.req(new NameValueCollection()
      {
        ["type"] = nameof (getvar),
        [nameof (var)] = var,
        ["sessionid"] = api.sessionid,
        ["name"] = this.name,
        ["ownerid"] = this.ownerid
      }));
      if (string.op_Equality(generic.ownerid, this.ownerid))
      {
        this.load_response_struct(generic);
        if (generic.success)
          return generic.response;
      }
      else
        api.TerminateProcess(api.GetCurrentProcess(), 1U);
      return (string) null;
    }

    public async Task ban(string reason = null)
    {
      this.CheckInit();
      api.response_structure generic = this.response_decoder.string_to_generic<api.response_structure>(await api.req(new NameValueCollection()
      {
        ["type"] = nameof (ban),
        [nameof (reason)] = reason,
        ["sessionid"] = api.sessionid,
        ["name"] = this.name,
        ["ownerid"] = this.ownerid
      }));
      if (string.op_Equality(generic.ownerid, this.ownerid))
        this.load_response_struct(generic);
      else
        api.TerminateProcess(api.GetCurrentProcess(), 1U);
    }

    public async Task<string> var(string varid)
    {
      this.CheckInit();
      api.response_structure generic = this.response_decoder.string_to_generic<api.response_structure>(await api.req(new NameValueCollection()
      {
        ["type"] = nameof (var),
        [nameof (varid)] = varid,
        ["sessionid"] = api.sessionid,
        ["name"] = this.name,
        ["ownerid"] = this.ownerid
      }));
      if (string.op_Equality(generic.ownerid, this.ownerid))
      {
        this.load_response_struct(generic);
        if (generic.success)
          return generic.message;
      }
      else
        api.TerminateProcess(api.GetCurrentProcess(), 1U);
      return (string) null;
    }

    public async Task<List<api.users>> fetchOnline()
    {
      this.CheckInit();
      api.response_structure generic = this.response_decoder.string_to_generic<api.response_structure>(await api.req(new NameValueCollection()
      {
        ["type"] = nameof (fetchOnline),
        ["sessionid"] = api.sessionid,
        ["name"] = this.name,
        ["ownerid"] = this.ownerid
      }));
      this.load_response_struct(generic);
      return !generic.success ? (List<api.users>) null : generic.users;
    }

    public async Task fetchStats()
    {
      this.CheckInit();
      api.response_structure generic = this.response_decoder.string_to_generic<api.response_structure>(await api.req(new NameValueCollection()
      {
        ["type"] = nameof (fetchStats),
        ["sessionid"] = api.sessionid,
        ["name"] = this.name,
        ["ownerid"] = this.ownerid
      }));
      this.load_response_struct(generic);
      if (!generic.success)
        return;
      this.load_app_data(generic.appinfo);
    }

    public async Task<List<api.msg>> chatget(string channelname)
    {
      this.CheckInit();
      api.response_structure generic = this.response_decoder.string_to_generic<api.response_structure>(await api.req(new NameValueCollection()
      {
        ["type"] = nameof (chatget),
        ["channel"] = channelname,
        ["sessionid"] = api.sessionid,
        ["name"] = this.name,
        ["ownerid"] = this.ownerid
      }));
      this.load_response_struct(generic);
      return !generic.success ? (List<api.msg>) null : generic.messages;
    }

    public async Task<bool> chatsend(string msg, string channelname)
    {
      this.CheckInit();
      api.response_structure generic = this.response_decoder.string_to_generic<api.response_structure>(await api.req(new NameValueCollection()
      {
        ["type"] = nameof (chatsend),
        ["message"] = msg,
        ["channel"] = channelname,
        ["sessionid"] = api.sessionid,
        ["name"] = this.name,
        ["ownerid"] = this.ownerid
      }));
      this.load_response_struct(generic);
      return generic.success;
    }

    public async Task<bool> checkblack()
    {
      this.CheckInit();
      string str = ((IdentityReference) WindowsIdentity.GetCurrent().User).Value;
      api.response_structure generic = this.response_decoder.string_to_generic<api.response_structure>(await api.req(new NameValueCollection()
      {
        ["type"] = "checkblacklist",
        ["hwid"] = str,
        ["sessionid"] = api.sessionid,
        ["name"] = this.name,
        ["ownerid"] = this.ownerid
      }));
      if (string.op_Equality(generic.ownerid, this.ownerid))
      {
        this.load_response_struct(generic);
        return generic.success;
      }
      api.TerminateProcess(api.GetCurrentProcess(), 1U);
      return true;
    }

    public async Task<string> webhook(string webid, string param, string body = "", string conttype = "")
    {
      this.CheckInit();
      api.response_structure generic = this.response_decoder.string_to_generic<api.response_structure>(await api.req(new NameValueCollection()
      {
        ["type"] = nameof (webhook),
        [nameof (webid)] = webid,
        ["params"] = param,
        [nameof (body)] = body,
        [nameof (conttype)] = conttype,
        ["sessionid"] = api.sessionid,
        ["name"] = this.name,
        ["ownerid"] = this.ownerid
      }));
      if (string.op_Equality(generic.ownerid, this.ownerid))
      {
        this.load_response_struct(generic);
        if (generic.success)
          return generic.response;
      }
      else
        api.TerminateProcess(api.GetCurrentProcess(), 1U);
      return (string) null;
    }

    public async Task<byte[]> download(string fileid)
    {
      this.CheckInit();
      api.response_structure generic = this.response_decoder.string_to_generic<api.response_structure>(await api.req(new NameValueCollection()
      {
        ["type"] = "file",
        [nameof (fileid)] = fileid,
        ["sessionid"] = api.sessionid,
        ["name"] = this.name,
        ["ownerid"] = this.ownerid
      }));
      this.load_response_struct(generic);
      return !generic.success ? (byte[]) null : encryption.str_to_byte_arr(generic.contents);
    }

    public async Task log(string message)
    {
      this.CheckInit();
      string str = await api.req(new NameValueCollection()
      {
        ["type"] = nameof (log),
        ["pcuser"] = Environment.UserName,
        [nameof (message)] = message,
        ["sessionid"] = api.sessionid,
        ["name"] = this.name,
        ["ownerid"] = this.ownerid
      });
    }

    public async Task changeUsername(string username)
    {
      this.CheckInit();
      this.load_response_struct(this.response_decoder.string_to_generic<api.response_structure>(await api.req(new NameValueCollection()
      {
        ["type"] = nameof (changeUsername),
        ["newUsername"] = username,
        ["sessionid"] = api.sessionid,
        ["name"] = this.name,
        ["ownerid"] = this.ownerid
      })));
    }

    public static string checksum(string filename)
    {
      using (MD5 md5 = MD5.Create())
      {
        using (FileStream fileStream = File.OpenRead(filename))
          return BitConverter.ToString(((HashAlgorithm) md5).ComputeHash((Stream) fileStream)).Replace("-", "").ToLowerInvariant();
      }
    }

    public static void error(string message)
    {
      string str1 = "Logs";
      string str2 = Path.Combine(str1, "ErrorLogs.txt");
      if (!Directory.Exists(str1))
        Directory.CreateDirectory(str1);
      if (!File.Exists(str2))
      {
        using (File.Create(str2))
          File.AppendAllText(str2, DateTime.Now.ToString() + " > This is the start of your error logs file");
      }
      File.AppendAllText(str2, DateTime.Now.ToString() + " > " + message + Environment.NewLine);
      Process.Start(new ProcessStartInfo("cmd.exe", "/c start cmd /C \"color b && title Error && echo " + message + " && timeout /t 5\"")
      {
        CreateNoWindow = true,
        RedirectStandardOutput = true,
        RedirectStandardError = true,
        UseShellExecute = false
      });
      api.TerminateProcess(api.GetCurrentProcess(), 1U);
    }

    private static async Task<string> req(NameValueCollection post_data)
    {
      try
      {
        if (api.FileCheck("keyauth.win"))
        {
          api.error("File manipulation detected. Terminating process.");
          Logger.LogEvent("File manipulation detected.");
          api.TerminateProcess(api.GetCurrentProcess(), 1U);
          return "";
        }
        List<KeyValuePair<string, string>> keyValuePairList = new List<KeyValuePair<string, string>>();
        foreach (string str in (NameObjectCollectionBase) post_data)
          keyValuePairList.Add(new KeyValuePair<string, string>(str, post_data[str]));
        FormUrlEncodedContent urlEncodedContent = new FormUrlEncodedContent((IEnumerable<KeyValuePair<string, string>>) keyValuePairList);
        using (HttpClient client = new HttpClient((HttpMessageHandler) new HttpClientHandler()
        {
          Proxy = (IWebProxy) null,
          ServerCertificateCustomValidationCallback = (Func<HttpRequestMessage, X509Certificate2, X509Chain, SslPolicyErrors, bool>) ((request, certificate, chain, sslPolicyErrors) => api.assertSSL((object) request, (X509Certificate) certificate, chain, sslPolicyErrors))
        }))
        {
          client.Timeout = TimeSpan.FromSeconds(20.0);
          HttpResponseMessage response = await client.PostAsync("https://keyauth.win/api/1.3/", (HttpContent) urlEncodedContent);
          if (!response.IsSuccessStatusCode)
          {
            if (response.StatusCode == 429)
            {
              api.error("You're connecting too faster to loader, slow down");
              Logger.LogEvent("You're connecting too faster to loader, slow down");
              api.TerminateProcess(api.GetCurrentProcess(), 1U);
            }
            else
            {
              api.error("Connection failure. Please try again, or contact us for help.");
              Logger.LogEvent("Connection failure. Please try again, or contact us for help.");
              api.TerminateProcess(api.GetCurrentProcess(), 1U);
            }
            return "";
          }
          string resp = await response.Content.ReadAsStringAsync();
          WebHeaderCollection headers = new WebHeaderCollection();
          IEnumerable<string> strings1;
          if (response.Headers.TryGetValues("x-signature-ed25519", ref strings1))
            ((NameValueCollection) headers)["x-signature-ed25519"] = Enumerable.FirstOrDefault<string>(strings1);
          IEnumerable<string> strings2;
          if (response.Headers.TryGetValues("x-signature-timestamp", ref strings2))
            ((NameValueCollection) headers)["x-signature-timestamp"] = Enumerable.FirstOrDefault<string>(strings2);
          api.sigCheck(resp, headers, post_data.Get(0));
          Logger.LogEvent(resp + "\n");
          return resp;
        }
      }
      catch (Exception ex)
      {
        api.error("Connection failure. Please try again, or contact us for help. Exception: " + ex.Message);
        Logger.LogEvent("Connection failure. Please try again, or contact us for help. Exception: " + ex.Message);
        api.TerminateProcess(api.GetCurrentProcess(), 1U);
        return "";
      }
    }

    private static bool FileCheck(string domain)
    {
      try
      {
        foreach (IPAddress hostAddress in Dns.GetHostAddresses(domain))
        {
          if (IPAddress.IsLoopback(hostAddress) || api.IsPrivateIP(hostAddress))
            return true;
        }
        return false;
      }
      catch
      {
        return true;
      }
    }

    private static bool IsPrivateIP(IPAddress ip)
    {
      byte[] addressBytes = ip.GetAddressBytes();
      return addressBytes[0] == (byte) 10 || addressBytes[0] == (byte) 172 && addressBytes[1] >= (byte) 16 && addressBytes[1] < (byte) 32 || addressBytes[0] == (byte) 192 && addressBytes[1] == (byte) 168;
    }

    private static bool assertSSL(
      object sender,
      X509Certificate certificate,
      X509Chain chain,
      SslPolicyErrors sslPolicyErrors)
    {
      if ((certificate.Issuer.Contains("Google Trust Services") || certificate.Issuer.Contains("Let's Encrypt")) && sslPolicyErrors == null)
        return true;
      api.error("SSL assertion fail, make sure you're not debugging Network. Disable internet firewall on router if possible. & echo: & echo If not, ask the developer of the program to use custom domains to fix this.");
      Logger.LogEvent("SSL assertion fail, make sure you're not debugging Network. Disable internet firewall on router if possible. If not, ask the developer of the program to use custom domains to fix this.");
      return false;
    }

    private static void sigCheck(string resp, WebHeaderCollection headers, string type)
    {
      if (string.op_Equality(type, "log") || string.op_Equality(type, "file") || string.op_Equality(type, "2faenable"))
        return;
      if (string.op_Equality(type, "2fadisable"))
        return;
      try
      {
        string header1 = ((NameValueCollection) headers)["x-signature-ed25519"];
        string header2 = ((NameValueCollection) headers)["x-signature-timestamp"];
        long num;
        if (!long.TryParse(header2, ref num))
          api.TerminateProcess(api.GetCurrentProcess(), 1U);
        if (DateTime.op_Subtraction(DateTime.UtcNow, DateTimeOffset.FromUnixTimeSeconds(num).UtcDateTime).TotalSeconds > 20.0)
          api.TerminateProcess(api.GetCurrentProcess(), 1U);
        byte[] byteArr1 = encryption.str_to_byte_arr(header1);
        byte[] byteArr2 = encryption.str_to_byte_arr("5586b4bc69c7a4b487e4563a4cd96afd39140f919bd31cea7d1c6a1e8439422b");
        byte[] bytes = Encoding.Default.GetBytes(header2 + resp);
        Console.Write(" Authenticating");
        byte[] message = bytes;
        byte[] publicKey = byteArr2;
        if (Ed25519.CheckValid(byteArr1, message, publicKey))
          return;
        api.error("Signature checksum failed. Request was tampered with or session ended most likely. & echo: & echo Response: " + resp);
        Logger.LogEvent(resp + "\n");
        api.TerminateProcess(api.GetCurrentProcess(), 1U);
      }
      catch
      {
        api.error("Signature checksum failed. Request was tampered with or session ended most likely. & echo: & echo Response: " + resp);
        Logger.LogEvent(resp + "\n");
        api.TerminateProcess(api.GetCurrentProcess(), 1U);
      }
    }

    private void load_app_data(api.app_data_structure data)
    {
      this.app_data.numUsers = data.numUsers;
      this.app_data.numOnlineUsers = data.numOnlineUsers;
      this.app_data.numKeys = data.numKeys;
      this.app_data.version = data.version;
      this.app_data.customerPanelLink = data.customerPanelLink;
    }

    private void load_user_data(api.user_data_structure data)
    {
      this.user_data.username = data.username;
      this.user_data.ip = data.ip;
      this.user_data.hwid = data.hwid;
      this.user_data.createdate = data.createdate;
      this.user_data.lastlogin = data.lastlogin;
      this.user_data.subscriptions = data.subscriptions;
    }

    private void load_response_struct(api.response_structure data)
    {
      this.response.success = data.success;
      this.response.message = data.message;
    }

    [DataContract]
    private class response_structure
    {
      [DataMember]
      public bool success { get; set; }

      [DataMember]
      public bool newSession { get; set; }

      [DataMember]
      public string sessionid { get; set; }

      [DataMember]
      public string contents { get; set; }

      [DataMember]
      public string response { get; set; }

      [DataMember]
      public string message { get; set; }

      [DataMember]
      public string ownerid { get; set; }

      [DataMember]
      public string download { get; set; }

      [DataMember(IsRequired = false, EmitDefaultValue = false)]
      public api.user_data_structure info { get; set; }

      [DataMember(IsRequired = false, EmitDefaultValue = false)]
      public api.app_data_structure appinfo { get; set; }

      [DataMember]
      public List<api.msg> messages { get; set; }

      [DataMember]
      public List<api.users> users { get; set; }

      [DataMember(Name = "2fa", IsRequired = false, EmitDefaultValue = false)]
      public api.TwoFactorData twoFactor { get; set; }
    }

    public class msg
    {
      public string message { get; set; }

      public string author { get; set; }

      public string timestamp { get; set; }
    }

    public class users
    {
      public string credential { get; set; }
    }

    [DataContract]
    private class user_data_structure
    {
      [DataMember]
      public string username { get; set; }

      [DataMember]
      public string ip { get; set; }

      [DataMember]
      public string hwid { get; set; }

      [DataMember]
      public string createdate { get; set; }

      [DataMember]
      public string lastlogin { get; set; }

      [DataMember]
      public List<api.Data> subscriptions { get; set; }
    }

    [DataContract]
    private class app_data_structure
    {
      [DataMember]
      public string numUsers { get; set; }

      [DataMember]
      public string numOnlineUsers { get; set; }

      [DataMember]
      public string numKeys { get; set; }

      [DataMember]
      public string version { get; set; }

      [DataMember]
      public string customerPanelLink { get; set; }

      [DataMember]
      public string downloadLink { get; set; }
    }

    public class app_data_class
    {
      public string numUsers { get; set; }

      public string numOnlineUsers { get; set; }

      public string numKeys { get; set; }

      public string version { get; set; }

      public string customerPanelLink { get; set; }

      public string downloadLink { get; set; }
    }

    public class user_data_class
    {
      public string username { get; set; }

      public string ip { get; set; }

      public string hwid { get; set; }

      public string createdate { get; set; }

      public string lastlogin { get; set; }

      public List<api.Data> subscriptions { get; set; }

      public DateTime CreationDate => api.UnixTimeToDateTime(long.Parse(this.createdate));

      public DateTime LastLoginDate => api.UnixTimeToDateTime(long.Parse(this.lastlogin));
    }

    public class Data
    {
      public string subscription { get; set; }

      public string expiry { get; set; }

      public string timeleft { get; set; }

      public string key { get; set; }

      public DateTime expiration => api.UnixTimeToDateTime(long.Parse(this.expiry));
    }

    [DataContract]
    private class TwoFactorData
    {
      [DataMember(Name = "secret_code")]
      public string SecretCode { get; set; }

      [DataMember(Name = "QRCode")]
      public string QRCode { get; set; }
    }

    public class response_class
    {
      public bool success { get; set; }

      public string message { get; set; }
    }
  }
}
