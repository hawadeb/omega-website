﻿// Decompiled with JetBrains decompiler
// Type: WinFormsApp1.Arrays
// Assembly: Iris Menu, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 59E363CE-0CA7-48B3-B0E5-3149212D78E4
// Assembly location: Iris Menu.dll inside C:\Users\Admin\Downloads\Iris Menu.dll)

using System;

#nullable enable
namespace WinFormsApp1
{
  internal static class Arrays
  {
    public static byte[] CopyOfRange(byte[] original, int from, int to)
    {
      int length = to - from;
      byte[] numArray = new byte[length];
      Array.Copy((Array) original, from, (Array) numArray, 0, length);
      return numArray;
    }
  }
}
