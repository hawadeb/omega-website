﻿// Decompiled with JetBrains decompiler
// Type: WinFormsApp1.encryption
// Assembly: Iris Menu, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 59E363CE-0CA7-48B3-B0E5-3149212D78E4
// Assembly location: Iris Menu.dll inside C:\Users\Admin\Downloads\Iris Menu.dll)

using System;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;

#nullable enable
namespace WinFormsApp1
{
  public static class encryption
  {
    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool TerminateProcess(IntPtr hProcess, uint uExitCode);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern IntPtr GetCurrentProcess();

    public static string HashHMAC(string enckey, string resp)
    {
      return encryption.byte_arr_to_str(((HashAlgorithm) new HMACSHA256(Encoding.UTF8.GetBytes(enckey))).ComputeHash(Encoding.UTF8.GetBytes(resp)));
    }

    public static string byte_arr_to_str(byte[] ba)
    {
      StringBuilder stringBuilder = new StringBuilder(ba.Length * 2);
      foreach (byte num in ba)
        stringBuilder.AppendFormat("{0:x2}", (object) num);
      return stringBuilder.ToString();
    }

    public static byte[] str_to_byte_arr(string hex)
    {
      try
      {
        int length = hex.Length;
        byte[] byteArr = new byte[length / 2];
        for (int index = 0; index < length; index += 2)
          byteArr[index / 2] = Convert.ToByte(hex.Substring(index, 2), 16);
        return byteArr;
      }
      catch
      {
        api.error("The session has ended, open program again.");
        encryption.TerminateProcess(encryption.GetCurrentProcess(), 1U);
        return (byte[]) null;
      }
    }

    public static string iv_key() => Guid.NewGuid().ToString().Substring(0, 16);
  }
}
