﻿// Decompiled with JetBrains decompiler
// Type: WinFormsApp1.Logger
// Assembly: Iris Menu, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 59E363CE-0CA7-48B3-B0E5-3149212D78E4
// Assembly location: Iris Menu.dll inside C:\Users\Admin\Downloads\Iris Menu.dll)

using System;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text.RegularExpressions;

#nullable enable
namespace WinFormsApp1
{
  public static class Logger
  {
    public static bool IsLoggingEnabled { get; set; }

    public static void LogEvent(string content)
    {
      if (!Logger.IsLoggingEnabled)
        return;
      string withoutExtension = Path.GetFileNameWithoutExtension(Assembly.GetEntryAssembly().Location);
      string str1 = Path.Combine(Environment.GetFolderPath((Environment.SpecialFolder) 35), "KeyAuth", "debug", withoutExtension);
      if (!Directory.Exists(str1))
        Directory.CreateDirectory(str1);
      DefaultInterpolatedStringHandler interpolatedStringHandler1 = new DefaultInterpolatedStringHandler(9, 1);
      interpolatedStringHandler1.AppendFormatted<DateTime>(DateTime.Now, "MMM_dd_yyyy");
      interpolatedStringHandler1.AppendLiteral("_logs.txt");
      string stringAndClear1 = interpolatedStringHandler1.ToStringAndClear();
      string str2 = Path.Combine(str1, stringAndClear1);
      try
      {
        content = Logger.RedactField(content, "sessionid");
        content = Logger.RedactField(content, "ownerid");
        content = Logger.RedactField(content, "app");
        content = Logger.RedactField(content, "version");
        content = Logger.RedactField(content, "fileid");
        content = Logger.RedactField(content, "webhooks");
        content = Logger.RedactField(content, "nonce");
        using (StreamWriter streamWriter1 = File.AppendText(str2))
        {
          StreamWriter streamWriter2 = streamWriter1;
          DefaultInterpolatedStringHandler interpolatedStringHandler2 = new DefaultInterpolatedStringHandler(6, 3);
          interpolatedStringHandler2.AppendLiteral("[");
          interpolatedStringHandler2.AppendFormatted<DateTime>(DateTime.Now);
          interpolatedStringHandler2.AppendLiteral("] [");
          interpolatedStringHandler2.AppendFormatted(AppDomain.CurrentDomain.FriendlyName);
          interpolatedStringHandler2.AppendLiteral("] ");
          interpolatedStringHandler2.AppendFormatted(content);
          string stringAndClear2 = interpolatedStringHandler2.ToStringAndClear();
          ((TextWriter) streamWriter2).WriteLine(stringAndClear2);
        }
      }
      catch (Exception ex)
      {
        Console.WriteLine("Error logging data: " + ex.Message);
      }
    }

    private static string RedactField(string content, string fieldName)
    {
      string str1 = "\"" + fieldName + "\":\"[^\"]*\"";
      string str2 = "\"" + fieldName + "\":\"REDACTED\"";
      return Regex.Replace(content, str1, str2);
    }
  }
}
