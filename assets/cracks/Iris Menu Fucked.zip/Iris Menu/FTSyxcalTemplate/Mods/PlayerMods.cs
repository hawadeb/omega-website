﻿// Decompiled with JetBrains decompiler
// Type: FTSyxcalTemplate.Mods.PlayerMods
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using FTSyxcalTemplate.Menu;
using UnityEngine;

#nullable disable
namespace FTSyxcalTemplate.Mods
{
  internal class PlayerMods
  {
    public static void OrbitBug()
    {
      float num1 = 0.1f;
      float num2 = 0.9f;
      ((TransferrableObject) GameObject.Find("Floating Bug Holdable").GetComponent<ThrowableBug>()).WorldShareableRequestOwnership();
      Vector3 position = ((Component) GorillaTagger.Instance.headCollider).transform.position;
      float num3 = (float) Time.frameCount * num1;
      float num4 = Mathf.Cos(num3) * num2;
      float num5 = Mathf.Sin(num3) * num2;
      GameObject.Find("Floating Bug Holdable").transform.position = Vector3.op_Addition(position, new Vector3(num4, 0.0f, num5));
    }

    public static void OrbitBat()
    {
      float num1 = 0.1f;
      float num2 = 0.9f;
      ((TransferrableObject) GameObject.Find("Cave Bat Holdable").GetComponent<ThrowableBug>()).WorldShareableRequestOwnership();
      Vector3 position = ((Component) GorillaTagger.Instance.headCollider).transform.position;
      float num3 = (float) Time.frameCount * num1;
      float num4 = Mathf.Cos(num3) * num2;
      float num5 = Mathf.Sin(num3) * num2;
      GameObject.Find("Cave Bat Holdable").transform.position = Vector3.op_Addition(position, new Vector3(num4, 0.0f, num5));
    }

    public static void OrbitMonster()
    {
      float num1 = 0.1f;
      float num2 = 0.9f;
      Vector3 position = ((Component) GorillaTagger.Instance.headCollider).transform.position;
      foreach (MonkeyeAI monkeyeAi in Object.FindObjectsOfType<MonkeyeAI>())
      {
        float num3 = (float) Time.frameCount * num1;
        float num4 = Mathf.Cos(num3) * num2;
        float num5 = Mathf.Sin(num3) * num2;
        ((Component) monkeyeAi).transform.position = Vector3.op_Addition(position, new Vector3(num4, 0.0f, num5));
      }
    }

    public static void FreezeAll()
    {
      foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
      {
        if (ControllerInputPoller.instance.rightGrab)
        {
          VRRig randomVrRig = Global.GetRandomVRRig(Object.op_Implicit((Object) vrrig));
          ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = false;
          ((Component) GorillaTagger.Instance.offlineVRRig).transform.position = ((Component) randomVrRig).transform.position;
          GorillaTagger.Instance.rightHandTransform.position = ((Component) randomVrRig).transform.position;
          GorillaTagger.Instance.leftHandTransform.position = ((Component) randomVrRig).transform.position;
        }
        else
          ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = true;
      }
    }
  }
}
