﻿// Decompiled with JetBrains decompiler
// Type: FTSyxcalTemplate.Mods.GuardianMods
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using FTSyxcalTemplate.Menu;
using Photon.Pun;
using UnityEngine;

#nullable disable
namespace FTSyxcalTemplate.Mods
{
  internal class GuardianMods
  {
    public static void GuardianGrabAll()
    {
      foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
      {
        if (ControllerInputPoller.instance.rightGrab && (double) Global.Delay < (double) Time.time)
        {
          Global.Delay = Time.time + 0.1f;
          GorillaTagger.Instance.myVRRig.SendRPC("GrabbedByPlayer", (RpcTarget) 0, new object[3]
          {
            (object) true,
            (object) false,
            (object) false
          });
          SafetyMods.FlushRPCs();
        }
      }
    }

    public static void GuardianInvisAll()
    {
      foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
      {
        if ((double) ControllerInputPoller.instance.rightControllerIndexFloat > 0.40000000596046448)
        {
          if ((double) Global.Delay < (double) Time.time)
          {
            Global.Delay = Time.time + 0.1f;
            ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = false;
            ((Component) GorillaTagger.Instance.offlineVRRig).transform.position = new Vector3(0.0f, 9999f, 0.0f);
            GorillaTagger.Instance.myVRRig.SendRPC("GrabbedByPlayer", (RpcTarget) 0, new object[3]
            {
              (object) true,
              (object) false,
              (object) false
            });
            SafetyMods.FlushRPCs();
          }
        }
        else
          ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = true;
      }
    }

    public static void GuardianSelf()
    {
      if (!PhotonNetwork.IsMasterClient)
        return;
      int num = 0;
      foreach (GorillaGuardianZoneManager zoneManager in GorillaGuardianZoneManager.zoneManagers)
      {
        if (((Behaviour) zoneManager).enabled)
        {
          zoneManager.SetGuardian(NetPlayer.op_Implicit(PhotonNetwork.LocalPlayer));
          ++num;
        }
      }
    }

    public static void UnGuardianSelf()
    {
      if (!PhotonNetwork.IsMasterClient)
        return;
      foreach (GorillaGuardianZoneManager zoneManager in GorillaGuardianZoneManager.zoneManagers)
      {
        if (((Behaviour) zoneManager).enabled)
          zoneManager.SetGuardian(NetPlayer.op_Implicit(PhotonNetwork.LocalPlayer));
      }
    }

    public static void GuardianAll()
    {
      if (!PhotonNetwork.IsMasterClient)
        return;
      int index = 0;
      foreach (GorillaGuardianZoneManager zoneManager in GorillaGuardianZoneManager.zoneManagers)
      {
        if (((Behaviour) zoneManager).enabled)
        {
          zoneManager.SetGuardian(NetPlayer.op_Implicit(PhotonNetwork.PlayerList[index]));
          ++index;
        }
      }
    }

    public static void UnguardianAll()
    {
      if (!PhotonNetwork.IsMasterClient)
        return;
      foreach (GorillaGuardianZoneManager zoneManager in GorillaGuardianZoneManager.zoneManagers)
        zoneManager.SetGuardian((NetPlayer) null);
    }
  }
}
