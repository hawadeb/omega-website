﻿// Decompiled with JetBrains decompiler
// Type: FTSyxcalTemplate.Mods.RigMods
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using FTSyxcalTemplate.Menu;
using FTSyxcalTemplate.Menu.Libs;
using GorillaLocomotion;
using StupidTemplate.Menu;
using System;
using UnityEngine;
using UnityEngine.InputSystem;

#nullable disable
namespace FTSyxcalTemplate.Mods
{
  internal class RigMods
  {
    private static GameObject GunSphere;

    public static void ResetArms()
    {
      ((Component) GTPlayer.Instance).transform.localScale = new Vector3(1f, 1f, 1f);
    }

    public static void LongArms()
    {
      ((Component) GTPlayer.Instance).transform.localScale = new Vector3(1.2f, 1.2f, 1.2f);
    }

    public static void LongerArms()
    {
      ((Component) GTPlayer.Instance).transform.localScale = new Vector3(1.4f, 1.4f, 1.4f);
    }

    public static void RigGunMod()
    {
      if (ControllerInputPoller.instance.rightGrab || Mouse.current.rightButton.isPressed)
      {
        RaycastHit raycastHit;
        Physics.Raycast(GTPlayer.Instance.rightControllerTransform.position, Vector3.op_UnaryNegation(GTPlayer.Instance.rightControllerTransform.up), ref raycastHit);
        if (Mouse.current.rightButton.isPressed)
          Physics.Raycast(GameObject.Find("Shoulder Camera").GetComponent<Camera>().ScreenPointToRay(Vector2.op_Implicit(((InputControl<Vector2>) ((Pointer) Mouse.current).position).ReadValue())), ref raycastHit, 100f);
        RigMods.GunSphere = GameObject.CreatePrimitive((PrimitiveType) 0);
        RigMods.GunSphere.transform.position = ((RaycastHit) ref raycastHit).point;
        RigMods.GunSphere.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
        RigMods.GunSphere.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
        RigMods.GunSphere.GetComponent<Renderer>().material.color = Color.white;
        Object.Destroy((Object) RigMods.GunSphere.GetComponent<BoxCollider>());
        Object.Destroy((Object) RigMods.GunSphere.GetComponent<Rigidbody>());
        Object.Destroy((Object) RigMods.GunSphere.GetComponent<Collider>());
        if ((double) ControllerInputPoller.instance.rightControllerIndexFloat > 0.10000000149011612 || Mouse.current.leftButton.isPressed)
        {
          Object.Destroy((Object) RigMods.GunSphere, Time.deltaTime);
          RigMods.GunSphere.GetComponent<Renderer>().material.color = GorillaTagger.Instance.offlineVRRig.playerColor;
          ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = false;
          ((Component) GorillaTagger.Instance.offlineVRRig).transform.position = Vector3.op_Addition(RigMods.GunSphere.transform.position, new Vector3(0.0f, 1f, 0.0f));
        }
        else
          ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = true;
      }
      if (!Object.op_Inequality((Object) RigMods.GunSphere, (Object) null))
        return;
      Object.Destroy((Object) RigMods.GunSphere, Time.deltaTime);
    }

    public static void SuperLongArms()
    {
      ((Component) GTPlayer.Instance).transform.localScale = new Vector3(1.8f, 1.8f, 1.8f);
    }

    public static void Shortarms()
    {
      ((Component) GTPlayer.Instance).transform.localScale = new Vector3(0.8f, 0.8f, 0.8f);
    }

    public static void Ghostmonke()
    {
      ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = !Global.ghostMonke;
      if (Global.ghostMonke)
        HandOrbLib.DrawHandOrbs();
      if (Global.right)
      {
        if (InputLib.Y())
          Global.ghostMonke = !Global.ghostMonke;
        Global.last = InputLib.Y();
      }
      else
      {
        if (InputLib.B())
          Global.ghostMonke = !Global.ghostMonke;
        Global.last = InputLib.B();
      }
    }

    public static void InvisMonke()
    {
      if (Global.invisMonke)
      {
        ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = false;
        ((Component) GorillaTagger.Instance.offlineVRRig).transform.position = new Vector3(9999f, 9999f, 9999f);
        HandOrbLib.DrawHandOrbs();
      }
      else
        ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = true;
      if (Global.right)
      {
        if (InputLib.Y() && !Global.last2)
          Global.invisMonke = !Global.invisMonke;
        Global.last2 = InputLib.Y();
      }
      else
      {
        if (InputLib.B() && !Global.last2)
          Global.invisMonke = !Global.invisMonke;
        Global.last2 = InputLib.B();
      }
    }

    public static void StickLongArms()
    {
      ((Component) GTPlayer.Instance.leftControllerTransform).transform.position = Vector3.op_Addition(GorillaTagger.Instance.leftHandTransform.position, Vector3.op_Multiply(GorillaTagger.Instance.leftHandTransform.forward, 0.917f));
      ((Component) GTPlayer.Instance.rightControllerTransform).transform.position = Vector3.op_Addition(GorillaTagger.Instance.rightHandTransform.position, Vector3.op_Multiply(GorillaTagger.Instance.rightHandTransform.forward, 0.917f));
    }

    public static void BayBlade()
    {
      if ((double) ControllerInputPoller.instance.rightControllerIndexFloat > 0.5)
      {
        ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = false;
        Transform transform1 = ((Component) GorillaTagger.Instance.offlineVRRig).transform;
        transform1.position = Vector3.op_Addition(transform1.position, new Vector3(0.0f, 0.0f, 0.0f));
        ((Component) GorillaTagger.Instance.offlineVRRig.head.rigTarget).transform.rotation = ((Component) GorillaTagger.Instance.offlineVRRig).transform.rotation;
        ((Component) GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget).transform.position = Vector3.op_Addition(((Component) GorillaTagger.Instance.offlineVRRig).transform.position, Vector3.op_Multiply(((Component) GorillaTagger.Instance.offlineVRRig).transform.right, -2f));
        ((Component) GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget).transform.position = Vector3.op_Addition(((Component) GorillaTagger.Instance.offlineVRRig).transform.position, Vector3.op_Multiply(((Component) GorillaTagger.Instance.offlineVRRig).transform.right, 2f));
        Transform transform2 = ((Component) GorillaTagger.Instance.offlineVRRig).transform;
        Quaternion rotation = ((Component) GorillaTagger.Instance.offlineVRRig).transform.rotation;
        Quaternion quaternion = Quaternion.Euler(Vector3.op_Addition(((Quaternion) ref rotation).eulerAngles, new Vector3(0.0f, 20f, 0.0f)));
        transform2.rotation = quaternion;
      }
      else
        ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = true;
    }

    public static void GrabRig()
    {
      if (InputLib.RG())
      {
        HandOrbLib.DrawHandOrbs();
        ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = false;
        ((Component) GorillaTagger.Instance.offlineVRRig).transform.position = GTPlayer.Instance.rightControllerTransform.position;
      }
      if (InputLib.LG())
      {
        HandOrbLib.DrawHandOrbs();
        ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = false;
        ((Component) GorillaTagger.Instance.offlineVRRig).transform.position = GTPlayer.Instance.leftControllerTransform.position;
      }
      if (InputLib.RG() || InputLib.LG())
        return;
      ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = true;
    }

    public static void SpazMonke()
    {
      if (InputLib.RG())
      {
        HandOrbLib.DrawHandOrbs();
        ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = false;
        Global.DelayedAction(0.02f, (Action) (() => ((Component) GorillaTagger.Instance.offlineVRRig).transform.position = Vector3.op_Addition(Global.orb.transform.position, Global.Random(0.4f))));
      }
      else
        ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = true;
    }

    public static void EnableFakeLag()
    {
      Global.fak = true;
      if (!Global.fak)
        return;
      Global.DelayedAction(0.9f, (Action) (() =>
      {
        ++Global.fake;
        if (Global.fake > 2)
          Global.fake = 1;
        if (Global.fake == 1)
          ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = false;
        if (Global.fake != 2)
          return;
        ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = true;
      }));
    }

    public static void DisableFakeLag()
    {
      if (!Global.fak)
        return;
      ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = true;
      Global.fak = true;
    }

    public static void freezerig()
    {
      if (!ControllerInputPoller.instance.rightGrab)
      {
        ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = true;
      }
      else
      {
        ((Component) GorillaTagger.Instance.offlineVRRig).transform.position = ((Component) GTPlayer.Instance.bodyCollider).transform.position;
        ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = false;
      }
    }

    public static void Helicopter()
    {
      if (ControllerInputPoller.instance.rightControllerPrimaryButton)
      {
        ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = false;
        Transform transform = ((Component) GorillaTagger.Instance.offlineVRRig).transform;
        transform.position = Vector3.op_Addition(transform.position, new Vector3(0.0f, 0.1f, 0.0f));
        ((Component) GorillaTagger.Instance.offlineVRRig).transform.Rotate(new Vector3(0.0f, 4f, 0.0f));
      }
      else
        ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = true;
    }

    public static void HoverMonke()
    {
      if (ControllerInputPoller.instance.rightControllerSecondaryButton)
      {
        ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = false;
        ((Component) GorillaTagger.Instance.offlineVRRig).transform.position = Vector3.op_Addition(((Component) GTPlayer.Instance.bodyCollider).transform.position, Vector3.up);
      }
      else
        ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = true;
    }

    public static void HyperSpinny()
    {
      if (ControllerInputPoller.instance.leftGrab)
      {
        ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = false;
        ((Component) GorillaTagger.Instance.offlineVRRig).transform.Rotate(new Vector3((float) Random.Range(30, 360), (float) Random.Range(30, 360), (float) Random.Range(30, 360)));
      }
      else
        ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = true;
    }

    public static void TPGun()
    {
      RaycastHit raycastHit;
      if (!ControllerInputPoller.instance.rightGrab || !Physics.Raycast(GTPlayer.Instance.rightControllerTransform.position, GTPlayer.Instance.rightControllerTransform.forward, ref raycastHit))
        return;
      GunLib.gunPointer = GameObject.CreatePrimitive((PrimitiveType) 0);
      GunLib.gunPointer.transform.position = ((RaycastHit) ref raycastHit).point;
      GunLib.gunPointer.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
      Object.Destroy((Object) GunLib.gunPointer.GetComponent<Rigidbody>());
      Object.Destroy((Object) GunLib.gunPointer.GetComponent<SphereCollider>());
      Color blue = Color.blue;
      GunLib.gunPointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
      GunLib.gunPointer.GetComponent<Renderer>().material.color = blue;
      LineRenderer lineRenderer = new GameObject("IM NOT OKAY").AddComponent<LineRenderer>();
      lineRenderer.positionCount = 2;
      lineRenderer.SetPosition(0, GTPlayer.Instance.rightControllerTransform.position);
      lineRenderer.SetPosition(1, GunLib.gunPointer.transform.position);
      lineRenderer.startWidth = 0.01f;
      lineRenderer.endWidth = 0.01f;
      ((Renderer) lineRenderer).material.shader = Shader.Find("GUI/Text Shader");
      ((Renderer) lineRenderer).material.color = blue;
      Object.Destroy((Object) GunLib.gunPointer, Time.deltaTime);
      Object.Destroy((Object) lineRenderer, Time.deltaTime);
      if ((double) ControllerInputPoller.instance.rightControllerIndexFloat > 0.40000000596046448 && (double) Global.Delay < (double) Time.time)
      {
        Global.Delay = Time.time + 1f;
        Color green = Color.green;
        GunLib.gunPointer.GetComponent<Renderer>().material.color = green;
        ((Renderer) lineRenderer).material.color = green;
        ((Component) GTPlayer.Instance).transform.position = GunLib.gunPointer.transform.position;
      }
    }
  }
}
