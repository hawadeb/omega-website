﻿// Decompiled with JetBrains decompiler
// Type: FTSyxcalTemplate.Mods.mod_check
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using ExitGames.Client.Photon;
using GorillaNetworking;
using Photon.Pun;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

#nullable disable
namespace FTSyxcalTemplate.Mods
{
  internal class mod_check
  {
    public class Important
    {
      public static GameObject theboxlol = (GameObject) null;
      private static float keyboardDelay = 0.0f;
      public static Quaternion lastHeadQuat = Quaternion.identity;
      public static Quaternion lastLHQuat = Quaternion.identity;
      public static Quaternion lastRHQuat = Quaternion.identity;
      public static bool lastTagLag = false;
      public static int tagLagFrames = 0;

      public static void Disconnect() => PhotonNetwork.Disconnect();

      public static void CreateRoom(string roomName, bool isPublic)
      {
        Debug.Log((object) (string) typeof (PhotonNetworkController).GetField("platformTag", BindingFlags.Instance | BindingFlags.NonPublic).GetValue((object) PhotonNetworkController.Instance));
        RoomConfig roomConfig1 = new RoomConfig();
        roomConfig1.createIfMissing = true;
        roomConfig1.isJoinable = true;
        roomConfig1.isPublic = isPublic;
        roomConfig1.MaxPlayers = PhotonNetworkController.Instance.GetRoomSize(PhotonNetworkController.Instance.currentJoinTrigger.networkZone);
        RoomConfig roomConfig2 = roomConfig1;
        Hashtable hashtable1 = new Hashtable();
        ((Dictionary<object, object>) hashtable1).Add((object) "gameMode", (object) PhotonNetworkController.Instance.currentJoinTrigger.GetFullDesiredGameModeString());
        ((Dictionary<object, object>) hashtable1).Add((object) "platform", (object) (string) typeof (PhotonNetworkController).GetField("platformTag", BindingFlags.Instance | BindingFlags.NonPublic).GetValue((object) PhotonNetworkController.Instance));
        ((Dictionary<object, object>) hashtable1).Add((object) "queueName", (object) GorillaComputer.instance.currentQueue);
        Hashtable hashtable2 = hashtable1;
        roomConfig2.CustomProps = hashtable2;
        RoomConfig roomConfig3 = roomConfig1;
        NetworkSystem.Instance.ConnectToRoom(roomName, roomConfig3, -1);
      }

      public static void EnableAntiAFK() => PhotonNetworkController.Instance.disableAFKKick = true;

      public static void DisableAntiAFK()
      {
        PhotonNetworkController.Instance.disableAFKKick = false;
      }

      public static void DisableNetworkTriggers()
      {
        GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab").SetActive(false);
      }

      public static void EnableNetworkTriggers()
      {
        GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab").SetActive(true);
      }

      public static void DisableMapTriggers()
      {
        GameObject.Find("Environment Objects/TriggerZones_Prefab/ZoneTransitions_Prefab").SetActive(false);
      }

      public static void EnableMapTriggers()
      {
        GameObject.Find("Environment Objects/TriggerZones_Prefab/ZoneTransitions_Prefab").SetActive(true);
      }

      public static void DisableQuitBox()
      {
        GameObject.Find("Environment Objects/TriggerZones_Prefab/ZoneTransitions_Prefab/QuitBox").SetActive(false);
      }

      public static void EnableQuitBox()
      {
        GameObject.Find("Environment Objects/TriggerZones_Prefab/ZoneTransitions_Prefab/QuitBox").SetActive(true);
      }

      public static void NotPhysicalQuitbox()
      {
        Object.Destroy((Object) mod_check.Important.theboxlol);
        GameObject.Find("Environment Objects/TriggerZones_Prefab/ZoneTransitions_Prefab/QuitBox").SetActive(true);
      }

      public static void EnableFPSBoost() => QualitySettings.globalTextureMipmapLimit = 99999;

      public static void DisableFPSBoost() => QualitySettings.globalTextureMipmapLimit = 1;

      public static void UncapFPS()
      {
        QualitySettings.vSyncCount = 0;
        Application.targetFrameRate = int.MaxValue;
      }

      public static void CapFPS() => Application.targetFrameRate = 144;

      public static void UnlockCompetitiveQueue()
      {
        GorillaComputer.instance.CompQueueUnlockButtonPress();
      }

      public static void EUServers() => PhotonNetwork.ConnectToRegion("eu");

      public static void USServers() => PhotonNetwork.ConnectToRegion("us");

      public static void USWServers() => PhotonNetwork.ConnectToRegion("usw");
    }
  }
}
