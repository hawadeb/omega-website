﻿// Decompiled with JetBrains decompiler
// Type: FTSyxcalTemplate.Mods.OverpoweredMods
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using FTSyxcalTemplate.Menu;
using GorillaTagScripts;
using HarmonyLib;
using Photon.Pun;
using StupidTemplate.Notifications;
using UnityEngine;

#nullable disable
namespace FTSyxcalTemplate.Mods
{
  internal class OverpoweredMods
  {
    public static void MasterCheck()
    {
      if (PhotonNetwork.IsMasterClient)
        NotifiLib.SendNotification("<color=grey>[</color><color=green>SUCCESS</color><color=grey>]</color> <color=white>You are master client.</color>");
      else
        NotifiLib.SendNotification("<color=grey>[</color><color=red>ERROR</color><color=grey>]</color> <color=white>You are not master client.</color>");
    }

    public static void CrashAll() => BuilderTable.instance.builderNetworking.PlayerEnterBuilder();

    public static void GuardianSelf()
    {
      if (PhotonNetwork.IsMasterClient)
      {
        foreach (GorillaGuardianZoneManager zoneManager in GorillaGuardianZoneManager.zoneManagers)
        {
          if (((Behaviour) zoneManager).enabled)
            zoneManager.SetGuardian(NetworkSystem.Instance.LocalPlayer);
        }
      }
      else
        NotifiLib.SendNotification("<color=grey>[</color><color=red>ERROR</color><color=grey>]</color> <color=white>You are not master client.</color>");
    }

    public static void UnguardianSelf()
    {
      if (PhotonNetwork.IsMasterClient)
      {
        foreach (GorillaGuardianZoneManager zoneManager in GorillaGuardianZoneManager.zoneManagers)
        {
          if (((Behaviour) zoneManager).enabled && zoneManager.CurrentGuardian == NetworkSystem.Instance.LocalPlayer)
            zoneManager.SetGuardian((NetPlayer) null);
        }
      }
      else
        NotifiLib.SendNotification("<color=grey>[</color><color=red>ERROR</color><color=grey>]</color> <color=white>You are not master client.</color>");
    }

    public static void SilentGuardian()
    {
      if (PhotonNetwork.IsMasterClient)
      {
        foreach (GorillaGuardianZoneManager zoneManager in GorillaGuardianZoneManager.zoneManagers)
        {
          if (((Behaviour) zoneManager).enabled && zoneManager.CurrentGuardian != NetworkSystem.Instance.LocalPlayer)
            Traverse.Create((object) zoneManager).Field("guardianPlayer").SetValue((object) NetworkSystem.Instance.LocalPlayer);
        }
      }
      else
        NotifiLib.SendNotification("<color=grey>[</color><color=red>ERROR</color><color=grey>]</color> <color=white>You are not master client.</color>");
    }

    public static void GuardianAll()
    {
      if (PhotonNetwork.IsMasterClient)
      {
        int index = 0;
        foreach (GorillaGuardianZoneManager zoneManager in GorillaGuardianZoneManager.zoneManagers)
        {
          if (((Behaviour) zoneManager).enabled)
          {
            zoneManager.SetGuardian(NetPlayer.op_Implicit(PhotonNetwork.PlayerList[index]));
            ++index;
          }
        }
      }
      else
        NotifiLib.SendNotification("<color=grey>[</color><color=red>ERROR</color><color=grey>]</color> <color=white>You are not master client.</color>");
    }

    public static void UnguardianAll()
    {
      if (PhotonNetwork.IsMasterClient)
      {
        foreach (GorillaGuardianZoneManager zoneManager in GorillaGuardianZoneManager.zoneManagers)
        {
          if (((Behaviour) zoneManager).enabled)
            zoneManager.SetGuardian((NetPlayer) null);
        }
      }
      else
        NotifiLib.SendNotification("<color=grey>[</color><color=red>ERROR</color><color=grey>]</color> <color=white>You are not master client.</color>");
    }

    public static void RpcAll()
    {
      foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
      {
        Global.GetNetworkViewFromVRRig(vrrig).SendRPC("RPC_ReportTag", (RpcTarget) 0, new object[3]
        {
          (object) 213,
          (object) true,
          (object) 999999f
        });
        SafetyMods.FlushRPCs();
      }
    }
  }
}
