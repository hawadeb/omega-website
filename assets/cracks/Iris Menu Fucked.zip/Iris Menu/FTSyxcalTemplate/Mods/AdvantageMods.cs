﻿// Decompiled with JetBrains decompiler
// Type: FTSyxcalTemplate.Mods.AdvantageMods
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using BepInEx;
using CC.Utilities;
using ExitGames.Client.Photon;
using FTSyxcalTemplate.Menu;
using FTSyxcalTemplate.Menu.Libs;
using GorillaGameModes;
using GorillaLocomotion;
using GorillaTagScripts;
using Photon.Pun;
using Photon.Realtime;
using StupidTemplate.Classes;
using StupidTemplate.Notifications;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

#nullable disable
namespace FTSyxcalTemplate.Mods
{
  internal class AdvantageMods
  {
    private static GorillaTagger gorilla = GorillaTagger.Instance;
    private static GameObject GunSphere;

    public static void InitializePhoton()
    {
      if (!PhotonNetwork.IsConnected)
      {
        PhotonNetwork.ConnectUsingSettings();
        Debug.Log((object) "Connecting to Photon...");
      }
      else
        Debug.Log((object) "Already connected to Photon.");
    }

    public static void TagLag()
    {
      if (!PhotonNetwork.IsMasterClient)
      {
        NotifiLib.SendNotification("<color=grey>[</color><color=red>ERROR</color><color=grey>]</color> <color=white>You are not master client.</color>");
      }
      else
      {
        GorillaTagManager component1 = GameObject.Find("GT Systems/GameModeSystem/Gorilla Tag Manager").GetComponent<GorillaTagManager>();
        GorillaAmbushManager component2 = GameObject.Find("GT Systems/GameModeSystem/Gorilla Stealth Manager").GetComponent<GorillaAmbushManager>();
        if (GorillaGameManager.instance.GameModeName().ToLower().Contains("ambush") || GorillaGameManager.instance.GameModeName().ToLower().Contains("stealth"))
          ((GorillaTagManager) component2).tagCoolDown = (float) int.MaxValue;
        else
          component1.tagCoolDown = (float) int.MaxValue;
      }
    }

    public static void NahTagLag()
    {
      GorillaTagManager component1 = GameObject.Find("GT Systems/GameModeSystem/Gorilla Tag Manager").GetComponent<GorillaTagManager>();
      GorillaAmbushManager component2 = GameObject.Find("GT Systems/GameModeSystem/Gorilla Stealth Manager").GetComponent<GorillaAmbushManager>();
      if (GorillaGameManager.instance.GameModeName().ToLower().Contains("ambush") || GorillaGameManager.instance.GameModeName().ToLower().Contains("stealth"))
        ((GorillaTagManager) component2).tagCoolDown = 5f;
      else
        component1.tagCoolDown = 5f;
    }

    public static void NoTagOnJoin()
    {
      PlayerPrefs.SetString("tutorial", "nope");
      PlayerPrefs.SetString("didTutorial", "nope");
      Hashtable hashtable = new Hashtable();
      ((Dictionary<object, object>) hashtable).Add((object) "didTutorial", (object) false);
      PhotonNetwork.LocalPlayer.SetCustomProperties(hashtable, (Hashtable) null, (WebFlags) null);
      PlayerPrefs.Save();
    }

    public static void TagOnJoin()
    {
      PlayerPrefs.SetString("tutorial", "done");
      PlayerPrefs.SetString("didTutorial", "done");
      Hashtable hashtable = new Hashtable();
      ((Dictionary<object, object>) hashtable).Add((object) "didTutorial", (object) true);
      PhotonNetwork.LocalPlayer.SetCustomProperties(hashtable, (Hashtable) null, (WebFlags) null);
      PlayerPrefs.Save();
    }

    public static void BattleStartGame()
    {
      if (!PhotonNetwork.IsMasterClient)
        NotifiLib.SendNotification("<color=grey>[</color><color=red>ERROR</color><color=grey>]</color> <color=white>You are not master client.</color>");
      else
        GameObject.Find("Gorilla Battle Manager").GetComponent<GorillaPaintbrawlManager>().StartBattle();
    }

    public static void BattleEndGame()
    {
      if (!PhotonNetwork.IsMasterClient)
        NotifiLib.SendNotification("<color=grey>[</color><color=red>ERROR</color><color=grey>]</color> <color=white>You are not master client.</color>");
      else
        GameObject.Find("Gorilla Battle Manager").GetComponent<GorillaPaintbrawlManager>().BattleEnd();
    }

    public static void BattleRestartGame()
    {
      if (!PhotonNetwork.IsMasterClient)
      {
        NotifiLib.SendNotification("<color=grey>[</color><color=red>ERROR</color><color=grey>]</color> <color=white>You are not master client.</color>");
      }
      else
      {
        GorillaPaintbrawlManager component = GameObject.Find("Gorilla Battle Manager").GetComponent<GorillaPaintbrawlManager>();
        component.BattleEnd();
        component.StartBattle();
      }
    }

    public static void BattleBalloonSpamSelf()
    {
      if (!PhotonNetwork.IsMasterClient)
        NotifiLib.SendNotification("<color=grey>[</color><color=red>ERROR</color><color=grey>]</color> <color=white>You are not master client.</color>");
      else
        GameObject.Find("Gorilla Battle Manager").GetComponent<GorillaPaintbrawlManager>().playerLives[PhotonNetwork.LocalPlayer.ActorNumber] = Random.Range(0, 4);
    }

    public static void BattleBalloonSpam()
    {
      if (!PhotonNetwork.IsMasterClient)
      {
        NotifiLib.SendNotification("<color=grey>[</color><color=red>ERROR</color><color=grey>]</color> <color=white>You are not master client.</color>");
      }
      else
      {
        GorillaPaintbrawlManager component = GameObject.Find("Gorilla Battle Manager").GetComponent<GorillaPaintbrawlManager>();
        foreach (Player player in PhotonNetwork.PlayerList)
          component.playerLives[player.ActorNumber] = Random.Range(0, 4);
      }
    }

    public static void BattleKillSelf()
    {
      if (!PhotonNetwork.IsMasterClient)
        NotifiLib.SendNotification("<color=grey>[</color><color=red>ERROR</color><color=grey>]</color> <color=white>You are not master client.</color>");
      else
        GameObject.Find("Gorilla Battle Manager").GetComponent<GorillaPaintbrawlManager>().playerLives[PhotonNetwork.LocalPlayer.ActorNumber] = 0;
    }

    public static void BattleKillAll()
    {
      if (!PhotonNetwork.IsMasterClient)
      {
        NotifiLib.SendNotification("<color=grey>[</color><color=red>ERROR</color><color=grey>]</color> <color=white>You are not master client.</color>");
      }
      else
      {
        GorillaPaintbrawlManager component = GameObject.Find("Gorilla Battle Manager").GetComponent<GorillaPaintbrawlManager>();
        foreach (Player player in PhotonNetwork.PlayerList)
          component.playerLives[player.ActorNumber] = 0;
      }
    }

    public static void BattleReviveSelf()
    {
      if (!PhotonNetwork.IsMasterClient)
        NotifiLib.SendNotification("<color=grey>[</color><color=red>ERROR</color><color=grey>]</color> <color=white>You are not master client.</color>");
      else
        GameObject.Find("Gorilla Battle Manager").GetComponent<GorillaPaintbrawlManager>().playerLives[PhotonNetwork.LocalPlayer.ActorNumber] = 4;
    }

    public static void BattleReviveAll()
    {
      if (!PhotonNetwork.IsMasterClient)
      {
        NotifiLib.SendNotification("<color=grey>[</color><color=red>ERROR</color><color=grey>]</color> <color=white>You are not master client.</color>");
      }
      else
      {
        GorillaPaintbrawlManager component = GameObject.Find("Gorilla Battle Manager").GetComponent<GorillaPaintbrawlManager>();
        foreach (Player player in PhotonNetwork.PlayerList)
          component.playerLives[player.ActorNumber] = 4;
      }
    }

    public static void BattleGodMode()
    {
      if (!PhotonNetwork.IsMasterClient)
      {
        NotifiLib.SendNotification("<color=grey>[</color><color=red>ERROR</color><color=grey>]</color> <color=white>You are not master client.</color>");
      }
      else
      {
        GameObject.Find("Gorilla Battle Manager").GetComponent<GorillaPaintbrawlManager>().playerLives[PhotonNetwork.LocalPlayer.ActorNumber] = 4;
        GTPlayer.Instance.disableMovement = false;
      }
    }

    public static void TagAll()
    {
      VRRig rigFromPlayer = RigManager.GetRigFromPlayer(new List<Player>((IEnumerable<Player>) PhotonNetwork.PlayerList)[Random.RandomRange(0, 10)]);
      if (AdvantageMods.isFected(AdvantageMods.gorilla.offlineVRRig) && !AdvantageMods.isFected(rigFromPlayer))
      {
        ((Behaviour) AdvantageMods.gorilla.offlineVRRig).enabled = false;
        ((Component) AdvantageMods.gorilla.offlineVRRig).transform.position = Vector3.op_Subtraction(((Component) rigFromPlayer).transform.position, new Vector3(0.0f, 3f, 0.0f));
        AdvantageMods.gorilla.rightHandTransform.position = rigFromPlayer.headMesh.transform.position;
        ((Behaviour) AdvantageMods.gorilla.offlineVRRig).enabled = true;
      }
      else
        ((Behaviour) AdvantageMods.gorilla).enabled = true;
    }

    private static bool isFected(VRRig check)
    {
      return ((Object) ((Renderer) check.mainSkin).material).name.Contains("fected") || ((Object) ((Renderer) check.mainSkin).material).name.Contains("It");
    }

    public static void FlickTagV1()
    {
      if (!ControllerInputPoller.instance.rightGrab)
        return;
      GTPlayer.Instance.rightControllerTransform.position = Vector3.op_Addition(GTPlayer.Instance.rightControllerTransform.position, Vector3.op_Multiply(GTPlayer.Instance.rightControllerTransform.forward, 10f));
    }

    public static void TagAura()
    {
      if (!Global.IAmInfected || (double) Global.pollerInstance.rightControllerIndexFloat <= 0.10000000149011612)
        return;
      foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
      {
        if (Global.IsOtherPlayer(vrrig) && !Global.RigIsInfected((object) vrrig) && (double) Vector3.Distance(((Component) Variables.taggerInstance.offlineVRRig).transform.position, ((Component) vrrig).transform.position) < 5.0)
          GTPlayer.Instance.rightControllerTransform.position = ((Component) vrrig).transform.position;
      }
    }

    public static void TagGun()
    {
      if (GameMode.ActiveGameMode.GameType() != 1)
        return;
      RaycastHit raycastHit;
      if (((double) ControllerInputPoller.instance.rightControllerGripFloat > 0.10000000149011612 || UnityInput.Current.GetMouseButton(1)) && Physics.Raycast(GTPlayer.Instance.rightControllerTransform.position, Vector3.op_UnaryNegation(GTPlayer.Instance.rightControllerTransform.up), ref raycastHit))
      {
        if (Mouse.current.rightButton.isPressed)
          Physics.Raycast(GameObject.Find("Shoulder Camera").GetComponent<Camera>().ScreenPointToRay(Vector2.op_Implicit(((InputControl<Vector2>) ((Pointer) Mouse.current).position).ReadValue())), ref raycastHit, 100f);
        AdvantageMods.GunSphere = GameObject.CreatePrimitive((PrimitiveType) 0);
        AdvantageMods.GunSphere.transform.position = ((RaycastHit) ref raycastHit).point;
        AdvantageMods.GunSphere.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
        AdvantageMods.GunSphere.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
        AdvantageMods.GunSphere.GetComponent<Renderer>().material.color = Color.white;
        Object.Destroy((Object) AdvantageMods.GunSphere.GetComponent<BoxCollider>());
        Object.Destroy((Object) AdvantageMods.GunSphere.GetComponent<Rigidbody>());
        Object.Destroy((Object) AdvantageMods.GunSphere.GetComponent<Collider>());
        VRRig component = ((Component) ((RaycastHit) ref raycastHit).collider).GetComponent<VRRig>();
        if (Object.op_Inequality((Object) component, (Object) null))
        {
          if ((double) ControllerInputPoller.instance.rightControllerIndexFloat > 0.10000000149011612 || UnityInput.Current.GetMouseButton(0))
          {
            Object.Destroy((Object) AdvantageMods.GunSphere, Time.deltaTime);
            AdvantageMods.GunSphere.GetComponent<Renderer>().material.color = GorillaTagger.Instance.offlineVRRig.playerColor;
            ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = false;
            ((Component) GorillaTagger.Instance.offlineVRRig).transform.position = ((Component) component).transform.position;
            for (int index = 0; index < 4; ++index)
              GameMode.ReportTag(component.OwningNetPlayer);
          }
          else
            ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = true;
        }
        else
          ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = true;
      }
      if (Object.op_Inequality((Object) AdvantageMods.GunSphere, (Object) null))
        Object.Destroy((Object) AdvantageMods.GunSphere, Time.deltaTime);
    }

    public static void TagAllV2()
    {
      if (GameMode.ActiveGameMode.GameType() != 1)
        return;
      bool flag = false;
      Vector3 vector3 = Vector3.zero;
      VRRig vrRig = (VRRig) null;
      if ((double) ControllerInputPoller.instance.rightControllerIndexFloat > 0.10000000149011612 || UnityInput.Current.GetKey((KeyCode) 116))
      {
        foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
        {
          if (Object.op_Inequality((Object) vrrig, (Object) GorillaTagger.Instance.offlineVRRig) && !((Object) ((Renderer) vrrig.mainSkin).material).name.Contains("fected"))
          {
            flag = true;
            vrRig = vrrig;
            vector3 = ((Component) vrrig).transform.position;
            ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = false;
          }
        }
        if (flag)
        {
          ((Component) GorillaTagger.Instance.offlineVRRig).transform.position = vector3;
          if (Object.op_Inequality((Object) vrRig, (Object) null))
          {
            for (int index = 0; index < 4; ++index)
              GameMode.ReportTag(vrRig.OwningNetPlayer);
          }
        }
        else
          ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = true;
      }
      else
        ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = true;
    }

    private static void RandomizeHandPositionsAndRotations(VRRig target)
    {
      ((Component) GorillaTagger.Instance.offlineVRRig.head.rigTarget).transform.rotation = Quaternion.Euler((float) Random.Range(0, 360), (float) Random.Range(0, 360), (float) Random.Range(0, 360));
      Vector3 vector3;
      // ISSUE: explicit constructor call
      ((Vector3) ref vector3).\u002Ector(Random.Range(-1f, 1f), Random.Range(-1f, 1f), Random.Range(-1f, 1f));
      ((Component) GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget).transform.position = Vector3.op_Addition(((Component) target).transform.position, vector3);
      ((Component) GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget).transform.position = Vector3.op_Addition(((Component) target).transform.position, vector3);
      ((Component) GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget).transform.rotation = Quaternion.Euler((float) Random.Range(0, 360), (float) Random.Range(0, 360), (float) Random.Range(0, 360));
      ((Component) GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget).transform.rotation = Quaternion.Euler((float) Random.Range(0, 360), (float) Random.Range(0, 360), (float) Random.Range(0, 360));
    }

    public static void TagSelf()
    {
      if (Global.Tagged(GorillaTagger.Instance.offlineVRRig))
        return;
      foreach (Player playerListOther in PhotonNetwork.PlayerListOthers)
      {
        VRRig vrRigFromPlayer = Global.GetVRRigFromPlayer(playerListOther);
        if (Global.Tagged(vrRigFromPlayer))
        {
          ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = false;
          ((Component) GorillaTagger.Instance.offlineVRRig).transform.position = vrRigFromPlayer.rightHandTransform.position;
          ((Component) GorillaTagger.Instance.myVRRig).transform.position = vrRigFromPlayer.rightHandTransform.position;
          ((Component) GTPlayer.Instance.bodyCollider).transform.position = vrRigFromPlayer.rightHandTransform.position;
          HandOrbLib.DrawHandOrbs();
        }
      }
    }

    public static void TagSelfV2()
    {
      if (!Global.IAmInfected)
      {
        if ((double) ControllerInputPoller.instance.rightControllerIndexFloat > 0.20000000298023224 || UnityInput.Current.GetKey(116.ToString()))
        {
          foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
          {
            if (Global.RigIsInfected((object) vrrig))
            {
              ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = false;
              ((Component) GorillaTagger.Instance.offlineVRRig).transform.position = vrrig.rightHandTransform.position;
              break;
            }
          }
        }
        else
          ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = true;
      }
      else
        ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = true;
    }

    public static void NoTagOnJoin(bool setActive)
    {
      string str = setActive ? "nope" : "done";
      bool flag = !setActive;
      PlayerPrefs.SetString("tutorial", str);
      PlayerPrefs.SetString("didTutorial", str);
      Player localPlayer = PhotonNetwork.LocalPlayer;
      if (localPlayer == null)
        return;
      Hashtable hashtable = new Hashtable();
      ((Dictionary<object, object>) hashtable).Add((object) "didTutorial", (object) flag);
      localPlayer.SetCustomProperties(hashtable, (Hashtable) null, (WebFlags) null);
    }

    public static void UntagSelf()
    {
      if (PhotonNetwork.InRoom)
      {
        if (!Global.IAmInfected)
          return;
        Global.Reconnect();
        AdvantageMods.NoTagOnJoin(true);
      }
      else
        NotifiLib.SendNotification("<color=red>Photon Error</color> : Not In A Room.");
    }

    public static void TagAuraV2()
    {
      foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
      {
        if ((double) Vector3.Distance(((Component) GorillaTagger.Instance.offlineVRRig).transform.position, ((Component) vrrig).transform.position) <= 4.0 && !((Object) ((Renderer) vrrig.mainSkin).material).name.Contains("fected") && ((Object) ((Renderer) GorillaTagger.Instance.offlineVRRig.mainSkin).material).name.Contains("fected") && ControllerInputPoller.instance.rightGrab)
          GTPlayer.Instance.rightControllerTransform.position = ((Component) vrrig).transform.position;
      }
    }
  }
}
