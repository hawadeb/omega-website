﻿// Decompiled with JetBrains decompiler
// Type: FTSyxcalTemplate.Mods.WorldMods
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using BepInEx;
using FTSyxcalTemplate.Menu;
using FTSyxcalTemplate.Menu.Libs;
using GorillaLocomotion;
using GorillaLocomotion.Gameplay;
using GorillaLocomotion.Swimming;
using GorillaNetworking;
using Photon.Pun;
using StupidTemplate.Menu;
using System;
using UnityEngine;

#nullable disable
namespace FTSyxcalTemplate.Mods
{
  internal class WorldMods
  {
    private static float WaterDelay;

    public static void Initialize()
    {
      WorldMods.InitializeGravity();
      WorldMods.InitializeRopeSettings();
      WorldMods.InitializeArcadeMachines();
      WorldMods.InitializeEnvironment();
      WorldMods.InitializeOtherSystems();
      Debug.Log((object) "WorldMods Initialized");
    }

    private static void InitializeGravity()
    {
      if (!Global.lowgrav)
        Global.Grav(-9.81f);
      Debug.Log((object) "Gravity initialized.");
    }

    private static void InitializeRopeSettings()
    {
      Global.ropesdelayy = 0.0f;
      Global.shouldDoFastRopes = false;
      Debug.Log((object) "Rope settings initialized.");
    }

    private static void InitializeArcadeMachines()
    {
      foreach (GorillaPressableButton gorillaPressableButton in Object.FindObjectsOfType<ArcadeMachineButton>())
        gorillaPressableButton.isOn = false;
      Debug.Log((object) "Arcade machines initialized.");
    }

    private static void InitializeEnvironment()
    {
      WorldMods.EnableILavaYou();
      Debug.Log((object) "Environment initialized.");
    }

    private static void InitializeOtherSystems()
    {
      PhotonNetwork.ConnectUsingSettings();
      Debug.Log((object) "Photon Network initialized.");
    }

    public static void GliderSpaz()
    {
      GameObject gameObject = GameObject.Find("LeafGliderFunctional (8)/GliderHoldable");
      if ((double) ControllerInputPoller.instance.rightControllerIndexFloat <= 0.0)
        return;
      gameObject.transform.Rotate(new Vector3(Random.Range(-10f, 10f), Random.Range(-10f, 10f), Random.Range(-10f, 10f)));
    }

    public static void TpToGlider()
    {
      if (!ControllerInputPoller.instance.rightGrab)
        return;
      ((Component) GorillaTagger.Instance).transform.position = GameObject.Find("GliderHoldable").transform.position;
    }

    public static void GrabMonsters()
    {
      if (!ControllerInputPoller.instance.rightGrab)
        return;
      foreach (Component component in Object.FindObjectsOfType<MonkeyeAI>())
        component.transform.position = GorillaTagger.Instance.rightHandTransform.position;
    }

    private GTPlayer.MaterialData GetMaterial(string v) => throw new NotImplementedException();

    public static void EndAllArcade()
    {
      foreach (GorillaPressableButton gorillaPressableButton in Object.FindObjectsOfType<ArcadeMachineButton>())
        gorillaPressableButton.isOn = false;
    }

    public static void TurnOnAllArcade()
    {
      foreach (GorillaPressableButton gorillaPressableButton in Object.FindObjectsOfType<ArcadeMachineButton>())
        gorillaPressableButton.isOn = false;
    }

    public static void JUMPSCARE()
    {
      if ((double) ControllerInputPoller.instance.rightControllerIndexFloat > 0.5)
      {
        ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = false;
        foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
        {
          if (!vrrig.isMyPlayer && (double) Vector3.Distance(((Component) GorillaTagger.Instance.offlineVRRig).transform.position, ((Component) vrrig).transform.position) < 6.0)
          {
            ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = false;
            Vector3 vector3_1 = Vector3.op_Subtraction(((Component) vrrig).transform.position, ((Component) GorillaTagger.Instance.offlineVRRig).transform.position);
            ((Vector3) ref vector3_1).Normalize();
            Vector3 vector3_2 = Vector3.op_Addition(((Component) GorillaTagger.Instance.offlineVRRig).transform.position, Vector3.op_Multiply(vector3_1, 10f * Time.deltaTime));
            ((Component) GorillaTagger.Instance.offlineVRRig).transform.position = vector3_2;
            ((Component) GorillaTagger.Instance.myVRRig).transform.position = vector3_2;
            ((Component) GorillaTagger.Instance.offlineVRRig).transform.LookAt(((Component) vrrig).transform.position);
            ((Component) GorillaTagger.Instance.myVRRig).transform.LookAt(((Component) vrrig).transform.position);
            ((Component) GorillaTagger.Instance.offlineVRRig.head.rigTarget).transform.rotation = ((Component) GorillaTagger.Instance.offlineVRRig).transform.rotation;
            ((Component) GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget).transform.position = Vector3.op_Addition(((Component) GorillaTagger.Instance.offlineVRRig).transform.position, Vector3.op_Multiply(((Component) GorillaTagger.Instance.offlineVRRig).transform.forward, 1f));
            ((Component) GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget).transform.position = Vector3.op_Addition(((Component) GorillaTagger.Instance.offlineVRRig).transform.position, Vector3.op_Multiply(((Component) GorillaTagger.Instance.offlineVRRig).transform.forward, 1f));
          }
        }
      }
      else
        ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = true;
    }

    public static void JumpScareGun()
    {
      GunLib.Gun2((Action) (() =>
      {
        if ((double) ControllerInputPoller.instance.rightControllerIndexFloat > 0.5)
        {
          ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = false;
          foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
          {
            if (!vrrig.isMyPlayer && (double) Vector3.Distance(((Component) GorillaTagger.Instance.offlineVRRig).transform.position, ((Component) vrrig).transform.position) < 6.0)
            {
              ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = false;
              Vector3 vector3_1 = Vector3.op_Subtraction(((Component) vrrig).transform.position, ((Component) GorillaTagger.Instance.offlineVRRig).transform.position);
              ((Vector3) ref vector3_1).Normalize();
              Vector3 vector3_2 = Vector3.op_Addition(((Component) GorillaTagger.Instance.offlineVRRig).transform.position, Vector3.op_Multiply(vector3_1, 10f * Time.deltaTime));
              ((Component) GorillaTagger.Instance.offlineVRRig).transform.position = vector3_2;
              ((Component) GorillaTagger.Instance.myVRRig).transform.position = vector3_2;
              ((Component) GorillaTagger.Instance.offlineVRRig).transform.LookAt(((Component) vrrig).transform.position);
              ((Component) GorillaTagger.Instance.myVRRig).transform.LookAt(((Component) vrrig).transform.position);
              ((Component) GorillaTagger.Instance.offlineVRRig.head.rigTarget).transform.rotation = ((Component) GorillaTagger.Instance.offlineVRRig).transform.rotation;
              ((Component) GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget).transform.position = Vector3.op_Addition(((Component) GorillaTagger.Instance.offlineVRRig).transform.position, Vector3.op_Multiply(((Component) GorillaTagger.Instance.offlineVRRig).transform.forward, 1f));
              ((Component) GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget).transform.position = Vector3.op_Addition(((Component) GorillaTagger.Instance.offlineVRRig).transform.position, Vector3.op_Multiply(((Component) GorillaTagger.Instance.offlineVRRig).transform.forward, 1f));
            }
          }
        }
        else
          ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = true;
      }));
    }

    public static void SolidWater()
    {
      foreach (Component component in Object.FindObjectsOfType<WaterVolume>())
        component.gameObject.layer = LayerMask.NameToLayer("Default");
    }

    public static void WaterSpamHands()
    {
      if ((double) Time.time <= (double) WorldMods.WaterDelay)
        return;
      WorldMods.WaterDelay = Time.time + 0.1f;
      if ((double) ControllerInputPoller.instance.leftControllerGripFloat > 0.10000000149011612 || UnityInput.Current.GetMouseButton(0))
        GorillaTagger.Instance.myVRRig.SendRPC("RPC_PlaySplashEffect", (RpcTarget) 0, new object[6]
        {
          (object) GorillaTagger.Instance.offlineVRRig.leftHandTransform.position,
          (object) GorillaTagger.Instance.offlineVRRig.leftHandTransform.rotation,
          (object) 4f,
          (object) 100f,
          (object) true,
          (object) false
        });
      if ((double) ControllerInputPoller.instance.rightControllerGripFloat > 0.10000000149011612 || UnityInput.Current.GetMouseButton(1))
        GorillaTagger.Instance.myVRRig.SendRPC("RPC_PlaySplashEffect", (RpcTarget) 0, new object[6]
        {
          (object) GorillaTagger.Instance.offlineVRRig.rightHandTransform.position,
          (object) GorillaTagger.Instance.offlineVRRig.rightHandTransform.rotation,
          (object) 4f,
          (object) 100f,
          (object) true,
          (object) false
        });
      WorldMods.Flush();
    }

    public static void Flush()
    {
      PhotonNetwork.RemoveRPCs(PhotonNetwork.LocalPlayer);
      PhotonNetwork.RemoveBufferedRPCs(0, (string) null, (int[]) null);
      GorillaGameManager.instance.OnPlayerLeftRoom(NetPlayer.op_Implicit(PhotonNetwork.LocalPlayer));
      GorillaGameManager.instance.OnMasterClientSwitched(PhotonNetwork.LocalPlayer);
      if (Object.op_Inequality((Object) GorillaTagger.Instance.myVRRig, (Object) null))
        PhotonNetwork.OpCleanRpcBuffer(GorillaTagger.Instance.myVRRig.GetView);
      GorillaNot.instance.rpcErrorMax = int.MaxValue;
      GorillaNot.instance.rpcCallLimit = int.MaxValue;
      GorillaNot.instance.logErrorMax = int.MaxValue;
      PhotonNetwork.RemoveRPCsInGroup(int.MaxValue);
      GorillaNot.instance.OnPlayerLeftRoom(NetPlayer.op_Implicit(PhotonNetwork.LocalPlayer));
      PhotonNetwork.SendAllOutgoingCommands();
    }

    public static void WaterSpamBody()
    {
      if ((double) Time.time <= (double) WorldMods.WaterDelay)
        return;
      WorldMods.WaterDelay = Time.time + 0.1f;
      if ((double) ControllerInputPoller.instance.rightControllerIndexFloat > 0.10000000149011612 || UnityInput.Current.GetKey((KeyCode) 116))
      {
        GorillaTagger.Instance.myVRRig.SendRPC("RPC_PlaySplashEffect", (RpcTarget) 0, new object[6]
        {
          (object) GorillaTagger.Instance.offlineVRRig.bodyTransform.position,
          (object) GorillaTagger.Instance.offlineVRRig.bodyTransform.rotation,
          (object) 4f,
          (object) 100f,
          (object) true,
          (object) false
        });
        WorldMods.Flush();
      }
    }

    public static void WaterSpamHead()
    {
      if ((double) Time.time <= (double) WorldMods.WaterDelay)
        return;
      WorldMods.WaterDelay = Time.time + 0.1f;
      if ((double) ControllerInputPoller.instance.rightControllerIndexFloat > 0.10000000149011612 || UnityInput.Current.GetKey((KeyCode) 116))
      {
        GorillaTagger.Instance.myVRRig.SendRPC("RPC_PlaySplashEffect", (RpcTarget) 0, new object[6]
        {
          (object) GorillaTagger.Instance.offlineVRRig.headConstraint.position,
          (object) GorillaTagger.Instance.offlineVRRig.headConstraint.rotation,
          (object) 4f,
          (object) 100f,
          (object) true,
          (object) false
        });
        WorldMods.Flush();
      }
    }

    public static void RideBat()
    {
      if (!ControllerInputPoller.instance.rightGrab)
        return;
      ((Component) GorillaTagger.Instance.rigidbody).transform.position = GameObject.Find("Cave Bat Holdable").transform.position;
      GorillaTagger.Instance.rigidbody.velocity = Vector3.zero;
    }

    public static void RideBug()
    {
      if (!ControllerInputPoller.instance.rightGrab)
        return;
      ((Component) GorillaTagger.Instance.rigidbody).transform.position = GameObject.Find("Floating Bug Holdable").transform.position;
      GorillaTagger.Instance.rigidbody.velocity = Vector3.zero;
    }

    public static void TpToStump()
    {
      if (!ControllerInputPoller.instance.rightGrab)
        return;
      ((Component) GorillaTagger.Instance.offlineVRRig).transform.position = new Vector3(0.0f, 0.0f, 0.0f);
    }

    public static void HighGravity()
    {
      ((Collider) GTPlayer.Instance.bodyCollider).attachedRigidbody.AddForce(Vector3.op_Multiply(Vector3.down, Time.deltaTime * (7.77f / Time.deltaTime)), (ForceMode) 5);
    }

    public static void LowGravity()
    {
      Global.lowgrav = true;
      if (!Global.lowgrav)
        return;
      Global.Grav(-4f);
    }

    public static void Gravity()
    {
      if (!Global.nograv)
        return;
      Global.Grav(-9.81f);
      Global.nograv = false;
    }

    public static void JoinRandomGhostCode()
    {
      string[] strArray = new string[25]
      {
        "SREN16",
        "SREN17",
        "SREN18",
        "DASIY09",
        "PBBV",
        "J3VU",
        "ECHO",
        "MIRRORMAN",
        "SPIDER",
        "ENDISNEAR",
        "ENDISHERE",
        "STATUE",
        "BANSHEE",
        "NULL",
        "NAMO",
        "NAME",
        "H3PLM3",
        "H3LP",
        "DAISYDAISY",
        "DAISYMONKE",
        "BANJO",
        "STALKER",
        "WATCHER",
        "NONAME",
        "RUN"
      };
      PhotonNetworkController.Instance.AttemptToJoinSpecificRoom(strArray[Random.Range(0, strArray.Length)], (JoinType) 0);
      Global.DisableButton("Join Ghost Codes");
    }

    public static void EnableILavaYou()
    {
      GameObject.Find("Environment Objects/LocalObjects_Prefab/Forest/ILavaYou_ForestArt_Prefab/").SetActive(true);
      GameObject.Find("Environment Objects/LocalObjects_Prefab/Forest/ILavaYou_PrefabV/").SetActive(true);
    }

    public static void DisableILavaYou()
    {
      GameObject.Find("Environment Objects/LocalObjects_Prefab/Forest/ILavaYou_ForestArt_Prefab/").SetActive(false);
      GameObject.Find("Environment Objects/LocalObjects_Prefab/Forest/ILavaYou_PrefabV/").SetActive(false);
    }

    public static void RopeLaunch(Vector3 velocity)
    {
      if (!ControllerInputPoller.instance.rightGrab || (double) Time.time <= (double) Global.ropesdelayy)
        return;
      Global.ropesdelayy = Time.time + 0.25f;
      foreach (GorillaRopeSwing gorillaRopeSwing in Object.FindObjectsOfType(typeof (GorillaRopeSwing)))
        ((NetworkSceneObject) RopeSwingManager.instance).photonView.RPC("SetVelocity", (RpcTarget) 0, new object[5]
        {
          (object) gorillaRopeSwing.ropeId,
          (object) 1,
          (object) velocity,
          (object) true,
          null
        });
    }

    public static void RopesFast()
    {
      if ((double) Time.time <= (double) Global.ropesdelayy)
        return;
      Global.ropesdelayy = Time.time + 0.15f;
      Global.shouldDoFastRopes = !Global.shouldDoFastRopes;
      foreach (GorillaRopeSwingSettings ropeSwingSettings in Object.FindObjectsOfType(typeof (GorillaRopeSwingSettings)))
      {
        if (((Object) ropeSwingSettings).name.Contains("Default"))
          ropeSwingSettings.inheritVelocityMultiplier = !Global.shouldDoFastRopes ? 0.9f : 4f;
      }
    }

    public static void RopeFling()
    {
      if (!InputLib.RG())
        return;
      WorldMods.RopeLaunch(new Vector3(-10f, -999f, 0.0f));
    }

    public static void RopesDown()
    {
      if (!InputLib.RG())
        return;
      WorldMods.RopeLaunch(new Vector3(0.0f, -100f, 0.0f));
    }

    public static void RopessUp()
    {
      if (!InputLib.RG())
        return;
      WorldMods.RopeLaunch(new Vector3(0.0f, 100f, 0.0f));
    }
  }
}
