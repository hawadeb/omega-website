﻿// Decompiled with JetBrains decompiler
// Type: FTSyxcalTemplate.Mods.NetworkMods
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using FTSyxcalTemplate.Menu;
using GorillaNetworking;
using Photon.Pun;
using UnityEngine;

#nullable disable
namespace FTSyxcalTemplate.Mods
{
  internal class NetworkMods
  {
    public static void DisableNetworkTriggers()
    {
      GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab").SetActive(false);
    }

    public static void EnableNetworkTriggers()
    {
      GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab").SetActive(true);
    }

    public static void DisableMapTriggers()
    {
      GameObject.Find("Environment Objects/TriggerZones_Prefab/ZoneTransitions_Prefab").SetActive(false);
    }

    public static void EnableMapTriggers()
    {
      GameObject.Find("Environment Objects/TriggerZones_Prefab/ZoneTransitions_Prefab").SetActive(true);
    }

    public static void EUServers() => PhotonNetwork.ConnectToRegion("eu");

    public static void USServers() => PhotonNetwork.ConnectToRegion("us");

    public static void USWServers() => PhotonNetwork.ConnectToRegion("usw");

    public static void UnlockCompetitiveQueue()
    {
      GorillaComputer.instance.CompQueueUnlockButtonPress();
    }

    public static void AntiAFK() => PhotonNetworkController.Instance.disableAFKKick = true;

    public static void KickAllGroup()
    {
      PhotonNetworkController.Instance.AttemptToJoinSpecificRoom("FUCKEDBYIRIS", (JoinType) 1);
      Global.Reconnect();
    }

    public static void KickAllParty()
    {
      PhotonNetworkController.Instance.AttemptToJoinSpecificRoom("FUCKEDBYIRIS", (JoinType) 2);
      Global.Reconnect();
    }
  }
}
