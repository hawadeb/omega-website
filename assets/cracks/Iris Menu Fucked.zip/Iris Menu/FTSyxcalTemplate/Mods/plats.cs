﻿// Decompiled with JetBrains decompiler
// Type: FTSyxcalTemplate.Mods.plats
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using GorillaLocomotion;
using UnityEngine;

#nullable disable
namespace FTSyxcalTemplate.Mods
{
  internal class plats
  {
    public static GameObject leftPlatform;
    public static bool leftPlatformEnabled = false;
    public static GameObject rightPlatform;
    public static bool rightPlatformEnabled = false;
    public bool platformLeft;
    public bool platformRight;
    private static Color startColor = Color.red;
    private static Color midColor = Color.green;
    private static Color finalColor = Color.blue;
    private static float transitionDuration = 3f;
    private static float elapsedTime = 0.0f;

    public static void Platforms()
    {
      if (ControllerInputPoller.instance.leftGrab)
      {
        if (!plats.leftPlatformEnabled)
        {
          plats.leftPlatform = GameObject.CreatePrimitive((PrimitiveType) 3);
          plats.leftPlatform.GetComponent<Renderer>().material.color = Color.black;
          plats.leftPlatform.GetComponent<Renderer>().material = new Material(Shader.Find("Sprites/Default"));
          plats.leftPlatform.transform.localScale = new Vector3(0.2f, 0.01f, 0.3f);
          plats.leftPlatform.transform.position = Vector3.op_Addition(GTPlayer.Instance.leftControllerTransform.position, new Vector3(0.0f, -0.02f, 0.0f));
          plats.leftPlatform.transform.rotation = Quaternion.op_Multiply(GTPlayer.Instance.leftControllerTransform.rotation, Quaternion.Euler(0.0f, 0.0f, -90f));
          plats.leftPlatformEnabled = true;
        }
        if ((double) plats.elapsedTime < (double) plats.transitionDuration)
        {
          plats.leftPlatform.GetComponent<Renderer>().material.color = Color.black;
          plats.elapsedTime += Time.deltaTime;
          if ((double) plats.elapsedTime >= (double) plats.transitionDuration)
            plats.elapsedTime = 0.0f;
        }
      }
      else if (plats.leftPlatformEnabled)
      {
        Object.Destroy((Object) plats.leftPlatform);
        plats.leftPlatformEnabled = false;
        return;
      }
      if (ControllerInputPoller.instance.rightGrab)
      {
        if (!plats.rightPlatformEnabled)
        {
          plats.rightPlatform = GameObject.CreatePrimitive((PrimitiveType) 3);
          plats.rightPlatform.GetComponent<Renderer>().material.color = Color.black;
          plats.rightPlatform.GetComponent<Renderer>().material = new Material(Shader.Find("Sprites/Default"));
          plats.rightPlatform.transform.localScale = new Vector3(0.2f, 0.01f, 0.3f);
          plats.rightPlatform.transform.position = Vector3.op_Addition(GTPlayer.Instance.rightControllerTransform.position, new Vector3(0.0f, -0.02f, 0.0f));
          plats.rightPlatform.transform.rotation = Quaternion.op_Multiply(GTPlayer.Instance.rightControllerTransform.rotation, Quaternion.Euler(0.0f, 0.0f, -90f));
          plats.rightPlatformEnabled = true;
        }
        if ((double) plats.elapsedTime < (double) plats.transitionDuration)
        {
          plats.rightPlatform.GetComponent<Renderer>().material.color = Color.black;
          plats.elapsedTime += Time.deltaTime;
          if ((double) plats.elapsedTime >= (double) plats.transitionDuration)
            plats.elapsedTime = 0.0f;
        }
      }
      else if (plats.rightPlatformEnabled)
      {
        Object.Destroy((Object) plats.rightPlatform);
        plats.rightPlatformEnabled = false;
        return;
      }
      if (!ControllerInputPoller.instance.leftGrab)
        Object.Destroy((Object) plats.leftPlatform);
      if (ControllerInputPoller.instance.rightGrab)
        return;
      Object.Destroy((Object) plats.rightPlatform);
    }
  }
}
