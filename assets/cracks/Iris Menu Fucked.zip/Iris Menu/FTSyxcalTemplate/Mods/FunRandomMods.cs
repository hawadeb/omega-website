﻿// Decompiled with JetBrains decompiler
// Type: FTSyxcalTemplate.Mods.FunRandomMods
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using FTSyxcalTemplate.Menu;
using FTSyxcalTemplate.Menu.Libs;
using GorillaLocomotion;
using GorillaNetworking;
using GorillaTagScripts;
using Photon.Pun;
using Photon.Realtime;
using Photon.Voice.Unity;
using Photon.Voice.Unity.UtilityScripts;
using POpusCodec.Enums;
using StupidTemplate.Notifications;
using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using UnityEngine;

#nullable disable
namespace FTSyxcalTemplate.Mods
{
  internal class FunRandomMods
  {
    private static LightmapData[] hell;
    private static float muteDelay;

    public static void NightTime() => BetterDayNightManager.instance.SetTimeOfDay(0);

    public static void EveningTime() => BetterDayNightManager.instance.SetTimeOfDay(7);

    public static void MorningTime() => BetterDayNightManager.instance.SetTimeOfDay(1);

    public static void DayTime() => BetterDayNightManager.instance.SetTimeOfDay(3);

    public static void Rain()
    {
      for (int index = 1; index < BetterDayNightManager.instance.weatherCycle.Length; ++index)
        BetterDayNightManager.instance.weatherCycle[index] = (BetterDayNightManager.WeatherType) 1;
    }

    public static void NoRain()
    {
      for (int index = 1; index < BetterDayNightManager.instance.weatherCycle.Length; ++index)
        BetterDayNightManager.instance.weatherCycle[index] = (BetterDayNightManager.WeatherType) 0;
    }

    public static void GreenSky()
    {
      Renderer component = GameObject.Find("Environment Objects/LocalObjects_Prefab/Standard Sky").GetComponent<Renderer>();
      component.material.shader = Shader.Find("GorillaTag/UberShader");
      component.material.color = Color.green;
    }

    public static void RedSky()
    {
      Renderer component = GameObject.Find("Environment Objects/LocalObjects_Prefab/Standard Sky").GetComponent<Renderer>();
      component.material.shader = Shader.Find("GorillaTag/UberShader");
      component.material.color = Color.red;
    }

    public static void BlueSky()
    {
      Renderer component = GameObject.Find("Environment Objects/LocalObjects_Prefab/Standard Sky").GetComponent<Renderer>();
      component.material.shader = Shader.Find("GorillaTag/UberShader");
      component.material.color = Color.blue;
    }

    public static void YellowSky()
    {
      Renderer component = GameObject.Find("Environment Objects/LocalObjects_Prefab/Standard Sky").GetComponent<Renderer>();
      component.material.shader = Shader.Find("GorillaTag/UberShader");
      component.material.color = Color.yellow;
    }

    public static void antimoderator()
    {
      foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
      {
        if (!vrrig.isOfflineVRRig && vrrig.concatStringOfCosmeticsAllowed.Contains("LBAAK"))
        {
          PhotonNetwork.Disconnect();
          NotifiLib.SendNotification("<color=red>[ANTI-MODERATOR]</color> Someone with a STICK joined, disconnected.");
        }
      }
    }

    public static void Fullbright()
    {
      FunRandomMods.hell = LightmapSettings.lightmaps;
      LightmapSettings.lightmaps = (LightmapData[]) null;
    }

    public static void Fullshade() => LightmapSettings.lightmaps = FunRandomMods.hell;

    public static void FixHead()
    {
      GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.x = 0.0f;
      GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.y = 0.0f;
      GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.z = 0.0f;
    }

    public static void UpsideDownHead()
    {
      GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.z = 180f;
    }

    public static void BrokenNeck()
    {
      GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.z = 90f;
    }

    public static void BackwardsHead()
    {
      GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.y = 180f;
    }

    public static void SpinHeadX()
    {
      if (((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled)
      {
        GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.x += 10f;
      }
      else
      {
        Transform transform = ((Component) GorillaTagger.Instance.offlineVRRig.head.rigTarget).transform;
        Quaternion rotation = ((Component) GorillaTagger.Instance.offlineVRRig.head.rigTarget).transform.rotation;
        Quaternion quaternion = Quaternion.Euler(Vector3.op_Addition(((Quaternion) ref rotation).eulerAngles, new Vector3(10f, 0.0f, 0.0f)));
        transform.rotation = quaternion;
      }
    }

    public static void SpinHeadY()
    {
      if (((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled)
      {
        GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.y += 10f;
      }
      else
      {
        Transform transform = ((Component) GorillaTagger.Instance.offlineVRRig.head.rigTarget).transform;
        Quaternion rotation = ((Component) GorillaTagger.Instance.offlineVRRig.head.rigTarget).transform.rotation;
        Quaternion quaternion = Quaternion.Euler(Vector3.op_Addition(((Quaternion) ref rotation).eulerAngles, new Vector3(0.0f, 10f, 0.0f)));
        transform.rotation = quaternion;
      }
    }

    public static void SpinHeadZ()
    {
      if (((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled)
      {
        GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.z += 10f;
      }
      else
      {
        Transform transform = ((Component) GorillaTagger.Instance.offlineVRRig.head.rigTarget).transform;
        Quaternion rotation = ((Component) GorillaTagger.Instance.offlineVRRig.head.rigTarget).transform.rotation;
        Quaternion quaternion = Quaternion.Euler(Vector3.op_Addition(((Quaternion) ref rotation).eulerAngles, new Vector3(0.0f, 0.0f, 10f)));
        transform.rotation = quaternion;
      }
    }

    public static void FlipHands()
    {
      Vector3 position1 = GorillaTagger.Instance.leftHandTransform.position;
      Vector3 position2 = GorillaTagger.Instance.rightHandTransform.position;
      Quaternion rotation1 = GorillaTagger.Instance.leftHandTransform.rotation;
      Quaternion rotation2 = GorillaTagger.Instance.rightHandTransform.rotation;
      ((Component) GTPlayer.Instance.rightControllerTransform).transform.position = position1;
      ((Component) GTPlayer.Instance.leftControllerTransform).transform.position = position2;
      ((Component) GTPlayer.Instance.rightControllerTransform).transform.rotation = rotation1;
      ((Component) GTPlayer.Instance.leftControllerTransform).transform.rotation = rotation2;
    }

    public static void EnableInstantHandTaps() => GorillaTagger.Instance.tapCoolDown = 0.0f;

    public static void DisableInstantHandTaps() => GorillaTagger.Instance.tapCoolDown = 0.33f;

    public static void LeaveParty() => FriendshipGroupDetection.Instance.LeaveParty();

    public static void MuteAll()
    {
      foreach (GorillaPlayerScoreboardLine allScoreboardLine in GorillaScoreboardTotalUpdater.allScoreboardLines)
      {
        if (!allScoreboardLine.muteButton.isAutoOn)
          allScoreboardLine.PressButton(true, (GorillaPlayerLineButton.ButtonType) 3);
      }
    }

    public static void UnmuteAll()
    {
      foreach (GorillaPlayerScoreboardLine allScoreboardLine in GorillaScoreboardTotalUpdater.allScoreboardLines)
      {
        if (allScoreboardLine.muteButton.isAutoOn)
          allScoreboardLine.PressButton(false, (GorillaPlayerLineButton.ButtonType) 3);
      }
    }

    public static void MicrophoneFeedback()
    {
      if (GorillaTagger.Instance.myRecorder.DebugEchoMode)
        return;
      GorillaTagger.Instance.myRecorder.DebugEchoMode = true;
    }

    public static void DisableMicrophoneFeedback()
    {
      if (!GorillaTagger.Instance.myRecorder.DebugEchoMode)
        return;
      GorillaTagger.Instance.myRecorder.DebugEchoMode = false;
    }

    public static void LowQualityMicrophone()
    {
      Recorder myRecorder = GorillaTagger.Instance.myRecorder;
      myRecorder.SamplingRate = (SamplingRate) 8000;
      myRecorder.Bitrate = 5;
      myRecorder.RestartRecording(true);
    }

    public static void HighQualityMicrophone()
    {
      Recorder myRecorder = GorillaTagger.Instance.myRecorder;
      myRecorder.SamplingRate = (SamplingRate) 16000;
      myRecorder.Bitrate = 20000;
      myRecorder.RestartRecording(true);
    }

    public static void LoudMicrophone()
    {
      Recorder myRecorder = GorillaTagger.Instance.myRecorder;
      if (!Object.op_Implicit((Object) ((Component) myRecorder).gameObject.GetComponent<MicAmplifier>()))
        ((Component) myRecorder).gameObject.AddComponent<MicAmplifier>();
      MicAmplifier component = ((Component) myRecorder).gameObject.GetComponent<MicAmplifier>();
      component.AmplificationFactor = 16f;
      component.BoostValue = 16f;
      myRecorder.RestartRecording(true);
    }

    public static void SpawnBugBabies()
    {
      GameObject.Find("Environment Objects/05Maze_PersistentObjects/BugBabies").SetActive(true);
    }

    public static void makeeveryonergb()
    {
      float num = (float) ((double) Time.frameCount / 180.0 % 1.0);
      foreach (VRRig vrRig in (VRRig[]) Object.FindObjectsOfType(typeof (VRRig)))
        ((Renderer) vrRig.mainSkin).material.color = Color.HSVToRGB(num, 1f, 1f);
    }

    public static void GrabBat()
    {
      if (ControllerInputPoller.instance.rightGrab)
        GameObject.Find("Cave Bat Holdable").transform.position = GorillaTagger.Instance.rightHandTransform.position;
      if (!ControllerInputPoller.instance.leftGrab)
        return;
      GameObject.Find("Cave Bat Holdable").transform.position = GorillaTagger.Instance.leftHandTransform.position;
    }

    public static void GrabBug()
    {
      if (ControllerInputPoller.instance.rightGrab)
        GameObject.Find("Floating Bug Holdable").transform.position = GorillaTagger.Instance.rightHandTransform.position;
      if (!ControllerInputPoller.instance.leftGrab)
        return;
      GameObject.Find("Floating Bug Holdable").transform.position = GorillaTagger.Instance.leftHandTransform.position;
    }

    public static void NameSmiley()
    {
      GorillaComputer.instance.currentName = ":)";
      PhotonNetwork.LocalPlayer.NickName = ":)";
      GorillaComputer.instance.savedName = ":)";
      PlayerPrefs.SetString("playerName", ":)");
      PlayerPrefs.Save();
    }

    public static void NameVortex()
    {
      GorillaComputer.instance.currentName = "<color=yellow>VORTEX ON TOP</color>";
      PhotonNetwork.LocalPlayer.NickName = "\"<color=yellow>VORTEX ON TOP</color>\"";
      GorillaComputer.instance.savedName = "\"<color=yellow>VORTEX ON TOP</color>\"";
      PlayerPrefs.SetString("playerName", "\"<color=yellow>VORTEX ON TOP</color>\"");
      PlayerPrefs.Save();
    }

    public static void NameIris()
    {
      GorillaComputer.instance.currentName = "<color=magenta>IR!S ON TOP</color>";
      PhotonNetwork.LocalPlayer.NickName = "\"<color=magenta>IR!S ON TOP</color>\"";
      GorillaComputer.instance.savedName = "\"<color=magenta>IR!S ON TOP</color>\"";
      PlayerPrefs.SetString("playerName", "\"<color=magenta>IR!S ON TOP</color>\"");
      PlayerPrefs.Save();
    }

    public static void NameCelestialgg()
    {
      GorillaComputer.instance.currentName = "<color=blue>Celestial.GG ON TOP</color>\"";
      PhotonNetwork.LocalPlayer.NickName = "\"<color=blue>Celestial.GG ON TOP</color>\"";
      GorillaComputer.instance.savedName = "\"<color=blue>Celestial.GG ON TOP</color>\"";
      PlayerPrefs.SetString("playerName", "\"<color=blue>Celestial.GG ON TOP</color>\"");
      PlayerPrefs.Save();
    }

    public static void NoName()
    {
      GorillaComputer.instance.currentName = "_";
      PhotonNetwork.LocalPlayer.NickName = "_";
      GorillaComputer.instance.savedName = "_";
      PlayerPrefs.SetString("playerName", "_");
      PlayerPrefs.Save();
    }

    public static void BanYourself()
    {
      PhotonNetwork.Disconnect();
      PhotonNetwork.JoinRoom("KKK", (string[]) null);
    }

    public static void CaseohMonke()
    {
      VRRig offlineVrRig = GorillaTagger.Instance.offlineVRRig;
      Color playerColor = offlineVrRig.playerColor;
      GameObject primitive = GameObject.CreatePrimitive((PrimitiveType) 0);
      primitive.transform.position = Vector3.op_Addition(Vector3.op_Addition(((Component) offlineVrRig).transform.position, Vector3.op_Multiply(((Component) offlineVrRig).transform.forward, 0.2f)), Vector3.op_Multiply(Vector3.down, 0.3f));
      primitive.transform.localScale = new Vector3(0.5f, 0.5f, 0.5f);
      primitive.transform.LookAt(((Component) ((Component) offlineVrRig).transform).transform);
      primitive.GetComponent<Renderer>().material = ((Renderer) GorillaTagger.Instance.offlineVRRig.mainSkin).material;
      primitive.GetComponent<Renderer>().material.color = ((Renderer) GorillaTagger.Instance.offlineVRRig.mainSkin).material.color;
      Object.Destroy((Object) primitive, Time.deltaTime);
      Object.Destroy((Object) primitive.GetComponent<Collider>());
    }

    public static void GrabRocket()
    {
      if (!ControllerInputPoller.instance.rightGrab)
        return;
      GameObject.Find("RocketShip_Prefab").transform.localScale = new Vector3(0.05f, 0.05f, 0.05f);
      GameObject.Find("RocketShip_Prefab").transform.position = new Vector3(0.0f, -0.0075f, 0.0f);
      GameObject.Find("RocketShip_Prefab").transform.position = GTPlayer.Instance.rightControllerTransform.position;
    }

    public static void MakeAllStrobe()
    {
      float time = Time.time;
      float num1 = (float) ((double) Mathf.Sin(time * 2f) * 0.5 + 0.5);
      float num2 = (float) ((double) Mathf.Sin(time * 10f) * 0.5 + 0.5);
      float num3 = (float) ((double) Mathf.Sin(time * 10f) * 0.5 + 0.5);
      foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
        ((Renderer) vrrig.mainSkin).material.color = new Color(num1, num2, num3);
    }

    public static void Antireportdisconnect()
    {
      GorillaPlayerScoreboardLine playerScoreboardLine = GorillaScoreboardTotalUpdater.allScoreboardLines.Find((Predicate<GorillaPlayerScoreboardLine>) (L => L.playerVRRig.isLocal));
      foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
      {
        float num1 = 0.51f;
        Vector3 position = ((Component) playerScoreboardLine.reportButton).gameObject.transform.position;
        float num2 = Vector3.Distance(vrrig.rightHandTransform.position, position);
        float num3 = Vector3.Distance(vrrig.leftHandTransform.position, position);
        if (((double) num2 <= (double) num1 || (double) num3 <= (double) num1) && !vrrig.isLocal)
        {
          PhotonNetwork.Disconnect();
          FunRandomMods.SendNotification("<color=grey>[</color><color=purple>ANTI-REPORT</color><color=grey>]</color> <color=white>Someone attempted to report you, you have been disconnected.</color>");
        }
      }
    }

    private static void SendNotification(string v) => throw new NotImplementedException();

    public static void BigBug()
    {
      GameObject.Find("Floating Bug Holdable").transform.localScale = new Vector3(5f, 5f, 5f);
    }

    public static void BigBat()
    {
      GameObject.Find("Cave Bat Holdable").transform.localScale = new Vector3(5f, 5f, 5f);
    }

    public static void GrabPlayerInfo()
    {
      string str1 = "Room: " + PhotonNetwork.CurrentRoom.Name;
      foreach (Player player in PhotonNetwork.PlayerList)
      {
        float num1 = 0.0f;
        float num2 = 0.0f;
        float num3 = 0.0f;
        string str2 = "";
        try
        {
          VRRig vrRigFromPlayer = Global.GetVRRigFromPlayer(player);
          num1 = vrRigFromPlayer.playerColor.r * (float) byte.MaxValue;
          num2 = vrRigFromPlayer.playerColor.g * (float) byte.MaxValue;
          num3 = vrRigFromPlayer.playerColor.b * (float) byte.MaxValue;
          str2 = vrRigFromPlayer.concatStringOfCosmeticsAllowed;
        }
        catch
        {
          Debug.Log((object) "Failed to log colors, rig most likely nonexistent");
        }
        try
        {
          str1 += "\n====================================\n";
          str1 = str1 + "Player Name: \"" + player.NickName + "\", Player ID: \"" + player.UserId + "\", Player Color: (R: " + num1.ToString() + ", G: " + num2.ToString() + ", B: " + num3.ToString() + "), Cosmetics: " + str2;
        }
        catch
        {
          Debug.Log((object) "Failed to log player");
        }
      }
      string contents = str1 + "\n====================================\n" + "Grabbed With Iris Menu";
      string str3 = "IrisMenu/PlayerInfo/" + PhotonNetwork.CurrentRoom.Name + ".txt";
      if (!Directory.Exists("IrisMenu"))
        Directory.CreateDirectory("IrisMenu");
      if (!Directory.Exists("IrisMenu/PlayerInfo"))
        Directory.CreateDirectory("IrisMenu/PlayerInfo");
      File.WriteAllText(str3, contents);
      string fileName = Path.Combine(Assembly.GetExecutingAssembly().Location, str3).Split("BepInEx\\")[0] + str3;
      try
      {
        Process.Start(fileName);
      }
      catch
      {
        Debug.Log((object) ("Could not open process " + fileName));
      }
    }

    public static void AcceptAgreements()
    {
      ((Behaviour) GameObject.Find("Miscellaneous Scripts/LegalAgreementCheck/Legal Agreements").GetComponent<LegalAgreements>()).enabled = false;
    }

    public static void AcceptTOS(bool tosActive)
    {
      GameObject gameObject = GameObject.Find("Miscellaneous Scripts/PopUpMessage");
      if (!Object.op_Inequality((Object) gameObject, (Object) null))
        return;
      gameObject.SetActive(tosActive);
      Global.TOSPatch.IsEnabled = tosActive;
    }

    public static void WaterPlayerGun()
    {
      GunLibthre.GunLibData gunLibData = GunLibthre.ShootLock();
      if (gunLibData == null || !gunLibData.isShooting || !gunLibData.isTriggered)
        return;
      VRRig lockedPlayer = gunLibData.lockedPlayer;
      if (Object.op_Implicit((Object) lockedPlayer) && Object.op_Inequality((Object) lockedPlayer, (Object) GorillaTagger.Instance.offlineVRRig))
        GorillaTagger.Instance.myVRRig.SendRPC("RPC_PlaySplashEffect", (RpcTarget) 0, new object[6]
        {
          (object) ((Component) gunLibData.lockedPlayer).transform.position,
          (object) ((Component) gunLibData.lockedPlayer).transform.rotation,
          (object) 4f,
          (object) 100f,
          (object) true,
          (object) false
        });
    }

    public static void WaterAura()
    {
      if ((double) Time.time <= (double) Global.ropesdelayy)
        return;
      GorillaTagger.Instance.myVRRig.SendRPC("RPC_PlaySplashEffect", (RpcTarget) 0, new object[6]
      {
        (object) Vector3.op_Addition(((Component) GorillaTagger.Instance.offlineVRRig).transform.position, new Vector3(Random.Range(-0.5f, 0.5f), Random.Range(-0.5f, 0.5f), Random.Range(-0.5f, 0.5f))),
        (object) Quaternion.Euler(new Vector3((float) Random.Range(0, 360), (float) Random.Range(0, 360), (float) Random.Range(0, 360))),
        (object) 4f,
        (object) 100f,
        (object) true,
        (object) false
      });
      Global.ropesdelayy = Time.time + 0.1f;
    }
  }
}
