﻿// Decompiled with JetBrains decompiler
// Type: FTSyxcalTemplate.Mods.SafetyMods
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using GorillaNetworking;
using Photon.Pun;
using StupidTemplate.Classes;
using StupidTemplate.Menu;
using StupidTemplate.Notifications;
using UnityEngine;

#nullable disable
namespace FTSyxcalTemplate.Mods
{
  internal class SafetyMods
  {
    public static bool lastjsi = false;
    public static bool isActive = true;
    public static bool smartarp = false;

    public static void NoFinger()
    {
      ControllerInputPoller.instance.leftControllerGripFloat = 0.0f;
      ControllerInputPoller.instance.rightControllerGripFloat = 0.0f;
      ControllerInputPoller.instance.leftControllerIndexFloat = 0.0f;
      ControllerInputPoller.instance.rightControllerIndexFloat = 0.0f;
      ControllerInputPoller.instance.leftControllerPrimaryButton = false;
      ControllerInputPoller.instance.leftControllerSecondaryButton = false;
      ControllerInputPoller.instance.rightControllerPrimaryButton = false;
      ControllerInputPoller.instance.rightControllerSecondaryButton = false;
      ControllerInputPoller.instance.leftControllerPrimaryButtonTouch = false;
      ControllerInputPoller.instance.leftControllerSecondaryButtonTouch = false;
      ControllerInputPoller.instance.rightControllerPrimaryButtonTouch = false;
      ControllerInputPoller.instance.rightControllerSecondaryButtonTouch = false;
    }

    public static void DisableGamemodeButtons()
    {
      GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/ModeSelector_Group").SetActive(false);
    }

    public static void EnableGamemodeButtons()
    {
      GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/ModeSelector_Group").SetActive(true);
    }

    public static void EnableSpoofSupportPage()
    {
      GorillaComputer.instance.screenText.Text = GorillaComputer.instance.screenText.Text.Replace("STEAM", "QUEST").Replace(GorillaComputer.instance.buildDate, "01/21/2025 16:50:12\nBUILD CODE BIGDICKRANDYINC\nMANAGED ACCOUNT: NO");
    }

    public static void DisableSpoofSupportPage()
    {
      GorillaComputer.instance.screenText.Text = GorillaComputer.instance.screenText.Text.Replace("STEAM", "QUEST").Replace(GorillaComputer.instance.buildDate, "01/21/2025 16:50:12\nBUILD CODE BIGDICKRANDYINC\nMANAGED ACCOUNT: NO");
    }

    public static void Antireportdisconnect()
    {
      foreach (GorillaPlayerScoreboardLine allScoreboardLine in GorillaScoreboardTotalUpdater.allScoreboardLines)
      {
        if (allScoreboardLine.linePlayer.IsLocal)
        {
          Transform transform = ((Component) allScoreboardLine.reportButton).gameObject.transform;
          foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
          {
            if (!vrrig.isOfflineVRRig)
            {
              float num1 = Vector3.Distance(vrrig.rightHandTransform.position, transform.position);
              float num2 = Vector3.Distance(vrrig.leftHandTransform.position, transform.position);
              if ((double) num1 <= 0.85000002384185791 || (double) num2 <= 0.85000002384185791)
              {
                PhotonNetwork.Disconnect();
                NotifiLib.SendNotification("<color=grey>[</color><color=purple>ANTI-REPORT</color><color=grey>]</color> <color=white>Someone attempted to report you, you have been disconnected.</color>");
              }
            }
          }
        }
      }
    }

    public static void Antireport()
    {
      try
      {
        foreach (GorillaPlayerScoreboardLine allScoreboardLine in GorillaScoreboardTotalUpdater.allScoreboardLines)
        {
          if (allScoreboardLine.linePlayer == NetworkSystem.Instance.LocalPlayer)
          {
            Transform transform = ((Component) allScoreboardLine.reportButton).gameObject.transform;
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
              if (Object.op_Inequality((Object) vrrig, (Object) GorillaTagger.Instance.offlineVRRig))
              {
                float num1 = Vector3.Distance(vrrig.rightHandTransform.position, transform.position);
                float num2 = Vector3.Distance(vrrig.leftHandTransform.position, transform.position);
                float num3 = 0.7f;
                if ((double) num1 < (double) num3 || (double) num2 < (double) num3)
                  NotifiLib.SendNotification("<color=grey></color><color=red>Someone Tried to report you </color>");
              }
            }
          }
        }
      }
      catch
      {
      }
    }

    public static void FlushRPCs()
    {
      GorillaNot gorillaNot = new GorillaNot()
      {
        rpcCallLimit = 99999999,
        rpcErrorMax = 99999999
      };
      PhotonNetwork.RemoveRPCs(PhotonNetwork.LocalPlayer);
      PhotonNetwork.RemoveRPCsInGroup(99999999);
      PhotonNetwork.RemoveBufferedRPCs(99999999, (string) null, (int[]) null);
    }

    public static void DisableAllMods()
    {
      foreach (ButtonInfo[] button in Buttons.buttons)
      {
        foreach (ButtonInfo buttonInfo in button)
        {
          if (buttonInfo.enabled)
            Main.Toggle(buttonInfo.buttonText);
        }
      }
      NotifiLib.ClearAllNotifications();
    }

    public static void AntireportReconnect()
    {
      try
      {
        foreach (GorillaPlayerScoreboardLine allScoreboardLine in GorillaScoreboardTotalUpdater.allScoreboardLines)
        {
          if (allScoreboardLine.linePlayer == NetworkSystem.Instance.LocalPlayer)
          {
            Transform transform = ((Component) allScoreboardLine.reportButton).gameObject.transform;
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
              if (Object.op_Inequality((Object) vrrig, (Object) GorillaTagger.Instance.offlineVRRig))
              {
                float num1 = Vector3.Distance(vrrig.rightHandTransform.position, transform.position);
                float num2 = Vector3.Distance(vrrig.leftHandTransform.position, transform.position);
                float num3 = 0.7f;
                if ((double) num1 < (double) num3 || (double) num2 < (double) num3)
                {
                  PhotonNetwork.Disconnect();
                  NotifiLib.SendNotification("<color=grey></color><color=red>Someone Tried to report you reconnecting...</color>");
                }
              }
            }
          }
        }
      }
      catch
      {
      }
    }

    public static void ReportAll()
    {
      foreach (GorillaPlayerScoreboardLine playerScoreboardLine in Object.FindObjectsOfType<GorillaPlayerScoreboardLine>())
      {
        if (playerScoreboardLine.linePlayer != null)
          playerScoreboardLine.PressButton(true, (GorillaPlayerLineButton.ButtonType) 0);
      }
    }

    public static void AntiReportV3()
    {
      try
      {
        foreach (GorillaPlayerScoreboardLine allScoreboardLine in GorillaScoreboardTotalUpdater.allScoreboardLines)
        {
          if (allScoreboardLine.linePlayer == NetworkSystem.Instance.LocalPlayer)
          {
            Transform transform = ((Component) allScoreboardLine.reportButton).gameObject.transform;
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
              if (Object.op_Inequality((Object) vrrig, (Object) GorillaTagger.Instance.offlineVRRig))
              {
                float num1 = Vector3.Distance(vrrig.rightHandTransform.position, transform.position);
                float num2 = Vector3.Distance(vrrig.leftHandTransform.position, transform.position);
                float num3 = 0.35f;
                if ((double) num1 < (double) num3 || (double) num2 < (double) num3)
                {
                  PhotonNetwork.Disconnect();
                  NotifiLib.SendNotification("<color=grey>[</color><color=purple>ANTI-REPORT</color><color=grey>]</color> <color=white>Someone reported you, Meta stopped it.</color>");
                }
              }
            }
          }
        }
      }
      catch
      {
      }
    }

    public static void UnlimitedRpcs()
    {
      GorillaNot gorillaNot = new GorillaNot()
      {
        rpcCallLimit = 999999999,
        rpcErrorMax = 999999999
      };
    }

    public class Safety
    {
      public static void NoFinger()
      {
        ControllerInputPoller.instance.leftControllerGripFloat = 0.0f;
        ControllerInputPoller.instance.rightControllerGripFloat = 0.0f;
        ControllerInputPoller.instance.leftControllerIndexFloat = 0.0f;
        ControllerInputPoller.instance.rightControllerIndexFloat = 0.0f;
        ControllerInputPoller.instance.leftControllerPrimaryButton = false;
        ControllerInputPoller.instance.leftControllerSecondaryButton = false;
        ControllerInputPoller.instance.rightControllerPrimaryButton = false;
        ControllerInputPoller.instance.rightControllerSecondaryButton = false;
        ControllerInputPoller.instance.leftControllerPrimaryButtonTouch = false;
        ControllerInputPoller.instance.leftControllerSecondaryButtonTouch = false;
        ControllerInputPoller.instance.rightControllerPrimaryButtonTouch = false;
        ControllerInputPoller.instance.rightControllerSecondaryButtonTouch = false;
      }

      public static void DisableGamemodeButtons()
      {
        GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/ModeSelector_Group").SetActive(false);
      }

      public static void EnableGamemodeButtons()
      {
        GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/ModeSelector_Group").SetActive(true);
      }

      public static void SpoofSupportPage()
      {
        GorillaComputer.instance.screenText.Text = GorillaComputer.instance.screenText.Text.Replace("STEAM", "QUEST").Replace(GorillaComputer.instance.buildDate, "05/30/2024 16:50:12\nBUILD CODE 4893\nMANAGED ACCOUNT: NO");
      }
    }
  }
}
