﻿// Decompiled with JetBrains decompiler
// Type: FTSyxcalTemplate.Mods.CosmeticMods
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using UnityEngine;

#nullable disable
namespace FTSyxcalTemplate.Mods
{
  internal class CosmeticMods
  {
    public static void ModeratorStick()
    {
      GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/Old Cosmetics Body/LBAAK.").SetActive(true);
    }

    public static void ModeratorStickDisable()
    {
      GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/Old Cosmetics Body/LBAAK.").SetActive(false);
    }

    public static void AdminBadge()
    {
      GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/Old Cosmetics Body/LBAAD.").SetActive(true);
    }

    public static void AdminBadgeDisable()
    {
      GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/Old Cosmetics Body/LBAAD.").SetActive(false);
    }

    public static void FingerPainterBadge()
    {
      GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/2023_04DungeonV2 Body/LBADE.").SetActive(true);
    }

    public static void FingerPainterBadgeDisable()
    {
      GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/2023_04DungeonV2 Body/LBADE.").SetActive(false);
    }

    public static void IllustratorBadge()
    {
      GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/LBAGS.").SetActive(true);
    }

    public static void DisableIllustratorBadge()
    {
      GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/RigAnchor/rig/body/LBAGS.").SetActive(false);
    }

    public static void PookieSweater()
    {
      GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/WinterJan2023 Body/LBACP.").SetActive(true);
    }

    public static void DiablePookieSweater()
    {
      GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/WinterJan2023 Body/LBACP.").SetActive(false);
    }
  }
}
