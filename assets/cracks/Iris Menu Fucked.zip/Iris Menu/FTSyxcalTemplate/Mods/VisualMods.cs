﻿// Decompiled with JetBrains decompiler
// Type: FTSyxcalTemplate.Mods.VisualMods
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using FTSyxcalTemplate.Menu;
using Photon.Pun;
using Photon.Realtime;
using StupidTemplate.Notifications;
using System;
using System.Collections.Generic;
using UnityEngine;

#nullable disable
namespace FTSyxcalTemplate.Mods
{
  internal class VisualMods
  {
    private const int V = 3;
    public static bool esp;
    public static List<GameObject> leaves = new List<GameObject>();
    public static List<GameObject> cosmetics = new List<GameObject>();

    public static void EnableAllChams()
    {
      VisualMods.esp = true;
      if (!VisualMods.esp)
        return;
      foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
      {
        if (!vrrig.isOfflineVRRig)
        {
          ((Renderer) vrrig.mainSkin).material.shader = Shader.Find("GUI/Text Shader");
          ((Renderer) vrrig.mainSkin).material.color = Color.yellow;
        }
      }
    }

    public static void DisableAllChams()
    {
      if (!VisualMods.esp)
        return;
      foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
      {
        if (!vrrig.isOfflineVRRig)
          ((Renderer) vrrig.mainSkin).material.shader = Shader.Find("GorillaTag/UberShade");
      }
      VisualMods.esp = false;
    }

    public static void EnableESP()
    {
      VisualMods.esp = true;
      if (!VisualMods.esp)
        return;
      foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
      {
        if (!vrrig.isOfflineVRRig)
        {
          ((Renderer) vrrig.mainSkin).material.shader = Shader.Find("Outlined/Uniform");
          ((Renderer) vrrig.mainSkin).material.SetColor("_OutlineColor", Color.yellow);
          ((Renderer) vrrig.mainSkin).material.SetFloat("_OutlineWidth", 0.02f);
        }
      }
    }

    public static void DisableESP()
    {
      if (!VisualMods.esp)
        return;
      foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
      {
        if (!vrrig.isOfflineVRRig)
          ((Renderer) vrrig.mainSkin).material.shader = Shader.Find("GorillaTag/UberShade");
      }
      VisualMods.esp = false;
    }

    public static void BoneESP()
    {
      if (!PhotonNetwork.InRoom && !PhotonNetwork.InLobby)
        return;
      foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
      {
        if (Object.op_Inequality((Object) vrrig, (Object) GorillaTagger.Instance.offlineVRRig))
        {
          foreach (Transform componentsInChild in ((Component) ((Component) vrrig).transform).GetComponentsInChildren<Transform>())
          {
            if (Object.op_Inequality((Object) componentsInChild, (Object) ((Component) vrrig).transform) && Object.op_Implicit((Object) componentsInChild.parent))
            {
              GameObject gameObject = new GameObject("Line");
              gameObject.transform.SetParent(componentsInChild);
              LineRenderer lineRenderer = gameObject.AddComponent<LineRenderer>();
              List<Vector3> vector3List = new List<Vector3>();
              vector3List.Add(componentsInChild.position);
              vector3List.Add(componentsInChild.parent.position);
              lineRenderer.startWidth = 0.03f;
              lineRenderer.endWidth = 0.03f;
              lineRenderer.positionCount = vector3List.Count;
              lineRenderer.SetPositions(vector3List.ToArray());
              Material material = new Material(Shader.Find("GUI/Text Shader"));
              ((Renderer) lineRenderer).material = material;
              float num = Mathf.PingPong(Time.time / 2f, 1f);
              material.color = Color.Lerp(SigmaColor.SigmaColor.hotPink, SigmaColor.SigmaColor.deepPink, num);
            }
          }
        }
      }
    }

    public static void Tracers()
    {
      foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
      {
        if (Object.op_Inequality((Object) vrrig, (Object) GorillaTagger.Instance.offlineVRRig))
        {
          GameObject gameObject = new GameObject("Line");
          LineRenderer lineRenderer = gameObject.AddComponent<LineRenderer>();
          Color playerColor = vrrig.playerColor;
          lineRenderer.startColor = playerColor;
          lineRenderer.endColor = playerColor;
          lineRenderer.startWidth = 0.025f;
          lineRenderer.endWidth = 0.025f;
          lineRenderer.positionCount = 2;
          lineRenderer.useWorldSpace = true;
          lineRenderer.SetPosition(0, GorillaTagger.Instance.rightHandTransform.position);
          lineRenderer.SetPosition(1, ((Component) vrrig).transform.position);
          ((Renderer) lineRenderer).material.shader = Shader.Find("GUI/Text Shader");
          Object.Destroy((Object) gameObject, Time.deltaTime);
        }
      }
    }

    public static void DisableTracers()
    {
      foreach (GameObject gameObject in Object.FindObjectsOfType<GameObject>())
      {
        if (((Object) gameObject).name == "Line")
          Object.Destroy((Object) gameObject);
      }
    }

    public static void LightningStrike(Vector3 position)
    {
      GameObject gameObject1 = new GameObject("LightningOuter");
      LineRenderer lineRenderer1 = gameObject1.AddComponent<LineRenderer>();
      lineRenderer1.startColor = Color.cyan;
      lineRenderer1.endColor = Color.cyan;
      lineRenderer1.startWidth = 0.25f;
      lineRenderer1.endWidth = 0.25f;
      lineRenderer1.positionCount = 5;
      lineRenderer1.useWorldSpace = true;
      Vector3 vector3 = position;
      for (int index = 0; index < 5; ++index)
      {
        GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(68, false, 5f);
        GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(68, true, 5f);
        lineRenderer1.SetPosition(index, vector3);
        vector3 = Vector3.op_Addition(vector3, new Vector3(Random.Range(-5f, 5f), 5f, Random.Range(-5f, 5f)));
      }
      ((Renderer) lineRenderer1).material.shader = Shader.Find("GUI/Text Shader");
      Object.Destroy((Object) gameObject1, 2f);
      GameObject gameObject2 = new GameObject("LightningInner");
      LineRenderer lineRenderer2 = gameObject2.AddComponent<LineRenderer>();
      lineRenderer2.startColor = Color.white;
      lineRenderer2.endColor = Color.white;
      lineRenderer2.startWidth = 0.15f;
      lineRenderer2.endWidth = 0.15f;
      lineRenderer2.positionCount = 5;
      lineRenderer2.useWorldSpace = true;
      for (int index = 0; index < 5; ++index)
        lineRenderer2.SetPosition(index, lineRenderer1.GetPosition(index));
      ((Renderer) lineRenderer2).material.shader = Shader.Find("GUI/Text Shader");
      ((Renderer) lineRenderer2).material.renderQueue = ((Renderer) lineRenderer1).material.renderQueue + 1;
      Object.Destroy((Object) gameObject2, 2f);
    }

    public static void FixRigColors()
    {
      foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
      {
        if (((Object) ((Renderer) vrrig.mainSkin).material).name.Contains("gorilla_body"))
          ((Renderer) vrrig.mainSkin).material.color = vrrig.playerColor;
      }
    }

    public static void EnableRemoveLeaves()
    {
      foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
      {
        if (gameObject.activeSelf && (((Object) gameObject).name.Contains("leaves_green") || ((Object) gameObject).name.Contains("fallleaves")))
        {
          gameObject.SetActive(false);
          VisualMods.leaves.Add(gameObject);
        }
      }
    }

    public static void DisableRemoveLeaves()
    {
      foreach (GameObject leaf in VisualMods.leaves)
        leaf.SetActive(true);
      VisualMods.leaves.Clear();
    }

    public static void EnableStreamerRemoveLeaves()
    {
      foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
      {
        if (gameObject.activeSelf && (((Object) gameObject).name.Contains("leaves_green") || ((Object) gameObject).name.Contains("fallleaves")))
        {
          gameObject.layer = 16;
          VisualMods.leaves.Add(gameObject);
        }
      }
    }

    public static void DisableStreamerRemoveLeaves()
    {
      foreach (GameObject leaf in VisualMods.leaves)
        leaf.layer = 0;
      VisualMods.leaves.Clear();
    }

    public static void DisableCosmetics()
    {
      try
      {
        foreach (GameObject cosmetic in GorillaTagger.Instance.offlineVRRig.cosmetics)
        {
          if (cosmetic.activeSelf && Object.op_Equality((Object) cosmetic.transform.parent, (Object) GorillaTagger.Instance.offlineVRRig.mainCamera.transform))
          {
            VisualMods.cosmetics.Add(cosmetic);
            cosmetic.SetActive(false);
          }
        }
      }
      catch
      {
      }
    }

    public static void EnableCosmetics()
    {
      foreach (GameObject cosmetic in VisualMods.cosmetics)
        cosmetic.SetActive(true);
      VisualMods.cosmetics.Clear();
    }

    public static void NoSmoothRigs()
    {
      foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
      {
        if (Object.op_Inequality((Object) vrrig, (Object) GorillaTagger.Instance.offlineVRRig))
        {
          vrrig.lerpValueBody = 1f;
          vrrig.lerpValueFingers = 1f;
        }
      }
    }

    public static void ReSmoothRigs()
    {
      foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
      {
        if (Object.op_Inequality((Object) vrrig, (Object) GorillaTagger.Instance.offlineVRRig))
        {
          vrrig.lerpValueBody = GorillaTagger.Instance.offlineVRRig.lerpValueBody;
          vrrig.lerpValueFingers = GorillaTagger.Instance.offlineVRRig.lerpValueFingers;
        }
      }
    }

    public static void Xray()
    {
      try
      {
        foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll(typeof (GameObject)))
        {
          Renderer component = gameObject.GetComponent<Renderer>();
          if (Object.op_Inequality((Object) component, (Object) null))
          {
            foreach (Material material in component.materials)
            {
              Color color = material.color;
              color.a = 0.5f;
              material.color = color;
              material.SetFloat("_Mode", 3f);
              material.SetInt("_SrcBlend", 5);
              material.SetInt("_DstBlend", 10);
              material.SetInt("_ZWrite", 0);
              material.renderQueue = 3000;
            }
          }
        }
      }
      catch
      {
        NotifiLib.SendNotification("Your game is broken, reload the mod/game to fix errors.");
      }
    }

    public static void DisableXray()
    {
      try
      {
        foreach (GameObject gameObject in Resources.FindObjectsOfTypeAll(typeof (GameObject)))
        {
          Renderer component = gameObject.GetComponent<Renderer>();
          if (Object.op_Inequality((Object) component, (Object) null))
          {
            foreach (Material material in component.materials)
            {
              Color color = material.color;
              color.a = 1f;
              material.color = color;
              material.SetFloat("_Mode", 0.0f);
              material.SetInt("_SrcBlend", 1);
              material.SetInt("_DstBlend", 0);
              material.SetInt("_ZWrite", 1);
              material.renderQueue = -1;
            }
          }
        }
      }
      catch
      {
        NotifiLib.SendNotification("Your game is broken, reload the mod/game to fix errors.");
      }
    }

    public static void BreakLightDisable()
    {
      BetterDayNightManager.instance.AnimateLightFlash(2, 2f, 2f, 2f);
    }

    public static void BreakLights()
    {
      BetterDayNightManager.instance.AnimateLightFlash(2, 0.0f, 0.0f, 2f);
    }

    public static void ForceRain()
    {
      BetterDayNightManager.instance.weatherCycle[BetterDayNightManager.instance.currentWeatherIndex + 1] = (BetterDayNightManager.WeatherType) 1;
      ++BetterDayNightManager.instance.currentWeatherIndex;
      BetterDayNightManager.instance.CurrentWeather();
    }

    public static void ClearWeather()
    {
      BetterDayNightManager.instance.weatherCycle[BetterDayNightManager.instance.currentWeatherIndex] = (BetterDayNightManager.WeatherType) 0;
      ++BetterDayNightManager.instance.currentWeatherIndex;
      BetterDayNightManager.instance.CurrentWeather();
    }

    public static void whitesky()
    {
      Renderer component = GameObject.Find("Environment Objects/LocalObjects_Prefab/Standard Sky").GetComponent<Renderer>();
      component.material.shader = Shader.Find("GorillaTag/UberShader");
      component.material.color = Color.white;
    }

    public static void graysky()
    {
      Renderer component = GameObject.Find("Environment Objects/LocalObjects_Prefab/Standard Sky").GetComponent<Renderer>();
      component.material.shader = Shader.Find("GorillaTag/UberShader");
      component.material.color = Color.gray;
    }

    public static void RgbSky()
    {
      float num = (float) ((double) Time.frameCount / 180.0 % 1.0);
      Renderer component = GameObject.Find("Environment Objects/LocalObjects_Prefab/Standard Sky").GetComponent<Renderer>();
      component.material.shader = Shader.Find("GorillaTag/UberShader");
      component.material.color = Color.HSVToRGB(num, 1f, 1f);
    }

    public static void ChamsInfection()
    {
      foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
      {
        if (Object.op_Inequality((Object) vrrig, (Object) GorillaTagger.Instance.offlineVRRig))
        {
          ((Renderer) vrrig.mainSkin).material.shader = Shader.Find("GUI/Text Shader");
          if (((Object) ((Renderer) vrrig.mainSkin).material).name.Contains("fected") || ((Object) ((Renderer) vrrig.mainSkin).material).name.Contains("it"))
            ((Renderer) vrrig.mainSkin).material.color = new Color((float) byte.MaxValue, 0.0f, 0.0f, 0.5f);
          else
            ((Renderer) vrrig.mainSkin).material.color = new Color(0.0f, (float) byte.MaxValue, 0.0f, 0.5f);
        }
      }
    }

    public static void DougESP()
    {
      GameObject gameObject = GameObject.Find("Floating Bug Holdable");
      GameObject primitive = GameObject.CreatePrimitive((PrimitiveType) 0);
      if (!Object.op_Inequality((Object) gameObject, (Object) null))
        return;
      primitive.transform.localScale = new Vector3(0.3f, 0.3f, 0.3f);
      primitive.transform.position = gameObject.transform.position;
      primitive.transform.rotation = gameObject.transform.rotation;
      Material material = new Material(Shader.Find("GUI/Text Shader"));
      primitive.GetComponent<Renderer>().material = material;
      float num = Mathf.PingPong(Time.time / 2f, 1f);
      Color color1;
      // ISSUE: explicit constructor call
      ((Color) ref color1).\u002Ector(SigmaColor.SigmaColor.hotPink.r, SigmaColor.SigmaColor.hotPink.g, SigmaColor.SigmaColor.hotPink.b, 0.5f);
      Color color2;
      // ISSUE: explicit constructor call
      ((Color) ref color2).\u002Ector(SigmaColor.SigmaColor.deepPink.r, SigmaColor.SigmaColor.deepPink.g, SigmaColor.SigmaColor.deepPink.b, 0.5f);
      Color color3 = Color.Lerp(color1, color2, num);
      material.color = color3;
      primitive.transform.SetParent(gameObject.transform);
      Object.Destroy((Object) primitive, Time.deltaTime);
    }

    public static void MatESP()
    {
      GameObject gameObject = GameObject.Find("Cave Bat Holdable");
      GameObject primitive = GameObject.CreatePrimitive((PrimitiveType) 0);
      if (!Object.op_Inequality((Object) gameObject, (Object) null))
        return;
      primitive.transform.localScale = new Vector3(0.3f, 0.3f, 0.3f);
      primitive.transform.position = gameObject.transform.position;
      primitive.transform.rotation = gameObject.transform.rotation;
      Material material = new Material(Shader.Find("GUI/Text Shader"));
      primitive.GetComponent<Renderer>().material = material;
      float num = Mathf.PingPong(Time.time / 2f, 1f);
      Color color1;
      // ISSUE: explicit constructor call
      ((Color) ref color1).\u002Ector(SigmaColor.SigmaColor.hotPink.r, SigmaColor.SigmaColor.hotPink.g, SigmaColor.SigmaColor.hotPink.b, 0.5f);
      Color color2;
      // ISSUE: explicit constructor call
      ((Color) ref color2).\u002Ector(SigmaColor.SigmaColor.deepPink.r, SigmaColor.SigmaColor.deepPink.g, SigmaColor.SigmaColor.deepPink.b, 0.5f);
      Color color3 = Color.Lerp(color1, color2, num);
      material.color = color3;
      primitive.transform.SetParent(gameObject.transform);
      Object.Destroy((Object) primitive, Time.deltaTime);
    }

    public static void HeadChams1()
    {
      if (!PhotonNetwork.InRoom)
        return;
      foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
      {
        if (!vrrig.isOfflineVRRig)
        {
          GameObject primitive = GameObject.CreatePrimitive((PrimitiveType) 0);
          Object.Destroy((Object) primitive, Time.deltaTime);
          Object.Destroy((Object) primitive.GetComponent<Rigidbody>());
          Object.Destroy((Object) primitive.GetComponent<SphereCollider>());
          primitive.transform.localScale = new Vector3(0.15f, 0.15f, 0.15f);
          primitive.transform.position = Vector3.op_Addition(((Component) vrrig).transform.position, new Vector3(0.0f, 0.4f, 0.0f));
          primitive.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
          if (((Object) ((Renderer) vrrig.mainSkin).material).name.Contains("fected") || ((Object) ((Renderer) vrrig.mainSkin).material).name.Contains("It"))
            primitive.GetComponent<Renderer>().material.color = Color32.op_Implicit(new Color32(byte.MaxValue, (byte) 106, (byte) 0, byte.MaxValue));
        }
      }
    }

    public static void SnakeESP2()
    {
      if (!PhotonNetwork.InRoom && !PhotonNetwork.InLobby)
        return;
      foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
      {
        if (Object.op_Inequality((Object) vrrig, (Object) GorillaTagger.Instance.offlineVRRig))
        {
          GameObject primitive = GameObject.CreatePrimitive((PrimitiveType) 0);
          primitive.transform.localScale = new Vector3(0.095f, 0.095f, 0.095f);
          primitive.transform.position = ((Component) vrrig).transform.position = GorillaTagger.Instance.rightHandTransform.position;
          primitive.transform.rotation = ((Component) vrrig).transform.rotation;
          Collider component = primitive.GetComponent<Collider>();
          if (Object.op_Implicit((Object) component))
            Object.Destroy((Object) component);
          Material material = new Material(Shader.Find("GUI/Text Shader"));
          primitive.GetComponent<Renderer>().material = material;
          float num = Mathf.PingPong(Time.time / 2f, 1f);
          material.color = Color.Lerp(SigmaColor.SigmaColor.hotPink, SigmaColor.SigmaColor.deepPink, num);
          Object.Destroy((Object) primitive, 0.5f);
        }
      }
    }

    public static void BoneESPV2()
    {
      foreach (Player playerListOther in PhotonNetwork.PlayerListOthers)
      {
        VRRig vrRigFromPlayer = Global.GetVRRigFromPlayer(playerListOther);
        if (!Object.op_Equality((Object) vrRigFromPlayer, (Object) null))
        {
          LineRenderer lineRenderer1 = ((Component) vrRigFromPlayer.head.rigTarget).gameObject.AddComponent<LineRenderer>();
          lineRenderer1.startWidth = 0.025f;
          lineRenderer1.endWidth = 0.025f;
          ((Renderer) lineRenderer1).material.shader = Shader.Find("GUI/Text Shader");
          lineRenderer1.startColor = Global.ESPColor(vrRigFromPlayer);
          lineRenderer1.endColor = Global.ESPColor(vrRigFromPlayer);
          lineRenderer1.SetPosition(0, Vector3.op_Addition(((Component) vrRigFromPlayer.head.rigTarget).transform.position, new Vector3(0.0f, 0.16f, 0.0f)));
          lineRenderer1.SetPosition(1, Vector3.op_Subtraction(((Component) vrRigFromPlayer.head.rigTarget).transform.position, new Vector3(0.0f, 0.4f, 0.0f)));
          Object.Destroy((Object) lineRenderer1, Time.deltaTime * 2f);
          for (int index = 0; index < Global.bones.Length; index += 2)
          {
            Transform bone1 = vrRigFromPlayer.mainSkin.bones[Global.bones[index]];
            Transform bone2 = vrRigFromPlayer.mainSkin.bones[Global.bones[index + 1]];
            if (!Object.op_Equality((Object) bone1, (Object) null) && !Object.op_Equality((Object) bone2, (Object) null))
            {
              LineRenderer lineRenderer2 = ((Component) bone1).gameObject.AddComponent<LineRenderer>();
              lineRenderer2.startWidth = 0.025f;
              lineRenderer2.endWidth = 0.025f;
              ((Renderer) lineRenderer2).material.shader = Shader.Find("GUI/Text Shader");
              lineRenderer2.startColor = Global.ESPColor(vrRigFromPlayer);
              lineRenderer2.endColor = Global.ESPColor(vrRigFromPlayer);
              lineRenderer2.SetPosition(0, bone1.position);
              lineRenderer2.SetPosition(1, bone2.position);
              Object.Destroy((Object) lineRenderer2, Time.deltaTime * 2f);
            }
          }
        }
      }
    }

    public static void BoxESP()
    {
      foreach (Player playerListOther in PhotonNetwork.PlayerListOthers)
      {
        VRRig vrRigFromPlayer = Global.GetVRRigFromPlayer(playerListOther);
        if (!Object.op_Equality((Object) vrRigFromPlayer, (Object) null))
        {
          GameObject primitive = GameObject.CreatePrimitive((PrimitiveType) 3);
          primitive.transform.position = ((Component) vrRigFromPlayer).transform.position;
          Object.Destroy((Object) primitive.GetComponent<BoxCollider>());
          primitive.transform.localScale = new Vector3(0.7f, 0.7f, 0.7f);
          primitive.transform.LookAt(((Component) GorillaTagger.Instance.headCollider).transform.position);
          Renderer component = primitive.GetComponent<Renderer>();
          if (Object.op_Inequality((Object) component, (Object) null))
          {
            component.material.shader = Shader.Find("GUI/Text Shader");
            component.material.color = Global.ESPColor(vrRigFromPlayer);
          }
          Object.Destroy((Object) primitive, Time.deltaTime * 2f);
        }
      }
    }

    public static void Beacons()
    {
      foreach (Player playerListOther in PhotonNetwork.PlayerListOthers)
      {
        VRRig vrRigFromPlayer = Global.GetVRRigFromPlayer(playerListOther);
        GameObject primitive = GameObject.CreatePrimitive((PrimitiveType) 2);
        Object.Destroy((Object) primitive.GetComponent<BoxCollider>());
        Object.Destroy((Object) primitive.GetComponent<Rigidbody>());
        Object.Destroy((Object) primitive.GetComponent<Collider>());
        primitive.transform.rotation = Quaternion.identity;
        primitive.transform.localScale = new Vector3(0.04f, 200f, 0.04f);
        primitive.transform.position = ((Component) vrRigFromPlayer).transform.position;
        primitive.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
        primitive.GetComponent<Renderer>().material.color = Global.ESPColor(vrRigFromPlayer);
        Object.Destroy((Object) primitive, Time.deltaTime);
      }
    }

    public static void InfectionBoxESP()
    {
      foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
      {
        if (Object.op_Inequality((Object) vrrig, (Object) GorillaTagger.Instance.offlineVRRig))
        {
          GameObject primitive = GameObject.CreatePrimitive((PrimitiveType) 1);
          primitive.transform.position = ((Component) vrrig).transform.position;
          Object.Destroy((Object) primitive.GetComponent<BoxCollider>());
          primitive.transform.localScale = new Vector3(0.5f, 0.5f, 0.0f);
          primitive.transform.LookAt(((Component) GorillaTagger.Instance.headCollider).transform.position);
          if (((Object) ((Renderer) vrrig.mainSkin).material).name.Contains("fected"))
          {
            primitive.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
            primitive.GetComponent<Renderer>().material.color = Color.red;
          }
          else
          {
            primitive.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
            primitive.GetComponent<Renderer>().material.color = Color.green;
          }
          Object.Destroy((Object) primitive, Time.deltaTime);
        }
      }
    }

    public static void BatHalo()
    {
      float num = 120f;
      GameObject.Find("Cave Bat Holdable").transform.position = Vector3.op_Addition(((Component) GorillaTagger.Instance.headCollider).transform.position, new Vector3(MathF.Cos(num + (float) Time.frameCount / 30f), 2f, MathF.Sin(num + (float) Time.frameCount / 30f)));
    }

    public static void InfectionBallESP()
    {
      foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
      {
        if (Object.op_Inequality((Object) vrrig, (Object) GorillaTagger.Instance.offlineVRRig))
        {
          GameObject primitive = GameObject.CreatePrimitive((PrimitiveType) 0);
          primitive.transform.position = ((Component) vrrig).transform.position;
          Object.Destroy((Object) primitive.GetComponent<BoxCollider>());
          primitive.transform.localScale = new Vector3(0.5f, 0.5f, 0.0f);
          primitive.transform.LookAt(((Component) GorillaTagger.Instance.headCollider).transform.position);
          if (((Object) ((Renderer) vrrig.mainSkin).material).name.Contains("fected"))
          {
            primitive.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
            primitive.GetComponent<Renderer>().material.color = Color.red;
          }
          else
          {
            primitive.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
            primitive.GetComponent<Renderer>().material.color = Color.green;
          }
          Object.Destroy((Object) primitive, Time.deltaTime);
        }
      }
    }

    public static void HandEsp()
    {
      foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
      {
        if (Object.op_Inequality((Object) vrrig, (Object) GorillaTagger.Instance.offlineVRRig))
        {
          GameObject primitive1 = GameObject.CreatePrimitive((PrimitiveType) 0);
          primitive1.transform.position = ((Component) vrrig.rightHandTransform).transform.position;
          primitive1.transform.localScale = new Vector3(0.15f, 0.15f, 0.15f);
          Object.Destroy((Object) primitive1.GetComponent<Rigidbody>());
          Object.Destroy((Object) primitive1.GetComponent<SphereCollider>());
          primitive1.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
          primitive1.GetComponent<Renderer>().material.color = Color.green;
          Object.Destroy((Object) primitive1, Time.deltaTime);
          GameObject primitive2 = GameObject.CreatePrimitive((PrimitiveType) 0);
          primitive2.transform.position = ((Component) vrrig.leftHandTransform).transform.position;
          primitive2.transform.localScale = new Vector3(0.15f, 0.15f, 0.15f);
          Object.Destroy((Object) primitive2.GetComponent<Rigidbody>());
          Object.Destroy((Object) primitive2.GetComponent<SphereCollider>());
          primitive2.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
          primitive2.GetComponent<Renderer>().material.color = Color.yellow;
          Object.Destroy((Object) primitive2, Time.deltaTime);
        }
      }
    }
  }
}
