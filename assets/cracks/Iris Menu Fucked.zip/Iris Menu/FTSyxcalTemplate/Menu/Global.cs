﻿// Decompiled with JetBrains decompiler
// Type: FTSyxcalTemplate.Menu.Global
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using FTSyxcalTemplate.Menu.Libs;
using FTSyxcalTemplate.Mods;
using GorillaLocomotion;
using GorillaNetworking;
using HarmonyLib;
using Photon.Pun;
using Photon.Realtime;
using StupidTemplate.Classes;
using StupidTemplate.Menu;
using StupidTemplate.Notifications;
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

#nullable disable
namespace FTSyxcalTemplate.Menu
{
  internal class Global
  {
    public static bool inSettings = false;
    public static bool inCat1 = false;
    public static bool inCat2 = false;
    public static Main instance = new Main();
    public static bool inCat3 = false;
    public static bool inCat4 = false;
    public static bool inCat5 = false;
    public static bool inCat6 = false;
    public static bool inCat7 = false;
    public static bool inCat8 = false;
    public static bool inCat9 = false;
    public static bool inCat10 = false;
    public static Color CurrentGunColor = Color.blue;
    public static Color CurrentESPColor = Color.blue;
    public static int change1 = 1;
    public static int change2 = 1;
    public static int change3 = 1;
    public static int change4 = 1;
    public static int change5 = 1;
    public static int change6 = 1;
    public static int change7 = 1;
    public static int change8 = 1;
    public static int change9 = 1;
    public static int change10 = 1;
    public static int change11 = 1;
    public static int change12 = 1;
    public static int change13 = 1;
    public static int change14 = 1;
    public static int change15 = 1;
    public static int change16 = 1;
    public static int change17 = 1;
    public static int change18 = 1;
    public static int change19 = 1;
    public static int change20 = 1;
    public static int change21 = 1;
    public static bool ghostMonke = false;
    public static bool rightHand = false;
    public static bool last;
    public static bool last2;
    public static bool last3;
    public static GameObject orb;
    public static GameObject orb2;
    public static bool longArms;
    public static bool longgArms;
    public static bool longggArms;
    public static bool fak;
    public static int fake;
    public static bool Head1;
    public static bool head2;
    public static bool head3;
    public static bool headback;
    public static bool downhead;
    public static bool noti;
    public static int g;
    public static int g1;
    public static int g2;
    public static int g3;
    public static int g4;
    public static int g5;
    public static int g6;
    public static int g7;
    public static int gt;
    public static float de = 0.0f;
    public static float dee = 0.0f;
    public static float deee = 0.0f;
    public static float orbit;
    public static float angle;
    public static float snowsize = 1f;
    public static bool beach;
    public static int g8;
    public static int g9;
    public static float AURA = 1.666f;
    public static float Walk = 10f;
    public static bool FPSPage;
    public static bool RGBMenu;
    public static bool right;
    public static bool fps;
    public static int ButtonSound = 67;
    public static float balll435342111;
    public static int[] bones = new int[38]
    {
      4,
      3,
      5,
      4,
      19,
      18,
      20,
      19,
      3,
      18,
      21,
      20,
      22,
      21,
      25,
      21,
      29,
      21,
      31,
      29,
      27,
      25,
      24,
      22,
      6,
      5,
      7,
      6,
      10,
      6,
      14,
      6,
      16,
      14,
      12,
      10,
      9,
      7
    };
    public static int floatblock = 1;
    public static int blockmul = 1;
    public static bool floatblockb = true;
    public static bool super;
    public static GameObject pointer = (GameObject) null;
    public static LineRenderer Line;
    public static RaycastHit raycastHit;
    public static bool hand = false;
    public static bool hand1 = false;
    public static RaycastHit raycastHitPC;
    public static VRRig lockedrig;
    public static Camera Cam;
    public static Vector3 MousePos;
    public static bool invisplat = false;
    public static bool invisMonke = false;
    public static bool stickyplatforms = false;
    public static Vector3 scale = new Vector3(0.0125f, 0.28f, 0.3825f);
    public static bool once_left;
    public static bool once_right;
    public static bool once_left_false;
    public static bool once_right_false;
    public static GameObject[] jump_left_network = new GameObject[9999];
    public static GameObject[] jump_right_network = new GameObject[9999];
    public static GameObject jump_left_local = (GameObject) null;
    public static GameObject jump_right_local = (GameObject) null;
    public static GradientColorKey[] colorKeysPlatformMonke = new GradientColorKey[4];
    public static bool TriggerPlats;
    public static bool RPlat;
    public static bool LPlat;
    public static bool ch;
    public static bool nograv;
    public static bool lowgrav;
    public static bool network;
    public static bool antikick;
    public static float delay;
    public static float delay1;
    public static bool actual_rig = Object.op_Implicit((Object) GorillaTagger.Instance.offlineVRRig);
    public static bool actual_right_hand = Object.op_Implicit((Object) GTPlayer.Instance.rightControllerTransform);
    public static bool actual_left_hand = Object.op_Implicit((Object) GTPlayer.Instance.leftControllerTransform);
    public static Vector3 head_body_offset = GorillaTagger.Instance.offlineVRRig.headBodyOffset;
    public static bool rig_right_hand = Object.op_Implicit((Object) GorillaTagger.Instance.rightHandTransform);
    public static bool rig_left_hand = Object.op_Implicit((Object) GorillaTagger.Instance.leftHandTransform);
    public static bool actual_rig_instance = Object.op_Implicit((Object) GTPlayer.Instance);
    public static VRMap head = GorillaTagger.Instance.offlineVRRig.head;
    public static bool rigidbody = Object.op_Implicit((Object) GorillaTagger.Instance.rigidbody);
    public static bool cam = Object.op_Implicit((Object) Camera.main);
    public static bool actual_rigidbody = Object.op_Implicit((Object) ((Component) GTPlayer.Instance).GetComponent<Rigidbody>());
    public static bool actual_head_collider = Object.op_Implicit((Object) GTPlayer.Instance.headCollider);
    public static bool rig_body_collider = Object.op_Implicit((Object) GorillaTagger.Instance.bodyCollider);
    public static bool actual_body_collider = Object.op_Implicit((Object) GTPlayer.Instance.bodyCollider);
    public static GameObject leftPlatform;
    public static float l;
    public static GameObject rightPlatform;
    public static GameObject menuObj = (GameObject) null;
    public static GameObject background = (GameObject) null;
    public static GameObject canvasObj = (GameObject) null;
    public static GameObject clickerObj = (GameObject) null;
    public static GameObject backgroundOutline = (GameObject) null;
    public static GameObject disconnectButton = (GameObject) null;
    public static GameObject disconnectButtonOutline = (GameObject) null;
    public static Color32 BackgroundColor = new Color32((byte) 15, (byte) 15, (byte) 15, byte.MaxValue);
    public static Color32 ModEnabledColor = new Color32((byte) 13, (byte) 13, (byte) 13, byte.MaxValue);
    public static Color32 ModDisabledColor = new Color32((byte) 0, (byte) 0, (byte) 0, byte.MaxValue);
    public static int currentCategoryPage = 0;
    public static int ButtonsPerPage = 7;
    public static bool wideMenu = false;
    public static bool toggledisconnectButton = false;
    public static bool rightHandedMenu = false;
    public static bool toggleNotifications = true;
    public static bool PCMenuOpen = false;
    public static KeyCode PCMenuKey = (KeyCode) 308;
    public static bool openMenu;
    public static bool menuOpen = false;
    public static bool InMenuCondition;
    public static bool InPcCondition;
    public static bool advancedTitle = false;
    public static string AllKeycards = "";
    public static bool didIds = false;
    public static bool ownersInRoom = false;
    public static bool notificationSent = false;
    public static Player playerInstance;
    public static Transform rightControllerTransform;
    public static GorillaTagger taggerInstance;
    public static ControllerInputPoller pollerInstance;
    public static VRRig vrrig = (VRRig) null;
    public static Material vrrigMaterial = (Material) null;
    public static GameObject thirdPersonCamera;
    public static GameObject shoulderCamera;
    public static GameObject TransformCam = (GameObject) null;
    public static bool didThirdPerson = false;
    public static GameObject cm;
    public static Rigidbody currentMenuRigidbody = (Rigidbody) null;
    public static Vector3 previousVelocity = Vector3.zero;
    public const float velocityThreshold = 0.05f;
    public static float lastFPSTime = 0.0f;
    public static float lastClearTime = 0.0f;
    public static float rpcCooldown = 0.0f;
    public static readonly Dictionary<string, string> gameModePaths;
    public static bool teamCheckedESP;
    public static int FlySpeed = 15;
    public static GameObject rightPlat;
    public static GameObject leftPlat;
    public static float Delay;
    public static VRRig compenentInParent;
    public static bool ghostToggle;
    public static bool True;
    public static string Room;
    public static GorillaGuardianManager _guardian;
    public static string roomsstring = (string) null;
    public static float distanceToLeave = 0.3393993f;
    public static float wDelay;
    public static bool e = true;
    public static GameObject gorillaVelocityEstimatorCustome;
    public static GorillaVelocityEstimator scriptedGorillaVelEst;
    public static bool objSuccess;
    public static float projDelay;
    public static float ropesdelayy;
    public static float ESP;
    public static float gDelay;
    public static float bdelay;
    public static bool projEnabled = false;
    public static float slingshotfloat;
    public static bool slingshotspitfireboooooooooool;
    public static float sdelay;
    public static bool DoTracers;
    public static bool mutethisboy;
    public static float door;
    public static float doorTime;
    public static float impactDelay;
    public static bool noclip;
    public static GameObject PlatsLeft;
    public static GameObject PlatsRight;
    public static bool PlatLSpawn;
    public static bool PlatRSpawn;
    public static GameObject GunSphere;
    public static bool shouldDoFastRopes;
    public static bool Enable;
    public static Vector3 closePosition;
    public static float flySpeed;
    public static Vector3 wallWalkPos;
    public static Vector3 wallWalkNormal;
    public static float lastTimesadsa = -1f;
    public static List<BuilderPiece> oldPieces = (List<BuilderPiece>) null;
    public static Dictionary<VRRig, float> flingTimers = new Dictionary<VRRig, float>();
    public static Dictionary<VRRig, int> flingPhases = new Dictionary<VRRig, int>();
    public static float globalCooldown = 0.0f;
    public static readonly float updateInterval = 0.1f;
    public static float flingEndTime;
    public static float quitGameStartTime;
    public static bool isQuitGameActive = false;
    public static float buttonStartTime = 0.0f;
    public static bool buttonDisabled = false;
    public static float clearTime;
    public static float distanceToFling = 5f;
    public static bool visualizeRadius = false;
    public static Vector3 lastButtonPosition;
    public static GameObject visualizationSphere = (GameObject) null;
    public static bool antiReportvisualizeRadius = false;
    public static GameObject antiReportvisualizationSphere = (GameObject) null;
    public static float antiReportdistanceToFling = 3f;
    public static Vector3 antiReportlastButtonPosition;
    public static bool antiLeavevisualizeRadius = false;
    public static GameObject antiLeavevisualizationSphere = (GameObject) null;
    public static float antiLeavedistanceToFling = 2f;
    public static Vector3 antiLeavelastButtonPosition;
    public static Color Infected = Color.red;
    public static Color NotInfected = Color.green;
    public static bool flingAuravisualizeRadius = false;
    public static GameObject flingAuravisualizationSphere = (GameObject) null;
    public static float flingAuradistanceToFling = 2f;
    public static Vector3 flingAuralastButtonPosition;
    public static bool grabAuravisualizeRadius = false;
    public static GameObject grabAuravisualizationSphere = (GameObject) null;
    public static float grabAuradistanceToFling = 2f;
    public static Vector3 grabAuralastButtonPosition;
    public static bool createAuraGunvisualizeRadius = false;
    public static GameObject createAuraGunvisualizationSphere = (GameObject) null;
    public static float createAuraGundistanceToFling = 2f;
    public static Vector3 createAuraGunlastButtonPosition;
    public static float antiReportCrashdistanceToFling = 0.7f;
    public static float antiLeaveFlingdistanceToFling = 2f;
    public static bool crashOnTouchvisualizeRadius = false;
    public static GameObject crashOnTouchvisualizationSphere = (GameObject) null;
    public static float crashOnTouchdistanceToFling = 0.5f;
    public static Vector3 crashOnTouchlastButtonPosition;
    public static bool crashOnTheirTouchvisualizeRadius = false;
    public static GameObject crashOnTheirTouchvisualizationSphere = (GameObject) null;
    public static float crashOnTheirTouchdistanceToFling = 0.5f;
    public static Vector3 crashOnTheirTouchlastButtonPosition;
    public static bool punchModSSvisualizeRadius = false;
    public static GameObject punchModSSvisualizationSphere = (GameObject) null;
    public static float punchModSSdistanceToFling = 0.5f;
    public static Vector3 punchModSSlastButtonPosition;
    public static bool punchModAllvisualizeRadius = false;
    public static float threshold = 0.35f;
    public static bool smartarp = false;
    public static string rejRoom;
    public static bool hasRemovedThisFrame;

    public static void ReturnHome() => Main.buttonsType = 0;

    public static void SnowballSpam()
    {
      if (!ControllerInputPoller.instance.rightGrab)
        return;
      int projHash = -675036877;
      int trailHash = -1;
      Color white = Color.white;
      Vector3 position = GTPlayer.Instance.rightControllerTransform.position;
      Vector3 averageVelocity = GTPlayer.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(true, 0.0f, false);
      Global.LaunchProjectile(projHash, trailHash, position, averageVelocity, white);
    }

    public static void WaterBallonSpam()
    {
      if (!ControllerInputPoller.instance.rightGrab)
        return;
      int projHash = -1674517839;
      int trailHash = -1;
      Color white = Color.white;
      Vector3 position = GTPlayer.Instance.rightControllerTransform.position;
      Vector3 averageVelocity = GTPlayer.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(true, 0.0f, false);
      Global.LaunchProjectile(projHash, trailHash, position, averageVelocity, white);
    }

    public static void iceSpam()
    {
      if (!ControllerInputPoller.instance.rightGrab)
        return;
      int projHash = -1671677000;
      int trailHash = -1277271056;
      Color white = Color.white;
      Vector3 position = GTPlayer.Instance.rightControllerTransform.position;
      Vector3 averageVelocity = GTPlayer.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(true, 0.0f, false);
      Global.LaunchProjectile(projHash, trailHash, position, averageVelocity, white);
    }

    public static void CloudSpam()
    {
      if (!ControllerInputPoller.instance.rightGrab)
        return;
      int projHash = -1671677000;
      int trailHash = 16948542;
      Color white = Color.white;
      Vector3 position = GTPlayer.Instance.rightControllerTransform.position;
      Vector3 averageVelocity = GTPlayer.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(true, 0.0f, false);
      Global.LaunchProjectile(projHash, trailHash, position, averageVelocity, white);
    }

    public static void CandyCaneSpam()
    {
      if (!ControllerInputPoller.instance.rightGrab)
        return;
      int projHash = -1671677000;
      int trailHash = -1;
      Color white = Color.white;
      Vector3 position = GTPlayer.Instance.rightControllerTransform.position;
      Vector3 averageVelocity = GTPlayer.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(true, 0.0f, false);
      Global.LaunchProjectile(projHash, trailHash, position, averageVelocity, white);
    }

    public static void LaunchProjectile(
      int projHash,
      int trailHash,
      Vector3 pos,
      Vector3 vel,
      Color col)
    {
      SlingshotProjectile component = ObjectPools.instance.Instantiate(projHash).GetComponent<SlingshotProjectile>();
      if (trailHash != -1)
        ObjectPools.instance.Instantiate(trailHash).GetComponent<SlingshotProjectileTrail>().AttachTrail(((Component) component).gameObject, false, false);
      int num1 = 0;
      SlingshotProjectile slingshotProjectile = component;
      Vector3 vector3_1 = pos;
      Vector3 vector3_2 = vel;
      NetPlayer localPlayer = NetworkSystem.Instance.LocalPlayer;
      int num2 = num1;
      int num3 = num2 + 1;
      Color color = col;
      slingshotProjectile.Launch(vector3_1, vector3_2, localPlayer, false, false, num2, 1f, true, color);
    }

    public static void ChangeWallWalk()
    {
      ++Global.change17;
      if (Global.change17 > 3)
        Global.change17 = 1;
      if (Global.change17 == 1)
      {
        Global.Walk = 10f;
        NotifiLib.SendNotification("[<color=blue>WALL WALK STRENGTH</color>] Current Strength: Normal");
      }
      if (Global.change17 == 2)
      {
        Global.Walk = 30f;
        NotifiLib.SendNotification("[<color=blue>WALL WALK STRENGTH</color>] Current Strength: Strong");
      }
      if (Global.change17 != 3)
        return;
      Global.Walk = 5f;
      NotifiLib.SendNotification("[<color=blue>WALL WALK STRENGTH</color>] Current Strength: Weak");
    }

    public static bool Tagged(VRRig rig)
    {
      return ((Object) ((Renderer) rig.mainSkin).material).name.Contains("fected") || ((Object) ((Renderer) rig.mainSkin).material).name.Contains("Ice") || rig.frozenEffect.activeSelf;
    }

    public static VRRig GetVRRigFromPlayer(Player p)
    {
      return GorillaGameManager.instance.FindPlayerVRRig(NetPlayer.op_Implicit(p));
    }

    public static Player GetPlayerFromVRRig(VRRig p) => Global.GetPhotonViewFromVRRig(p).Owner;

    public static NetPlayer GetPlayerFromGun()
    {
      return ((Component) ((RaycastHit) ref Global.raycastHit).collider).GetComponentInParent<VRRig>().OwningNetPlayer;
    }

    public static PhotonView GetPhotonViewFromVRRig(VRRig p)
    {
      return (PhotonView) Traverse.Create((object) p).Field("photonView").GetValue();
    }

    public static VRRig GetOwnVRRig() => GorillaTagger.Instance.offlineVRRig;

    public static NetworkView GetNetworkFromRig(VRRig rig)
    {
      return (NetworkView) Traverse.Create((object) rig).Field("netView").GetValue();
    }

    public static Color ESPColor(VRRig rig)
    {
      Color color;
      if (Global.change9 > 9)
      {
        switch (Global.change9)
        {
          case 10:
            GradientColorKey[] gradientColorKeyArray = new GradientColorKey[7];
            gradientColorKeyArray[0].color = Color.red;
            gradientColorKeyArray[0].time = 0.0f;
            gradientColorKeyArray[1].color = Color.yellow;
            gradientColorKeyArray[1].time = 0.2f;
            gradientColorKeyArray[2].color = Color.green;
            gradientColorKeyArray[2].time = 0.3f;
            gradientColorKeyArray[3].color = Color.cyan;
            gradientColorKeyArray[3].time = 0.5f;
            gradientColorKeyArray[4].color = Color.blue;
            gradientColorKeyArray[4].time = 0.6f;
            gradientColorKeyArray[5].color = Color.magenta;
            gradientColorKeyArray[5].time = 0.8f;
            gradientColorKeyArray[6].color = Color.red;
            gradientColorKeyArray[6].time = 1f;
            Gradient gradient = new Gradient();
            gradient.colorKeys = gradientColorKeyArray;
            float num = Mathf.PingPong(Time.time / 2f, 1f);
            color = gradient.Evaluate(num);
            goto label_9;
          case 11:
            color = rig.playerColor;
            goto label_7;
          case 12:
            color = !Global.Tagged(rig) ? Color32.op_Implicit(new Color32((byte) 0, byte.MaxValue, (byte) 0, (byte) 100)) : Color32.op_Implicit(new Color32(byte.MaxValue, (byte) 0, (byte) 0, (byte) 100));
            break;
          default:
            color = Color.white;
            break;
        }
label_7:;
      }
      else
        color = Global.CurrentESPColor;
label_9:
      return color;
    }

    public static void Speed(float speed) => GTPlayer.Instance.maxJumpSpeed = speed;

    public static void KickMethod(VRRig rig, bool gun)
    {
      if (PhotonNetworkController.Instance.currentJoinTrigger.networkZone.Contains("beach"))
      {
        if (!Global.beach && Global.g4 == 6)
          Global.g4 = 1;
        if (Global.g4 == 3)
          Global.g4 = 1;
        Global.beach = true;
        Global.DelayedAction(8f, (Action) (() =>
        {
          ++Global.g4;
          if (Global.g4 <= 3)
            return;
          Global.g4 = 1;
        }));
        if (Global.g4 == 1)
          Global.DelayedAction1(0.3f, (Action) (() => Global.Throw(rig, new Vector3(50f, 500f, 50f), true, true, gun)));
        if (Global.g4 == 2)
          Global.DelayedAction1(0.3f, (Action) (() =>
          {
            ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = false;
            HandOrbLib.DrawHandOrbs();
            Global.Throw(rig, ((Component) GorillaTagger.Instance.offlineVRRig).transform.position, true, false, gun);
            ((Component) GorillaTagger.Instance.offlineVRRig).transform.position = Vector3.op_Addition(GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Clouds From Computer").transform.position, Global.Random(0.1f));
          }));
        if (Global.g4 != 3)
          return;
        if (!((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled)
          ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = true;
        if (!gun)
          Global.DisableButton("Kick All");
      }
      else
      {
        if (Global.beach && Global.g4 == 3)
          Global.g4 = 1;
        if (Global.g4 == 6)
          Global.g4 = 1;
        Global.beach = false;
        Global.DelayedAction(3f, (Action) (() =>
        {
          ++Global.g4;
          if (Global.g4 <= 6)
            return;
          Global.g4 = 1;
        }));
        if (Global.g4 == 1)
          Global.DelayedAction1(0.3f, (Action) (() => Global.Throw(rig, new Vector3(-50f, 500f, -50f), true, true, gun)));
        if (Global.g4 == 2)
          Global.DelayedAction1(0.3f, (Action) (() => Global.Throw(rig, new Vector3(-10f, 300f, -10f), true, true, gun)));
        if (Global.g4 == 3)
          Global.DelayedAction1(0.3f, (Action) (() => Global.Throw(rig, new Vector3(400f, 100f, 400f), true, true, gun)));
        if (Global.g4 == 4)
          Global.DelayedAction1(0.3f, (Action) (() =>
          {
            ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = false;
            HandOrbLib.DrawHandOrbs();
            Global.Throw(rig, ((Component) GorillaTagger.Instance.offlineVRRig).transform.position, true, false, gun);
            ((Component) GorillaTagger.Instance.offlineVRRig).transform.position = GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Beach for Computer").transform.position;
          }));
        if (Global.g4 == 5)
          Global.DelayedAction1(0.3f, (Action) (() =>
          {
            HandOrbLib.DrawHandOrbs();
            Global.Throw(rig, ((Component) GorillaTagger.Instance.offlineVRRig).transform.position, true, false, gun);
            ((Component) GorillaTagger.Instance.offlineVRRig).transform.position = GameObject.Find("Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Beach for Computer").transform.position;
          }));
        if (Global.g4 == 6)
        {
          if (!((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled)
            ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = true;
          if (!gun)
            Global.DisableButton("Kick All");
        }
      }
    }

    public static void DelayedAction1(float time, Action shit)
    {
      if ((double) Time.time <= (double) Global.delay1)
        return;
      shit();
      Global.delay1 = Time.time + time;
    }

    public static void DelayedAction(float time, Action shit)
    {
      if ((double) Time.time <= (double) Global.delay)
        return;
      shit();
      Global.delay = Time.time + time;
    }

    public static void Throw(VRRig rig, Vector3 t, bool grab, bool drop, bool gun)
    {
      if (gun)
      {
        if (grab && !drop)
          Global.GetNetworkFromRig(rig).SendRPC("GrabbedByPlayer", Global.GetNetworkFromRig(rig).Owner, new object[3]
          {
            (object) true,
            (object) false,
            (object) false
          });
        if (!grab & drop)
          Global.GetNetworkFromRig(rig).SendRPC("DroppedByPlayer", Global.GetNetworkFromRig(rig).Owner, new object[1]
          {
            (object) t
          });
        if (!(grab & drop))
          return;
        Global.GetNetworkFromRig(rig).SendRPC("GrabbedByPlayer", Global.GetNetworkFromRig(rig).Owner, new object[3]
        {
          (object) true,
          (object) false,
          (object) false
        });
        Global.GetNetworkFromRig(rig).SendRPC("DroppedByPlayer", Global.GetNetworkFromRig(rig).Owner, new object[1]
        {
          (object) t
        });
      }
      else
      {
        if (grab && !drop)
          Global.GetNetworkFromRig(rig).SendRPC("GrabbedByPlayer", (RpcTarget) 1, new object[3]
          {
            (object) true,
            (object) false,
            (object) false
          });
        if (!grab & drop)
          Global.GetNetworkFromRig(rig).SendRPC("DroppedByPlayer", (RpcTarget) 1, new object[1]
          {
            (object) t
          });
        if (grab & drop)
        {
          Global.GetNetworkFromRig(rig).SendRPC("GrabbedByPlayer", (RpcTarget) 1, new object[3]
          {
            (object) true,
            (object) false,
            (object) false
          });
          Global.GetNetworkFromRig(rig).SendRPC("DroppedByPlayer", (RpcTarget) 1, new object[1]
          {
            (object) t
          });
        }
      }
    }

    public static Vector3 Random(float dis)
    {
      Vector3[] vector3Array = new Vector3[14]
      {
        new Vector3(dis, 0.0f, 0.0f),
        new Vector3(dis, dis, 0.0f),
        new Vector3(dis, dis, dis),
        new Vector3(dis, 0.0f, dis),
        new Vector3(0.0f, 0.0f, dis),
        new Vector3(0.0f, dis, dis),
        new Vector3(0.0f, dis, 0.0f),
        new Vector3(-dis, 0.0f, 0.0f),
        new Vector3(-dis, -dis, 0.0f),
        new Vector3(-dis, -dis, -dis),
        new Vector3(-dis, 0.0f, -dis),
        new Vector3(0.0f, 0.0f, -dis),
        new Vector3(0.0f, -dis, -dis),
        new Vector3(0.0f, -dis, 0.0f)
      };
      return vector3Array[UnityEngine.Random.Range(0, vector3Array.Length)];
    }

    public static void DisableButton(string name)
    {
      ButtonInfo buttonInfo = new ButtonInfo()
      {
        buttonText = "Im a placeholder",
        method = (Action) (() => Placeholders.Placeholder()),
        disableMethod = (Action) (() => Placeholders.DisablePlaceholder()),
        isTogglable = true,
        toolTip = ""
      };
    }

    public static bool IAmInfected
    {
      get
      {
        return Object.op_Inequality((Object) GorillaTagger.Instance.offlineVRRig, (Object) null) && Global.RigIsInfected((object) Global.taggerInstance.offlineVRRig);
      }
    }

    public static bool RigIsInfected(object offlineVRRig) => throw new NotImplementedException();

    public static void Platform(
      ref GameObject platform,
      bool isGrabbing,
      Transform controllerTransform,
      bool InvisPlat)
    {
      if (isGrabbing)
      {
        if (!Object.op_Equality((Object) platform, (Object) null))
          return;
        platform = GameObject.CreatePrimitive((PrimitiveType) 1);
        platform.transform.localScale = new Vector3(0.28f, 0.015f, 0.28f);
        platform.transform.position = Vector3.op_Addition(controllerTransform.position, new Vector3(0.0f, -0.02f, 0.0f));
        platform.transform.rotation = Quaternion.op_Multiply(controllerTransform.rotation, Quaternion.Euler(0.0f, 0.0f, -90f));
        platform.GetComponent<Renderer>().material.shader = Shader.Find("UI/Default");
        platform.GetComponent<Renderer>().material.color = Color32.op_Implicit(new Color32((byte) 123, (byte) 3, (byte) 252, (byte) 80));
        platform.AddComponent<GorillaSurfaceOverride>().overrideIndex = GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/sky jungle entrance 2/ElevatorClouds/Cloud_Platform_001 Variant").GetComponent<GorillaSurfaceOverride>().overrideIndex;
        if (InvisPlat)
          platform.GetComponent<Renderer>().enabled = false;
      }
      else if (Object.op_Inequality((Object) platform, (Object) null))
      {
        Object.Destroy((Object) platform);
        platform = (GameObject) null;
      }
    }

    public static void Grav(float g) => Physics.gravity = new Vector3(0.0f, g, 0.0f);

    public static void VoidMethod(VRRig rig, bool gun)
    {
      Global.DelayedAction(5f, (Action) (() =>
      {
        ++Global.g3;
        if (Global.g3 <= 4)
          return;
        Global.g3 = 1;
      }));
      if (Global.g3 == 1)
        Global.DelayedAction1(0.3f, (Action) (() => Global.Throw(rig, new Vector3(10f, 500f, 10f), true, true, gun)));
      if (Global.g3 == 2)
      {
        ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = false;
        ((Component) GorillaTagger.Instance.offlineVRRig).transform.position = new Vector3(0.0f, 110f, 0.0f);
        HandOrbLib.DrawHandOrbs();
        Global.DelayedAction1(0.3f, (Action) (() => Global.Throw(rig, ((Component) GorillaTagger.Instance.offlineVRRig).transform.position, true, false, gun)));
      }
      if (Global.g3 == 3)
      {
        HandOrbLib.DrawHandOrbs();
        ((Component) GorillaTagger.Instance.offlineVRRig).transform.position = new Vector3(999f, 999f, 999f);
        Global.DelayedAction1(0.3f, (Action) (() => Global.Throw(rig, ((Component) GorillaTagger.Instance.offlineVRRig).transform.position, true, false, gun)));
      }
      if (Global.g3 != 4)
        return;
      ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = true;
      if (!gun)
        Global.DisableButton("Void All");
    }

    public static void GrabAndDropMethod(VRRig rig, bool grab, bool gun)
    {
      if (grab)
      {
        Global.Throw(rig, new Vector3(0.0f, 0.0f, 0.0f), true, false, gun);
        if (gun)
          return;
        Global.DisableButton("Grab All");
      }
      else
      {
        Global.Throw(rig, new Vector3(0.0f, 0.0f, 0.0f), false, true, gun);
        if (!gun)
          Global.DisableButton("Drop All");
      }
    }

    public static void AppQuitMethod(VRRig rig, bool gun)
    {
      Global.DelayedAction(4.5f, (Action) (() =>
      {
        ++Global.g;
        if (Global.g <= 4)
          return;
        Global.g = 1;
      }));
      if (Global.g == 1)
        Global.DelayedAction1(0.1f, (Action) (() => Global.Throw(rig, new Vector3(50f, 500f, 50f), true, true, gun)));
      if (Global.g == 2)
      {
        ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = false;
        ((Component) GorillaTagger.Instance.offlineVRRig).transform.position = new Vector3(0.0f, 110f, 0.0f);
        HandOrbLib.DrawHandOrbs();
        Global.DelayedAction1(0.1f, (Action) (() => Global.Throw(rig, ((Component) GorillaTagger.Instance.offlineVRRig).transform.position, true, false, gun)));
      }
      if (Global.g == 3)
      {
        HandOrbLib.DrawHandOrbs();
        if (!gun)
        {
          if (Vector3.op_Inequality(((Component) GorillaTagger.Instance.offlineVRRig).transform.position, new Vector3(30f, -400f, 30f)))
            ((Component) GorillaTagger.Instance.offlineVRRig).transform.position = new Vector3(30f, -400f, 30f);
        }
        else if (Vector3.op_Inequality(((Component) GorillaTagger.Instance.offlineVRRig).transform.position, new Vector3(30f, -100f, 30f)))
          ((Component) GorillaTagger.Instance.offlineVRRig).transform.position = new Vector3(30f, -100f, 30f);
        if (!gun)
          Global.DelayedAction1(0.1f, (Action) (() => Global.Throw(rig, ((Component) GorillaTagger.Instance.offlineVRRig).transform.position, true, false, gun)));
        else
          Global.DelayedAction1(0.1f, (Action) (() => Global.Throw(rig, ((Component) GorillaTagger.Instance.offlineVRRig).transform.position, false, true, gun)));
      }
      if (Global.g != 4)
        return;
      if (!((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled)
        ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = true;
      if (!gun)
        Global.DisableButton("App Quit All");
    }

    public static void OnTouchMethod(VRRig rig, Action shit, Action shit1)
    {
      if (rig.isOfflineVRRig)
        return;
      if ((double) Vector3.Distance(rig.rightHandTransform.position, GorillaTagger.Instance.offlineVRRig.head.rigTarget.position) < 0.25)
        shit();
      if ((double) Vector3.Distance(rig.leftHandTransform.position, GorillaTagger.Instance.offlineVRRig.head.rigTarget.position) < 0.25)
        shit1();
    }

    public static void MakeLock()
    {
      if (Global.hand1 || Mouse.current.leftButton.isPressed)
      {
        if (Mouse.current.leftButton.isPressed)
        {
          if (Object.op_Inequality((Object) ((Component) ((RaycastHit) ref Global.raycastHitPC).collider).GetComponentInParent<VRRig>(), (Object) null) && !((Component) ((RaycastHit) ref Global.raycastHitPC).collider).GetComponentInParent<VRRig>().isOfflineVRRig)
            Global.lockedrig = ((Component) ((RaycastHit) ref Global.raycastHitPC).collider).GetComponentInParent<VRRig>();
        }
        else if (Object.op_Inequality((Object) ((Component) ((RaycastHit) ref Global.raycastHit).collider).GetComponentInParent<VRRig>(), (Object) null) && !((Component) ((RaycastHit) ref Global.raycastHit).collider).GetComponentInParent<VRRig>().isOfflineVRRig)
          Global.lockedrig = ((Component) ((RaycastHit) ref Global.raycastHit).collider).GetComponentInParent<VRRig>();
        if (Object.op_Inequality((Object) Global.lockedrig, (Object) null))
        {
          Global.Line.SetPosition(1, ((Component) Global.lockedrig).transform.position);
          Global.pointer.transform.position = ((Component) Global.lockedrig).transform.position;
        }
        else if (Mouse.current.leftButton.isPressed || Mouse.current.rightButton.isPressed)
        {
          Global.Line.SetPosition(1, ((RaycastHit) ref Global.raycastHitPC).point);
          Global.pointer.transform.position = ((RaycastHit) ref Global.raycastHitPC).point;
        }
        else
        {
          Global.Line.SetPosition(1, ((RaycastHit) ref Global.raycastHit).point);
          Global.pointer.transform.position = ((RaycastHit) ref Global.raycastHit).point;
        }
      }
      else if (Mouse.current.rightButton.isPressed)
      {
        Global.Line.SetPosition(1, ((RaycastHit) ref Global.raycastHitPC).point);
        Global.pointer.transform.position = ((RaycastHit) ref Global.raycastHitPC).point;
      }
      else
      {
        Global.Line.SetPosition(1, ((RaycastHit) ref Global.raycastHit).point);
        Global.pointer.transform.position = ((RaycastHit) ref Global.raycastHit).point;
      }
      if (!Object.op_Equality((Object) Global.lockedrig, (Object) null))
        return;
      if (Mouse.current.leftButton.isPressed || Mouse.current.rightButton.isPressed)
      {
        Global.Line.SetPosition(1, ((RaycastHit) ref Global.raycastHitPC).point);
        Global.pointer.transform.position = ((RaycastHit) ref Global.raycastHitPC).point;
      }
      else
      {
        Global.Line.SetPosition(1, ((RaycastHit) ref Global.raycastHit).point);
        Global.pointer.transform.position = ((RaycastHit) ref Global.raycastHit).point;
      }
    }

    public static void GiveUpAndDownMethod(VRRig rig)
    {
      if (rig.isOfflineVRRig)
        return;
      if ((double) ((VRMap) rig.rightIndex).calcT > 0.5)
        Global.Throw(rig, Vector3.op_Multiply(rig.headMesh.transform.up, 30f), true, true, true);
      if ((double) ((VRMap) rig.leftIndex).calcT > 0.5)
        Global.Throw(rig, Vector3.op_Multiply(Vector3.op_UnaryNegation(rig.headMesh.transform.up), 30f), true, true, true);
    }

    public static void GiveFlyMethod(VRRig rig)
    {
      if (rig.isOfflineVRRig || (double) ((VRMap) rig.rightThumb).calcT <= 0.5)
        return;
      Global.Throw(rig, Vector3.op_Multiply(rig.headMesh.transform.forward, 30f), true, true, true);
    }

    public static void GodMode()
    {
      foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
      {
        Global.l += 5f * Time.deltaTime;
        GameObject primitive = GameObject.CreatePrimitive((PrimitiveType) 0);
        primitive.gameObject.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
        Object.Destroy((Object) primitive.gameObject.GetComponent<SphereCollider>());
        primitive.gameObject.GetComponent<Renderer>().material.color = Color32.op_Implicit(Color32.Lerp(new Color32((byte) 123, (byte) 3, (byte) 252, byte.MaxValue), new Color32((byte) 230, (byte) 230, (byte) 250, byte.MaxValue), Mathf.PingPong(Time.time, 1f)));
        float num1 = ((Component) GorillaTagger.Instance.offlineVRRig.headConstraint).transform.position.x + 0.6f * Mathf.Cos(Global.l);
        float num2 = ((Component) GorillaTagger.Instance.offlineVRRig.headConstraint).transform.position.y - 1f;
        float num3 = ((Component) GorillaTagger.Instance.offlineVRRig.headConstraint).transform.position.z + 0.6f * Mathf.Sin(Global.l);
        primitive.gameObject.transform.position = Vector3.op_Addition(Vector3.op_Addition(((Component) vrrig).transform.position, new Vector3(0.6f * Mathf.Cos(Global.l), -1f, 0.6f * Mathf.Sin(Global.l))), new Vector3(0.0f, 1.75f, 0.0f));
        Object.Destroy((Object) new GameObject("Line"), Time.deltaTime);
        Object.Destroy((Object) primitive.gameObject, 0.2f);
      }
    }

    public static void BlueHaloESP()
    {
      foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
      {
        Global.l += 5f * Time.deltaTime;
        GameObject primitive = GameObject.CreatePrimitive((PrimitiveType) 0);
        primitive.gameObject.transform.localScale = new Vector3(0.2f, 0.2f, 0.2f);
        Object.Destroy((Object) primitive.gameObject.GetComponent<SphereCollider>());
        primitive.gameObject.GetComponent<Renderer>().material.color = Color32.op_Implicit(Color32.Lerp(new Color32((byte) 0, (byte) 0, byte.MaxValue, byte.MaxValue), new Color32((byte) 0, (byte) 0, (byte) 128, byte.MaxValue), Mathf.PingPong(Time.time, 1f)));
        float num1 = ((Component) GorillaTagger.Instance.offlineVRRig.headConstraint).transform.position.x + 0.6f * Mathf.Cos(Global.l);
        float num2 = ((Component) GorillaTagger.Instance.offlineVRRig.headConstraint).transform.position.y - 1f;
        float num3 = ((Component) GorillaTagger.Instance.offlineVRRig.headConstraint).transform.position.z + 0.6f * Mathf.Sin(Global.l);
        primitive.gameObject.transform.position = Vector3.op_Addition(Vector3.op_Addition(((Component) vrrig).transform.position, new Vector3(0.6f * Mathf.Cos(Global.l), -1f, 0.6f * Mathf.Sin(Global.l))), new Vector3(0.0f, 1.75f, 0.0f));
        Object.Destroy((Object) new GameObject("Line"), Time.deltaTime);
        Object.Destroy((Object) primitive.gameObject, 0.2f);
      }
    }

    public static void DisableESP()
    {
      foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
      {
        if (Object.op_Inequality((Object) vrrig, (Object) GorillaTagger.Instance.offlineVRRig))
          ((Renderer) vrrig.mainSkin).material.shader = Shader.Find("GorillaTag/UberShader");
      }
    }

    public static void Rain()
    {
      for (int index = 1; index < BetterDayNightManager.instance.weatherCycle.Length; ++index)
        BetterDayNightManager.instance.weatherCycle[index] = (BetterDayNightManager.WeatherType) 1;
    }

    public static void EnableILavaYou()
    {
      GameObject.Find("Environment Objects/LocalObjects_Prefab/Forest/ILavaYou_ForestArt_Prefab/").SetActive(true);
      GameObject.Find("Environment Objects/LocalObjects_Prefab/Forest/ILavaYou_PrefabV/").SetActive(true);
    }

    public static void DayTimeMod() => BetterDayNightManager.instance.SetTimeOfDay(3);

    public static void NightTimeMod() => BetterDayNightManager.instance.SetTimeOfDay(0);

    public static void DisableILavaYou()
    {
      GameObject.Find("Environment Objects/LocalObjects_Prefab/Forest/ILavaYou_ForestArt_Prefab/").SetActive(false);
      GameObject.Find("Environment Objects/LocalObjects_Prefab/Forest/ILavaYou_PrefabV/").SetActive(false);
    }

    public static void BugHalo()
    {
      float num = 0.0f;
      GameObject.Find("Floating Bug Holdable").transform.position = Vector3.op_Addition(((Component) GorillaTagger.Instance.headCollider).transform.position, new Vector3(MathF.Cos(num + (float) Time.frameCount / 30f), 2f, MathF.Sin(num + (float) Time.frameCount / 30f)));
    }

    public static void BatHalo()
    {
      float num = 120f;
      GameObject.Find("Cave Bat Holdable").transform.position = Vector3.op_Addition(((Component) GorillaTagger.Instance.headCollider).transform.position, new Vector3(MathF.Cos(num + (float) Time.frameCount / 30f), 2f, MathF.Sin(num + (float) Time.frameCount / 30f)));
    }

    public static bool IsOtherPlayer(VRRig rig)
    {
      return Object.op_Inequality((Object) rig, (Object) null) && Object.op_Inequality((Object) rig, (Object) Global.taggerInstance.offlineVRRig) && !rig.isOfflineVRRig && !rig.isMyPlayer;
    }

    public static VRRig GetRandomVRRig(bool includeSelf)
    {
      VRRig vrrig = GorillaParent.instance.vrrigs[UnityEngine.Random.Range(0, GorillaParent.instance.vrrigs.Count - 1)];
      return !includeSelf ? (!Object.op_Inequality((Object) vrrig, (Object) GorillaTagger.Instance.offlineVRRig) ? RigManager.GetRandomVRRig(includeSelf) : vrrig) : vrrig;
    }

    public static VRRig GetClosestVRRig()
    {
      float num = float.MaxValue;
      VRRig closestVrRig = (VRRig) null;
      foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
      {
        if ((double) Vector3.Distance(((Component) GorillaTagger.Instance.bodyCollider).transform.position, ((Component) vrrig).transform.position) < (double) num)
        {
          num = Vector3.Distance(((Component) GorillaTagger.Instance.bodyCollider).transform.position, ((Component) vrrig).transform.position);
          closestVrRig = vrrig;
        }
      }
      return closestVrRig;
    }

    public static NetworkView GetNetworkViewFromVRRig(VRRig p)
    {
      return (NetworkView) Traverse.Create((object) p).Field("networkView").GetValue();
    }

    public static Player NetPlayerToPlayer(NetPlayer p) => p.GetPlayerRef();

    public static Player GetPlayerFromID(string id)
    {
      Player playerFromId = (Player) null;
      foreach (Player player in PhotonNetwork.PlayerList)
      {
        if (player.UserId == id)
        {
          playerFromId = player;
          break;
        }
      }
      return playerFromId;
    }

    public static void NoClipButton()
    {
      foreach (MeshCollider meshCollider in Object.FindObjectsOfType<MeshCollider>())
      {
        if (ControllerInputPoller.instance.rightControllerPrimaryButton)
          ((Collider) meshCollider).enabled = false;
        else
          ((Collider) meshCollider).enabled = true;
      }
    }

    public static void Disconnect() => PhotonNetwork.Disconnect();

    public static void Reconnect()
    {
      Global.rejRoom = PhotonNetwork.CurrentRoom.Name;
      PhotonNetwork.Disconnect();
    }

    public class TOSPatch
    {
      public static bool IsEnabled;

      [Global.NullableContext(1)]
      public static bool Prefix(LegalAgreements __instance)
      {
        bool flag;
        if (!Global.TOSPatch.IsEnabled)
        {
          flag = true;
        }
        else
        {
          __instance.TurnPage(999);
          Traverse.Create((object) __instance).Field("controllerBehaviour").Field("buttonDown").SetValue((object) true);
          flag = false;
        }
        return flag;
      }
    }

    internal sealed class NullableContextAttribute : Attribute
    {
      public readonly byte Flag;

      public NullableContextAttribute(byte A_1) => this.Flag = A_1;
    }
  }
}
