﻿// Decompiled with JetBrains decompiler
// Type: FTSyxcalTemplate.Menu.Libs.HandOrbLib
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using UnityEngine;

#nullable disable
namespace FTSyxcalTemplate.Menu.Libs
{
  internal class HandOrbLib
  {
    public static void DrawHandOrbs()
    {
      Global.orb = GameObject.CreatePrimitive((PrimitiveType) 0);
      Global.orb2 = GameObject.CreatePrimitive((PrimitiveType) 0);
      Object.Destroy((Object) Global.orb.GetComponent<SphereCollider>());
      Object.Destroy((Object) Global.orb2.GetComponent<SphereCollider>());
      Global.orb.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
      Global.orb2.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
      Global.orb.transform.position = GorillaTagger.Instance.leftHandTransform.position;
      Global.orb2.transform.position = GorillaTagger.Instance.rightHandTransform.position;
      Global.orb.GetComponent<Renderer>().material.color = Global.CurrentGunColor;
      Global.orb2.GetComponent<Renderer>().material.color = Global.CurrentGunColor;
      Object.Destroy((Object) Global.orb, Time.deltaTime);
      Object.Destroy((Object) Global.orb2, Time.deltaTime);
    }
  }
}
