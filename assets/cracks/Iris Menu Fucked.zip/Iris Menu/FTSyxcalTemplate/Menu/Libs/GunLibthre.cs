﻿// Decompiled with JetBrains decompiler
// Type: FTSyxcalTemplate.Menu.Libs.GunLibthre
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using BepInEx;
using GorillaLocomotion;
using System;
using UnityEngine;
using UnityEngine.XR;

#nullable disable
namespace FTSyxcalTemplate.Menu.Libs
{
  internal class GunLibthre
  {
    private static GameObject pointer;
    private static LineRenderer lr;
    private static GunLibthre.GunLibData data = new GunLibthre.GunLibData(false, false, false, hitpos: new Vector3(), raycastHit: new RaycastHit());

    public static void GunCleanUp()
    {
      if (Object.op_Inequality((Object) GunLibthre.pointer, (Object) null))
      {
        Object.Destroy((Object) GunLibthre.pointer);
        GunLibthre.pointer = (GameObject) null;
      }
      if (Object.op_Inequality((Object) GunLibthre.lr, (Object) null))
      {
        Object.Destroy((Object) ((Component) GunLibthre.lr).gameObject);
        GunLibthre.lr = (LineRenderer) null;
      }
      GunLibthre.data = new GunLibthre.GunLibData(false, false, false, hitpos: new Vector3(), raycastHit: new RaycastHit());
    }

    public static GunLibthre.GunLibData ShootLock()
    {
      try
      {
        return XRSettings.isDeviceActive ? GunLibthre.HandleVRInput() : GunLibthre.HandleNonVRInput();
      }
      catch (Exception ex)
      {
        Debug.LogError((object) string.Format("Error in ShootLock: {0}", (object) ex));
        return (GunLibthre.GunLibData) null;
      }
    }

    private static GunLibthre.GunLibData HandleVRInput()
    {
      Transform controllerTransform = GTPlayer.Instance.rightControllerTransform;
      GunLibthre.data.isShooting = ControllerInputPoller.instance.rightGrab;
      GunLibthre.data.isTriggered = (double) ControllerInputPoller.instance.rightControllerIndexFloat > 0.10000000149011612;
      if (GunLibthre.data.isShooting)
        GunLibthre.HandleShooting(controllerTransform);
      else
        GunLibthre.GunCleanUp();
      return GunLibthre.data;
    }

    private static GunLibthre.GunLibData HandleNonVRInput()
    {
      GunLibthre.data.isShooting = UnityInput.Current.GetMouseButton(1);
      GunLibthre.data.isTriggered = UnityInput.Current.GetMouseButton(0);
      if (GunLibthre.data.isShooting)
        GunLibthre.HandleShootingNonVR();
      else
        GunLibthre.GunCleanUp();
      return GunLibthre.data;
    }

    private static void HandleShooting(Transform rightControllerTransform)
    {
      Renderer component = GunLibthre.pointer?.GetComponent<Renderer>();
      RaycastHit raycastHit;
      if (!Physics.Raycast(Vector3.op_Subtraction(rightControllerTransform.position, rightControllerTransform.up), Vector3.op_UnaryNegation(rightControllerTransform.up), ref raycastHit) || !Object.op_Equality((Object) GunLibthre.pointer, (Object) null))
        return;
      GunLibthre.CreatePointerAndLine(component);
      GunLibthre.UpdateLineRenderer(rightControllerTransform.position, ((RaycastHit) ref raycastHit).point);
      GunLibthre.data.hitPosition = ((RaycastHit) ref raycastHit).point;
      GunLibthre.pointer.transform.position = ((RaycastHit) ref raycastHit).point;
      VRRig componentInParent = ((Component) ((RaycastHit) ref raycastHit).collider).GetComponentInParent<VRRig>();
      if (Object.op_Inequality((Object) componentInParent, (Object) null))
        GunLibthre.HandlePlayerLock(component, componentInParent);
      else
        GunLibthre.SetLineColor(component, Color.red);
    }

    private static void HandleShootingNonVR()
    {
      Renderer component = GunLibthre.pointer?.GetComponent<Renderer>();
      Ray ray = (GameObject.Find("Shoulder Camera").GetComponent<Camera>() ?? GorillaTagger.Instance.mainCamera.GetComponent<Camera>()).ScreenPointToRay(UnityInput.Current.mousePosition);
      RaycastHit raycastHit;
      if (!Physics.Raycast(((Ray) ref ray).origin, ((Ray) ref ray).direction, ref raycastHit) || !Object.op_Equality((Object) GunLibthre.pointer, (Object) null))
        return;
      GunLibthre.CreatePointerAndLine(component);
      GunLibthre.UpdateLineRenderer(((Component) GTPlayer.Instance.headCollider).transform.position, ((RaycastHit) ref raycastHit).point);
      GunLibthre.data.hitPosition = ((RaycastHit) ref raycastHit).point;
      GunLibthre.pointer.transform.position = ((RaycastHit) ref raycastHit).point;
      VRRig componentInParent = ((Component) ((RaycastHit) ref raycastHit).collider).GetComponentInParent<VRRig>();
      if (Object.op_Inequality((Object) componentInParent, (Object) null))
        GunLibthre.HandlePlayerLock(component, componentInParent);
      else
        GunLibthre.SetLineColor(component, Color.red);
    }

    private static void CreatePointerAndLine(Renderer renderer)
    {
      GunLibthre.pointer = GameObject.CreatePrimitive((PrimitiveType) 0);
      Object.Destroy((Object) GunLibthre.pointer.GetComponent<Rigidbody>());
      Object.Destroy((Object) GunLibthre.pointer.GetComponent<SphereCollider>());
      GunLibthre.pointer.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
      renderer = GunLibthre.pointer.GetComponent<Renderer>();
      renderer.material.color = Color.red;
      renderer.material.shader = Shader.Find("Standard");
      if (!Object.op_Equality((Object) GunLibthre.lr, (Object) null))
        return;
      GunLibthre.lr = new GameObject("line").AddComponent<LineRenderer>();
      GunLibthre.lr.endWidth = 0.01f;
      GunLibthre.lr.startWidth = 0.01f;
      ((Renderer) GunLibthre.lr).material = new Material(Shader.Find("Standard"));
    }

    private static void UpdateLineRenderer(Vector3 start, Vector3 end)
    {
      GunLibthre.lr.SetPosition(0, start);
      GunLibthre.lr.SetPosition(1, end);
    }

    private static void HandlePlayerLock(Renderer renderer, VRRig componentInParent)
    {
      if (GunLibthre.data.isTriggered)
      {
        GunLibthre.data.lockedPlayer = componentInParent;
        GunLibthre.data.isLocked = true;
        GunLibthre.SetLineColor(renderer, Color.blue);
      }
      else
      {
        GunLibthre.data.isLocked = false;
        GunLibthre.SetLineColor(renderer, Color.green);
        GorillaTagger.Instance.StartVibration(false, GorillaTagger.Instance.tagHapticStrength / 2f, GorillaTagger.Instance.tagHapticDuration / 2f);
      }
    }

    private static void SetLineColor(Renderer renderer, Color color)
    {
      GunLibthre.lr.startColor = color;
      GunLibthre.lr.endColor = color;
      if (!Object.op_Inequality((Object) renderer, (Object) null))
        return;
      renderer.material.color = color;
    }

    public class GunLibData
    {
      public VRRig lockedPlayer { get; set; }

      public bool isShooting { get; set; }

      public bool isLocked { get; set; }

      public Vector3 hitPosition { get; set; }

      public GameObject hitPointer { get; set; }

      public RaycastHit RaycastHit { get; set; }

      public bool isTriggered { get; set; }

      public GunLibData(
        bool stateTriggered,
        bool triggy,
        bool foundPlayer,
        VRRig player = null,
        Vector3 hitpos = default (Vector3),
        RaycastHit raycastHit = default (RaycastHit))
      {
        this.lockedPlayer = player;
        this.isShooting = stateTriggered;
        this.isLocked = foundPlayer;
        this.hitPosition = hitpos;
        this.isTriggered = triggy;
        this.RaycastHit = raycastHit;
      }
    }
  }
}
