﻿// Decompiled with JetBrains decompiler
// Type: FTSyxcalTemplate.Menu.Libs.GunLib
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using BepInEx;
using GorillaLocomotion;
using System;
using UnityEngine;
using UnityEngine.InputSystem;

#nullable disable
namespace FTSyxcalTemplate.Menu.Libs
{
  internal class GunLib
  {
    public static GameObject Pointer = (GameObject) null;
    public static Material color = new Material(Shader.Find("GorillaTag/UberShader"));
    public static VRRig locked = (VRRig) null;
    public static RaycastHit Hitinfo;
    public static Vector3 lr;
    public static bool isWiggling = true;
    public static VRRig lockedTargetRig;
    public static VRRig potentialTargetRig;
    public static GameObject lineFollow = (GameObject) null;
    public static LineRenderer lineRenderer = (LineRenderer) null;
    public static Material lineMaterial = (Material) null;
    public static GameObject gunPointer = (GameObject) null;
    public static RaycastHit raycastHit;
    private const float WiggleSpeed = 7.5f;
    private const float WiggleAmplitude = 0.05f;
    private const int LineSegments = 50;

    public static void Gun(Action gunaction, bool Locker)
    {
      if (Locker)
      {
        if (ControllerInputPoller.instance.rightGrab)
        {
          Physics.Raycast(Vector3.op_Subtraction(GTPlayer.Instance.rightControllerTransform.position, GTPlayer.Instance.rightControllerTransform.up), Vector3.op_UnaryNegation(GTPlayer.Instance.rightControllerTransform.up), ref GunLib.Hitinfo);
          GunLib.color.color = Color.red;
          GunLib.Pointer = GameObject.CreatePrimitive((PrimitiveType) 0);
          GunLib.Pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
          Object.Destroy((Object) GunLib.Pointer.GetComponent<SphereCollider>());
          Object.Destroy((Object) GunLib.Pointer.GetComponent<Rigidbody>());
          GunLib.Pointer.GetComponent<Renderer>().material = GunLib.color;
          GunLib.Pointer.transform.localScale = new Vector3(0.14f, 0.14f, 0.14f);
          GunLib.Pointer.transform.position = ((RaycastHit) ref GunLib.Hitinfo).point;
          Object.Destroy((Object) GunLib.Pointer, Time.deltaTime);
          GameObject gameObject = new GameObject("Line");
          LineRenderer lineRenderer = gameObject.AddComponent<LineRenderer>();
          ((Renderer) lineRenderer).material.shader = Shader.Find("GUI/Text Shader");
          lineRenderer.startColor = Color.red;
          lineRenderer.endColor = Color.red;
          lineRenderer.startWidth = 0.01f;
          lineRenderer.endWidth = 0.01f;
          lineRenderer.positionCount = 2;
          lineRenderer.useWorldSpace = true;
          lineRenderer.SetPosition(0, GorillaTagger.Instance.rightHandTransform.position);
          lineRenderer.SetPosition(1, ((RaycastHit) ref GunLib.Hitinfo).point);
          Object.Destroy((Object) gameObject, Time.deltaTime);
          if (Object.op_Equality((Object) GunLib.locked, (Object) null))
          {
            GunLib.color.color = Color.red;
            lineRenderer.startColor = Color.red;
            lineRenderer.endColor = Color.red;
            GunLib.Pointer.transform.position = ((RaycastHit) ref GunLib.Hitinfo).point;
            lineRenderer.SetPosition(1, ((RaycastHit) ref GunLib.Hitinfo).point);
          }
          else
          {
            GunLib.color.color = Color.green;
            lineRenderer.startColor = Color.green;
            lineRenderer.endColor = Color.green;
            GunLib.Pointer.transform.position = ((Component) GunLib.locked).transform.position;
            lineRenderer.SetPosition(1, ((Component) GunLib.locked).transform.position);
          }
          if ((double) ControllerInputPoller.instance.rightControllerIndexFloat > 0.0 && Object.op_Inequality((Object) GunLib.locked, (Object) null))
          {
            if (gunaction != null)
            {
              try
              {
                gunaction();
              }
              catch
              {
              }
            }
          }
          if ((double) ControllerInputPoller.instance.rightControllerIndexFloat <= 0.0 || !Object.op_Equality((Object) GunLib.locked, (Object) null) || !Object.op_Implicit((Object) ((Component) ((RaycastHit) ref GunLib.Hitinfo).collider).GetComponentInParent<VRRig>()))
            return;
          GunLib.locked = ((Component) ((RaycastHit) ref GunLib.Hitinfo).collider).GetComponentInParent<VRRig>();
        }
        else
        {
          Object.Destroy((Object) GunLib.Pointer);
          ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = true;
          GunLib.locked = (VRRig) null;
          GunLib.Pointer = (GameObject) null;
        }
      }
      else if (ControllerInputPoller.instance.rightGrab)
      {
        Physics.Raycast(Vector3.op_Subtraction(GTPlayer.Instance.rightControllerTransform.position, GTPlayer.Instance.rightControllerTransform.up), Vector3.op_UnaryNegation(GTPlayer.Instance.rightControllerTransform.up), ref GunLib.Hitinfo);
        GunLib.color.color = SigmaColor.SigmaColor.black;
        GunLib.Pointer = GameObject.CreatePrimitive((PrimitiveType) 0);
        GunLib.Pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
        Object.Destroy((Object) GunLib.Pointer.GetComponent<SphereCollider>());
        Object.Destroy((Object) GunLib.Pointer.GetComponent<Rigidbody>());
        GunLib.Pointer.GetComponent<Renderer>().material = GunLib.color;
        GunLib.Pointer.transform.localScale = new Vector3(0.14f, 0.14f, 0.14f);
        GunLib.Pointer.transform.position = ((RaycastHit) ref GunLib.Hitinfo).point;
        Object.Destroy((Object) GunLib.Pointer, Time.deltaTime);
        GameObject gameObject = new GameObject("Line");
        LineRenderer lineRenderer = gameObject.AddComponent<LineRenderer>();
        ((Renderer) lineRenderer).material.shader = Shader.Find("GUI/Text Shader");
        lineRenderer.startColor = SigmaColor.SigmaColor.black;
        lineRenderer.endColor = SigmaColor.SigmaColor.black;
        lineRenderer.startWidth = 0.01f;
        lineRenderer.endWidth = 0.01f;
        lineRenderer.positionCount = 2;
        lineRenderer.useWorldSpace = true;
        lineRenderer.SetPosition(0, GorillaTagger.Instance.rightHandTransform.position);
        lineRenderer.SetPosition(1, ((RaycastHit) ref GunLib.Hitinfo).point);
        Object.Destroy((Object) gameObject, Time.deltaTime);
        if ((double) ControllerInputPoller.instance.rightControllerIndexFloat > 0.0)
        {
          if (gunaction != null)
          {
            try
            {
              gunaction();
            }
            catch
            {
            }
          }
        }
      }
      else
      {
        Object.Destroy((Object) GunLib.Pointer);
        ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = true;
        GunLib.Pointer = (GameObject) null;
        GunLib.locked = (VRRig) null;
      }
    }

    public static void Gun2(Action gunaction)
    {
      if (ControllerInputPoller.instance.rightGrab)
      {
        Physics.Raycast(Vector3.op_Subtraction(GTPlayer.Instance.rightControllerTransform.position, GTPlayer.Instance.rightControllerTransform.up), Vector3.op_UnaryNegation(GTPlayer.Instance.rightControllerTransform.up), ref GunLib.Hitinfo);
        GunLib.color.color = Color.red;
        GunLib.Pointer = GameObject.CreatePrimitive((PrimitiveType) 0);
        GunLib.Pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
        Object.Destroy((Object) GunLib.Pointer.GetComponent<SphereCollider>());
        Object.Destroy((Object) GunLib.Pointer.GetComponent<Rigidbody>());
        GunLib.Pointer.GetComponent<Renderer>().material = GunLib.color;
        GunLib.Pointer.transform.localScale = new Vector3(0.14f, 0.14f, 0.14f);
        GunLib.Pointer.transform.position = ((RaycastHit) ref GunLib.Hitinfo).point;
        Object.Destroy((Object) GunLib.Pointer, Time.deltaTime);
        GameObject gameObject = new GameObject("Line");
        LineRenderer lineRenderer = gameObject.AddComponent<LineRenderer>();
        ((Renderer) lineRenderer).material.shader = Shader.Find("GUI/Text Shader");
        lineRenderer.startColor = Color.red;
        lineRenderer.endColor = Color.red;
        lineRenderer.startWidth = 0.01f;
        lineRenderer.endWidth = 0.01f;
        lineRenderer.positionCount = 2;
        lineRenderer.useWorldSpace = true;
        lineRenderer.SetPosition(0, GorillaTagger.Instance.rightHandTransform.position);
        lineRenderer.SetPosition(1, ((RaycastHit) ref GunLib.Hitinfo).point);
        Object.Destroy((Object) gameObject, Time.deltaTime);
        if ((double) ControllerInputPoller.instance.rightControllerIndexFloat > 0.0)
        {
          GunLib.color.color = Color.green;
          lineRenderer.startColor = Color.green;
          lineRenderer.endColor = Color.green;
          if (gunaction == null)
            return;
          try
          {
            gunaction();
          }
          catch
          {
          }
        }
        else
        {
          GunLib.color.color = Color.red;
          lineRenderer.startColor = Color.red;
          lineRenderer.endColor = Color.red;
        }
      }
      else
      {
        Object.Destroy((Object) GunLib.Pointer);
        ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = true;
        GunLib.Pointer = (GameObject) null;
      }
    }

    public static void StartPcGun(Action action, bool LockOn)
    {
      Ray ray = GameObject.Find("Shoulder Camera").activeSelf ? GameObject.Find("Shoulder Camera").GetComponent<Camera>().ScreenPointToRay(UnityInput.Current.mousePosition) : GorillaTagger.Instance.mainCamera.GetComponent<Camera>().ScreenPointToRay(UnityInput.Current.mousePosition);
      if (Mouse.current.rightButton.isPressed)
      {
        RaycastHit raycastHit;
        if (Physics.Raycast(((Ray) ref ray).origin, ((Ray) ref ray).direction, ref raycastHit, float.PositiveInfinity, -32777) && Object.op_Equality((Object) GunLib.Pointer, (Object) null) && Object.op_Equality((Object) GunLib.Pointer, (Object) null))
        {
          GunLib.Pointer = GameObject.CreatePrimitive((PrimitiveType) 0);
          GunLib.Pointer.AddComponent<Renderer>();
          GunLib.Pointer.transform.localScale = new Vector3(0.15f, 0.15f, 0.15f);
          GunLib.Pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
          Object.Destroy((Object) GunLib.Pointer.GetComponent<BoxCollider>());
          Object.Destroy((Object) GunLib.Pointer.GetComponent<Rigidbody>());
          Object.Destroy((Object) GunLib.Pointer.GetComponent<Collider>());
          GunLib.lr = GorillaTagger.Instance.offlineVRRig.rightHandTransform.position;
        }
        if (Object.op_Equality((Object) GunLib.locked, (Object) null))
        {
          GunLib.Pointer.transform.position = ((RaycastHit) ref raycastHit).point;
          GunLib.Pointer.GetComponent<Renderer>().material.color = Color.black;
        }
        else
          GunLib.Pointer.transform.position = ((Component) GunLib.locked).transform.position;
        GunLib.lr = Vector3.Lerp(GunLib.lr, Vector3.op_Division(Vector3.op_Addition(GorillaTagger.Instance.rightHandTransform.position, GunLib.Pointer.transform.position), 2f), Time.deltaTime * 6f);
        LineRenderer lineRenderer = new GameObject("Line").AddComponent<LineRenderer>();
        lineRenderer.startWidth = 0.025f;
        lineRenderer.endWidth = 0.025f;
        lineRenderer.startColor = Color.black;
        lineRenderer.endColor = Color.black;
        lineRenderer.useWorldSpace = true;
        ((Renderer) lineRenderer).material = new Material(Shader.Find("GUI/Text Shader"));
        Object.Destroy((Object) lineRenderer, Time.deltaTime);
        if (Mouse.current.leftButton.isPressed)
        {
          lineRenderer.startColor = Color.black;
          lineRenderer.endColor = Color.black;
          GunLib.Pointer.GetComponent<Renderer>().material.color = Color.black;
          if (LockOn)
          {
            if (Object.op_Equality((Object) GunLib.locked, (Object) null))
              GunLib.locked = ((Component) ((RaycastHit) ref raycastHit).collider).GetComponentInParent<VRRig>();
            if (!Object.op_Inequality((Object) GunLib.locked, (Object) null))
              return;
            GunLib.Pointer.transform.position = ((Component) GunLib.locked).transform.position;
            action();
          }
          else
            action();
        }
        else if (Object.op_Inequality((Object) GunLib.locked, (Object) null))
          GunLib.locked = (VRRig) null;
      }
      else if (Object.op_Inequality((Object) GunLib.Pointer, (Object) null))
      {
        Object.Destroy((Object) GunLib.Pointer);
        GunLib.Pointer = (GameObject) null;
        GunLib.locked = (VRRig) null;
      }
    }
  }
}
