﻿// Decompiled with JetBrains decompiler
// Type: FTSyxcalTemplate.Menu.Libs.GunLibary
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using GorillaLocomotion;
using System;
using UnityEngine;

#nullable disable
namespace FTSyxcalTemplate.Menu.Libs
{
  internal class GunLibary
  {
    public static GameObject Pointer = (GameObject) null;
    public static Material color = new Material(Shader.Find("GorillaTag/UberShader"));
    public static VRRig locked = (VRRig) null;
    public static RaycastHit Hitinfo;

    public static void GunLib(Action gunAction, bool locker)
    {
      if (locker)
      {
        if (ControllerInputPoller.instance.rightGrab)
        {
          Physics.Raycast(Vector3.op_Subtraction(GTPlayer.Instance.rightControllerTransform.position, GTPlayer.Instance.rightControllerTransform.up), Vector3.op_UnaryNegation(GTPlayer.Instance.rightControllerTransform.up), ref GunLibary.Hitinfo);
          GunLibary.color.color = Color.red;
          GunLibary.Pointer = GameObject.CreatePrimitive((PrimitiveType) 0);
          GunLibary.Pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
          Object.Destroy((Object) GunLibary.Pointer.GetComponent<SphereCollider>());
          Object.Destroy((Object) GunLibary.Pointer.GetComponent<Rigidbody>());
          GunLibary.Pointer.GetComponent<Renderer>().material = GunLibary.color;
          GunLibary.Pointer.transform.localScale = new Vector3(0.14f, 0.14f, 0.14f);
          GunLibary.Pointer.transform.position = ((RaycastHit) ref GunLibary.Hitinfo).point;
          Object.Destroy((Object) GunLibary.Pointer, Time.deltaTime);
          GameObject gameObject = new GameObject("Line");
          LineRenderer lineRenderer = gameObject.AddComponent<LineRenderer>();
          ((Renderer) lineRenderer).material.shader = Shader.Find("GUI/Text Shader");
          lineRenderer.startColor = Color.red;
          lineRenderer.endColor = Color.red;
          lineRenderer.startWidth = 0.01f;
          lineRenderer.endWidth = 0.01f;
          lineRenderer.positionCount = 2;
          lineRenderer.useWorldSpace = true;
          lineRenderer.SetPosition(0, GorillaTagger.Instance.rightHandTransform.position);
          lineRenderer.SetPosition(1, ((RaycastHit) ref GunLibary.Hitinfo).point);
          Object.Destroy((Object) gameObject, Time.deltaTime);
          if (Object.op_Equality((Object) GunLibary.locked, (Object) null))
          {
            GunLibary.color.color = Color.red;
            lineRenderer.startColor = Color.red;
            lineRenderer.endColor = Color.red;
            GunLibary.Pointer.transform.position = ((RaycastHit) ref GunLibary.Hitinfo).point;
            lineRenderer.SetPosition(1, ((RaycastHit) ref GunLibary.Hitinfo).point);
          }
          else
          {
            GunLibary.color.color = Color.green;
            lineRenderer.startColor = Color.green;
            lineRenderer.endColor = Color.green;
            GunLibary.Pointer.transform.position = ((Component) GunLibary.locked).transform.position;
            lineRenderer.SetPosition(1, ((Component) GunLibary.locked).transform.position);
          }
          if ((double) ControllerInputPoller.instance.rightControllerIndexFloat > 0.0 && Object.op_Inequality((Object) GunLibary.locked, (Object) null) && gunAction != null)
            gunAction();
          if ((double) ControllerInputPoller.instance.rightControllerIndexFloat <= 0.0 || !Object.op_Equality((Object) GunLibary.locked, (Object) null) || !Object.op_Implicit((Object) ((Component) ((RaycastHit) ref GunLibary.Hitinfo).collider).GetComponentInParent<VRRig>()))
            return;
          GunLibary.locked = ((Component) ((RaycastHit) ref GunLibary.Hitinfo).collider).GetComponentInParent<VRRig>();
        }
        else
        {
          Object.Destroy((Object) GunLibary.Pointer);
          ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = true;
          GunLibary.locked = (VRRig) null;
          GunLibary.Pointer = (GameObject) null;
        }
      }
      else if (ControllerInputPoller.instance.rightGrab)
      {
        Physics.Raycast(Vector3.op_Subtraction(GTPlayer.Instance.rightControllerTransform.position, GTPlayer.Instance.rightControllerTransform.up), Vector3.op_UnaryNegation(GTPlayer.Instance.rightControllerTransform.up), ref GunLibary.Hitinfo);
        GunLibary.color.color = Color.black;
        GunLibary.Pointer = GameObject.CreatePrimitive((PrimitiveType) 0);
        GunLibary.Pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
        Object.Destroy((Object) GunLibary.Pointer.GetComponent<SphereCollider>());
        Object.Destroy((Object) GunLibary.Pointer.GetComponent<Rigidbody>());
        GunLibary.Pointer.GetComponent<Renderer>().material = GunLibary.color;
        GunLibary.Pointer.transform.localScale = new Vector3(0.14f, 0.14f, 0.14f);
        GunLibary.Pointer.transform.position = ((RaycastHit) ref GunLibary.Hitinfo).point;
        Object.Destroy((Object) GunLibary.Pointer, Time.deltaTime);
        GameObject gameObject = new GameObject("Line");
        LineRenderer lineRenderer = gameObject.AddComponent<LineRenderer>();
        ((Renderer) lineRenderer).material.shader = Shader.Find("GUI/Text Shader");
        lineRenderer.startColor = Color.black;
        lineRenderer.endColor = Color.black;
        lineRenderer.startWidth = 0.01f;
        lineRenderer.endWidth = 0.01f;
        lineRenderer.positionCount = 2;
        lineRenderer.useWorldSpace = true;
        lineRenderer.SetPosition(0, GorillaTagger.Instance.rightHandTransform.position);
        lineRenderer.SetPosition(1, ((RaycastHit) ref GunLibary.Hitinfo).point);
        Object.Destroy((Object) gameObject, Time.deltaTime);
        if ((double) ControllerInputPoller.instance.rightControllerIndexFloat > 0.0)
        {
          GunLibary.color.color = Color.green;
          lineRenderer.startColor = Color.green;
          lineRenderer.endColor = Color.green;
          if (gunAction != null)
            gunAction();
        }
        else
        {
          GunLibary.color.color = Color.red;
          lineRenderer.startColor = Color.red;
          lineRenderer.endColor = Color.red;
        }
      }
      else
      {
        Object.Destroy((Object) GunLibary.Pointer);
        ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = true;
        GunLibary.Pointer = (GameObject) null;
        GunLibary.locked = (VRRig) null;
      }
    }

    public static void Gun2(Action gunAction)
    {
      if (ControllerInputPoller.instance.rightGrab)
      {
        Physics.Raycast(Vector3.op_Subtraction(GTPlayer.Instance.rightControllerTransform.position, GTPlayer.Instance.rightControllerTransform.up), Vector3.op_UnaryNegation(GTPlayer.Instance.rightControllerTransform.up), ref GunLibary.Hitinfo);
        GunLibary.color.color = Color.red;
        GunLibary.Pointer = GameObject.CreatePrimitive((PrimitiveType) 0);
        GunLibary.Pointer.GetComponent<Renderer>().material.shader = Shader.Find("GUI/Text Shader");
        Object.Destroy((Object) GunLibary.Pointer.GetComponent<SphereCollider>());
        Object.Destroy((Object) GunLibary.Pointer.GetComponent<Rigidbody>());
        GunLibary.Pointer.GetComponent<Renderer>().material = GunLibary.color;
        GunLibary.Pointer.transform.localScale = new Vector3(0.14f, 0.14f, 0.14f);
        GunLibary.Pointer.transform.position = ((RaycastHit) ref GunLibary.Hitinfo).point;
        Object.Destroy((Object) GunLibary.Pointer, Time.deltaTime);
        GameObject gameObject = new GameObject("Line");
        LineRenderer lineRenderer = gameObject.AddComponent<LineRenderer>();
        ((Renderer) lineRenderer).material.shader = Shader.Find("GUI/Text Shader");
        lineRenderer.startColor = Color.red;
        lineRenderer.endColor = Color.red;
        lineRenderer.startWidth = 0.01f;
        lineRenderer.endWidth = 0.01f;
        lineRenderer.positionCount = 2;
        lineRenderer.useWorldSpace = true;
        lineRenderer.SetPosition(0, GorillaTagger.Instance.rightHandTransform.position);
        lineRenderer.SetPosition(1, ((RaycastHit) ref GunLibary.Hitinfo).point);
        Object.Destroy((Object) gameObject, Time.deltaTime);
        if ((double) ControllerInputPoller.instance.rightControllerIndexFloat > 0.0)
        {
          GunLibary.color.color = Color.green;
          lineRenderer.startColor = Color.green;
          lineRenderer.endColor = Color.green;
          if (gunAction == null)
            return;
          gunAction();
        }
        else
        {
          GunLibary.color.color = Color.red;
          lineRenderer.startColor = Color.red;
          lineRenderer.endColor = Color.red;
        }
      }
      else
      {
        Object.Destroy((Object) GunLibary.Pointer);
        ((Behaviour) GorillaTagger.Instance.offlineVRRig).enabled = true;
        GunLibary.Pointer = (GameObject) null;
      }
    }
  }
}
