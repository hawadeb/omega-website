﻿// Decompiled with JetBrains decompiler
// Type: Libs.TimedBehaviour
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using UnityEngine;

#nullable disable
namespace Libs
{
  public class TimedBehaviour : MonoBehaviour
  {
    public bool complete = false;
    public bool loop = true;
    public float progress = 0.0f;
    protected bool paused = false;
    protected float startTime;
    protected float duration = 2f;

    public virtual void Start() => this.startTime = Time.time;

    public virtual void Update()
    {
      if (this.complete)
        return;
      this.progress = Mathf.Clamp((Time.time - this.startTime) / this.duration, 0.0f, 1f);
      if ((double) Time.time - (double) this.startTime > (double) this.duration)
      {
        if (this.loop)
          this.OnLoop();
        else
          this.complete = true;
      }
    }

    public virtual void OnLoop() => this.startTime = Time.time;
  }
}
