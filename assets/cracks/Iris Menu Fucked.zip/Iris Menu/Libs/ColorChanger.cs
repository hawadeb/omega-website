﻿// Decompiled with JetBrains decompiler
// Type: Libs.ColorChanger
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using UnityEngine;

#nullable disable
namespace Libs
{
  public class ColorChanger : TimedBehaviour
  {
    public Renderer gameObjectRenderer;
    public Gradient colors = (Gradient) null;
    public Color color;
    public bool timeBased = true;

    public override void Start()
    {
      base.Start();
      if (!Object.op_Inequality((Object) ((Component) this).GetComponent<Renderer>(), (Object) null))
        return;
      this.gameObjectRenderer = ((Component) this).GetComponent<Renderer>();
    }

    public override void Update()
    {
      base.Update();
      if (this.colors == null)
        return;
      if (this.timeBased)
        this.color = this.colors.Evaluate(this.progress);
      this.gameObjectRenderer.material.color = this.color;
      this.gameObjectRenderer.material.SetColor("_EmissionColor", this.color);
    }
  }
}
