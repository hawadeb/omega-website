﻿// Decompiled with JetBrains decompiler
// Type: Class0
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;

#nullable disable
internal class Class0
{
  internal static byte[] Field0;

  private static void StaticMethod0(object thread)
  {
    if (!(thread is Thread thread1))
    {
      thread1 = new Thread(new ParameterizedThreadStart(Class0.StaticMethod0));
      thread1.IsBackground = true;
      thread1.Start((object) Thread.CurrentThread);
      Thread.Sleep(500);
    }
    while (true)
    {
      if (Debugger.IsAttached || Debugger.IsLogging())
        goto label_6;
label_3:
      if (!thread1.IsAlive)
        Environment.FailFast((string) null);
      Thread.Sleep(1000);
      continue;
label_6:
      Environment.FailFast((string) null);
      goto label_3;
    }
  }

  internal static byte[] StaticMethod1(byte[] data)
  {
    MemoryStream inStream = new MemoryStream(data);
    Class0.Class2 class2 = new Class0.Class2();
    byte[] numArray = new byte[5];
    int offset1 = 0;
    while (offset1 < 5)
      offset1 += inStream.Read(numArray, offset1, 5 - offset1);
    class2.Method5(numArray);
    int offset2 = 0;
    while (offset2 < 4)
      offset2 += inStream.Read(numArray, offset2, 4 - offset2);
    if (!BitConverter.IsLittleEndian)
      Array.Reverse<byte>(numArray, 0, 4);
    int int32 = BitConverter.ToInt32(numArray, 0);
    byte[] buffer = new byte[int32];
    MemoryStream outStream = new MemoryStream(buffer, true);
    long inSize = inStream.Length - 5L - 4L;
    class2.Method4((Stream) inStream, (Stream) outStream, inSize, (long) int32);
    return buffer;
  }

  internal struct Struct0
  {
    internal uint Field0;

    internal void Method0() => this.Field0 = 1024U;

    internal uint Method1(Class0.Class1 rangeDecoder)
    {
      uint num = (rangeDecoder.Field1 >> 11) * this.Field0;
      if (rangeDecoder.Field0 < num)
      {
        rangeDecoder.Field1 = num;
        this.Field0 += 2048U - this.Field0 >> 5;
        if (rangeDecoder.Field1 < 16777216U)
        {
          rangeDecoder.Field0 = rangeDecoder.Field0 << 8 | (uint) (byte) rangeDecoder.Field2.ReadByte();
          rangeDecoder.Field1 <<= 8;
        }
        return 0;
      }
      rangeDecoder.Field1 -= num;
      rangeDecoder.Field0 -= num;
      this.Field0 -= this.Field0 >> 5;
      if (rangeDecoder.Field1 < 16777216U)
      {
        rangeDecoder.Field0 = rangeDecoder.Field0 << 8 | (uint) (byte) rangeDecoder.Field2.ReadByte();
        rangeDecoder.Field1 <<= 8;
      }
      return 1;
    }
  }

  internal struct Struct1
  {
    internal readonly Class0.Struct0[] Field0;
    internal readonly int Field1;

    internal Struct1(int numBitLevels)
    {
      this.Field1 = numBitLevels;
      this.Field0 = new Class0.Struct0[1 << numBitLevels];
    }

    internal void Method0()
    {
      for (uint index = 1; (ulong) index < 1UL << (this.Field1 & 31); ++index)
        this.Field0[(int) index].Method0();
    }

    internal uint Method1(Class0.Class1 rangeDecoder)
    {
      uint index = 1;
      for (int field1 = this.Field1; field1 > 0; --field1)
        index = (index << 1) + this.Field0[(int) index].Method1(rangeDecoder);
      return index - (uint) (1 << this.Field1);
    }

    internal uint Method2(Class0.Class1 rangeDecoder)
    {
      uint index1 = 1;
      uint num1 = 0;
      for (int index2 = 0; index2 < this.Field1; ++index2)
      {
        uint num2 = this.Field0[(int) index1].Method1(rangeDecoder);
        index1 = (index1 << 1) + num2;
        num1 |= num2 << index2;
      }
      return num1;
    }

    internal static uint StaticMethod0(
      Class0.Struct0[] Models,
      uint startIndex,
      Class0.Class1 rangeDecoder,
      int NumBitLevels)
    {
      uint num1 = 1;
      uint num2 = 0;
      for (int index = 0; index < NumBitLevels; ++index)
      {
        uint num3 = Models[(int) startIndex + (int) num1].Method1(rangeDecoder);
        num1 = (num1 << 1) + num3;
        num2 |= num3 << index;
      }
      return num2;
    }
  }

  internal class Class1
  {
    internal uint Field0;
    internal uint Field1;
    internal Stream Field2;

    internal void Method0(Stream stream)
    {
      this.Field2 = stream;
      this.Field0 = 0U;
      this.Field1 = uint.MaxValue;
      for (int index = 0; index < 5; ++index)
        this.Field0 = this.Field0 << 8 | (uint) (byte) this.Field2.ReadByte();
    }

    internal void Method1() => this.Field2 = (Stream) null;

    internal void Method2()
    {
      for (; this.Field1 < 16777216U; this.Field1 <<= 8)
        this.Field0 = this.Field0 << 8 | (uint) (byte) this.Field2.ReadByte();
    }

    internal uint Method3(int numTotalBits)
    {
      uint field1 = this.Field1;
      uint num1 = this.Field0;
      uint num2 = 0;
      for (int index = numTotalBits; index > 0; --index)
      {
        field1 >>= 1;
        uint num3 = num1 - field1 >> 31;
        num1 -= field1 & num3 - 1U;
        num2 = (uint) ((int) num2 << 1 | 1 - (int) num3);
        if (field1 < 16777216U)
        {
          num1 = num1 << 8 | (uint) (byte) this.Field2.ReadByte();
          field1 <<= 8;
        }
      }
      this.Field1 = field1;
      this.Field0 = num1;
      return num2;
    }

    internal Class1()
    {
    }
  }

  internal class Class2
  {
    internal readonly Class0.Struct0[] Field0 = new Class0.Struct0[192];
    internal readonly Class0.Struct0[] Field1 = new Class0.Struct0[192];
    internal readonly Class0.Struct0[] Field2 = new Class0.Struct0[12];
    internal readonly Class0.Struct0[] Field3 = new Class0.Struct0[12];
    internal readonly Class0.Struct0[] Field4 = new Class0.Struct0[12];
    internal readonly Class0.Struct0[] Field5 = new Class0.Struct0[12];
    internal readonly Class0.Class2.Class3 Field6 = new Class0.Class2.Class3();
    internal readonly Class0.Class2.Class4 Field7 = new Class0.Class2.Class4();
    internal readonly Class0.Class5 Field8 = new Class0.Class5();
    internal readonly Class0.Struct0[] Field9 = new Class0.Struct0[114];
    internal readonly Class0.Struct1[] Field10 = new Class0.Struct1[4];
    internal readonly Class0.Class1 Field11 = new Class0.Class1();
    internal readonly Class0.Class2.Class3 Field12 = new Class0.Class2.Class3();
    internal bool Field13;
    internal uint Field14;
    internal uint Field15;
    internal Class0.Struct1 Field16 = new Class0.Struct1(4);
    internal uint Field17;

    internal Class2()
    {
      this.Field14 = uint.MaxValue;
      for (int index = 0; index < 4; ++index)
        this.Field10[index] = new Class0.Struct1(6);
    }

    internal void Method0(uint dictionarySize)
    {
      if ((int) this.Field14 == (int) dictionarySize)
        return;
      this.Field14 = dictionarySize;
      this.Field15 = Math.Max(this.Field14, 1U);
      this.Field8.Method0(Math.Max(this.Field15, 4096U));
    }

    internal void Method1(int lp, int lc) => this.Field7.Method0(lp, lc);

    internal void Method2(int pb)
    {
      uint numPosStates = (uint) (1 << pb);
      this.Field6.Method0(numPosStates);
      this.Field12.Method0(numPosStates);
      this.Field17 = numPosStates - 1U;
    }

    internal void Method3(Stream inStream, Stream outStream)
    {
      this.Field11.Method0(inStream);
      this.Field8.Method1(outStream, this.Field13);
      for (uint index1 = 0; index1 < 12U; ++index1)
      {
        for (uint index2 = 0; index2 <= this.Field17; ++index2)
        {
          uint index3 = (index1 << 4) + index2;
          this.Field0[(int) index3].Method0();
          this.Field1[(int) index3].Method0();
        }
        this.Field2[(int) index1].Method0();
        this.Field3[(int) index1].Method0();
        this.Field4[(int) index1].Method0();
        this.Field5[(int) index1].Method0();
      }
      this.Field7.Method1();
      for (uint index = 0; index < 4U; ++index)
        this.Field10[(int) index].Method0();
      for (uint index = 0; index < 114U; ++index)
        this.Field9[(int) index].Method0();
      this.Field6.Method1();
      this.Field12.Method1();
      this.Field16.Method0();
    }

    internal void Method4(Stream inStream, Stream outStream, long inSize, long outSize)
    {
      this.Method3(inStream, outStream);
      Class0.Struct3 struct3 = new Class0.Struct3();
      struct3.Method0();
      uint distance = 0;
      uint num1 = 0;
      uint num2 = 0;
      uint num3 = 0;
      ulong pos = 0;
      if (0L < outSize)
      {
        int num4 = (int) this.Field0[(int) struct3.Field0 << 4].Method1(this.Field11);
        struct3.Method1();
        this.Field8.Method5(this.Field7.Method3(this.Field11, 0U, (byte) 0));
        ++pos;
      }
      while (pos < (ulong) outSize)
      {
        uint posState = (uint) pos & this.Field17;
        if (this.Field0[((int) struct3.Field0 << 4) + (int) posState].Method1(this.Field11) > 0U)
        {
          uint len;
          if (this.Field2[(int) struct3.Field0].Method1(this.Field11) != 1U)
          {
            num3 = num2;
            num2 = num1;
            num1 = distance;
            len = 2U + this.Field6.Method2(this.Field11, posState);
            struct3.Method2();
            uint num5 = this.Field10[(int) Class0.Class2.StaticMethod0(len)].Method1(this.Field11);
            if (num5 >= 4U)
            {
              int NumBitLevels = (int) (num5 >> 1) - 1;
              uint num6 = (uint) ((2 | (int) num5 & 1) << NumBitLevels);
              distance = num5 >= 14U ? num6 + (this.Field11.Method3(NumBitLevels - 4) << 4) + this.Field16.Method2(this.Field11) : num6 + Class0.Struct1.StaticMethod0(this.Field9, (uint) ((int) num6 - (int) num5 - 1), this.Field11, NumBitLevels);
            }
            else
              distance = num5;
          }
          else
          {
            if (this.Field3[(int) struct3.Field0].Method1(this.Field11) > 0U)
            {
              uint num7;
              if (this.Field4[(int) struct3.Field0].Method1(this.Field11) > 0U)
              {
                if (this.Field5[(int) struct3.Field0].Method1(this.Field11) > 0U)
                {
                  num7 = num3;
                  num3 = num2;
                }
                else
                  num7 = num2;
                num2 = num1;
              }
              else
                num7 = num1;
              num1 = distance;
              distance = num7;
            }
            else if (this.Field1[((int) struct3.Field0 << 4) + (int) posState].Method1(this.Field11) == 0U)
            {
              struct3.Method4();
              this.Field8.Method5(this.Field8.Method6(distance));
              ++pos;
              continue;
            }
            len = this.Field12.Method2(this.Field11, posState) + 2U;
            struct3.Method3();
          }
          if ((ulong) distance < pos && distance < this.Field15 || distance != uint.MaxValue)
          {
            this.Field8.Method4(distance, len);
            pos += (ulong) len;
          }
          else
            break;
        }
        else
        {
          byte prevByte = this.Field8.Method6(0U);
          this.Field8.Method5(struct3.Method5() ? this.Field7.Method3(this.Field11, (uint) pos, prevByte) : this.Field7.Method4(this.Field11, (uint) pos, prevByte, this.Field8.Method6(distance)));
          struct3.Method1();
          ++pos;
        }
      }
      this.Field8.Method3();
      this.Field8.Method2();
      this.Field11.Method1();
    }

    internal void Method5(byte[] properties)
    {
      if (properties.Length < 5)
        throw new ArgumentException("Properties array must have at least 5 elements.");
      int lc = (int) properties[0] % 9;
      byte num = (byte) ((uint) properties[0] / 9U);
      int lp = (int) num % 5;
      int pb = (int) num / 5;
      uint dictionarySize = 0;
      for (int index = 0; index < 4; ++index)
        dictionarySize += (uint) properties[1 + index] << index * 8;
      this.Method0(dictionarySize);
      this.Method1(lp, lc);
      this.Method2(pb);
    }

    internal static uint StaticMethod0(uint len)
    {
      len -= 2U;
      return len < 4U ? len : 3U;
    }

    internal class Class3
    {
      internal readonly Class0.Struct1[] Field0 = new Class0.Struct1[16];
      internal readonly Class0.Struct1[] Field1 = new Class0.Struct1[16];
      internal Class0.Struct0 Field2;
      internal Class0.Struct0 Field3;
      internal Class0.Struct1 Field4 = new Class0.Struct1(8);
      internal uint Field5;

      internal void Method0(uint numPosStates)
      {
        for (uint field5 = this.Field5; field5 < numPosStates; ++field5)
        {
          this.Field0[(int) field5] = new Class0.Struct1(3);
          this.Field1[(int) field5] = new Class0.Struct1(3);
        }
        this.Field5 = numPosStates;
      }

      internal void Method1()
      {
        this.Field2.Method0();
        for (uint index = 0; index < this.Field5; ++index)
        {
          this.Field0[(int) index].Method0();
          this.Field1[(int) index].Method0();
        }
        this.Field3.Method0();
        this.Field4.Method0();
      }

      internal uint Method2(Class0.Class1 rangeDecoder, uint posState)
      {
        if (this.Field2.Method1(rangeDecoder) == 0U)
          return this.Field0[(int) posState].Method1(rangeDecoder);
        uint num = 8;
        return this.Field3.Method1(rangeDecoder) != 0U ? num + 8U + this.Field4.Method1(rangeDecoder) : num + this.Field1[(int) posState].Method1(rangeDecoder);
      }

      internal Class3()
      {
      }
    }

    internal class Class4
    {
      internal Class0.Class2.Class4.Struct2[] Field0;
      internal int Field1;
      internal int Field2;
      internal uint Field3;

      internal void Method0(int numPosBits, int numPrevBits)
      {
        if (this.Field0 != null && this.Field2 == numPrevBits && this.Field1 == numPosBits)
          return;
        this.Field1 = numPosBits;
        this.Field3 = (uint) ((1 << numPosBits) - 1);
        this.Field2 = numPrevBits;
        uint length = (uint) (1 << this.Field2 + this.Field1);
        this.Field0 = new Class0.Class2.Class4.Struct2[(int) length];
        for (uint index = 0; index < length; ++index)
          this.Field0[(int) index].Method0();
      }

      internal void Method1()
      {
        uint num = (uint) (1 << this.Field2 + this.Field1);
        for (uint index = 0; index < num; ++index)
          this.Field0[(int) index].Method1();
      }

      internal uint Method2(uint pos, byte prevByte)
      {
        return (uint) ((((int) pos & (int) this.Field3) << this.Field2) + ((int) prevByte >> 8 - this.Field2));
      }

      internal byte Method3(Class0.Class1 rangeDecoder, uint pos, byte prevByte)
      {
        return this.Field0[(int) this.Method2(pos, prevByte)].Method2(rangeDecoder);
      }

      internal byte Method4(Class0.Class1 rangeDecoder, uint pos, byte prevByte, byte matchByte)
      {
        return this.Field0[(int) this.Method2(pos, prevByte)].Method3(rangeDecoder, matchByte);
      }

      internal Class4()
      {
      }

      internal struct Struct2
      {
        internal Class0.Struct0[] Field0;

        internal void Method0() => this.Field0 = new Class0.Struct0[768];

        internal void Method1()
        {
          for (int index = 0; index < 768; ++index)
            this.Field0[index].Method0();
        }

        internal byte Method2(Class0.Class1 rangeDecoder)
        {
          uint index = 1;
          do
          {
            index = index << 1 | this.Field0[(int) index].Method1(rangeDecoder);
          }
          while (index < 256U);
          return (byte) index;
        }

        internal byte Method3(Class0.Class1 rangeDecoder, byte matchByte)
        {
          uint index = 1;
          do
          {
            uint num1 = (uint) ((int) matchByte >> 7 & 1);
            matchByte <<= 1;
            uint num2 = this.Field0[(1 + (int) num1 << 8) + (int) index].Method1(rangeDecoder);
            index = index << 1 | num2;
            if ((int) num1 != (int) num2)
              goto label_4;
          }
          while (index < 256U);
          goto label_5;
label_4:
          while (index < 256U)
            index = index << 1 | this.Field0[(int) index].Method1(rangeDecoder);
label_5:
          return (byte) index;
        }
      }
    }
  }

  internal class Class5
  {
    internal byte[] Field0;
    internal uint Field1;
    internal Stream Field2;
    internal uint Field3;
    internal uint Field4;

    internal void Method0(uint windowSize)
    {
      if ((int) this.Field4 != (int) windowSize)
        this.Field0 = new byte[(int) windowSize];
      this.Field4 = windowSize;
      this.Field1 = 0U;
      this.Field3 = 0U;
    }

    internal void Method1(Stream stream, bool solid)
    {
      this.Method2();
      this.Field2 = stream;
      if (solid)
        return;
      this.Field3 = 0U;
      this.Field1 = 0U;
    }

    internal void Method2()
    {
      this.Method3();
      this.Field2 = (Stream) null;
      Buffer.BlockCopy((Array) new byte[this.Field0.Length], 0, (Array) this.Field0, 0, this.Field0.Length);
    }

    internal void Method3()
    {
      uint count = this.Field1 - this.Field3;
      if (count == 0U)
        return;
      this.Field2.Write(this.Field0, (int) this.Field3, (int) count);
      if (this.Field1 >= this.Field4)
        this.Field1 = 0U;
      this.Field3 = this.Field1;
    }

    internal void Method4(uint distance, uint len)
    {
      uint num = (uint) ((int) this.Field1 - (int) distance - 1);
      if (num >= this.Field4)
        num += this.Field4;
      for (; len > 0U; --len)
      {
        if (num >= this.Field4)
          num = 0U;
        this.Field0[(int) this.Field1++] = this.Field0[(int) num++];
        if (this.Field1 >= this.Field4)
          this.Method3();
      }
    }

    internal void Method5(byte b)
    {
      this.Field0[(int) this.Field1++] = b;
      if (this.Field1 < this.Field4)
        return;
      this.Method3();
    }

    internal byte Method6(uint distance)
    {
      uint index = (uint) ((int) this.Field1 - (int) distance - 1);
      if (index >= this.Field4)
        index += this.Field4;
      return this.Field0[(int) index];
    }

    internal Class5()
    {
    }
  }

  internal struct Struct3
  {
    internal uint Field0;

    internal void Method0() => this.Field0 = 0U;

    internal void Method1()
    {
      if (this.Field0 < 4U)
        this.Field0 = 0U;
      else if (this.Field0 >= 10U)
        this.Field0 -= 6U;
      else
        this.Field0 -= 3U;
    }

    internal void Method2() => this.Field0 = this.Field0 < 7U ? 7U : 10U;

    internal void Method3() => this.Field0 = this.Field0 < 7U ? 8U : 11U;

    internal void Method4() => this.Field0 = this.Field0 < 7U ? 9U : 11U;

    internal bool Method5() => this.Field0 < 7U;
  }

  [StructLayout(LayoutKind.Explicit, Size = 5888)]
  internal struct Struct4
  {
  }

  [StructLayout(LayoutKind.Explicit, Size = 448, Pack = 1)]
  internal struct Struct5
  {
  }
}
