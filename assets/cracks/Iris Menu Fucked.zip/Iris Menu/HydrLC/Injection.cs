﻿// Decompiled with JetBrains decompiler
// Type: HydrLC.Injection
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using Loading;
using StupidTemplate.Classes;
using StupidTemplate.Menu;
using StupidTemplate.Notifications;
using System;
using System.Threading;
using UnityEngine;

#nullable disable
namespace HydrLC
{
  internal class Injection : MonoBehaviour
  {
    private static GameObject obj;

    private static void StartInjection()
    {
      if (Injection.obj != null)
        return;
      Injection.obj = (GameObject.Find("HydrLC") ?? new GameObject("HydrLC")).Also<GameObject>((Action<GameObject>) (o =>
      {
        Object.DontDestroyOnLoad((Object) o);
        o.AddComponent<Injection>().RunInjectionThread();
      }));
    }

    private void RunInjectionThread() => new Thread((ThreadStart) (() => this.Inject())).Start();

    private void Inject()
    {
      Injection.obj.AddComponent<NotifiLib>();
      NotifiLib.SendNotification("Iris Menu Injected");
      Injection.obj.AddComponent<Main>();
      Injection.obj.AddComponent<Button>();
      Injection.obj.AddComponent<Loader>();
      Injection.obj.AddComponent<ColorChanger>();
      Object.Destroy((Object) this);
    }
  }
}
