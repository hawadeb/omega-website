﻿// Decompiled with JetBrains decompiler
// Type: StupidTemplate.Classes.RigManager
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using BepInEx;
using HarmonyLib;
using Photon.Pun;
using Photon.Realtime;
using System;
using UnityEngine;

#nullable disable
namespace StupidTemplate.Classes
{
  internal class RigManager : BaseUnityPlugin
  {
    public static VRRig GetVRRigFromPlayer(Player p)
    {
      return GorillaGameManager.instance.FindPlayerVRRig(NetPlayer.op_Implicit(p));
    }

    public static VRRig GetRandomVRRig(bool includeSelf)
    {
      VRRig vrrig = GorillaParent.instance.vrrigs[Random.Range(0, GorillaParent.instance.vrrigs.Count - 1)];
      return includeSelf || Object.op_Inequality((Object) vrrig, (Object) GorillaTagger.Instance.offlineVRRig) ? vrrig : RigManager.GetRandomVRRig(includeSelf);
    }

    public static VRRig GetClosestVRRig()
    {
      float num = float.MaxValue;
      VRRig closestVrRig = (VRRig) null;
      foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
      {
        if ((double) Vector3.Distance(((Component) GorillaTagger.Instance.bodyCollider).transform.position, ((Component) vrrig).transform.position) < (double) num)
        {
          num = Vector3.Distance(((Component) GorillaTagger.Instance.bodyCollider).transform.position, ((Component) vrrig).transform.position);
          closestVrRig = vrrig;
        }
      }
      return closestVrRig;
    }

    public static PhotonView GetPhotonViewFromVRRig(VRRig p)
    {
      return (PhotonView) Traverse.Create((object) p).Field("photonView").GetValue();
    }

    public static Player GetRandomPlayer(bool includeSelf)
    {
      return includeSelf ? PhotonNetwork.PlayerList[Random.Range(0, PhotonNetwork.PlayerList.Length - 1)] : PhotonNetwork.PlayerListOthers[Random.Range(0, PhotonNetwork.PlayerListOthers.Length - 1)];
    }

    public static Player GetPlayerFromVRRig(VRRig p) => RigManager.GetPhotonViewFromVRRig(p).Owner;

    public static Player GetPlayerFromID(string id)
    {
      Player playerFromId = (Player) null;
      foreach (Player player in PhotonNetwork.PlayerList)
      {
        if (player.UserId == id)
        {
          playerFromId = player;
          break;
        }
      }
      return playerFromId;
    }

    internal static VRRig GetRigFromPlayer(Player player) => throw new NotImplementedException();
  }
}
