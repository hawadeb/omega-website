﻿// Decompiled with JetBrains decompiler
// Type: StupidTemplate.Classes.Button
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using StupidTemplate.Menu;
using UnityEngine;

#nullable disable
namespace StupidTemplate.Classes
{
  internal class Button : MonoBehaviour
  {
    public string relatedText;
    public static float buttonCooldown;

    public void OnTriggerEnter(Collider collider)
    {
      if ((double) Time.time <= (double) Button.buttonCooldown || !Object.op_Equality((Object) collider, (Object) Main.buttonCollider) || !Object.op_Inequality((Object) Main.menu, (Object) null))
        return;
      Button.buttonCooldown = Time.time + 0.2f;
      GorillaTagger.Instance.StartVibration(Settings.rightHanded, GorillaTagger.Instance.tagHapticStrength / 2f, GorillaTagger.Instance.tagHapticDuration / 2f);
      GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(176, Settings.rightHanded, 0.4f);
      Main.Toggle(this.relatedText);
    }
  }
}
