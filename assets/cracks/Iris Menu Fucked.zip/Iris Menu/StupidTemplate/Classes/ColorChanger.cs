﻿// Decompiled with JetBrains decompiler
// Type: StupidTemplate.Classes.ColorChanger
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using UnityEngine;

#nullable disable
namespace StupidTemplate.Classes
{
  public class ColorChanger : TimedBehaviour
  {
    public Renderer renderer;
    public ExtGradient colorInfo;

    public override void Start()
    {
      base.Start();
      this.renderer = ((Component) this).GetComponent<Renderer>();
      this.Update();
    }

    public override void Update()
    {
      base.Update();
      if (this.colorInfo == null)
        return;
      if (!this.colorInfo.copyRigColors)
      {
        Color rgb = new Gradient()
        {
          colorKeys = this.colorInfo.colors
        }.Evaluate((float) ((double) Time.time / 2.0 % 1.0));
        if (this.colorInfo.isRainbow)
          rgb = Color.HSVToRGB((float) ((double) Time.frameCount / 180.0 % 1.0), 1f, 1f);
        this.renderer.material.color = rgb;
      }
      else
        this.renderer.material = ((Renderer) GorillaTagger.Instance.offlineVRRig.mainSkin).material;
    }
  }
}
