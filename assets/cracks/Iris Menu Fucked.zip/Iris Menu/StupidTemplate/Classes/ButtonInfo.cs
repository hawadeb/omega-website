﻿// Decompiled with JetBrains decompiler
// Type: StupidTemplate.Classes.ButtonInfo
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using System;

#nullable disable
namespace StupidTemplate.Classes
{
  public class ButtonInfo
  {
    public string buttonText = "-";
    public string overlapText = (string) null;
    public Action method = (Action) null;
    public Action enableMethod = (Action) null;
    public Action disableMethod = (Action) null;
    public bool enabled = false;
    public bool isTogglable = true;
    public string toolTip = "This button doesn't have a tooltip/tutorial.";
  }
}
