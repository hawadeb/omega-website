﻿// Decompiled with JetBrains decompiler
// Type: StupidTemplate.PluginInfo
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

#nullable disable
namespace StupidTemplate
{
  internal class PluginInfo
  {
    public const string GUID = "org.ftsyxcal.gorillatag.menutemplate";
    public const string Name = "FTSyxcal Template";
    public const string Description = "Created by @ftsyxcal with hate <3";
    public const string Version = "1.0.0";
  }
}
