﻿// Decompiled with JetBrains decompiler
// Type: StupidTemplate.Menu.Main
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using BepInEx;
using GorillaLocomotion;
using MenkerMenu.Utilities;
using Photon.Pun;
using StupidTemplate.Classes;
using StupidTemplate.Notifications;
using System;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

#nullable disable
namespace StupidTemplate.Menu
{
  public class Main : MonoBehaviour
  {
    public static string[] ExternalProjectileNames;
    public static string[] InternalProjectileNames;
    public static string[] InternalProjectileNamesRight;
    public static bool longmenu = false;
    public static bool disorganized = false;
    public static bool flipMenu = false;
    public static bool shinymenu = false;
    public static bool dropOnRemove = true;
    public static bool shouldOutline = false;
    public static bool shouldRound = false;
    public static bool lastclicking = false;
    public static bool openedwithright = false;
    public static bool likebark = false;
    public static GameObject menu;
    public static GameObject menuBackground;
    public static GameObject reference;
    public static GameObject canvasObject;
    public static SphereCollider buttonCollider;
    public static Camera TPC;
    public static Text fpsObject;
    public static GameObject outline;
    public static int pageNumber = 0;
    public static int buttonsType = 0;
    public static Main instance = new Main();

    public static void Customboards()
    {
      Material material = new Material(Shader.Find("GUI/Text Shader"))
      {
        color = Color.Lerp(Color32.op_Implicit(ColorLib.Pink), Color32.op_Implicit(new Color32((byte) 125, (byte) 0, byte.MaxValue, byte.MaxValue)), Mathf.PingPong(Time.time, 1.5f))
      };
      material.SetFloat("_Mode", 2f);
      GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomBoundaryStones/BoundaryStoneSet_Forest/wallmonitorforestbg").GetComponent<Renderer>().material = new Material(Shader.Find("GorillaTag/UberShader"))
      {
        color = material.color
      };
      ((TMP_Text) GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/motd (1)").GetComponent<TextMeshPro>()).text = "IRIS MENU | V1\n--------------------------------------------";
      ((Graphic) GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/motd (1)").GetComponent<TextMeshPro>()).color = material.color;
      TextMeshPro component1 = GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/motdtext").GetComponent<TextMeshPro>();
      ((Graphic) ((Component) component1).GetComponent<TextMeshPro>()).color = material.color;
      if (PhotonNetwork.InRoom)
      {
        string upper1 = PhotonNetwork.CurrentRoom.Name.ToUpper();
        byte num = PhotonNetwork.CurrentRoom.PlayerCount;
        string upper2 = num.ToString().ToUpper();
        num = PhotonNetwork.CurrentRoom.MaxPlayers;
        string upper3 = num.ToString().ToUpper();
        string upper4 = PhotonNetwork.GetPing().ToString().ToUpper();
        string str = PhotonNetwork.IsMasterClient ? "YES" : "NO";
        string upper5 = PhotonNetwork.MasterClient.NickName.ToUpper();
        ((TMP_Text) component1).text = "<color=#00ff00>\nIN ROOM: " + upper1 + "</color>\nPLAYERS: " + upper2 + "/" + upper3 + "\nPING: " + upper4 + "ms\nAM I MASTER CLIENT?: " + str + "\nMASTER CLIENT: " + upper5 + "\nMADE BY: FTSYXCAL";
      }
      else
        ((TMP_Text) component1).text = "<color=#ff0000>\nNOT CONNECTED TO A ROOM</color>\nMADE BY: FTSYXCAL";
      ((TMP_Text) component1).alignment = (TextAlignmentOptions) 258;
      ((TMP_Text) GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/CodeOfConduct").GetComponent<TextMeshPro>()).text = "WHAT DO THESE SYMBOLS MEAN?";
      ((Graphic) GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/CodeOfConduct").GetComponent<TextMeshPro>()).color = material.color;
      TextMeshPro component2 = GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/COC Text").GetComponent<TextMeshPro>();
      ((TMP_Text) component2).text = "\n[D?] = MIGHT BE DETECTED \n[D] - DETECTED\n[U] - USE\n[P] - PRIMARY\n[S] - SECONDARY\n[G] - GRIP\n[T] - TRIGGER\n[W?] - MAYBE WORKING\n[B] - BUGGY\n\nTHIS MENU IS SIGMA IF YOU SAY IT'S NOT.... YOU MEAN";
      ((TMP_Text) component2).alignment = (TextAlignmentOptions) 258;
      ((Graphic) ((Component) component2).GetComponent<TextMeshPro>()).color = material.color;
      ((TMP_Text) GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/GameModes Title Text").GetComponent<TextMeshPro>()).text = "Iris Menu";
      ((Graphic) GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/GameModes Title Text").GetComponent<TextMeshPro>()).color = material.color;
    }

    public void LateUpdate()
    {
      try
      {
        bool flag = !Settings.rightHanded && ControllerInputPoller.instance.leftControllerSecondaryButton || Settings.rightHanded && ControllerInputPoller.instance.rightControllerSecondaryButton;
        bool key = UnityInput.Current.GetKey(Settings.keyboardButton);
        if (Object.op_Equality((Object) Main.menu, (Object) null))
        {
          if (flag | key)
          {
            Main.CreateMenu();
            Main.RecenterMenu(Settings.rightHanded, key);
            if (Object.op_Equality((Object) Main.reference, (Object) null))
              this.CreateReference(Settings.rightHanded);
          }
        }
        else if (flag | key)
        {
          Main.RecenterMenu(Settings.rightHanded, key);
        }
        else
        {
          (Main.menu.AddComponent(typeof (Rigidbody)) as Rigidbody).velocity = !Settings.rightHanded ? GTPlayer.Instance.leftHandCenterVelocityTracker.GetAverageVelocity(true, 0.0f, false) : GTPlayer.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(true, 0.0f, false);
          Object.Destroy((Object) Main.menu, 2f);
          Main.menu = (GameObject) null;
          Object.Destroy((Object) Main.reference);
          Main.reference = (GameObject) null;
        }
      }
      catch (Exception ex)
      {
        Debug.LogError((object) string.Format("{0} // Error initializing at {1}: {2}", (object) "FTSyxcal Template", (object) ex.StackTrace, (object) ex.Message));
      }
      try
      {
        if (Object.op_Inequality((Object) Main.fpsObject, (Object) null))
          Main.fpsObject.text = "FPS: " + Mathf.Ceil(1f / Time.unscaledDeltaTime).ToString();
        foreach (ButtonInfo[] button in Buttons.buttons)
        {
          foreach (ButtonInfo buttonInfo in button)
          {
            if (buttonInfo.enabled)
            {
              if (buttonInfo.method != null)
              {
                try
                {
                  buttonInfo.method();
                }
                catch (Exception ex)
                {
                  Debug.LogError((object) string.Format("{0} // Error with mod {1} at {2}: {3}", (object) "FTSyxcal Template", (object) buttonInfo.buttonText, (object) ex.StackTrace, (object) ex.Message));
                }
              }
            }
          }
        }
      }
      catch (Exception ex)
      {
        Debug.LogError((object) string.Format("{0} // Error with executing mods at {1}: {2}", (object) "FTSyxcal Template", (object) ex.StackTrace, (object) ex.Message));
      }
    }

    public static void CreateMenu()
    {
      Main.menu = GameObject.CreatePrimitive((PrimitiveType) 3);
      Object.Destroy((Object) Main.menu.GetComponent<Rigidbody>());
      Object.Destroy((Object) Main.menu.GetComponent<BoxCollider>());
      Object.Destroy((Object) Main.menu.GetComponent<Renderer>());
      Main.menu.transform.localScale = new Vector3(0.1f, 0.3f, 0.3825f);
      Main.menuBackground = GameObject.CreatePrimitive((PrimitiveType) 3);
      Object.Destroy((Object) Main.menuBackground.GetComponent<Rigidbody>());
      Object.Destroy((Object) Main.menuBackground.GetComponent<BoxCollider>());
      Main.menuBackground.transform.parent = Main.menu.transform;
      Main.menuBackground.transform.rotation = Quaternion.identity;
      Main.menuBackground.transform.localScale = Settings.menuSize;
      Main.menuBackground.GetComponent<Renderer>().material.color = Settings.backgroundColor.colors[0].color;
      Main.menuBackground.transform.position = new Vector3(0.05f, 0.0f, 0.0f);
      ColorChanger colorChanger1 = Main.menuBackground.AddComponent<ColorChanger>();
      colorChanger1.colorInfo = Settings.backgroundColor;
      colorChanger1.Start();
      Main.canvasObject = new GameObject();
      Main.canvasObject.transform.parent = Main.menu.transform;
      Canvas canvas = Main.canvasObject.AddComponent<Canvas>();
      CanvasScaler canvasScaler = Main.canvasObject.AddComponent<CanvasScaler>();
      Main.canvasObject.AddComponent<GraphicRaycaster>();
      canvas.renderMode = (RenderMode) 2;
      canvasScaler.dynamicPixelsPerUnit = 1000f;
      Text text1 = new GameObject()
      {
        transform = {
          parent = Main.canvasObject.transform
        }
      }.AddComponent<Text>();
      Text text2 = new GameObject()
      {
        transform = {
          parent = Main.canvasObject.transform
        }
      }.AddComponent<Text>();
      text1.font = Settings.currentFont;
      text1.text = "Iris Menu";
      text2.text = " <color=grey>[</color><color=white>" + (Main.pageNumber + 1).ToString() + "</color><color=grey>]</color>";
      text1.fontSize = 1;
      ((Graphic) text1).color = Settings.textColors[0];
      text1.supportRichText = true;
      text1.fontStyle = (FontStyle) 2;
      text1.alignment = (TextAnchor) 4;
      text1.resizeTextForBestFit = true;
      text1.resizeTextMinSize = 0;
      RectTransform component1 = ((Component) text1).GetComponent<RectTransform>();
      ((Transform) component1).localPosition = Vector3.zero;
      component1.sizeDelta = new Vector2(0.28f, 0.05f);
      ((Transform) component1).position = new Vector3(0.06f, 0.0f, 0.165f);
      ((Transform) component1).rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
      RectTransform component2 = ((Component) text2).GetComponent<RectTransform>();
      ((Transform) component2).localPosition = Vector3.zero;
      component2.sizeDelta = new Vector2(0.25f, 0.05f);
      ((Transform) component2).position = new Vector3(0.06f, 0.0f, 0.165f);
      ((Transform) component2).rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
      if (Settings.fpsCounter)
      {
        Main.fpsObject = new GameObject()
        {
          transform = {
            parent = Main.canvasObject.transform
          }
        }.AddComponent<Text>();
        Main.fpsObject.font = Settings.currentFont;
        Main.fpsObject.text = "<color=magenta>FPS</color>: " + Mathf.Ceil(1f / Time.unscaledDeltaTime).ToString();
        ((Graphic) Main.fpsObject).color = Settings.textColors[0];
        Main.fpsObject.fontSize = 1;
        Main.fpsObject.supportRichText = true;
        Main.fpsObject.fontStyle = (FontStyle) 2;
        Main.fpsObject.alignment = (TextAnchor) 4;
        Main.fpsObject.horizontalOverflow = (HorizontalWrapMode) 1;
        Main.fpsObject.resizeTextForBestFit = true;
        Main.fpsObject.resizeTextMinSize = 0;
        RectTransform component3 = ((Component) Main.fpsObject).GetComponent<RectTransform>();
        ((Transform) component3).localPosition = Vector3.zero;
        component3.sizeDelta = new Vector2(0.28f, 0.02f);
        ((Transform) component3).position = new Vector3(0.06f, 0.0f, 0.135f);
        ((Transform) component3).rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
      }
      if (Settings.outsline)
      {
        Main.outline = GameObject.CreatePrimitive((PrimitiveType) 3);
        Object.Destroy((Object) Main.outline.GetComponent<Rigidbody>());
        Main.outline.transform.parent = Main.menu.transform;
        Main.outline.transform.rotation = Quaternion.identity;
        ((Object) Main.outline).name = "Outline";
        Main.outline.transform.localScale = new Vector3(0.099f, 1.05f, 1.05f);
        Main.outline.transform.position = new Vector3(0.05f, 0.0f, 0.0f);
        Main.outline.GetComponent<Renderer>().material.color = Color.white;
        Main.outline.GetComponent<Renderer>().material.color = Color32.op_Implicit(Settings.OutlineColor);
        Object.Destroy((Object) Main.outline.GetComponent<Rigidbody>());
        Object.Destroy((Object) Main.outline.GetComponent<Collider>());
        Object.Destroy((Object) Main.outline.GetComponent<BoxCollider>());
      }
      if (Settings.disconnectButton)
      {
        GameObject primitive = GameObject.CreatePrimitive((PrimitiveType) 3);
        if (!UnityInput.Current.GetKey((KeyCode) 113))
          primitive.layer = 2;
        Object.Destroy((Object) primitive.GetComponent<Rigidbody>());
        ((Collider) primitive.GetComponent<BoxCollider>()).isTrigger = true;
        primitive.transform.parent = Main.menu.transform;
        primitive.transform.rotation = Quaternion.identity;
        primitive.transform.localScale = new Vector3(0.09f, 0.9f, 0.08f);
        primitive.transform.localPosition = new Vector3(0.56f, 0.0f, 0.6f);
        primitive.GetComponent<Renderer>().material.color = Settings.buttonColors[0].colors[0].color;
        primitive.AddComponent<Button>().relatedText = "Disconnect";
        ColorChanger colorChanger2 = primitive.AddComponent<ColorChanger>();
        colorChanger2.colorInfo = Settings.buttonColors[0];
        colorChanger2.Start();
        Text text3 = new GameObject()
        {
          transform = {
            parent = Main.canvasObject.transform
          }
        }.AddComponent<Text>();
        text3.text = "Disconnect";
        text3.font = Settings.currentFont;
        text3.fontSize = 1;
        ((Graphic) text3).color = Settings.textColors[0];
        text3.alignment = (TextAnchor) 4;
        text3.resizeTextForBestFit = true;
        text3.resizeTextMinSize = 0;
        RectTransform component4 = ((Component) text3).GetComponent<RectTransform>();
        ((Transform) component4).localPosition = Vector3.zero;
        component4.sizeDelta = new Vector2(0.2f, 0.03f);
        ((Transform) component4).localPosition = new Vector3(0.064f, 0.0f, 0.23f);
        ((Transform) component4).rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
      }
      GameObject primitive1 = GameObject.CreatePrimitive((PrimitiveType) 3);
      if (!UnityInput.Current.GetKey((KeyCode) 113))
        primitive1.layer = 2;
      Object.Destroy((Object) primitive1.GetComponent<Rigidbody>());
      ((Collider) primitive1.GetComponent<BoxCollider>()).isTrigger = true;
      primitive1.transform.parent = Main.menu.transform;
      primitive1.transform.rotation = Quaternion.identity;
      primitive1.transform.localScale = Settings.BtnHeight;
      primitive1.transform.localPosition = Settings.prevbtnpos;
      primitive1.GetComponent<Renderer>().material.color = Color32.op_Implicit(Settings.nextnprvcolor);
      primitive1.AddComponent<Button>().relatedText = "PreviousPage";
      Text text4 = new GameObject()
      {
        transform = {
          parent = Main.canvasObject.transform
        }
      }.AddComponent<Text>();
      text4.font = Settings.currentFont;
      text4.text = "<----";
      text4.fontSize = 1;
      ((Graphic) text4).color = Color32.op_Implicit(Settings.ButtonTextColor);
      text4.alignment = (TextAnchor) 4;
      text4.resizeTextForBestFit = true;
      text4.resizeTextMinSize = 0;
      RectTransform component5 = ((Component) text4).GetComponent<RectTransform>();
      ((Transform) component5).localPosition = Vector3.zero;
      component5.sizeDelta = new Vector2(0.2f, 0.03f);
      ((Transform) component5).localPosition = Settings.prevbtntext;
      ((Transform) component5).rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
      GameObject primitive2 = GameObject.CreatePrimitive((PrimitiveType) 3);
      if (!UnityInput.Current.GetKey((KeyCode) 113))
        primitive2.layer = 2;
      Object.Destroy((Object) primitive2.GetComponent<Rigidbody>());
      ((Collider) primitive2.GetComponent<BoxCollider>()).isTrigger = true;
      primitive2.transform.parent = Main.menu.transform;
      primitive2.transform.rotation = Quaternion.identity;
      primitive2.transform.localScale = Settings.BtnHeight;
      primitive2.transform.localPosition = Settings.nextbtnpos;
      primitive2.GetComponent<Renderer>().material.color = Color32.op_Implicit(Settings.nextnprvcolor);
      primitive2.AddComponent<Button>().relatedText = "NextPage";
      Text text5 = new GameObject()
      {
        transform = {
          parent = Main.canvasObject.transform
        }
      }.AddComponent<Text>();
      text5.font = Settings.currentFont;
      text5.text = "---->";
      text5.fontSize = 1;
      ((Graphic) text5).color = Color32.op_Implicit(Settings.ButtonTextColor);
      text5.alignment = (TextAnchor) 4;
      text5.resizeTextForBestFit = true;
      text5.resizeTextMinSize = 0;
      RectTransform component6 = ((Component) text5).GetComponent<RectTransform>();
      ((Transform) component6).localPosition = Vector3.zero;
      component6.sizeDelta = new Vector2(0.2f, 0.03f);
      ((Transform) component6).localPosition = Settings.nextbtntext;
      ((Transform) component6).rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
      ButtonInfo[] array = ((IEnumerable<ButtonInfo>) Buttons.buttons[Main.buttonsType]).Skip<ButtonInfo>(Main.pageNumber * Settings.buttonsPerPage).Take<ButtonInfo>(Settings.buttonsPerPage).ToArray<ButtonInfo>();
      for (int index = 0; index < array.Length; ++index)
        Main.CreateButton((float) index * 0.1f, array[index]);
    }

    public void ShowMenu()
    {
      Console.BackgroundColor = ConsoleColor.Black;
      Console.ForegroundColor = ConsoleColor.Magenta;
      Console.Clear();
      Console.WriteLine("Iris Menu:");
      Console.ForegroundColor = ConsoleColor.Blue;
      Console.WriteLine("(in blue =) Menu Loaded...");
      Console.ForegroundColor = ConsoleColor.Red;
      Console.WriteLine("(in red) = Have fun!");
      Console.ResetColor();
      Console.WriteLine("Press any key to exit...");
      Console.ReadKey();
    }

    public static void CreateButton(float offset, ButtonInfo method)
    {
      GameObject primitive = GameObject.CreatePrimitive((PrimitiveType) 3);
      if (!UnityInput.Current.GetKey((KeyCode) 113))
        primitive.layer = 2;
      Object.Destroy((Object) primitive.GetComponent<Rigidbody>());
      ((Collider) primitive.GetComponent<BoxCollider>()).isTrigger = true;
      primitive.transform.parent = Main.menu.transform;
      primitive.transform.rotation = Quaternion.identity;
      primitive.transform.localScale = new Vector3(0.09f, 0.9f, 0.08f);
      primitive.transform.localPosition = new Vector3(0.56f, 0.0f, 0.28f - offset);
      primitive.AddComponent<Button>().relatedText = method.buttonText;
      ColorChanger colorChanger = primitive.AddComponent<ColorChanger>();
      if (method.enabled)
        primitive.GetComponent<Renderer>().material.color = Color32.op_Implicit(Settings.btndiscolor);
      else
        primitive.GetComponent<Renderer>().material.color = Color32.op_Implicit(Settings.btndiscolor);
      colorChanger.Start();
      Text text = new GameObject()
      {
        transform = {
          parent = Main.canvasObject.transform
        }
      }.AddComponent<Text>();
      text.font = Settings.currentFont;
      text.text = method.buttonText;
      if (method.overlapText != null)
        text.text = method.overlapText;
      text.supportRichText = true;
      text.fontSize = 1;
      if (method.enabled)
        ((Graphic) text).color = Settings.textColors[1];
      else
        ((Graphic) text).color = Settings.textColors[0];
      text.alignment = (TextAnchor) 4;
      text.fontStyle = (FontStyle) 2;
      text.resizeTextForBestFit = true;
      text.resizeTextMinSize = 0;
      RectTransform component = ((Component) text).GetComponent<RectTransform>();
      ((Transform) component).localPosition = Vector3.zero;
      component.sizeDelta = new Vector2(0.2f, 0.03f);
      ((Transform) component).localPosition = new Vector3(0.064f, 0.0f, (float) (0.11100000143051147 - (double) offset / 2.5999999046325684));
      ((Transform) component).rotation = Quaternion.Euler(new Vector3(180f, 90f, 90f));
    }

    public static void RecreateMenu()
    {
      if (!Object.op_Inequality((Object) Main.menu, (Object) null))
        return;
      Object.Destroy((Object) Main.menu);
      Main.menu = (GameObject) null;
      Main.CreateMenu();
      Main.RecenterMenu(Settings.rightHanded, UnityInput.Current.GetKey(Settings.keyboardButton));
    }

    public static void RecenterMenu(bool isRightHanded, bool isKeyboardCondition)
    {
      if (!isKeyboardCondition)
      {
        if (!isRightHanded)
        {
          Main.menu.transform.position = GorillaTagger.Instance.leftHandTransform.position;
          Main.menu.transform.rotation = GorillaTagger.Instance.leftHandTransform.rotation;
        }
        else
        {
          Main.menu.transform.position = GorillaTagger.Instance.rightHandTransform.position;
          Quaternion rotation = GorillaTagger.Instance.rightHandTransform.rotation;
          Vector3 vector3 = Vector3.op_Addition(((Quaternion) ref rotation).eulerAngles, new Vector3(0.0f, 0.0f, 180f));
          Main.menu.transform.rotation = Quaternion.Euler(vector3);
        }
      }
      else
      {
        try
        {
          Main.TPC = GameObject.Find("Player Objects/Third Person Camera/Shoulder Camera").GetComponent<Camera>();
        }
        catch
        {
        }
        if (Object.op_Inequality((Object) Main.TPC, (Object) null))
        {
          ((Component) Main.TPC).transform.position = new Vector3(-999f, -999f, -999f);
          ((Component) Main.TPC).transform.rotation = Quaternion.identity;
          GameObject primitive = GameObject.CreatePrimitive((PrimitiveType) 3);
          primitive.transform.localScale = new Vector3(10f, 10f, 0.01f);
          ((Component) primitive.transform).transform.position = Vector3.op_Addition(((Component) Main.TPC).transform.position, ((Component) Main.TPC).transform.forward);
          primitive.GetComponent<Renderer>().material.color = Color32.op_Implicit(new Color32((byte) ((double) Settings.backgroundColor.colors[0].color.r * 50.0), (byte) ((double) Settings.backgroundColor.colors[0].color.g * 50.0), (byte) ((double) Settings.backgroundColor.colors[0].color.b * 50.0), byte.MaxValue));
          Object.Destroy((Object) primitive, Time.deltaTime);
          Main.menu.transform.parent = ((Component) Main.TPC).transform;
          Main.menu.transform.position = Vector3.op_Addition(Vector3.op_Addition(((Component) Main.TPC).transform.position, Vector3.Scale(((Component) Main.TPC).transform.forward, new Vector3(0.5f, 0.5f, 0.5f))), Vector3.Scale(((Component) Main.TPC).transform.up, new Vector3(-0.02f, -0.02f, -0.02f)));
          Quaternion rotation = ((Component) Main.TPC).transform.rotation;
          Vector3 eulerAngles = ((Quaternion) ref rotation).eulerAngles;
          // ISSUE: explicit constructor call
          ((Vector3) ref eulerAngles).\u002Ector(eulerAngles.x - 90f, eulerAngles.y + 90f, eulerAngles.z);
          Main.menu.transform.rotation = Quaternion.Euler(eulerAngles);
          if (Object.op_Inequality((Object) Main.reference, (Object) null))
          {
            if (Mouse.current.leftButton.isPressed)
            {
              RaycastHit raycastHit;
              if (Physics.Raycast(Main.TPC.ScreenPointToRay(Vector2.op_Implicit(((InputControl<Vector2>) ((Pointer) Mouse.current).position).ReadValue())), ref raycastHit, 100f))
              {
                Button component = ((Component) ((RaycastHit) ref raycastHit).transform).gameObject.GetComponent<Button>();
                if (Object.op_Inequality((Object) component, (Object) null))
                  component.OnTriggerEnter((Collider) Main.buttonCollider);
              }
            }
            else
              Main.reference.transform.position = new Vector3(999f, -999f, -999f);
          }
        }
      }
    }

    public void CreateReference(bool isRightHanded)
    {
      Main.reference = GameObject.CreatePrimitive((PrimitiveType) 0);
      Main.reference.transform.parent = !isRightHanded ? GorillaTagger.Instance.rightHandTransform : GorillaTagger.Instance.leftHandTransform;
      Main.reference.GetComponent<Renderer>().material.color = Settings.backgroundColor.colors[0].color;
      Main.reference.transform.localPosition = new Vector3(0.0f, -0.1f, 0.0f);
      Main.reference.transform.localScale = new Vector3(0.01f, 0.01f, 0.01f);
      Main.buttonCollider = Main.reference.GetComponent<SphereCollider>();
      ColorChanger colorChanger = Main.reference.AddComponent<ColorChanger>();
      colorChanger.colorInfo = Settings.backgroundColor;
      colorChanger.Start();
    }

    public static void Toggle(string buttonText)
    {
      int num = (Buttons.buttons[Main.buttonsType].Length + Settings.buttonsPerPage - 1) / Settings.buttonsPerPage - 1;
      switch (buttonText)
      {
        case "PreviousPage":
          --Main.pageNumber;
          if (Main.pageNumber < 0)
          {
            Main.pageNumber = num;
            goto label_25;
          }
          else
            goto label_25;
        case "NextPage":
          ++Main.pageNumber;
          if (Main.pageNumber > num)
          {
            Main.pageNumber = 0;
            break;
          }
          break;
        default:
          ButtonInfo index = Main.GetIndex(buttonText);
          if (index != null)
          {
            if (index.isTogglable)
            {
              index.enabled = !index.enabled;
              if (index.enabled)
              {
                NotifiLib.SendNotification("<color=grey>[</color><color=green>ENABLE</color><color=grey>]</color> " + index.toolTip);
                if (index.enableMethod != null)
                {
                  try
                  {
                    index.enableMethod();
                  }
                  catch
                  {
                  }
                }
              }
              else
              {
                NotifiLib.SendNotification("<color=grey>[</color><color=red>DISABLE</color><color=grey>]</color> " + index.toolTip);
                if (index.disableMethod != null)
                {
                  try
                  {
                    index.disableMethod();
                  }
                  catch
                  {
                  }
                }
              }
            }
            else
            {
              NotifiLib.SendNotification("<color=grey>[</color><color=green>ENABLE</color><color=grey>]</color> " + index.toolTip);
              if (index.method != null)
              {
                try
                {
                  index.method();
                }
                catch
                {
                }
              }
            }
          }
          else
            Debug.LogError((object) (buttonText + " does not exist"));
          break;
      }
label_25:
      Main.RecreateMenu();
    }

    public static GradientColorKey[] GetSolidGradient(Color color)
    {
      return new GradientColorKey[2]
      {
        new GradientColorKey(color, 0.0f),
        new GradientColorKey(color, 1f)
      };
    }

    public static ButtonInfo GetIndex(string buttonText)
    {
      foreach (ButtonInfo[] button in Buttons.buttons)
      {
        foreach (ButtonInfo index in button)
        {
          if (index.buttonText == buttonText)
            return index;
        }
      }
      return (ButtonInfo) null;
    }

    internal static object GetProjectile(string v) => throw new NotImplementedException();
  }
}
