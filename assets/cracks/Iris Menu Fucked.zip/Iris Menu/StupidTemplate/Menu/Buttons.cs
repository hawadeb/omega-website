﻿// Decompiled with JetBrains decompiler
// Type: StupidTemplate.Menu.Buttons
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using FTSyxcalTemplate.Menu;
using FTSyxcalTemplate.Mods;
using SigmaColor;
using StupidTemplate.Classes;
using StupidTemplate.Mods;
using System;

#nullable disable
namespace StupidTemplate.Menu
{
  internal class Buttons
  {
    public static ButtonInfo[][] buttons = new ButtonInfo[20][]
    {
      new ButtonInfo[17]
      {
        new ButtonInfo()
        {
          buttonText = "Settings",
          method = (Action) (() => SettingsMods.EnterSettings()),
          isTogglable = false,
          toolTip = "Opens the main Settings page for the menu."
        },
        new ButtonInfo()
        {
          buttonText = "Disconnect",
          method = (Action) (() => SettingsMods.Disconnect()),
          isTogglable = false,
          toolTip = "Disconnects from the lobby."
        },
        new ButtonInfo()
        {
          buttonText = "Movement Mods",
          method = (Action) (() => SettingsMods.MovementMods()),
          isTogglable = false,
          toolTip = "Opens the Movement Mods page for the menu."
        },
        new ButtonInfo()
        {
          buttonText = "Rig Mods",
          method = (Action) (() => SettingsMods.RigMods()),
          isTogglable = false,
          toolTip = "Opens the Rig Mods page for the menu."
        },
        new ButtonInfo()
        {
          buttonText = "Cosmetic Mods",
          method = (Action) (() => SettingsMods.CosmeticMods()),
          isTogglable = false,
          toolTip = "Opens the Cosmetic Mods page for the menu."
        },
        new ButtonInfo()
        {
          buttonText = "Fun/Random Mods",
          method = (Action) (() => SettingsMods.FunRandomMods()),
          isTogglable = false,
          toolTip = "Opens the Fun/Random mods page for the menu."
        },
        new ButtonInfo()
        {
          buttonText = "Visual Mods",
          method = (Action) (() => SettingsMods.VisualMods()),
          isTogglable = false,
          toolTip = "Opens the Visual Mods page for the menu."
        },
        new ButtonInfo()
        {
          buttonText = "Safety Mods",
          method = (Action) (() => SettingsMods.SafetyMods()),
          isTogglable = false,
          toolTip = "Opens the Safety Mods page for the menu."
        },
        new ButtonInfo()
        {
          buttonText = "Advantage Mods",
          method = (Action) (() => SettingsMods.AdvantageMods()),
          isTogglable = false,
          toolTip = "Opens the Advantage Mods page for the menu."
        },
        new ButtonInfo()
        {
          buttonText = "Network Mods",
          method = (Action) (() => SettingsMods.NetworkMods()),
          isTogglable = false,
          toolTip = "Opens the Network Mods page for the menu."
        },
        new ButtonInfo()
        {
          buttonText = "Player Mods",
          method = (Action) (() => SettingsMods.PlayerMods()),
          isTogglable = false,
          toolTip = "Opens the Advantage Mods page for the menu."
        },
        new ButtonInfo()
        {
          buttonText = "World Mods",
          method = (Action) (() => SettingsMods.WorldMods()),
          isTogglable = false,
          toolTip = "Opens the World Mods page for the menu."
        },
        new ButtonInfo()
        {
          buttonText = "Overpowered Mods",
          method = (Action) (() => SettingsMods.OverpoweredMods()),
          isTogglable = false,
          toolTip = "Opens the Overpowered Mods page for the menu."
        },
        new ButtonInfo()
        {
          buttonText = "Projectile Mods",
          method = (Action) (() => SettingsMods.ProjectileMods()),
          isTogglable = false,
          toolTip = "Opens the Projectile Mods page for the menu."
        },
        new ButtonInfo()
        {
          buttonText = "Outline Theme Mods",
          method = (Action) (() => SettingsMods.ThemeMods()),
          isTogglable = false,
          toolTip = "Opens the Outline Theme Mods page for the menu."
        },
        new ButtonInfo()
        {
          buttonText = "Guardian Mods",
          method = (Action) (() => SettingsMods.GuardianMods()),
          isTogglable = false,
          toolTip = "Opens the Guardian Mods page for the menu."
        },
        new ButtonInfo()
        {
          buttonText = "Credits",
          method = (Action) (() => SettingsMods.Credits()),
          isTogglable = false,
          toolTip = "Opens the Credits page for the menu."
        }
      },
      new ButtonInfo[4]
      {
        new ButtonInfo()
        {
          buttonText = "Return to Main",
          method = (Action) (() => Global.ReturnHome()),
          isTogglable = false,
          toolTip = "Returns to the main page of the menu."
        },
        new ButtonInfo()
        {
          buttonText = "Disconnect",
          method = (Action) (() => SettingsMods.Disconnect()),
          isTogglable = false,
          toolTip = "Disconnects from the lobby."
        },
        new ButtonInfo()
        {
          buttonText = "Menu",
          method = (Action) (() => SettingsMods.MenuSettings()),
          isTogglable = false,
          toolTip = "Opens the settings for the menu."
        },
        new ButtonInfo()
        {
          buttonText = "Mod Settings",
          method = (Action) (() => SettingsMods.ModSettings()),
          isTogglable = false,
          toolTip = "Opens the Mod Settings for the menu."
        }
      },
      new ButtonInfo[15]
      {
        new ButtonInfo()
        {
          buttonText = "Return to Settings",
          method = (Action) (() => SettingsMods.EnterSettings()),
          isTogglable = false,
          toolTip = "Returns to the main settings page for the menu."
        },
        new ButtonInfo()
        {
          buttonText = "Right Hand [W]",
          enableMethod = (Action) (() => SettingsMods.RightHand()),
          disableMethod = (Action) (() => SettingsMods.LeftHand()),
          toolTip = "Puts the menu on your right hand."
        },
        new ButtonInfo()
        {
          buttonText = "Disconnect Button [W]",
          enableMethod = (Action) (() => SettingsMods.DisableDisconnectButton()),
          disableMethod = (Action) (() => SettingsMods.EnableDisconnectButton()),
          toolTip = "Puts the menu on your right hand."
        },
        new ButtonInfo()
        {
          buttonText = "Notifications [W]",
          enableMethod = (Action) (() => SettingsMods.EnableNotifications()),
          disableMethod = (Action) (() => SettingsMods.DisableNotifications()),
          toolTip = "Toggles the notifications."
        },
        new ButtonInfo()
        {
          buttonText = "FPS Counter [W]",
          enableMethod = (Action) (() => SettingsMods.EnableFPSCounter()),
          disableMethod = (Action) (() => SettingsMods.DisableFPSCounter()),
          toolTip = "Toggles the FPS counter."
        },
        new ButtonInfo()
        {
          buttonText = "FPS Boost [W]",
          method = (Action) (() => SettingsMods.EnableFPSBoost()),
          disableMethod = (Action) (() => SettingsMods.DisableFPSBoost()),
          isTogglable = false,
          toolTip = "Gives you an FPS boost."
        },
        new ButtonInfo()
        {
          buttonText = "FPS Cap [W]",
          method = (Action) (() => SettingsMods.CapFPS()),
          disableMethod = (Action) (() => SettingsMods.UncapFPS()),
          isTogglable = false,
          toolTip = "Caps your FPS at 144."
        },
        new ButtonInfo()
        {
          buttonText = "No Drop Menu [W]",
          method = (Action) (() => SettingsMods.DropMenuOff()),
          disableMethod = (Action) (() => SettingsMods.DropMenu()),
          isTogglable = false,
          toolTip = "Disables drop menus."
        },
        new ButtonInfo()
        {
          buttonText = "Long Menu [W]",
          method = (Action) (() => SettingsMods.LongMenuOn()),
          disableMethod = (Action) (() => SettingsMods.LongMenuOff()),
          isTogglable = false,
          toolTip = "Makes menu long."
        },
        new ButtonInfo()
        {
          buttonText = "Shiny Menu [W]",
          method = (Action) (() => SettingsMods.ShinyMenu()),
          disableMethod = (Action) (() => SettingsMods.NoShinyMenu()),
          isTogglable = false,
          toolTip = "Makes menu shiny."
        },
        new ButtonInfo()
        {
          buttonText = "Round Menu [W]",
          method = (Action) (() => SettingsMods.RoundMenuOn()),
          disableMethod = (Action) (() => SettingsMods.RoundMenuOff()),
          isTogglable = false,
          toolTip = "Makes menu round."
        },
        new ButtonInfo()
        {
          buttonText = "Outline Menu [W]",
          method = (Action) (() => SettingsMods.OutlineMenuOn()),
          disableMethod = (Action) (() => SettingsMods.OutlineMenuOff()),
          isTogglable = false,
          toolTip = "Disables outline."
        },
        new ButtonInfo()
        {
          buttonText = "Flip Menu [W]",
          method = (Action) (() => SettingsMods.FlipMenu()),
          disableMethod = (Action) (() => SettingsMods.NonFlippedMenu()),
          isTogglable = false,
          toolTip = "Flips menu."
        },
        new ButtonInfo()
        {
          buttonText = "Rainbow Menu [W?] (not outline)",
          method = (Action) (() => ThemeMods.RainbowMenu()),
          disableMethod = (Action) (() => ThemeMods.NonRainbowMenu()),
          isTogglable = true,
          toolTip = "Changes to a rainbow type theme."
        },
        new ButtonInfo()
        {
          buttonText = "No Outline",
          method = (Action) (() => ThemeMods.NoMoOutline()),
          disableMethod = (Action) (() => ThemeMods.GiveMoOutline()),
          isTogglable = true,
          toolTip = "Takes away the outline good for rainbow theme."
        }
      },
      new ButtonInfo[3]
      {
        new ButtonInfo()
        {
          buttonText = "Return to Main",
          method = (Action) (() => Global.ReturnHome()),
          isTogglable = false,
          toolTip = "Returns to the main page of the menu."
        },
        new ButtonInfo()
        {
          buttonText = "Change Wall Walk",
          method = (Action) (() => Global.ChangeWallWalk()),
          isTogglable = false,
          toolTip = "Changes the amount of wall walk you have."
        },
        new ButtonInfo()
        {
          buttonText = "Rainbow Projectiles",
          method = (Action) (() => ProjectilesMods.EnableRainbowSnowballs()),
          disableMethod = (Action) (() => ProjectilesMods.DisableRainbowSnowballs()),
          isTogglable = false,
          toolTip = "Changes the amount of wall walk you have."
        }
      },
      new ButtonInfo[24]
      {
        new ButtonInfo()
        {
          buttonText = "Return to Main",
          method = (Action) (() => Global.ReturnHome()),
          isTogglable = false,
          toolTip = "Returns to the main page of the menu."
        },
        new ButtonInfo()
        {
          buttonText = "Speedboost [W]",
          method = (Action) (() => MovementMods.Speedboost()),
          isTogglable = true,
          toolTip = "Gives you a small speed boost."
        },
        new ButtonInfo()
        {
          buttonText = "Mosaboost [W]",
          method = (Action) (() => MovementMods.Mosaboost()),
          isTogglable = true,
          toolTip = "Gives you a speed boost like mosa."
        },
        new ButtonInfo()
        {
          buttonText = "TTTPig Boost [W]",
          method = (Action) (() => MovementMods.TTTPigBoost()),
          isTogglable = true,
          toolTip = "Gives you a speed boost like tttpig."
        },
        new ButtonInfo()
        {
          buttonText = "Platforms [W]",
          method = (Action) (() => plats.Platforms()),
          isTogglable = true,
          toolTip = "Spawns platforms under your hand when you press grips."
        },
        new ButtonInfo()
        {
          buttonText = "Invis Platforms [W]",
          method = (Action) (() => MovementMods.InvisPlatforms()),
          isTogglable = true,
          toolTip = "Spawns platforms under your hand when you press grips but you cant see them."
        },
        new ButtonInfo()
        {
          buttonText = "Anti Tag Freeze [W]",
          method = (Action) (() => MovementMods.AntiTagFreeze()),
          isTogglable = true,
          toolTip = "No tag freeze after being tagged."
        },
        new ButtonInfo()
        {
          buttonText = "Ghost Walk [W]",
          method = (Action) (() => MovementMods.TagFreezeWalk()),
          disableMethod = (Action) (() => MovementMods.AntiTagFreeze()),
          isTogglable = true,
          toolTip = "Have tag freeze at all times."
        },
        new ButtonInfo()
        {
          buttonText = "Bunny Hop [W]",
          method = (Action) (() => MovementMods.BunnyHop()),
          isTogglable = true,
          toolTip = "Hop hop give me carrot."
        },
        new ButtonInfo()
        {
          buttonText = "Strafe [W]",
          method = (Action) (() => MovementMods.Strafe()),
          isTogglable = true,
          toolTip = "Makes you strafe."
        },
        new ButtonInfo()
        {
          buttonText = "Dynamic Strafe [W]",
          method = (Action) (() => MovementMods.DynamicStrafe()),
          isTogglable = true,
          toolTip = "Strafe with dynamic speed."
        },
        new ButtonInfo()
        {
          buttonText = "Air Swim [W]",
          method = (Action) (() => MovementMods.AirSwim()),
          isTogglable = true,
          disableMethod = (Action) (() => MovementMods.DisableAirSwim()),
          toolTip = "Swim in air like a fish."
        },
        new ButtonInfo()
        {
          buttonText = "Fast Swim [W]",
          method = (Action) (() => MovementMods.FastSwim()),
          isTogglable = true,
          toolTip = "Swim fast."
        },
        new ButtonInfo()
        {
          buttonText = "NoClip [W]",
          method = (Action) (() => MovementMods.noclip2()),
          isTogglable = true,
          toolTip = "Makes you no clip."
        },
        new ButtonInfo()
        {
          buttonText = "Fly [RG]",
          method = (Action) (() => MovementMods.Fly()),
          isTogglable = true,
          toolTip = "Makes you fly."
        },
        new ButtonInfo()
        {
          buttonText = "Iron Monkey [LG][RG]",
          method = (Action) (() => MovementMods.IronMonke()),
          isTogglable = true,
          toolTip = "Fly like iron man."
        },
        new ButtonInfo()
        {
          buttonText = "Grip Speed Boost [LG][RG]",
          method = (Action) (() => MovementMods.GripSpeedBoost()),
          isTogglable = true,
          toolTip = "Speed boost only while holding grips."
        },
        new ButtonInfo()
        {
          buttonText = "Wall Walk [RG]",
          method = (Action) (() => MovementMods.WallWalk()),
          isTogglable = true,
          toolTip = "When holding right grip you will stick to a wall."
        },
        new ButtonInfo()
        {
          buttonText = "Super Monkey [W?][B]",
          method = (Action) (() => MovementMods.SuperMonke()),
          isTogglable = true,
          toolTip = "Fly like superman."
        },
        new ButtonInfo()
        {
          buttonText = "Low Gravity [W?]",
          method = (Action) (() => WorldMods.LowGravity()),
          disableMethod = (Action) (() => WorldMods.Gravity()),
          isTogglable = true,
          toolTip = "Gives you low gravity."
        },
        new ButtonInfo()
        {
          buttonText = "High Gravity [W?]",
          method = (Action) (() => WorldMods.HighGravity()),
          disableMethod = (Action) (() => WorldMods.Gravity()),
          isTogglable = true,
          toolTip = "Gives you high gravity."
        },
        new ButtonInfo()
        {
          buttonText = "Car Monke [W?]",
          method = (Action) (() => MovementMods.CarMonkey()),
          isTogglable = true,
          toolTip = "Drive a car as a monkey."
        },
        new ButtonInfo()
        {
          buttonText = "Slide Control [W?]",
          method = (Action) (() => MovementMods.SlideControl()),
          isTogglable = true,
          toolTip = "Gives you good side control."
        },
        new ButtonInfo()
        {
          buttonText = "TP Gun [W?]",
          method = (Action) (() => RigMods.TPGun()),
          isTogglable = true,
          toolTip = "Teleports you to where you shoot the gun."
        }
      },
      new ButtonInfo[24]
      {
        new ButtonInfo()
        {
          buttonText = "Return to Main",
          method = (Action) (() => Global.ReturnHome()),
          isTogglable = false,
          toolTip = "Returns to the main page of the menu."
        },
        new ButtonInfo()
        {
          buttonText = "Long Arms [W]",
          method = (Action) (() => RigMods.LongArms()),
          disableMethod = (Action) (() => RigMods.ResetArms()),
          isTogglable = true,
          toolTip = "Gives you long arms."
        },
        new ButtonInfo()
        {
          buttonText = "Long Long Arms [W]",
          method = (Action) (() => RigMods.LongerArms()),
          disableMethod = (Action) (() => RigMods.ResetArms()),
          isTogglable = true,
          toolTip = "Gives you longer arms."
        },
        new ButtonInfo()
        {
          buttonText = "Super Long Long Arms [W]",
          method = (Action) (() => RigMods.SuperLongArms()),
          disableMethod = (Action) (() => RigMods.ResetArms()),
          isTogglable = true,
          toolTip = "Gives you super long arms."
        },
        new ButtonInfo()
        {
          buttonText = "Short Arms [W]",
          method = (Action) (() => RigMods.Shortarms()),
          disableMethod = (Action) (() => RigMods.ResetArms()),
          isTogglable = true,
          toolTip = "Gives you short arms."
        },
        new ButtonInfo()
        {
          buttonText = "Stick Long Arms [W?]",
          method = (Action) (() => RigMods.StickLongArms()),
          disableMethod = (Action) (() => RigMods.ResetArms()),
          isTogglable = true,
          toolTip = "Gives you stick long arms."
        },
        new ButtonInfo()
        {
          buttonText = "Ghost Monkey [W]",
          method = (Action) (() => RigMods.Ghostmonke()),
          isTogglable = true,
          toolTip = "Makes you a ghost monkey."
        },
        new ButtonInfo()
        {
          buttonText = "Invis Monkey [W?]",
          method = (Action) (() => RigMods.InvisMonke()),
          isTogglable = true,
          toolTip = "Makes you invisible."
        },
        new ButtonInfo()
        {
          buttonText = "Upside Down Head [W]",
          method = (Action) (() => FunRandomMods.UpsideDownHead()),
          disableMethod = (Action) (() => FunRandomMods.FixHead()),
          isTogglable = true,
          toolTip = "Flips your head upside down."
        },
        new ButtonInfo()
        {
          buttonText = "Backwards Head [W]",
          method = (Action) (() => FunRandomMods.BackwardsHead()),
          disableMethod = (Action) (() => FunRandomMods.FixHead()),
          isTogglable = true,
          toolTip = "Flips your head backwards."
        },
        new ButtonInfo()
        {
          buttonText = "Spin Head X [W]",
          method = (Action) (() => FunRandomMods.SpinHeadX()),
          disableMethod = (Action) (() => FunRandomMods.FixHead()),
          isTogglable = true,
          toolTip = "Spins head on the X axis."
        },
        new ButtonInfo()
        {
          buttonText = "Spin Head Y [W]",
          method = (Action) (() => FunRandomMods.SpinHeadY()),
          disableMethod = (Action) (() => FunRandomMods.FixHead()),
          isTogglable = true,
          toolTip = "Spins head on the Y axis."
        },
        new ButtonInfo()
        {
          buttonText = "Spin Head Z [W]",
          method = (Action) (() => FunRandomMods.SpinHeadZ()),
          disableMethod = (Action) (() => FunRandomMods.FixHead()),
          isTogglable = true,
          toolTip = "Spins head on the Z axis."
        },
        new ButtonInfo()
        {
          buttonText = "Broken Neck [W]",
          method = (Action) (() => FunRandomMods.BrokenNeck()),
          disableMethod = (Action) (() => FunRandomMods.FixHead()),
          isTogglable = true,
          toolTip = "Breaks neck."
        },
        new ButtonInfo()
        {
          buttonText = "Flip Hands [W]",
          method = (Action) (() => FunRandomMods.FlipHands()),
          disableMethod = (Action) (() => FunRandomMods.FlipHands()),
          isTogglable = true,
          toolTip = "Flips hands."
        },
        new ButtonInfo()
        {
          buttonText = "Rig Gun [W]",
          method = (Action) (() => RigMods.RigGunMod()),
          isTogglable = true,
          toolTip = "Moves your rig to where you shoot."
        },
        new ButtonInfo()
        {
          buttonText = "Spinny Monkey [W?]",
          method = (Action) (() => RigMods.BayBlade()),
          isTogglable = true,
          toolTip = "Monkey goes spinny."
        },
        new ButtonInfo()
        {
          buttonText = "Grab Rig [LG][RG][W?]",
          method = (Action) (() => RigMods.GrabRig()),
          isTogglable = true,
          toolTip = "When you click right and left grip it will grab your rig."
        },
        new ButtonInfo()
        {
          buttonText = "Spaz Monkey [RG][W?]",
          method = (Action) (() => RigMods.SpazMonke()),
          isTogglable = true,
          toolTip = "When you hold right grip it will spaz your rig."
        },
        new ButtonInfo()
        {
          buttonText = "Fake Lag [W?]",
          method = (Action) (() => RigMods.EnableFakeLag()),
          disableMethod = (Action) (() => RigMods.DisableFakeLag()),
          isTogglable = true,
          toolTip = "Makes you have fake lag."
        },
        new ButtonInfo()
        {
          buttonText = "Freeze Rig [W?]",
          method = (Action) (() => RigMods.freezerig()),
          isTogglable = true,
          toolTip = "Makes your rig freeze."
        },
        new ButtonInfo()
        {
          buttonText = "Helicopter Monke [W?]",
          method = (Action) (() => RigMods.Helicopter()),
          isTogglable = true,
          toolTip = "Makes your rig go helicopter."
        },
        new ButtonInfo()
        {
          buttonText = "Hover Monke [W?]",
          method = (Action) (() => RigMods.HoverMonke()),
          isTogglable = true,
          toolTip = "Makes your rig hover."
        },
        new ButtonInfo()
        {
          buttonText = "Spinny Monkey V2 [W?][RG]",
          method = (Action) (() => RigMods.HyperSpinny()),
          isTogglable = true,
          toolTip = "Makes your rig hover."
        }
      },
      new ButtonInfo[2]
      {
        new ButtonInfo()
        {
          buttonText = "Return to Main",
          method = (Action) (() => Global.ReturnHome()),
          isTogglable = false,
          toolTip = "Returns to the main page of the menu."
        },
        new ButtonInfo()
        {
          buttonText = "Illustrator Badge [CS][W]",
          method = (Action) (() => CosmeticMods.IllustratorBadge()),
          disableMethod = (Action) (() => CosmeticMods.DisableIllustratorBadge()),
          isTogglable = true,
          toolTip = "Gives you an illustrator badge but only you can see it."
        }
      },
      new ButtonInfo[9]
      {
        new ButtonInfo()
        {
          buttonText = "Return to Main",
          method = (Action) (() => Global.ReturnHome()),
          isTogglable = false,
          toolTip = "Returns to the main page of the menu."
        },
        new ButtonInfo()
        {
          buttonText = "Instant Hand Taps [W]",
          method = (Action) (() => FunRandomMods.EnableInstantHandTaps()),
          disableMethod = (Action) (() => FunRandomMods.DisableInstantHandTaps()),
          isTogglable = true,
          toolTip = "Makes your hand taps instant."
        },
        new ButtonInfo()
        {
          buttonText = "Leave Party [W?]",
          method = (Action) (() => FunRandomMods.LeaveParty()),
          isTogglable = true,
          toolTip = "Leaves the party."
        },
        new ButtonInfo()
        {
          buttonText = "Mute All [W]",
          method = (Action) (() => FunRandomMods.MuteAll()),
          disableMethod = (Action) (() => FunRandomMods.UnmuteAll()),
          isTogglable = true,
          toolTip = "Mutes everyone in the lobby."
        },
        new ButtonInfo()
        {
          buttonText = "Spawn Bug Baby [NW]",
          method = (Action) (() => FunRandomMods.SpawnBugBabies()),
          isTogglable = true,
          toolTip = "Spawns the bug baby."
        },
        new ButtonInfo()
        {
          buttonText = "Grab All Ids [W?]",
          method = (Action) (() => FunRandomMods.GrabPlayerInfo()),
          isTogglable = true,
          toolTip = "Grabs all players info in the lobby."
        },
        new ButtonInfo()
        {
          buttonText = "Accept Agreements [W?]",
          method = (Action) (() => FunRandomMods.AcceptAgreements()),
          isTogglable = true,
          toolTip = "Accepts the agreements when you join on a new account."
        },
        new ButtonInfo()
        {
          buttonText = "Decline TOS [W?]",
          method = (Action) (() => FunRandomMods.AcceptTOS(false)),
          isTogglable = true,
          toolTip = "Accepts the TOS when you join on a new account."
        },
        new ButtonInfo()
        {
          buttonText = "Water Aura",
          method = (Action) (() => FunRandomMods.WaterAura()),
          isTogglable = true,
          toolTip = "Anyone who comes near you gets splashed with water"
        }
      },
      new ButtonInfo[33]
      {
        new ButtonInfo()
        {
          buttonText = "Return to Main",
          method = (Action) (() => Global.ReturnHome()),
          isTogglable = false,
          toolTip = "Returns to the main page of the menu."
        },
        new ButtonInfo()
        {
          buttonText = "Chams [W]",
          method = (Action) (() => VisualMods.EnableAllChams()),
          disableMethod = (Action) (() => VisualMods.DisableAllChams()),
          isTogglable = true,
          toolTip = "Lets you see people through walls."
        },
        new ButtonInfo()
        {
          buttonText = "Infection Chams [W?]",
          method = (Action) (() => VisualMods.ChamsInfection()),
          disableMethod = (Action) (() => VisualMods.DisableAllChams()),
          isTogglable = true,
          toolTip = "Lets you see infected players through walls."
        },
        new ButtonInfo()
        {
          buttonText = "Head Chams [W?]",
          method = (Action) (() => VisualMods.HeadChams1()),
          disableMethod = (Action) (() => VisualMods.DisableAllChams()),
          isTogglable = true,
          toolTip = "Lets you see players' heads through walls."
        },
        new ButtonInfo()
        {
          buttonText = "ESP [W?]",
          method = (Action) (() => VisualMods.EnableESP()),
          disableMethod = (Action) (() => VisualMods.DisableESP()),
          isTogglable = true,
          toolTip = "Adds glowing outlines around players."
        },
        new ButtonInfo()
        {
          buttonText = "Bone ESP [W?] [could crash game]",
          method = (Action) (() => VisualMods.BoneESPV2()),
          isTogglable = true,
          toolTip = "Adds a glow to all faces or bones of the gorilla."
        },
        new ButtonInfo()
        {
          buttonText = "Tracers",
          method = (Action) (() => VisualMods.Tracers()),
          disableMethod = (Action) (() => VisualMods.DisableTracers()),
          isTogglable = true,
          toolTip = "Adds a line following the player."
        },
        new ButtonInfo()
        {
          buttonText = "Remove Leaves [W?]",
          method = (Action) (() => VisualMods.EnableRemoveLeaves()),
          disableMethod = (Action) (() => VisualMods.DisableRemoveLeaves()),
          isTogglable = true,
          toolTip = "Removes leaves from the forest."
        },
        new ButtonInfo()
        {
          buttonText = "Streamer Remove Leaves [W?]",
          method = (Action) (() => VisualMods.EnableStreamerRemoveLeaves()),
          disableMethod = (Action) (() => VisualMods.DisableStreamerRemoveLeaves()),
          isTogglable = true,
          toolTip = "Removes leaves in-game but not on camera."
        },
        new ButtonInfo()
        {
          buttonText = "Disable Cosmetics [W?]",
          method = (Action) (() => VisualMods.DisableCosmetics()),
          disableMethod = (Action) (() => VisualMods.EnableCosmetics()),
          isTogglable = true,
          toolTip = "Removes cosmetics, good for lag."
        },
        new ButtonInfo()
        {
          buttonText = "Green Sky [W]",
          method = (Action) (() => FunRandomMods.GreenSky()),
          isTogglable = true,
          toolTip = "Makes the sky green."
        },
        new ButtonInfo()
        {
          buttonText = "Red Sky [W]",
          method = (Action) (() => FunRandomMods.RedSky()),
          isTogglable = true,
          toolTip = "Makes the sky red."
        },
        new ButtonInfo()
        {
          buttonText = "Blue Sky [W]",
          method = (Action) (() => FunRandomMods.BlueSky()),
          isTogglable = true,
          toolTip = "Makes the sky blue."
        },
        new ButtonInfo()
        {
          buttonText = "Yellow Sky [W]",
          method = (Action) (() => FunRandomMods.YellowSky()),
          isTogglable = true,
          toolTip = "Makes the sky yellow."
        },
        new ButtonInfo()
        {
          buttonText = "RGB Sky [W?]",
          method = (Action) (() => VisualMods.RgbSky()),
          isTogglable = true,
          toolTip = "Makes the sky RGB."
        },
        new ButtonInfo()
        {
          buttonText = "Night Time [W]",
          method = (Action) (() => FunRandomMods.NightTime()),
          isTogglable = true,
          toolTip = "Makes it night time."
        },
        new ButtonInfo()
        {
          buttonText = "Evening Time [W]",
          method = (Action) (() => FunRandomMods.EveningTime()),
          isTogglable = true,
          toolTip = "Makes it evening time."
        },
        new ButtonInfo()
        {
          buttonText = "Morning Time [W]",
          method = (Action) (() => FunRandomMods.MorningTime()),
          isTogglable = true,
          toolTip = "Makes it morning time."
        },
        new ButtonInfo()
        {
          buttonText = "Day Time [W]",
          method = (Action) (() => FunRandomMods.DayTime()),
          isTogglable = true,
          toolTip = "Makes it day time."
        },
        new ButtonInfo()
        {
          buttonText = "Rain [W]",
          method = (Action) (() => FunRandomMods.Rain()),
          isTogglable = true,
          toolTip = "Makes it rain."
        },
        new ButtonInfo()
        {
          buttonText = "Stop Rain [W]",
          method = (Action) (() => FunRandomMods.NoRain()),
          isTogglable = true,
          toolTip = "Stops the rain."
        },
        new ButtonInfo()
        {
          buttonText = "Full Bright [W]",
          method = (Action) (() => FunRandomMods.Fullbright()),
          isTogglable = true,
          toolTip = "Makes everything bright."
        },
        new ButtonInfo()
        {
          buttonText = "Full Shade [W?]",
          method = (Action) (() => FunRandomMods.Fullshade()),
          isTogglable = true,
          toolTip = "Stops full bright."
        },
        new ButtonInfo()
        {
          buttonText = "Xray (COULD CRASH GAME)[W?]",
          method = (Action) (() => VisualMods.Xray()),
          disableMethod = (Action) (() => VisualMods.DisableXray()),
          isTogglable = true,
          toolTip = "See through walls."
        },
        new ButtonInfo()
        {
          buttonText = "Doug ESP[W?]",
          method = (Action) (() => VisualMods.DougESP()),
          isTogglable = true,
          toolTip = "See Doug the Bug through walls."
        },
        new ButtonInfo()
        {
          buttonText = "Mat ESP[W?]",
          method = (Action) (() => VisualMods.MatESP()),
          isTogglable = true,
          toolTip = "See Mat the Bat through walls."
        },
        new ButtonInfo()
        {
          buttonText = "Snake ESP[W?]",
          method = (Action) (() => VisualMods.SnakeESP2()),
          isTogglable = true,
          toolTip = "Gives players a sphere on there head."
        },
        new ButtonInfo()
        {
          buttonText = "Box ESP[W?]",
          method = (Action) (() => VisualMods.BoxESP()),
          isTogglable = true,
          toolTip = "Puts a box around players."
        },
        new ButtonInfo()
        {
          buttonText = "Beacons [W?]",
          method = (Action) (() => VisualMods.Beacons()),
          isTogglable = true,
          toolTip = "Puts a beacon on players."
        },
        new ButtonInfo()
        {
          buttonText = "Infection Box ESP [W?]",
          method = (Action) (() => VisualMods.InfectionBoxESP()),
          isTogglable = true,
          toolTip = "Puts a box on tagged on players."
        },
        new ButtonInfo()
        {
          buttonText = "Bat Halo [W?]",
          method = (Action) (() => VisualMods.BatHalo()),
          isTogglable = true,
          toolTip = "Puts a halo on Mat the Bat."
        },
        new ButtonInfo()
        {
          buttonText = "Ball Infection ESP [W?]",
          method = (Action) (() => VisualMods.InfectionBallESP()),
          isTogglable = true,
          toolTip = "Gives you an infection esp but its a ball"
        },
        new ButtonInfo()
        {
          buttonText = "Hand ESP [W?]",
          method = (Action) (() => VisualMods.HandEsp()),
          isTogglable = true,
          toolTip = "Gives you an esp on peoples hand"
        }
      },
      new ButtonInfo[13]
      {
        new ButtonInfo()
        {
          buttonText = "Return to Main",
          method = (Action) (() => Global.ReturnHome()),
          isTogglable = false,
          toolTip = "Returns to the main page of the menu."
        },
        new ButtonInfo()
        {
          buttonText = "Disable Gamemodes [W?]",
          method = (Action) (() => SafetyMods.DisableGamemodeButtons()),
          disableMethod = (Action) (() => SafetyMods.EnableGamemodeButtons()),
          isTogglable = true,
          toolTip = "Disables the gamemode buttons."
        },
        new ButtonInfo()
        {
          buttonText = "Spoof Page [W?]",
          method = (Action) (() => SafetyMods.EnableSpoofSupportPage()),
          disableMethod = (Action) (() => SafetyMods.DisableSpoofSupportPage()),
          isTogglable = true,
          toolTip = "Makes support page look like Oculus."
        },
        new ButtonInfo()
        {
          buttonText = "Anti Moderator [W?]",
          method = (Action) (() => FunRandomMods.antimoderator()),
          isTogglable = true,
          toolTip = "Leaves the lobby if a moderator joins."
        },
        new ButtonInfo()
        {
          buttonText = "Master Check [W?]",
          method = (Action) (() => OverpoweredMods.MasterCheck()),
          isTogglable = true,
          toolTip = "Checks if you are a master."
        },
        new ButtonInfo()
        {
          buttonText = "Anti Report V1 [W?]",
          method = (Action) (() => SafetyMods.Antireportdisconnect()),
          isTogglable = true,
          toolTip = "Enables an anti report ."
        },
        new ButtonInfo()
        {
          buttonText = "Anti Report V2 [W?]",
          method = (Action) (() => SafetyMods.Antireportdisconnect()),
          isTogglable = true,
          toolTip = "Enables an anti report V2."
        },
        new ButtonInfo()
        {
          buttonText = "Anti Report V3 [W?]",
          method = (Action) (() => SafetyMods.AntiReportV3()),
          isTogglable = true,
          toolTip = "Enables an anti report V3."
        },
        new ButtonInfo()
        {
          buttonText = "Anti Report Reconnect [W?]",
          method = (Action) (() => SafetyMods.AntireportReconnect()),
          isTogglable = true,
          toolTip = "Enables an anti report but you will reconnect."
        },
        new ButtonInfo()
        {
          buttonText = "Flush RPC [W?]",
          method = (Action) (() => SafetyMods.FlushRPCs()),
          isTogglable = true,
          toolTip = "Flushes RPCs."
        },
        new ButtonInfo()
        {
          buttonText = "Unlimited RPC [W?]",
          method = (Action) (() => SafetyMods.UnlimitedRpcs()),
          isTogglable = true,
          toolTip = "Gives you 999999999 RPCs."
        },
        new ButtonInfo()
        {
          buttonText = "Panic [W?]",
          method = (Action) (() => SafetyMods.DisableAllMods()),
          isTogglable = true,
          toolTip = "Disables ALL mods."
        },
        new ButtonInfo()
        {
          buttonText = "Report All [W?]",
          method = (Action) (() => SafetyMods.ReportAll()),
          isTogglable = true,
          toolTip = "Reports everyone in the lobby."
        }
      },
      new ButtonInfo[11]
      {
        new ButtonInfo()
        {
          buttonText = "Return to Main",
          method = (Action) (() => Global.ReturnHome()),
          isTogglable = false,
          toolTip = "Returns to the main page of the menu."
        },
        new ButtonInfo()
        {
          buttonText = "Tag Lag [W?]",
          method = (Action) (() => AdvantageMods.TagLag()),
          disableMethod = (Action) (() => AdvantageMods.NahTagLag()),
          isTogglable = true,
          toolTip = "Gives the lobby tag lag."
        },
        new ButtonInfo()
        {
          buttonText = "Tag All [W?]",
          method = (Action) (() => AdvantageMods.TagAllV2()),
          isTogglable = true,
          toolTip = "Tags the whole lobby."
        },
        new ButtonInfo()
        {
          buttonText = "Flick Tag [RG][W]",
          method = (Action) (() => AdvantageMods.FlickTagV1()),
          isTogglable = true,
          toolTip = "Teleports your hand to tag people farther away."
        },
        new ButtonInfo()
        {
          buttonText = "Tag Aura [W?]",
          method = (Action) (() => AdvantageMods.TagAura()),
          isTogglable = true,
          toolTip = "Anyone who comes close to you gets auto tagged."
        },
        new ButtonInfo()
        {
          buttonText = "Tag Aura V2 [RG][W?]",
          method = (Action) (() => AdvantageMods.TagAuraV2()),
          isTogglable = true,
          toolTip = "Anyone who comes close to you gets auto tagged."
        },
        new ButtonInfo()
        {
          buttonText = "Tag Gun [W?]",
          method = (Action) (() => AdvantageMods.TagGun()),
          isTogglable = true,
          toolTip = "Anyone you shoot with this will get tagged."
        },
        new ButtonInfo()
        {
          buttonText = "Tag Self [W?]",
          method = (Action) (() => AdvantageMods.TagSelf()),
          isTogglable = true,
          toolTip = "Tags yourself."
        },
        new ButtonInfo()
        {
          buttonText = "Tag Self V2 [W?]",
          method = (Action) (() => AdvantageMods.TagSelfV2()),
          isTogglable = true,
          toolTip = "Tags yourself V2."
        },
        new ButtonInfo()
        {
          buttonText = "No Tag On Join [W?]",
          method = (Action) (() => AdvantageMods.NoTagOnJoin()),
          isTogglable = true,
          toolTip = "Makes it so that whenever you join a lobby you do not get tagged right away."
        },
        new ButtonInfo()
        {
          buttonText = "Untag Self [W?]",
          method = (Action) (() => AdvantageMods.UntagSelf()),
          isTogglable = true,
          toolTip = "Make you a normal nontagged monkey you."
        }
      },
      new ButtonInfo[10]
      {
        new ButtonInfo()
        {
          buttonText = "Return to Main",
          method = (Action) (() => Global.ReturnHome()),
          isTogglable = false,
          toolTip = "Returns to the main page of the menu."
        },
        new ButtonInfo()
        {
          buttonText = "Disable Network Triggers [W?]",
          method = (Action) (() => NetworkMods.DisableNetworkTriggers()),
          disableMethod = (Action) (() => NetworkMods.DisableNetworkTriggers()),
          isTogglable = true,
          toolTip = "Turns off network triggers."
        },
        new ButtonInfo()
        {
          buttonText = "Disable Map Triggers [W?]",
          method = (Action) (() => NetworkMods.DisableMapTriggers()),
          disableMethod = (Action) (() => NetworkMods.EnableMapTriggers()),
          isTogglable = true,
          toolTip = "Turns off map triggers."
        },
        new ButtonInfo()
        {
          buttonText = "Join US Servers [W?]",
          method = (Action) (() => NetworkMods.USServers()),
          isTogglable = true,
          toolTip = "Joins US region servers."
        },
        new ButtonInfo()
        {
          buttonText = "Join USW Servers [W?]",
          method = (Action) (() => NetworkMods.USWServers()),
          isTogglable = true,
          toolTip = "Joins USW region servers."
        },
        new ButtonInfo()
        {
          buttonText = "Join EU Servers [W?]",
          method = (Action) (() => NetworkMods.EUServers()),
          isTogglable = true,
          toolTip = "Joins EU region servers."
        },
        new ButtonInfo()
        {
          buttonText = "Unlock Comp Queue [W?]",
          method = (Action) (() => NetworkMods.UnlockCompetitiveQueue()),
          isTogglable = true,
          toolTip = "Unlocks Competitive Queue."
        },
        new ButtonInfo()
        {
          buttonText = "Anti AFK [W?]",
          method = (Action) (() => NetworkMods.AntiAFK()),
          isTogglable = true,
          toolTip = "Prevents being kicked for being AFK."
        },
        new ButtonInfo()
        {
          buttonText = "Kick All Party [W?]",
          method = (Action) (() => NetworkMods.KickAllParty()),
          isTogglable = true,
          toolTip = "Kicks everyone in your party."
        },
        new ButtonInfo()
        {
          buttonText = "Kick All Group [W?]",
          method = (Action) (() => NetworkMods.KickAllGroup()),
          isTogglable = true,
          toolTip = "Kicks everyone who is next to the computer."
        }
      },
      new ButtonInfo[12]
      {
        new ButtonInfo()
        {
          buttonText = "Return to Main",
          method = (Action) (() => Global.ReturnHome()),
          isTogglable = false,
          toolTip = "Returns to the main page of the menu."
        },
        new ButtonInfo()
        {
          buttonText = "Ir!s Name [W?]",
          method = (Action) (() => FunRandomMods.NameVortex()),
          isTogglable = true,
          toolTip = "Changes name to Ir!s On Top."
        },
        new ButtonInfo()
        {
          buttonText = "Smiley Name [W?]",
          method = (Action) (() => FunRandomMods.NameSmiley()),
          isTogglable = true,
          toolTip = "Changes name to :)."
        },
        new ButtonInfo()
        {
          buttonText = "Vortex Name [W?]",
          method = (Action) (() => FunRandomMods.NameVortex()),
          isTogglable = true,
          toolTip = "Changes name to Vortex On Top."
        },
        new ButtonInfo()
        {
          buttonText = "Celestial.GG Name [W?]",
          method = (Action) (() => FunRandomMods.NameCelestialgg()),
          isTogglable = true,
          toolTip = "Changes name to Celestial.GG ON TOP."
        },
        new ButtonInfo()
        {
          buttonText = "Strobe All [W?]",
          method = (Action) (() => FunRandomMods.MakeAllStrobe()),
          isTogglable = true,
          toolTip = "Makes all strobe."
        },
        new ButtonInfo()
        {
          buttonText = "Make Everyone RGB",
          method = (Action) (() => FunRandomMods.makeeveryonergb()),
          isTogglable = true,
          toolTip = "Makes everyone RGB."
        },
        new ButtonInfo()
        {
          buttonText = "Caseoh Monkey [W]",
          method = (Action) (() => FunRandomMods.CaseohMonke()),
          isTogglable = true,
          toolTip = "Become Caseoh."
        },
        new ButtonInfo()
        {
          buttonText = "Orbit Bug [W?]",
          method = (Action) (() => PlayerMods.OrbitBug()),
          isTogglable = true,
          toolTip = "Orbits Doug the Bug."
        },
        new ButtonInfo()
        {
          buttonText = "Orbit Bat [W?]",
          method = (Action) (() => PlayerMods.OrbitBat()),
          isTogglable = true,
          toolTip = "Orbits Mat the Bat."
        },
        new ButtonInfo()
        {
          buttonText = "Orbit Monster [W?]",
          method = (Action) (() => PlayerMods.OrbitMonster()),
          isTogglable = true,
          toolTip = "Orbits Monsters."
        },
        new ButtonInfo()
        {
          buttonText = "Freeze All [W?]",
          method = (Action) (() => PlayerMods.FreezeAll()),
          isTogglable = true,
          toolTip = "Freeze's all players."
        }
      },
      new ButtonInfo[22]
      {
        new ButtonInfo()
        {
          buttonText = "Return to Main",
          method = (Action) (() => Global.ReturnHome()),
          isTogglable = false,
          toolTip = "Returns to the main page of the menu."
        },
        new ButtonInfo()
        {
          buttonText = "Glider Spaz [W?]",
          method = (Action) (() => WorldMods.GliderSpaz()),
          isTogglable = true,
          toolTip = "Makes gliders spam."
        },
        new ButtonInfo()
        {
          buttonText = "TP To Glider [W?]",
          method = (Action) (() => WorldMods.TpToGlider()),
          isTogglable = true,
          toolTip = "Teleports you to a glider."
        },
        new ButtonInfo()
        {
          buttonText = "Grab Bug [W]",
          method = (Action) (() => FunRandomMods.GrabBug()),
          isTogglable = true,
          toolTip = "Grabs Doug the Bug."
        },
        new ButtonInfo()
        {
          buttonText = "Big AHH Bug [W]",
          method = (Action) (() => FunRandomMods.BigBug()),
          isTogglable = true,
          toolTip = "Makes Doug the Bug big."
        },
        new ButtonInfo()
        {
          buttonText = "Grab Bat [W]",
          method = (Action) (() => FunRandomMods.GrabBat()),
          isTogglable = true,
          toolTip = "Grabs Mat the Bat."
        },
        new ButtonInfo()
        {
          buttonText = "Big AHH Bat [W]",
          method = (Action) (() => FunRandomMods.BigBat()),
          isTogglable = true,
          toolTip = "Makes Mat the Bat big."
        },
        new ButtonInfo()
        {
          buttonText = "Grab Rocket [W]",
          method = (Action) (() => FunRandomMods.GrabRocket()),
          isTogglable = true,
          toolTip = "Grabs rocket."
        },
        new ButtonInfo()
        {
          buttonText = "Grab Monsters [W?]",
          method = (Action) (() => WorldMods.GrabMonsters()),
          isTogglable = true,
          toolTip = "Grabs monsters."
        },
        new ButtonInfo()
        {
          buttonText = "End All Arcade [W?]",
          method = (Action) (() => WorldMods.EndAllArcade()),
          isTogglable = true,
          toolTip = "Ends all arcade machines."
        },
        new ButtonInfo()
        {
          buttonText = "Start All Arcade [W?]",
          method = (Action) (() => WorldMods.TurnOnAllArcade()),
          isTogglable = true,
          toolTip = "Starts all arcade machines."
        },
        new ButtonInfo()
        {
          buttonText = "Walk On Water [W?]",
          method = (Action) (() => WorldMods.SolidWater()),
          isTogglable = true,
          toolTip = "Allows you to walk on water."
        },
        new ButtonInfo()
        {
          buttonText = "Water Splash Hands [W?]",
          method = (Action) (() => WorldMods.WaterSpamHands()),
          isTogglable = true,
          toolTip = "Will splash your hands."
        },
        new ButtonInfo()
        {
          buttonText = "Water Splash Body [W?]",
          method = (Action) (() => WorldMods.WaterSpamBody()),
          isTogglable = true,
          toolTip = "Will splash your body."
        },
        new ButtonInfo()
        {
          buttonText = "Water Splash Head [W?]",
          method = (Action) (() => WorldMods.WaterSpamHead()),
          isTogglable = true,
          toolTip = "Will splash your head."
        },
        new ButtonInfo()
        {
          buttonText = "Ride Bug [W?]",
          method = (Action) (() => WorldMods.RideBug()),
          isTogglable = true,
          toolTip = "Rides Doug the Bug."
        },
        new ButtonInfo()
        {
          buttonText = "Ride Bat [W?]",
          method = (Action) (() => WorldMods.RideBat()),
          isTogglable = true,
          toolTip = "Rides Mat the Bat."
        },
        new ButtonInfo()
        {
          buttonText = "Join Ghost Codes [W?]",
          method = (Action) (() => WorldMods.JoinRandomGhostCode()),
          isTogglable = true,
          toolTip = "Joins random ghost codes."
        },
        new ButtonInfo()
        {
          buttonText = "I Lava You Update [W?]",
          method = (Action) (() => WorldMods.EnableILavaYou()),
          disableMethod = (Action) (() => WorldMods.DisableILavaYou()),
          isTogglable = true,
          toolTip = "Enables the i lava you update."
        },
        new ButtonInfo()
        {
          buttonText = "Ropes Up [RG]",
          method = (Action) (() => WorldMods.RopessUp()),
          isTogglable = true,
          toolTip = "Flings ropes up"
        },
        new ButtonInfo()
        {
          buttonText = "Ropes Down [RG]",
          method = (Action) (() => WorldMods.RopesDown()),
          isTogglable = true,
          toolTip = "Flings ropes down"
        },
        new ButtonInfo()
        {
          buttonText = "Rope Fling [RG]",
          method = (Action) (() => WorldMods.RopeFling()),
          isTogglable = true,
          toolTip = "Flings ropes"
        }
      },
      new ButtonInfo[3]
      {
        new ButtonInfo()
        {
          buttonText = "Return to Main",
          method = (Action) (() => Global.ReturnHome()),
          isTogglable = false,
          toolTip = "Returns to the main page of the menu."
        },
        new ButtonInfo()
        {
          buttonText = "Crash All [W?]",
          method = (Action) (() => OverpoweredMods.CrashAll()),
          isTogglable = true,
          toolTip = "Will freeze your game for about 5 seconds then crash everyone in game."
        },
        new ButtonInfo()
        {
          buttonText = "RPC All [W?]",
          method = (Action) (() => OverpoweredMods.RpcAll()),
          isTogglable = true,
          toolTip = "Gives everyone RPC's other then yourself."
        }
      },
      new ButtonInfo[15]
      {
        new ButtonInfo()
        {
          buttonText = "Return to Main",
          method = (Action) (() => Global.ReturnHome()),
          isTogglable = false,
          toolTip = "Returns to the main page of the menu."
        },
        new ButtonInfo()
        {
          buttonText = "Snowball Spam [W?][RG][LG]",
          method = (Action) (() => ProjectilesMods.SnowballSpam()),
          isTogglable = true,
          toolTip = "Spam drops snowballs."
        },
        new ButtonInfo()
        {
          buttonText = "Water Balloon Spam [W?][RG][LG]",
          method = (Action) (() => ProjectilesMods.WaterBallonSpam()),
          isTogglable = true,
          toolTip = "Spam drops water balloons."
        },
        new ButtonInfo()
        {
          buttonText = "Ice Spam [W?][RG][LG]",
          method = (Action) (() => ProjectilesMods.iceSpam()),
          isTogglable = true,
          toolTip = "Spam drops ice."
        },
        new ButtonInfo()
        {
          buttonText = "Cloud Spam [W?][RG][LG]",
          method = (Action) (() => ProjectilesMods.CloudSpam()),
          isTogglable = true,
          toolTip = "Spam drops clouds."
        },
        new ButtonInfo()
        {
          buttonText = "Candy Cane Spam [W?][RG][LG]",
          method = (Action) (() => ProjectilesMods.CandyCaneSpam()),
          isTogglable = true,
          toolTip = "Spam drops candy canes."
        },
        new ButtonInfo()
        {
          buttonText = "Coal Spam [NW][RG][LG]",
          method = (Action) (() => ProjectilesMods.CoalSpam()),
          isTogglable = true,
          toolTip = "Spam drops coal."
        },
        new ButtonInfo()
        {
          buttonText = "Cum Spam [W?][RG][LG]",
          method = (Action) (() => ProjectilesMods.CUM()),
          isTogglable = true,
          toolTip = "Release your children into the world of monkey."
        },
        new ButtonInfo()
        {
          buttonText = "Piss Spam [W?][RG][LG]",
          method = (Action) (() => ProjectilesMods.PISS()),
          isTogglable = true,
          toolTip = "Piss on everyone."
        },
        new ButtonInfo()
        {
          buttonText = "Shit Spam [W?][RG][LG]",
          method = (Action) (() => ProjectilesMods.SHIT()),
          isTogglable = true,
          toolTip = "Shit on everyone."
        },
        new ButtonInfo()
        {
          buttonText = "Apple Spam [W?][RG][LG]",
          method = (Action) (() => ProjectilesMods.Applespammmer()),
          isTogglable = true,
          toolTip = "Spam drops apples."
        },
        new ButtonInfo()
        {
          buttonText = "Cupid Spam [W?][RG][LG]",
          method = (Action) (() => ProjectilesMods.cupidspammmer()),
          isTogglable = true,
          toolTip = "Spam drops cup."
        },
        new ButtonInfo()
        {
          buttonText = "Elf Spam [W?][RG][LG]",
          method = (Action) (() => ProjectilesMods.elfspammmer()),
          isTogglable = true,
          toolTip = "Spam drops elfs."
        },
        new ButtonInfo()
        {
          buttonText = "Eyeball Spam [W?][RG][LG]",
          method = (Action) (() => ProjectilesMods.eyeballspammmer()),
          isTogglable = true,
          toolTip = "Spam drops eyeballs."
        },
        new ButtonInfo()
        {
          buttonText = "Candy Corn Spam [W?][RG][LG]",
          method = (Action) (() => ProjectilesMods.candycornspammmer()),
          isTogglable = true,
          toolTip = "Spam drops candy corn."
        }
      },
      new ButtonInfo[191]
      {
        new ButtonInfo()
        {
          buttonText = "Return to Main",
          method = (Action) (() => Global.ReturnHome()),
          isTogglable = false,
          toolTip = "Returns to the main page of the menu."
        },
        new ButtonInfo()
        {
          buttonText = "Default Theme [W?]",
          method = (Action) (() => ThemeMods.DefaultTheme()),
          isTogglable = true,
          toolTip = "Changes to default black and yellow theme because im to lazy to set up a disable method."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 1 [W?]",
          method = (Action) (() => ThemeMods.Theme1()),
          isTogglable = true,
          toolTip = "Changes to a dark grey type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 2 [W?]",
          method = (Action) (() => ThemeMods.Theme2()),
          isTogglable = true,
          toolTip = "Changes to a dark grey v2 type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 3 [W?]",
          method = (Action) (() => ThemeMods.Theme3()),
          isTogglable = true,
          toolTip = "Changes to a dark red type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 4 [W?]",
          method = (Action) (() => ThemeMods.Theme4()),
          isTogglable = true,
          toolTip = "Changes to a crimson type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 5 [W?]",
          method = (Action) (() => ThemeMods.Theme5()),
          isTogglable = true,
          toolTip = "Changes to a maroon type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 6 [W?]",
          method = (Action) (() => ThemeMods.Theme6()),
          isTogglable = true,
          toolTip = "Changes to an Indian red type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 7 [W?]",
          method = (Action) (() => ThemeMods.Theme7()),
          isTogglable = true,
          toolTip = "Changes to a firebrick type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 8 [W?]",
          method = (Action) (() => ThemeMods.Theme8()),
          isTogglable = true,
          toolTip = "Changes to a dark blue type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 9 [W?]",
          method = (Action) (() => ThemeMods.Theme9()),
          isTogglable = true,
          toolTip = "Changes to a brick red type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 10 [W?]",
          method = (Action) (() => ThemeMods.Theme10()),
          isTogglable = true,
          toolTip = "Changes to a tomato type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 11 [W?]",
          method = (Action) (() => ThemeMods.Theme11()),
          isTogglable = true,
          toolTip = "Changes to a coral type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 12 [W?]",
          method = (Action) (() => ThemeMods.Theme12()),
          isTogglable = true,
          toolTip = "Changes to a dark salmon type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 13 [W?]",
          method = (Action) (() => ThemeMods.Theme13()),
          isTogglable = true,
          toolTip = "Changes to a salmon type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 14 [W?]",
          method = (Action) (() => ThemeMods.Theme14()),
          isTogglable = true,
          toolTip = "Changes to a light coral type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 15 [W?]",
          method = (Action) (() => ThemeMods.Theme15()),
          isTogglable = true,
          toolTip = "Changes to a hot pink type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 16 [W?]",
          method = (Action) (() => ThemeMods.Theme16()),
          isTogglable = true,
          toolTip = "Changes to a pale violet red type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 17 [W?]",
          method = (Action) (() => ThemeMods.Theme17()),
          isTogglable = true,
          toolTip = "Changes to a medium violet red type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 18 [W?]",
          method = (Action) (() => ThemeMods.Theme18()),
          isTogglable = true,
          toolTip = "Changes to a deep pink type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 19 [W?]",
          method = (Action) (() => ThemeMods.Theme19()),
          isTogglable = true,
          toolTip = "Changes to a pink type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 20 [W?]",
          method = (Action) (() => ThemeMods.Theme20()),
          isTogglable = true,
          toolTip = "Changes to a light purple type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 21 [W?]",
          method = (Action) (() => ThemeMods.Theme21()),
          isTogglable = true,
          toolTip = "Changes to a dark purple type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 22 [W?]",
          method = (Action) (() => ThemeMods.Theme22()),
          isTogglable = true,
          toolTip = "Changes to a purply again type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 23 [W?]",
          method = (Action) (() => ThemeMods.Theme23()),
          isTogglable = true,
          toolTip = "Changes to a theme color purple type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 24 [W?]",
          method = (Action) (() => ThemeMods.Theme24()),
          isTogglable = true,
          toolTip = "Changes to a darker pink type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 25 [W?]",
          method = (Action) (() => ThemeMods.Theme25()),
          isTogglable = true,
          toolTip = "Changes to a light pink type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 26 [W?]",
          method = (Action) (() => ThemeMods.Theme26()),
          isTogglable = true,
          toolTip = "Changes to an orchid type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 27 [W?]",
          method = (Action) (() => ThemeMods.Theme27()),
          isTogglable = true,
          toolTip = "Changes to a medium orchid type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 28 [W?]",
          method = (Action) (() => ThemeMods.Theme28()),
          isTogglable = true,
          toolTip = "Changes to a pale orchid type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 29 [W?]",
          method = (Action) (() => ThemeMods.Theme29()),
          isTogglable = true,
          toolTip = "Changes to a purple type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 30 [W?]",
          method = (Action) (() => ThemeMods.Theme30()),
          isTogglable = true,
          toolTip = "Changes to a second purple type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 31 [W?]",
          method = (Action) (() => ThemeMods.Theme31()),
          isTogglable = true,
          toolTip = "Changes to a medium purple type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 32 [W?]",
          method = (Action) (() => ThemeMods.Theme32()),
          isTogglable = true,
          toolTip = "Changes to a purple von type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 33 [W?]",
          method = (Action) (() => ThemeMods.Theme33()),
          isTogglable = true,
          toolTip = "Changes to a dark grey von type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 34 [W?]",
          method = (Action) (() => ThemeMods.Theme34()),
          isTogglable = true,
          toolTip = "Changes to a thistle type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 35 [W?]",
          method = (Action) (() => ThemeMods.Theme35()),
          isTogglable = true,
          toolTip = "Changes to a plum type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 36 [W?]",
          method = (Action) (() => ThemeMods.Theme36()),
          isTogglable = true,
          toolTip = "Changes to a lavender type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 37 [W?]",
          method = (Action) (() => ThemeMods.Theme37()),
          isTogglable = true,
          toolTip = "Changes to a violet type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 38 [W?]",
          method = (Action) (() => ThemeMods.Theme38()),
          isTogglable = true,
          toolTip = "Changes to an indigo type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 39 [W?]",
          method = (Action) (() => ThemeMods.Theme39()),
          isTogglable = true,
          toolTip = "Changes to a slate blue type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 40 [W?]",
          method = (Action) (() => ThemeMods.Theme40()),
          isTogglable = true,
          toolTip = "Changes to a dark slate blue type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 41 [W?]",
          method = (Action) (() => ThemeMods.Theme41()),
          isTogglable = true,
          toolTip = "Changes to a medium slate blue type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 42 [W?]",
          method = (Action) (() => ThemeMods.Theme42()),
          isTogglable = true,
          toolTip = "Changes to a blue violet type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 43 [W?]",
          method = (Action) (() => ThemeMods.Theme43()),
          isTogglable = true,
          toolTip = "Changes to a dark violet type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 44 [W?]",
          method = (Action) (() => ThemeMods.Theme44()),
          isTogglable = true,
          toolTip = "Changes to a dark orchid type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 45 [W?]",
          method = (Action) (() => ThemeMods.Theme45()),
          isTogglable = true,
          toolTip = "Changes to a dark magenta type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 46 [W?]",
          method = (Action) (() => ThemeMods.Theme46()),
          isTogglable = true,
          toolTip = "Changes to a dark lavender type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 47 [W?]",
          method = (Action) (() => ThemeMods.Theme47()),
          isTogglable = true,
          toolTip = "Changes to a dark indigo type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 48 [W?]",
          method = (Action) (() => ThemeMods.Theme48()),
          isTogglable = true,
          toolTip = "Changes to a dark cornflower blue type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 49 [W?]",
          method = (Action) (() => ThemeMods.Theme49()),
          isTogglable = true,
          toolTip = "Changes to a dark cyan type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 50 [W?]",
          method = (Action) (() => ThemeMods.Theme50()),
          isTogglable = true,
          toolTip = "Changes to a cadet blue type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 51 [W?]",
          method = (Action) (() => ThemeMods.Theme51()),
          isTogglable = true,
          toolTip = "Changes to a dark turquoise type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 52 [W?]",
          method = (Action) (() => ThemeMods.Theme52()),
          isTogglable = true,
          toolTip = "Changes to a medium turquoise type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 53 [W?]",
          method = (Action) (() => ThemeMods.Theme53()),
          isTogglable = true,
          toolTip = "Changes to a light sea green type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 54 [W?]",
          method = (Action) (() => ThemeMods.Theme54()),
          isTogglable = true,
          toolTip = "Changes to a turquoise type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 55 [W?]",
          method = (Action) (() => ThemeMods.Theme55()),
          isTogglable = true,
          toolTip = "Changes to an aquamarine type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 56 [W?]",
          method = (Action) (() => ThemeMods.Theme56()),
          isTogglable = true,
          toolTip = "Changes to a medium aquamarine type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 57 [W?]",
          method = (Action) (() => ThemeMods.Theme57()),
          isTogglable = true,
          toolTip = "Changes to a light green type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 58 [W?]",
          method = (Action) (() => ThemeMods.Theme58()),
          isTogglable = true,
          toolTip = "Changes to a pale green type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 59 [W?]",
          method = (Action) (() => ThemeMods.Theme59()),
          isTogglable = true,
          toolTip = "Changes to a spring green type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 60 [W?]",
          method = (Action) (() => ThemeMods.Theme60()),
          isTogglable = true,
          toolTip = "Changes to a medium spring green type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 61 [W?]",
          method = (Action) (() => ThemeMods.Theme61()),
          isTogglable = true,
          toolTip = "Changes to a dark sea green type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 62 [W?]",
          method = (Action) (() => ThemeMods.Theme62()),
          isTogglable = true,
          toolTip = "Changes to a sea green type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 63 [W?]",
          method = (Action) (() => ThemeMods.Theme63()),
          isTogglable = true,
          toolTip = "Changes to a forest green type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 64 [W?]",
          method = (Action) (() => ThemeMods.Theme64()),
          isTogglable = true,
          toolTip = "Changes to a green type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 65 [W?]",
          method = (Action) (() => ThemeMods.Theme65()),
          isTogglable = true,
          toolTip = "Changes to a dark olive green type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 66 [W?]",
          method = (Action) (() => ThemeMods.Theme66()),
          isTogglable = true,
          toolTip = "Changes to an olive drab type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 67 [W?]",
          method = (Action) (() => ThemeMods.Theme67()),
          isTogglable = true,
          toolTip = "Changes to an olive type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 68 [W?]",
          method = (Action) (() => ThemeMods.Theme68()),
          isTogglable = true,
          toolTip = "Changes to a yellow green type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 69 [W?]",
          method = (Action) (() => ThemeMods.Theme69()),
          isTogglable = true,
          toolTip = "Changes to a chartreuse type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 70 [W?]",
          method = (Action) (() => ThemeMods.Theme70()),
          isTogglable = true,
          toolTip = "Changes to a lawn green type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 71 [W?]",
          method = (Action) (() => ThemeMods.Theme71()),
          isTogglable = true,
          toolTip = "Changes to a lime type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 72 [W?]",
          method = (Action) (() => ThemeMods.Theme72()),
          isTogglable = true,
          toolTip = "Changes to a lime green type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 73 [W?]",
          method = (Action) (() => ThemeMods.Theme73()),
          isTogglable = true,
          toolTip = "Changes to a light goldenrod yellow type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 74 [W?]",
          method = (Action) (() => ThemeMods.Theme74()),
          isTogglable = true,
          toolTip = "Changes to a light yellow type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 75 [W?]",
          method = (Action) (() => ThemeMods.Theme75()),
          isTogglable = true,
          toolTip = "Changes to a pale goldenrod type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 76 [W?]",
          method = (Action) (() => ThemeMods.Theme76()),
          isTogglable = true,
          toolTip = "Changes to a dark khaki type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 77 [W?]",
          method = (Action) (() => ThemeMods.Theme77()),
          isTogglable = true,
          toolTip = "Changes to a gold type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 78 [W?]",
          method = (Action) (() => ThemeMods.Theme78()),
          isTogglable = true,
          toolTip = "Changes to a light goldenrod type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 79 [W?]",
          method = (Action) (() => ThemeMods.Theme79()),
          isTogglable = true,
          toolTip = "Changes to a goldenrod type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 80 [W?]",
          method = (Action) (() => ThemeMods.Theme80()),
          isTogglable = true,
          toolTip = "Changes to a dark goldenrod type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 81 [W?]",
          method = (Action) (() => ThemeMods.Theme81()),
          isTogglable = true,
          toolTip = "Changes to a rosy brown type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 82 [W?]",
          method = (Action) (() => ThemeMods.Theme82()),
          isTogglable = true,
          toolTip = "Changes to a saddle brown type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 83 [W?]",
          method = (Action) (() => ThemeMods.Theme83()),
          isTogglable = true,
          toolTip = "Changes to a sienna type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 84 [W?]",
          method = (Action) (() => ThemeMods.Theme84()),
          isTogglable = true,
          toolTip = "Changes to a peru type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 85 [W?]",
          method = (Action) (() => ThemeMods.Theme85()),
          isTogglable = true,
          toolTip = "Changes to a burlywood type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 86 [W?]",
          method = (Action) (() => ThemeMods.Theme86()),
          isTogglable = true,
          toolTip = "Changes to a beige type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 87 [W?]",
          method = (Action) (() => ThemeMods.Theme87()),
          isTogglable = true,
          toolTip = "Changes to a wheat type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 88 [W?]",
          method = (Action) (() => ThemeMods.Theme88()),
          isTogglable = true,
          toolTip = "Changes to a sandy brown type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 89 [W?]",
          method = (Action) (() => ThemeMods.Theme89()),
          isTogglable = true,
          toolTip = "Changes to a tan type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 90 [W?]",
          method = (Action) (() => ThemeMods.Theme90()),
          isTogglable = true,
          toolTip = "Changes to a chocolate type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 91 [W?]",
          method = (Action) (() => ThemeMods.Theme91()),
          isTogglable = true,
          toolTip = "Changes to a brown type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 92 [W?]",
          method = (Action) (() => ThemeMods.Theme92()),
          isTogglable = true,
          toolTip = "Changes to a light salmon type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 93 [W?]",
          method = (Action) (() => ThemeMods.Theme93()),
          isTogglable = true,
          toolTip = "Changes to an orange type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 94 [W?]",
          method = (Action) (() => ThemeMods.Theme94()),
          isTogglable = true,
          toolTip = "Changes to a dark orange type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 95 [W?]",
          method = (Action) (() => ThemeMods.Theme95()),
          isTogglable = true,
          toolTip = "Changes to an orange red type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 96 [W?]",
          method = (Action) (() => ThemeMods.Theme96()),
          isTogglable = true,
          toolTip = "Changes to a khaki type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 97 [W?]",
          method = (Action) (() => ThemeMods.Theme97()),
          isTogglable = true,
          toolTip = "Changes to a red real type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 98 [W?]",
          method = (Action) (() => ThemeMods.Theme98()),
          isTogglable = true,
          toolTip = "Changes to a green real type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 99 [W?]",
          method = (Action) (() => ThemeMods.Theme99()),
          isTogglable = true,
          toolTip = "Changes to a green really type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 100 [W?]",
          method = (Action) (() => ThemeMods.Theme100()),
          isTogglable = true,
          toolTip = "Changes to a red really type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 101 [W?]",
          method = (Action) (() => ThemeMods.Theme101()),
          isTogglable = true,
          toolTip = "Changes to a lavender blush type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 102 [W?]",
          method = (Action) (() => ThemeMods.Theme102()),
          isTogglable = true,
          toolTip = "Changes to a misty rose type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 103 [W?]",
          method = (Action) (() => ThemeMods.Theme103()),
          isTogglable = true,
          toolTip = "Changes to a peach type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 104 [W?]",
          method = (Action) (() => ThemeMods.Theme104()),
          isTogglable = true,
          toolTip = "Changes to a papaya whip type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 105 [W?]",
          method = (Action) (() => ThemeMods.Theme105()),
          isTogglable = true,
          toolTip = "Changes to a linen type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 106 [W?]",
          method = (Action) (() => ThemeMods.Theme106()),
          isTogglable = true,
          toolTip = "Changes to an old lace type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 107 [W?]",
          method = (Action) (() => ThemeMods.Theme107()),
          isTogglable = true,
          toolTip = "Changes to a sea shell type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 108 [W?]",
          method = (Action) (() => ThemeMods.Theme108()),
          isTogglable = true,
          toolTip = "Changes to a cornsilk type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 109 [W?]",
          method = (Action) (() => ThemeMods.Theme109()),
          isTogglable = true,
          toolTip = "Changes to a lemon chiffon type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 110 [W?]",
          method = (Action) (() => ThemeMods.Theme110()),
          isTogglable = true,
          toolTip = "Changes to a floral white type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 111 [W?]",
          method = (Action) (() => ThemeMods.Theme111()),
          isTogglable = true,
          toolTip = "Changes to a snow type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 112 [W?]",
          method = (Action) (() => ThemeMods.Theme112()),
          isTogglable = true,
          toolTip = "Changes to an ivory type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 113 [W?]",
          method = (Action) (() => ThemeMods.Theme113()),
          isTogglable = true,
          toolTip = "Changes to a honeydew type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 114 [W?]",
          method = (Action) (() => ThemeMods.Theme114()),
          isTogglable = true,
          toolTip = "Changes to a mint cream type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 115 [W?]",
          method = (Action) (() => ThemeMods.Theme115()),
          isTogglable = true,
          toolTip = "Changes to an azure type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 116 [W?]",
          method = (Action) (() => ThemeMods.Theme116()),
          isTogglable = true,
          toolTip = "Changes to an alice blue type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 117 [W?]",
          method = (Action) (() => ThemeMods.Theme117()),
          isTogglable = true,
          toolTip = "Changes to a lavender grey type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 118 [W?]",
          method = (Action) (() => ThemeMods.Theme118()),
          isTogglable = true,
          toolTip = "Changes to a light steel blue type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 119 [W?]",
          method = (Action) (() => ThemeMods.Theme119()),
          isTogglable = true,
          toolTip = "Changes to a powder blue type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 120 [W?]",
          method = (Action) (() => ThemeMods.Theme120()),
          isTogglable = true,
          toolTip = "Changes to a pale turquoise type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 121 [W?]",
          method = (Action) (() => ThemeMods.Theme121()),
          isTogglable = true,
          toolTip = "Changes to a light blue type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 122 [W?]",
          method = (Action) (() => ThemeMods.Theme122()),
          isTogglable = true,
          toolTip = "Changes to a sky blue type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 123 [W?]",
          method = (Action) (() => ThemeMods.Theme123()),
          isTogglable = true,
          toolTip = "Changes to a light sky blue type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 124 [W?]",
          method = (Action) (() => ThemeMods.Theme124()),
          isTogglable = true,
          toolTip = "Changes to a deep sky blue type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 125 [W?]",
          method = (Action) (() => ThemeMods.Theme125()),
          isTogglable = true,
          toolTip = "Changes to a dodger blue type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 126 [W?]",
          method = (Action) (() => ThemeMods.Theme126()),
          isTogglable = true,
          toolTip = "Changes to a cornflower blue type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 127 [W?]",
          method = (Action) (() => ThemeMods.Theme127()),
          isTogglable = true,
          toolTip = "Changes to a steel blue type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 128 [W?]",
          method = (Action) (() => ThemeMods.Theme128()),
          isTogglable = true,
          toolTip = "Changes to a royal blue type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 129 [W?]",
          method = (Action) (() => ThemeMods.Theme129()),
          isTogglable = true,
          toolTip = "Changes to a medium blue type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 130 [W?]",
          method = (Action) (() => ThemeMods.Theme130()),
          isTogglable = true,
          toolTip = "Changes to a dark blue type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 131 [W?]",
          method = (Action) (() => ThemeMods.Theme131()),
          isTogglable = true,
          toolTip = "Changes to a navy type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 132 [W?]",
          method = (Action) (() => ThemeMods.Theme132()),
          isTogglable = true,
          toolTip = "Changes to a midnight blue type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 133 [W?]",
          method = (Action) (() => ThemeMods.Theme133()),
          isTogglable = true,
          toolTip = "Changes to an orange2 type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 134 [W?]",
          method = (Action) (() => ThemeMods.Theme134()),
          isTogglable = true,
          toolTip = "Changes to a button color type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 135 [W?]",
          method = (Action) (() => ThemeMods.Theme135()),
          isTogglable = true,
          toolTip = "Changes to a button color 2 type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 136 [W?]",
          method = (Action) (() => ThemeMods.Theme136()),
          isTogglable = true,
          toolTip = "Changes to a grey type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 137 [W?]",
          method = (Action) (() => ThemeMods.Theme137()),
          isTogglable = true,
          toolTip = "Changes to a color purple type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 138 [W?]",
          method = (Action) (() => ThemeMods.Theme138()),
          isTogglable = true,
          toolTip = "Changes to a black type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 139 [W?]",
          method = (Action) (() => ThemeMods.Theme139()),
          isTogglable = true,
          toolTip = "Changes to a white type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 140 [W?]",
          method = (Action) (() => ThemeMods.Theme140()),
          isTogglable = true,
          toolTip = "Changes to a button color grey type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 141 [W?]",
          method = (Action) (() => ThemeMods.Theme141()),
          isTogglable = true,
          toolTip = "Changes to a button color dark grey type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 142 [W?]",
          method = (Action) (() => ThemeMods.Theme142()),
          isTogglable = true,
          toolTip = "Changes to a neon pink type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 143 [W?]",
          method = (Action) (() => ThemeMods.Theme143()),
          isTogglable = true,
          toolTip = "Changes to an electric blue type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 144 [W?]",
          method = (Action) (() => ThemeMods.Theme144()),
          isTogglable = true,
          toolTip = "Changes to a neon green type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 145 [W?]",
          method = (Action) (() => ThemeMods.Theme145()),
          isTogglable = true,
          toolTip = "Changes to a white v2 type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 146 [W?]",
          method = (Action) (() => ThemeMods.Theme146()),
          isTogglable = true,
          toolTip = "Changes to a deep green type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 147 [W?]",
          method = (Action) (() => ThemeMods.Theme147()),
          isTogglable = true,
          toolTip = "Changes to a medium pink type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 148 [W?]",
          method = (Action) (() => ThemeMods.Theme148()),
          isTogglable = true,
          toolTip = "Changes to a dark pink type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 149 [W?]",
          method = (Action) (() => ThemeMods.Theme149()),
          isTogglable = true,
          toolTip = "Changes to a pale pink type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 150 [W?]",
          method = (Action) (() => ThemeMods.Theme150()),
          isTogglable = true,
          toolTip = "Changes to a pastel pink type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 151 [W?]",
          method = (Action) (() => ThemeMods.Theme151()),
          isTogglable = true,
          toolTip = "Changes to a baby pink type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 152 [W?]",
          method = (Action) (() => ThemeMods.Theme152()),
          isTogglable = true,
          toolTip = "Changes to a cotton candy pink type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 153 [W?]",
          method = (Action) (() => ThemeMods.Theme153()),
          isTogglable = true,
          toolTip = "Changes to a salmon pink type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 154 [W?]",
          method = (Action) (() => ThemeMods.Theme154()),
          isTogglable = true,
          toolTip = "Changes to a fuchsia pink type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 155 [W?]",
          method = (Action) (() => ThemeMods.Theme155()),
          isTogglable = true,
          toolTip = "Changes to a magenta pink type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 156 [W?]",
          method = (Action) (() => ThemeMods.Theme156()),
          isTogglable = true,
          toolTip = "Changes to a blush pink type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 157 [W?]",
          method = (Action) (() => ThemeMods.Theme157()),
          isTogglable = true,
          toolTip = "Changes to a rose pink type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 158 [W?]",
          method = (Action) (() => ThemeMods.Theme158()),
          isTogglable = true,
          toolTip = "Changes to a bubble gum pink type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 159 [W?]",
          method = (Action) (() => ThemeMods.Theme159()),
          isTogglable = true,
          toolTip = "Changes to a flamingo pink type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 160 [W?]",
          method = (Action) (() => ThemeMods.Theme160()),
          isTogglable = true,
          toolTip = "Changes to a peachy pink type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 161 [W?]",
          method = (Action) (() => ThemeMods.Theme161()),
          isTogglable = true,
          toolTip = "Changes to a coral pink type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 162 [W?]",
          method = (Action) (() => ThemeMods.Theme162()),
          isTogglable = true,
          toolTip = "Changes to an orchid pink type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 163 [W?]",
          method = (Action) (() => ThemeMods.Theme163()),
          isTogglable = true,
          toolTip = "Changes to a raspberry pink type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 164 [W?]",
          method = (Action) (() => ThemeMods.Theme164()),
          isTogglable = true,
          toolTip = "Changes to a candy pink type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 165 [W?]",
          method = (Action) (() => ThemeMods.Theme165()),
          isTogglable = true,
          toolTip = "Changes to a flamingo pink 2 type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 166 [W?]",
          method = (Action) (() => ThemeMods.Theme166()),
          isTogglable = true,
          toolTip = "Changes to a salmon pink 2 type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 167 [W?]",
          method = (Action) (() => ThemeMods.Theme167()),
          isTogglable = true,
          toolTip = "Changes to a rose pink 2 type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 168 [W?]",
          method = (Action) (() => ThemeMods.Theme168()),
          isTogglable = true,
          toolTip = "Changes to a pink lemonade type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 169 [W?]",
          method = (Action) (() => ThemeMods.Theme169()),
          isTogglable = true,
          toolTip = "Changes to a bubblegum pink 2 type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 170 [W?]",
          method = (Action) (() => ThemeMods.Theme170()),
          isTogglable = true,
          toolTip = "Changes to a pink sherbet type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 171 [W?]",
          method = (Action) (() => ThemeMods.Theme171()),
          isTogglable = true,
          toolTip = "Changes to a cotton candy pink 2 type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 172 [W?]",
          method = (Action) (() => ThemeMods.Theme172()),
          isTogglable = true,
          toolTip = "Changes to a peachy pink 2 type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 173 [W?]",
          method = (Action) (() => ThemeMods.Theme173()),
          isTogglable = true,
          toolTip = "Changes to a rose pink 3 type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 174 [W?]",
          method = (Action) (() => ThemeMods.Theme174()),
          isTogglable = true,
          toolTip = "Changes to a strawberry pink type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 175 [W?]",
          method = (Action) (() => ThemeMods.Theme175()),
          isTogglable = true,
          toolTip = "Changes to a pink champagne type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 176 [W?]",
          method = (Action) (() => ThemeMods.Theme176()),
          isTogglable = true,
          toolTip = "Changes to a flamingo pink 3 type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 177 [W?]",
          method = (Action) (() => ThemeMods.Theme177()),
          isTogglable = true,
          toolTip = "Changes to a blush pink 2 type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 178 [W?]",
          method = (Action) (() => ThemeMods.Theme178()),
          isTogglable = true,
          toolTip = "Changes to a cherry blossom pink type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 180 [W?]",
          method = (Action) (() => ThemeMods.Theme180()),
          isTogglable = true,
          toolTip = "Changes to a pink lemonade 2 type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 181 [W?]",
          method = (Action) (() => ThemeMods.Theme181()),
          isTogglable = true,
          toolTip = "Changes to a bubblegum pink 3 type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 182 [W?]",
          method = (Action) (() => ThemeMods.Theme182()),
          isTogglable = true,
          toolTip = "Changes to a cotton candy pink 3 type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 183 [W?]",
          method = (Action) (() => ThemeMods.Theme183()),
          isTogglable = true,
          toolTip = "Changes to a peachy pink 3 type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 184 [W?]",
          method = (Action) (() => ThemeMods.Theme184()),
          isTogglable = true,
          toolTip = "Changes to a rose pink 4 type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 185 [W?]",
          method = (Action) (() => ThemeMods.Theme185()),
          isTogglable = true,
          toolTip = "Changes to a pink sherbet 3 type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 186 [W?]",
          method = (Action) (() => ThemeMods.Theme186()),
          isTogglable = true,
          toolTip = "Changes to a flamingo pink 4 type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 187 [W?]",
          method = (Action) (() => ThemeMods.Theme187()),
          isTogglable = true,
          toolTip = "Changes to a blush pink 3 type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 188 [W?]",
          method = (Action) (() => ThemeMods.Theme188()),
          isTogglable = true,
          toolTip = "Changes to a cherry blossom pink 2 type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 189 [W?]",
          method = (Action) (() => ThemeMods.Theme189()),
          isTogglable = true,
          toolTip = "Changes to a salmon pink 4 type theme."
        },
        new ButtonInfo()
        {
          buttonText = "Theme 190 [W?]",
          method = (Action) (() => ThemeMods.Theme190()),
          isTogglable = true,
          toolTip = "Changes to a pink lemonade 4 type theme."
        }
      },
      new ButtonInfo[7]
      {
        new ButtonInfo()
        {
          buttonText = "Return to Main",
          method = (Action) (() => Global.ReturnHome()),
          isTogglable = false,
          toolTip = "Returns to the main page of the menu."
        },
        new ButtonInfo()
        {
          buttonText = "Guardian Grab All",
          method = (Action) (() => GuardianMods.GuardianGrabAll()),
          isTogglable = false,
          toolTip = "Grabs everyone if you are guardian."
        },
        new ButtonInfo()
        {
          buttonText = "Guardian Invis All",
          method = (Action) (() => GuardianMods.GuardianInvisAll()),
          isTogglable = false,
          toolTip = "Makes everyone invis everyone if you are guardian."
        },
        new ButtonInfo()
        {
          buttonText = "Self Guardian [W?]",
          method = (Action) (() => OverpoweredMods.GuardianSelf()),
          disableMethod = (Action) (() => OverpoweredMods.UnguardianSelf()),
          isTogglable = true,
          toolTip = "Makes you guardian."
        },
        new ButtonInfo()
        {
          buttonText = "Silent Guardian [W?]",
          method = (Action) (() => OverpoweredMods.SilentGuardian()),
          isTogglable = true,
          toolTip = "Makes a silent guardian."
        },
        new ButtonInfo()
        {
          buttonText = "Guardian Self [M]",
          method = (Action) (() => GuardianMods.GuardianSelf()),
          disableMethod = (Action) (() => GuardianMods.UnGuardianSelf()),
          isTogglable = true,
          toolTip = "Makes you a guardian"
        },
        new ButtonInfo()
        {
          buttonText = "Guardian All [M]",
          method = (Action) (() => GuardianMods.GuardianAll()),
          disableMethod = (Action) (() => GuardianMods.UnguardianAll()),
          isTogglable = true,
          toolTip = "Makes everyone a guardian"
        }
      },
      new ButtonInfo[2]
      {
        new ButtonInfo()
        {
          buttonText = "Return to Main",
          method = (Action) (() => Global.ReturnHome()),
          isTogglable = false,
          toolTip = "Returns to the main page of the menu."
        },
        new ButtonInfo()
        {
          buttonText = "Dependencies",
          method = (Action) (() => Main.Customboards()),
          enabled = true,
          isTogglable = false,
          toolTip = "DO NOT TOUCH, THIS IS NEEDED TO BE HERE."
        }
      },
      new ButtonInfo[3]
      {
        new ButtonInfo()
        {
          buttonText = "Return to Main",
          method = (Action) (() => Global.ReturnHome()),
          isTogglable = false,
          toolTip = "Returns to the main page of the menu."
        },
        new ButtonInfo()
        {
          buttonText = "Owner, Developer - FTSyxcal",
          method = (Action) (() => Credits.filler()),
          isTogglable = false,
          toolTip = "Main Owner, Developer - FTSyxcal."
        },
        new ButtonInfo()
        {
          buttonText = "Beta Tester - Ladder",
          method = (Action) (() => Credits.filler()),
          isTogglable = true,
          toolTip = "Beta Tester - Ladder."
        }
      }
    };
  }
}
