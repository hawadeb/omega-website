﻿// Decompiled with JetBrains decompiler
// Type: StupidTemplate.Menu.InputLib
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using BepInEx;
using UnityEngine;

#nullable disable
namespace StupidTemplate.Menu
{
  internal class InputLib : BaseUnityPlugin
  {
    public static bool RT()
    {
      return (double) ControllerInputPoller.instance.rightControllerIndexFloat == 1.0;
    }

    public static bool LT()
    {
      return (double) ControllerInputPoller.instance.leftControllerIndexFloat == 1.0;
    }

    public static bool RG()
    {
      return (double) ControllerInputPoller.instance.rightControllerGripFloat == 1.0;
    }

    public static bool LG()
    {
      return (double) ControllerInputPoller.instance.leftControllerGripFloat == 1.0;
    }

    public static bool X() => ControllerInputPoller.instance.leftControllerPrimaryButton;

    public static bool Y() => ControllerInputPoller.instance.leftControllerSecondaryButton;

    public static bool B() => ControllerInputPoller.instance.rightControllerSecondaryButton;

    public static bool A() => ControllerInputPoller.instance.rightControllerPrimaryButton;

    public static bool instance() => Object.op_Implicit((Object) ControllerInputPoller.instance);
  }
}
