﻿// Decompiled with JetBrains decompiler
// Type: StupidTemplate.Notifications.NotifiLib
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using BepInEx;
using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

#nullable disable
namespace StupidTemplate.Notifications
{
  [BepInPlugin("org.gorillatag.lars.notifications2", "NotificationLibrary", "1.0.5")]
  public class NotifiLib : BaseUnityPlugin
  {
    private GameObject HUDObj;
    private GameObject HUDObj2;
    private GameObject MainCamera;
    private Text Testtext;
    private Material AlertText = new Material(Shader.Find("GUI/Text Shader"));
    private int NotificationDecayTime = 144;
    private int NotificationDecayTimeCounter;
    public static int NoticationThreshold = 30;
    private string[] Notifilines;
    private string newtext;
    public static string PreviousNotifi;
    private bool HasInit;
    private static Text NotifiText;
    public static bool IsEnabled = true;

    private void Awake() => this.Logger.LogInfo((object) "Plugin NotificationLibrary is loaded!");

    private void Init()
    {
      this.MainCamera = GameObject.Find("Main Camera");
      this.HUDObj = new GameObject();
      this.HUDObj2 = new GameObject();
      ((Object) this.HUDObj2).name = "NOTIFICATIONLIB_HUD_OBJ";
      ((Object) this.HUDObj).name = "NOTIFICATIONLIB_HUD_OBJ";
      this.HUDObj.AddComponent<Canvas>();
      this.HUDObj.AddComponent<CanvasScaler>();
      this.HUDObj.AddComponent<GraphicRaycaster>();
      ((Behaviour) this.HUDObj.GetComponent<Canvas>()).enabled = true;
      this.HUDObj.GetComponent<Canvas>().renderMode = (RenderMode) 2;
      this.HUDObj.GetComponent<Canvas>().worldCamera = this.MainCamera.GetComponent<Camera>();
      this.HUDObj.GetComponent<RectTransform>().sizeDelta = new Vector2(5f, 5f);
      ((Transform) this.HUDObj.GetComponent<RectTransform>()).position = new Vector3(this.MainCamera.transform.position.x, this.MainCamera.transform.position.y, this.MainCamera.transform.position.z);
      this.HUDObj2.transform.position = new Vector3(this.MainCamera.transform.position.x, this.MainCamera.transform.position.y, this.MainCamera.transform.position.z - 4.6f);
      this.HUDObj.transform.parent = this.HUDObj2.transform;
      ((Transform) this.HUDObj.GetComponent<RectTransform>()).localPosition = new Vector3(0.0f, 0.0f, 1.6f);
      Quaternion rotation = ((Transform) this.HUDObj.GetComponent<RectTransform>()).rotation;
      Vector3 eulerAngles = ((Quaternion) ref rotation).eulerAngles;
      eulerAngles.y = -270f;
      this.HUDObj.transform.localScale = new Vector3(1f, 1f, 1f);
      ((Transform) this.HUDObj.GetComponent<RectTransform>()).rotation = Quaternion.Euler(eulerAngles);
      this.Testtext = new GameObject()
      {
        transform = {
          parent = this.HUDObj.transform
        }
      }.AddComponent<Text>();
      this.Testtext.text = "";
      this.Testtext.fontSize = 30;
      this.Testtext.font = Settings.currentFont;
      ((Graphic) this.Testtext).rectTransform.sizeDelta = new Vector2(450f, 210f);
      this.Testtext.alignment = (TextAnchor) 6;
      ((Transform) ((Graphic) this.Testtext).rectTransform).localScale = new Vector3(1f / 300f, 1f / 300f, 0.333333343f);
      ((Transform) ((Graphic) this.Testtext).rectTransform).localPosition = new Vector3(-1f, -1f, -0.5f);
      ((Graphic) this.Testtext).material = this.AlertText;
      NotifiLib.NotifiText = this.Testtext;
    }

    private void FixedUpdate()
    {
      if (!this.HasInit && Object.op_Inequality((Object) GameObject.Find("Main Camera"), (Object) null))
      {
        this.Init();
        this.HasInit = true;
      }
      this.HUDObj2.transform.position = new Vector3(this.MainCamera.transform.position.x, this.MainCamera.transform.position.y, this.MainCamera.transform.position.z);
      this.HUDObj2.transform.rotation = this.MainCamera.transform.rotation;
      if (this.Testtext.text != "")
      {
        ++this.NotificationDecayTimeCounter;
        if (this.NotificationDecayTimeCounter <= this.NotificationDecayTime)
          return;
        this.Notifilines = (string[]) null;
        this.newtext = "";
        this.NotificationDecayTimeCounter = 0;
        this.Notifilines = ((IEnumerable<string>) this.Testtext.text.Split(Environment.NewLine.ToCharArray())).Skip<string>(1).ToArray<string>();
        foreach (string notifiline in this.Notifilines)
        {
          if (notifiline != "")
            this.newtext = this.newtext + notifiline + "\n";
        }
        this.Testtext.text = this.newtext;
      }
      else
        this.NotificationDecayTimeCounter = 0;
    }

    public static void SendNotification(string NotificationText)
    {
      if (Settings.disableNotifications)
        return;
      try
      {
        if (NotifiLib.IsEnabled && NotifiLib.PreviousNotifi != NotificationText)
        {
          if (!NotificationText.Contains(Environment.NewLine))
            NotificationText += Environment.NewLine;
          NotifiLib.NotifiText.text += NotificationText;
          NotifiLib.NotifiText.supportRichText = true;
          NotifiLib.PreviousNotifi = NotificationText;
        }
      }
      catch
      {
        Debug.LogError((object) ("Notification failed, object probably nil due to third person ; " + NotificationText));
      }
    }

    public static void ClearAllNotifications() => NotifiLib.NotifiText.text = "";

    public static void ClearPastNotifications(int amount)
    {
      string str1 = "";
      foreach (string str2 in ((IEnumerable<string>) NotifiLib.NotifiText.text.Split(Environment.NewLine.ToCharArray())).Skip<string>(amount).ToArray<string>())
      {
        if (str2 != "")
          str1 = str1 + str2 + "\n";
      }
      NotifiLib.NotifiText.text = str1;
    }
  }
}
