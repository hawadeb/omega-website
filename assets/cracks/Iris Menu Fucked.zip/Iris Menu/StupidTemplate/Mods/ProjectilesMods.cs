﻿// Decompiled with JetBrains decompiler
// Type: StupidTemplate.Mods.ProjectilesMods
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using FTSyxcalTemplate.Menu;
using GorillaLocomotion;
using UnityEngine;

#nullable disable
namespace StupidTemplate.Mods
{
  internal class ProjectilesMods
  {
    public static void SnowballSpam()
    {
      if (!ControllerInputPoller.instance.rightGrab)
        return;
      int projHash = -675036877;
      int trailHash = -1;
      Color white = Color.white;
      Vector3 position = GTPlayer.Instance.rightControllerTransform.position;
      Vector3 averageVelocity = GTPlayer.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(true, 0.0f, false);
      ProjectilesMods.LaunchProjectile(projHash, trailHash, position, averageVelocity, white);
    }

    public static void WaterBallonSpam()
    {
      if (!ControllerInputPoller.instance.rightGrab)
        return;
      int projHash = -1674517839;
      int trailHash = -1;
      Color white = Color.white;
      Vector3 position = GTPlayer.Instance.rightControllerTransform.position;
      Vector3 averageVelocity = GTPlayer.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(true, 0.0f, false);
      ProjectilesMods.LaunchProjectile(projHash, trailHash, position, averageVelocity, white);
    }

    public static void iceSpam()
    {
      if (!ControllerInputPoller.instance.rightGrab)
        return;
      int projHash = -1671677000;
      int trailHash = -1277271056;
      Color white = Color.white;
      Vector3 position = GTPlayer.Instance.rightControllerTransform.position;
      Vector3 averageVelocity = GTPlayer.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(true, 0.0f, false);
      ProjectilesMods.LaunchProjectile(projHash, trailHash, position, averageVelocity, white);
    }

    public static void CloudSpam()
    {
      if (!ControllerInputPoller.instance.rightGrab)
        return;
      int projHash = -1671677000;
      int trailHash = 16948542;
      Color white = Color.white;
      Vector3 position = GTPlayer.Instance.rightControllerTransform.position;
      Vector3 averageVelocity = GTPlayer.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(true, 0.0f, false);
      ProjectilesMods.LaunchProjectile(projHash, trailHash, position, averageVelocity, white);
    }

    public static void CandyCaneSpam()
    {
      if (!ControllerInputPoller.instance.rightGrab)
        return;
      int projHash = -1671677000;
      int trailHash = -1;
      Color white = Color.white;
      Vector3 position = GTPlayer.Instance.rightControllerTransform.position;
      Vector3 averageVelocity = GTPlayer.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(true, 0.0f, false);
      ProjectilesMods.LaunchProjectile(projHash, trailHash, position, averageVelocity, white);
    }

    public static void LaunchProjectile(
      int projHash,
      int trailHash,
      Vector3 pos,
      Vector3 vel,
      Color col)
    {
      SlingshotProjectile component = ObjectPools.instance.Instantiate(projHash).GetComponent<SlingshotProjectile>();
      if (trailHash != -1)
        ObjectPools.instance.Instantiate(trailHash).GetComponent<SlingshotProjectileTrail>().AttachTrail(((Component) component).gameObject, false, false);
      int num1 = 0;
      SlingshotProjectile slingshotProjectile = component;
      Vector3 vector3_1 = pos;
      Vector3 vector3_2 = vel;
      NetPlayer localPlayer = NetworkSystem.Instance.LocalPlayer;
      int num2 = num1;
      int num3 = num2 + 1;
      Color color = col;
      slingshotProjectile.Launch(vector3_1, vector3_2, localPlayer, false, false, num2, 1f, true, color);
    }

    public static void CoalSpam()
    {
      if (!ControllerInputPoller.instance.rightGrab)
        return;
      int projHash = 1433634409;
      int trailHash = -1;
      Color white = Color.white;
      Vector3 position = GTPlayer.Instance.rightControllerTransform.position;
      Vector3 averageVelocity = GTPlayer.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(true, 0.0f, false);
      ProjectilesMods.LaunchProjectile(projHash, trailHash, position, averageVelocity, white);
    }

    public static void CUM()
    {
      if (!ControllerInputPoller.instance.rightGrab)
        return;
      int projHash = -820530352;
      int trailHash = -1;
      Color white = Color.white;
      Vector3 position = ((Component) GTPlayer.Instance.bodyCollider).transform.position;
      Vector3 vel = Vector3.op_Multiply(((Component) GTPlayer.Instance.bodyCollider).transform.forward, 8.33f);
      ProjectilesMods.LaunchProjectile(projHash, trailHash, position, vel, white);
    }

    public static void Applespammmer()
    {
      if (!ControllerInputPoller.instance.rightGrab)
        return;
      int projHash = 1918888813;
      int trailHash = -1;
      Color white = Color.white;
      Vector3 position = GTPlayer.Instance.rightControllerTransform.position;
      Vector3 averageVelocity = GTPlayer.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(true, 0.0f, false);
      ProjectilesMods.LaunchProjectile(projHash, trailHash, position, averageVelocity, white);
    }

    public static void batspammmer()
    {
      if (!ControllerInputPoller.instance.rightGrab)
        return;
      int projHash = 1848916225;
      int trailHash = -1;
      Color white = Color.white;
      Vector3 position = GTPlayer.Instance.rightControllerTransform.position;
      Vector3 averageVelocity = GTPlayer.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(true, 0.0f, false);
      ProjectilesMods.LaunchProjectile(projHash, trailHash, position, averageVelocity, white);
    }

    public static void cupidspammmer()
    {
      if (!ControllerInputPoller.instance.rightGrab)
        return;
      int projHash = 825718363;
      int trailHash = -1;
      Color white = Color.white;
      Vector3 position = GTPlayer.Instance.rightControllerTransform.position;
      Vector3 averageVelocity = GTPlayer.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(true, 0.0f, false);
      Global.LaunchProjectile(projHash, trailHash, position, averageVelocity, white);
    }

    public static void elfspammmer()
    {
      if (!ControllerInputPoller.instance.rightGrab)
        return;
      int projHash = 1705139863;
      int trailHash = -1;
      Color white = Color.white;
      Vector3 position = GTPlayer.Instance.rightControllerTransform.position;
      Vector3 averageVelocity = GTPlayer.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(true, 0.0f, false);
      Global.LaunchProjectile(projHash, trailHash, position, averageVelocity, white);
    }

    public static void eyeballspammmer()
    {
      if (!ControllerInputPoller.instance.rightGrab)
        return;
      int projHash = -829423852;
      int trailHash = -1;
      Color white = Color.white;
      Vector3 position = GTPlayer.Instance.rightControllerTransform.position;
      Vector3 averageVelocity = GTPlayer.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(true, 0.0f, false);
      Global.LaunchProjectile(projHash, trailHash, position, averageVelocity, white);
    }

    public static void candycornspammmer()
    {
      if (!ControllerInputPoller.instance.rightGrab)
        return;
      int projHash = 1077936051;
      int trailHash = -1;
      Color white = Color.white;
      Vector3 position = GTPlayer.Instance.rightControllerTransform.position;
      Vector3 averageVelocity = GTPlayer.Instance.rightHandCenterVelocityTracker.GetAverageVelocity(true, 0.0f, false);
      Global.LaunchProjectile(projHash, trailHash, position, averageVelocity, white);
    }

    public static void PISS()
    {
      if (!ControllerInputPoller.instance.rightGrab)
        return;
      int projHash = -820530352;
      int trailHash = -1;
      Color yellow = Color.yellow;
      Vector3 position = ((Component) GTPlayer.Instance.bodyCollider).transform.position;
      Vector3 vel = Vector3.op_Multiply(((Component) GTPlayer.Instance.bodyCollider).transform.forward, 8.33f);
      Global.LaunchProjectile(projHash, trailHash, position, vel, yellow);
    }

    public static void SHIT()
    {
      if (!ControllerInputPoller.instance.rightGrab)
        return;
      int projHash = -1433634409;
      int trailHash = -1;
      Color red = Color.red;
      Vector3 position = ((Component) GTPlayer.Instance.bodyCollider).transform.position;
      Vector3 vel = Vector3.op_Multiply(((Component) GTPlayer.Instance.bodyCollider).transform.forward, -8.33f);
      ProjectilesMods.LaunchProjectile(projHash, trailHash, position, vel, red);
    }

    public static void EnableRainbowSnowballs()
    {
      foreach (SnowballThrowable snowballThrowable in Object.FindObjectsOfType<SnowballThrowable>())
      {
        if (!snowballThrowable.randomizeColor)
          snowballThrowable.randomizeColor = true;
      }
    }

    public static void DisableRainbowSnowballs()
    {
      foreach (SnowballThrowable snowballThrowable in Object.FindObjectsOfType<SnowballThrowable>())
      {
        if (!snowballThrowable.randomizeColor)
          snowballThrowable.randomizeColor = false;
      }
    }
  }
}
