﻿// Decompiled with JetBrains decompiler
// Type: StupidTemplate.Mods.taggerInstance
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

#nullable disable
namespace StupidTemplate.Mods
{
  internal class taggerInstance
  {
    internal static object offlineVRRig;
  }
}
