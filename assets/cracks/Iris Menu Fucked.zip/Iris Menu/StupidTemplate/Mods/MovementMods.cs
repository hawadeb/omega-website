﻿// Decompiled with JetBrains decompiler
// Type: StupidTemplate.Mods.MovementMods
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using BepInEx;
using FTSyxcalTemplate.Menu;
using GorillaLocomotion;
using StupidTemplate.Menu;
using UnityEngine;

#nullable disable
namespace StupidTemplate.Mods
{
  internal class MovementMods
  {
    public static Vector3[] lastLeft = new Vector3[10]
    {
      Vector3.zero,
      Vector3.zero,
      Vector3.zero,
      Vector3.zero,
      Vector3.zero,
      Vector3.zero,
      Vector3.zero,
      Vector3.zero,
      Vector3.zero,
      Vector3.zero
    };
    public static Vector3[] lastRight = new Vector3[10]
    {
      Vector3.zero,
      Vector3.zero,
      Vector3.zero,
      Vector3.zero,
      Vector3.zero,
      Vector3.zero,
      Vector3.zero,
      Vector3.zero,
      Vector3.zero,
      Vector3.zero
    };
    private static VRRig sithlord = (VRRig) null;
    private static bool sithright = false;
    private static float sithdist = 1f;
    private static float preBounciness = 0.0f;
    private static PhysicMaterialCombine whateverthisis = (PhysicMaterialCombine) 3;
    private static float preFrictiness = 0.0f;
    public static GameObject airSwimPart = (GameObject) null;
    private bool leftGrab = ControllerInputPoller.instance.leftGrab;
    private bool rightgrab = ControllerInputPoller.instance.rightGrab;
    public static float flySpeed = 20f;

    public static void Speedboost()
    {
      GTPlayer.Instance.maxJumpSpeed = 8f;
      GTPlayer.Instance.jumpMultiplier = 8f;
    }

    public static void Mosaboost()
    {
      GTPlayer.Instance.maxJumpSpeed = 5f;
      GTPlayer.Instance.jumpMultiplier = 5f;
    }

    public static void TTTPigBoost()
    {
      GTPlayer.Instance.maxJumpSpeed = 6f;
      GTPlayer.Instance.jumpMultiplier = 6f;
    }

    public static void TriggerFly()
    {
      if (!((double) ControllerInputPoller.instance.rightControllerIndexFloat == 1.0 & (double) ControllerInputPoller.instance.leftControllerIndexFloat == 1.0))
        return;
      Transform transform = ((Component) GTPlayer.Instance).transform;
      transform.position = Vector3.op_Addition(transform.position, Vector3.op_Multiply(Vector3.op_Multiply(((Component) GTPlayer.Instance.headCollider).transform.forward, Time.deltaTime), 10f));
      ((Component) GTPlayer.Instance).GetComponent<Rigidbody>().velocity = Vector3.zero;
    }

    public static void AntiTagFreeze() => GTPlayer.Instance.disableMovement = false;

    public static void TagFreezeWalk() => GTPlayer.Instance.disableMovement = true;

    public static void PunchMod()
    {
      int index = -1;
      foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
      {
        if (Object.op_Inequality((Object) vrrig, (Object) GorillaTagger.Instance.offlineVRRig))
        {
          ++index;
          Vector3 position1 = vrrig.rightHandTransform.position;
          Vector3 position2 = GorillaTagger.Instance.offlineVRRig.head.rigTarget.position;
          if ((double) Vector3.Distance(position1, position2) < 0.25)
          {
            Rigidbody component = ((Component) GTPlayer.Instance).GetComponent<Rigidbody>();
            component.velocity = Vector3.op_Addition(component.velocity, Vector3.op_Multiply(Vector3.Normalize(Vector3.op_Subtraction(vrrig.rightHandTransform.position, MovementMods.lastRight[index])), 10f));
          }
          MovementMods.lastRight[index] = vrrig.rightHandTransform.position;
          if ((double) Vector3.Distance(vrrig.leftHandTransform.position, position2) < 0.25)
          {
            Rigidbody component = ((Component) GTPlayer.Instance).GetComponent<Rigidbody>();
            component.velocity = Vector3.op_Addition(component.velocity, Vector3.op_Multiply(Vector3.Normalize(Vector3.op_Subtraction(vrrig.leftHandTransform.position, MovementMods.lastLeft[index])), 10f));
          }
          MovementMods.lastLeft[index] = vrrig.leftHandTransform.position;
        }
      }
    }

    public static void BunnyHop()
    {
      RaycastHit raycastHit;
      Physics.Raycast(Vector3.op_Subtraction(((Component) GorillaTagger.Instance.bodyCollider).transform.position, new Vector3(0.0f, 0.2f, 0.0f)), Vector3.down, ref raycastHit, 512f, LayerMask.op_Implicit(GTPlayer.Instance.locomotionEnabledLayers));
      if ((double) ((RaycastHit) ref raycastHit).distance >= 0.15000000596046448)
        return;
      ((Collider) GorillaTagger.Instance.bodyCollider).attachedRigidbody.velocity = new Vector3(((Collider) GorillaTagger.Instance.bodyCollider).attachedRigidbody.velocity.x, GTPlayer.Instance.jumpMultiplier * 2.72727275f, ((Collider) GorillaTagger.Instance.bodyCollider).attachedRigidbody.velocity.z);
    }

    public static void Strafe()
    {
      Vector3 vector3 = Vector3.op_Multiply(((Component) GorillaTagger.Instance.bodyCollider).transform.forward, GTPlayer.Instance.maxJumpSpeed);
      ((Collider) GorillaTagger.Instance.bodyCollider).attachedRigidbody.velocity = new Vector3(vector3.x, ((Collider) GorillaTagger.Instance.bodyCollider).attachedRigidbody.velocity.y, vector3.z);
      Vector3 velocity = ((Collider) GorillaTagger.Instance.bodyCollider).attachedRigidbody.velocity;
      velocity.y = (double) velocity.y < 0.0 ? 0.0f : velocity.y;
    }

    public static void DynamicStrafe()
    {
      Vector3 vector3_1 = new Vector3(((Collider) GorillaTagger.Instance.bodyCollider).attachedRigidbody.velocity.x, 0.0f, ((Collider) GorillaTagger.Instance.bodyCollider).attachedRigidbody.velocity.z);
      Vector3 vector3_2 = Vector3.op_Multiply(((Component) GorillaTagger.Instance.bodyCollider).transform.forward, ((Vector3) ref vector3_1).magnitude);
      ((Collider) GorillaTagger.Instance.bodyCollider).attachedRigidbody.velocity = new Vector3(vector3_2.x, ((Collider) GorillaTagger.Instance.bodyCollider).attachedRigidbody.velocity.y, vector3_2.z);
    }

    public static void PreBouncy()
    {
      MovementMods.preBounciness = ((Collider) GorillaTagger.Instance.bodyCollider).material.bounciness;
      MovementMods.whateverthisis = ((Collider) GorillaTagger.Instance.bodyCollider).material.bounceCombine;
      MovementMods.preFrictiness = ((Collider) GorillaTagger.Instance.bodyCollider).material.dynamicFriction;
    }

    public static void Bouncy()
    {
      ((Collider) GorillaTagger.Instance.bodyCollider).material.bounciness = 1f;
      ((Collider) GorillaTagger.Instance.bodyCollider).material.bounceCombine = (PhysicMaterialCombine) 3;
      ((Collider) GorillaTagger.Instance.bodyCollider).material.dynamicFriction = 0.0f;
    }

    public static void PostBouncy()
    {
      ((Collider) GorillaTagger.Instance.bodyCollider).material.bounciness = MovementMods.preBounciness;
      ((Collider) GorillaTagger.Instance.bodyCollider).material.bounceCombine = MovementMods.whateverthisis;
      ((Collider) GorillaTagger.Instance.bodyCollider).material.dynamicFriction = MovementMods.preFrictiness;
    }

    public static void AirSwim()
    {
      if (Object.op_Equality((Object) MovementMods.airSwimPart, (Object) null))
      {
        MovementMods.airSwimPart = Object.Instantiate<GameObject>(GameObject.Find("Environment Objects/LocalObjects_Prefab/ForestToBeach/ForestToBeach_Prefab_V4/CaveWaterVolume"));
        MovementMods.airSwimPart.transform.localScale = new Vector3(5f, 5f, 5f);
        MovementMods.airSwimPart.GetComponent<Renderer>().enabled = false;
      }
      else
      {
        GTPlayer.Instance.audioManager.UnsetMixerSnapshot(0.1f);
        MovementMods.airSwimPart.transform.position = Vector3.op_Addition(((Component) GorillaTagger.Instance.headCollider).transform.position, new Vector3(0.0f, 2.5f, 0.0f));
      }
    }

    public static void DisableAirSwim()
    {
      if (!Object.op_Inequality((Object) MovementMods.airSwimPart, (Object) null))
        return;
      Object.Destroy((Object) MovementMods.airSwimPart);
    }

    public static void FastSwim()
    {
      if (!GTPlayer.Instance.InWater)
        return;
      Rigidbody component = ((Component) GTPlayer.Instance).gameObject.GetComponent<Rigidbody>();
      component.velocity = Vector3.op_Multiply(component.velocity, 1.069f);
    }

    public static void noclip2()
    {
      foreach (MeshCollider meshCollider in Resources.FindObjectsOfTypeAll<MeshCollider>())
      {
        if (InputLib.RT())
          ((Collider) meshCollider).enabled = false;
        else
          ((Collider) meshCollider).enabled = true;
      }
    }

    public static void Fly()
    {
      if (!ControllerInputPoller.instance.rightGrab)
        return;
      Transform transform = ((Component) GTPlayer.Instance).transform;
      transform.position = Vector3.op_Addition(transform.position, Vector3.op_Multiply(Vector3.op_Multiply(((Component) GTPlayer.Instance.headCollider).transform.forward, 10f), Time.deltaTime));
      ((Collider) GTPlayer.Instance.bodyCollider).attachedRigidbody.velocity = Vector3.zero;
    }

    public static void Frozone()
    {
      if (InputLib.LG())
      {
        GameObject primitive = GameObject.CreatePrimitive((PrimitiveType) 3);
        primitive.transform.localScale = new Vector3(0.025f, 0.3f, 0.4f);
        primitive.transform.localPosition = Vector3.op_Addition(GorillaTagger.Instance.leftHandTransform.position, new Vector3(0.0f, -0.05f, 0.0f));
        primitive.transform.rotation = GorillaTagger.Instance.leftHandTransform.rotation;
        primitive.AddComponent<GorillaSurfaceOverride>().overrideIndex = 61;
        primitive.GetComponent<Renderer>().material.color = Color.cyan;
        Object.Destroy((Object) primitive, 0.3f);
      }
      if (!InputLib.RG())
        return;
      GameObject primitive1 = GameObject.CreatePrimitive((PrimitiveType) 3);
      primitive1.transform.localScale = new Vector3(0.025f, 0.3f, 0.4f);
      primitive1.transform.localPosition = Vector3.op_Addition(GorillaTagger.Instance.rightHandTransform.position, new Vector3(0.0f, -0.05f, 0.0f));
      primitive1.transform.rotation = GorillaTagger.Instance.rightHandTransform.rotation;
      primitive1.AddComponent<GorillaSurfaceOverride>().overrideIndex = 61;
      primitive1.GetComponent<Renderer>().material.color = Color.cyan;
      Object.Destroy((Object) primitive1, 0.3f);
    }

    public static void IronMonke()
    {
      InputLib.LG();
      ((Collider) GTPlayer.Instance.bodyCollider).attachedRigidbody.AddForce(Vector3.op_Multiply(MovementMods.flySpeed, Vector3.op_UnaryNegation(GorillaTagger.Instance.leftHandTransform.right)), (ForceMode) 5);
      GorillaTagger instance1 = GorillaTagger.Instance;
      double num1 = (double) GorillaTagger.Instance.tapHapticStrength / 50.0;
      Vector3 velocity1 = ((Collider) GTPlayer.Instance.bodyCollider).attachedRigidbody.velocity;
      double magnitude1 = (double) ((Vector3) ref velocity1).magnitude;
      double num2 = num1 * magnitude1;
      double tapHapticDuration1 = (double) GorillaTagger.Instance.tapHapticDuration;
      instance1.StartVibration(true, (float) num2, (float) tapHapticDuration1);
      InputLib.RG();
      ((Collider) GTPlayer.Instance.bodyCollider).attachedRigidbody.AddForce(Vector3.op_Multiply(MovementMods.flySpeed, GorillaTagger.Instance.rightHandTransform.right), (ForceMode) 5);
      GorillaTagger instance2 = GorillaTagger.Instance;
      double num3 = (double) GorillaTagger.Instance.tapHapticStrength / 50.0;
      Vector3 velocity2 = ((Collider) GTPlayer.Instance.bodyCollider).attachedRigidbody.velocity;
      double magnitude2 = (double) ((Vector3) ref velocity2).magnitude;
      double num4 = num3 * magnitude2;
      double tapHapticDuration2 = (double) GorillaTagger.Instance.tapHapticDuration;
      instance2.StartVibration(false, (float) num4, (float) tapHapticDuration2);
    }

    public static void GripSpeedBoost()
    {
      if (ControllerInputPoller.instance.rightGrab)
        MovementMods.Speedboost();
      if (!ControllerInputPoller.instance.leftGrab)
        return;
      MovementMods.Speedboost();
    }

    public static void WallWalk()
    {
      if (!InputLib.RG())
        return;
      RaycastHit raycastHit;
      Physics.Raycast(GTPlayer.Instance.rightControllerTransform.position, Vector3.op_UnaryNegation(GTPlayer.Instance.rightControllerTransform.up), ref raycastHit);
      if ((double) ((RaycastHit) ref raycastHit).distance < 3.0)
      {
        Physics.gravity = new Vector3(0.0f, 0.0f, 0.0f);
        Rigidbody attachedRigidbody = ((Collider) GTPlayer.Instance.bodyCollider).attachedRigidbody;
        attachedRigidbody.velocity = Vector3.op_Subtraction(attachedRigidbody.velocity, Vector3.op_Multiply(((RaycastHit) ref raycastHit).normal, Global.Walk * Time.deltaTime));
      }
      Physics.gravity = new Vector3(0.0f, -9.81f, 0.0f);
    }

    private void Update()
    {
      RaycastHit raycastHit;
      if (!Physics.Raycast(GTPlayer.Instance.rightControllerTransform.position, Vector3.op_UnaryNegation(GTPlayer.Instance.rightControllerTransform.up), ref raycastHit))
        return;
      Debug.Log((object) ("Hit: " + ((Object) ((RaycastHit) ref raycastHit).collider).name));
    }

    public static void SuperMonke()
    {
      if (Global.super)
        Physics.gravity = new Vector3(0.0f, 0.0f, 0.0f);
      else if (Vector3.op_Equality(Physics.gravity, new Vector3(0.0f, 0.0f, 0.0f)))
        Physics.gravity = new Vector3(0.0f, -9.81f, 0.0f);
      MovementMods.FasterFly(15f);
      if (InputLib.B())
        Global.super = !Global.super;
      Global.last3 = InputLib.B();
    }

    public static void FasterFly(float speed)
    {
      if (!InputLib.A())
        return;
      Transform transform = ((Component) GTPlayer.Instance).transform;
      transform.position = Vector3.op_Addition(transform.position, Vector3.op_Multiply(Vector3.op_Multiply(((Component) GTPlayer.Instance.headCollider).transform.forward, Time.deltaTime), speed));
      ((Component) GTPlayer.Instance).GetComponent<Rigidbody>().velocity = Vector3.zero;
    }

    public static void InvisPlatforms()
    {
      Global.Platform(ref Global.leftPlatform, ControllerInputPoller.instance.leftGrab || UnityInput.Current.GetKey((KeyCode) 104), GTPlayer.Instance.leftControllerTransform, true);
      Global.Platform(ref Global.rightPlatform, ControllerInputPoller.instance.rightGrab || UnityInput.Current.GetKey((KeyCode) 103), GTPlayer.Instance.rightControllerTransform, true);
    }

    public static void CarMonkey()
    {
      Vector3 forward = ((Component) GTPlayer.Instance.headCollider).transform.forward;
      forward.y = 0.0f;
      ((Vector3) ref forward).Normalize();
      if ((double) ControllerInputPoller.instance.rightControllerIndexFloat > 0.20000000298023224 | UnityInput.Current.GetKey((KeyCode) 116))
      {
        Transform transform = ((Component) GTPlayer.Instance).transform;
        transform.position = Vector3.op_Addition(transform.position, Vector3.op_Multiply(Vector3.op_Multiply(forward, Time.deltaTime), 25f));
        ((Component) GTPlayer.Instance).GetComponent<Rigidbody>().velocity = Vector3.zero;
      }
      if (!((double) ControllerInputPoller.instance.leftControllerIndexFloat > 0.20000000298023224 | UnityInput.Current.GetKey((KeyCode) 121)))
        return;
      Transform transform1 = ((Component) GTPlayer.Instance).transform;
      transform1.position = Vector3.op_Subtraction(transform1.position, Vector3.op_Multiply(Vector3.op_Multiply(forward, Time.deltaTime), 25f));
      ((Component) GTPlayer.Instance).GetComponent<Rigidbody>().velocity = Vector3.zero;
    }

    public static void SlideControl() => GTPlayer.Instance.slideControl = 1f;

    public static void NoLowGrav()
    {
      if (!Global.lowgrav)
        return;
      Global.Grav(-9.81f);
      Global.lowgrav = false;
    }

    public static void NoClipFly()
    {
      Global.NoClipButton();
      if (!ControllerInputPoller.instance.rightControllerPrimaryButton)
        return;
      Transform transform = ((Component) GTPlayer.Instance).transform;
      transform.position = Vector3.op_Addition(transform.position, Vector3.op_Multiply(Vector3.op_Multiply(((Component) GTPlayer.Instance.headCollider).transform.forward, Time.deltaTime), (float) Global.FlySpeed));
      ((Component) GTPlayer.Instance).GetComponent<Rigidbody>().velocity = Vector3.zero;
    }
  }
}
