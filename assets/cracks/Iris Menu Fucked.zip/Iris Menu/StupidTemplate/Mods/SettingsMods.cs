﻿// Decompiled with JetBrains decompiler
// Type: StupidTemplate.Mods.SettingsMods
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using FTSyxcalTemplate.Menu;
using StupidTemplate.Menu;
using UnityEngine;

#nullable disable
namespace StupidTemplate.Mods
{
  internal class SettingsMods
  {
    private float keyboardDelay = 0.0f;

    public static void EnterSettings()
    {
      Main.buttonsType = 1;
      Main.pageNumber = 0;
    }

    public static void MenuSettings()
    {
      Main.buttonsType = 2;
      Main.pageNumber = 0;
    }

    public static void ModSettings()
    {
      Main.buttonsType = 3;
      Main.pageNumber = 0;
    }

    public static void MovementMods()
    {
      Main.buttonsType = 4;
      Main.pageNumber = 0;
    }

    public static void RigMods()
    {
      Main.buttonsType = 5;
      Main.pageNumber = 0;
    }

    public static void CosmeticMods()
    {
      Main.buttonsType = 6;
      Main.pageNumber = 0;
    }

    public static void FunRandomMods()
    {
      Main.buttonsType = 7;
      Main.pageNumber = 0;
    }

    public static void VisualMods()
    {
      Main.buttonsType = 8;
      Main.pageNumber = 0;
    }

    public static void SafetyMods()
    {
      Main.buttonsType = 9;
      Main.pageNumber = 0;
    }

    public static void AdvantageMods()
    {
      Main.buttonsType = 10;
      Main.pageNumber = 0;
    }

    public static void NetworkMods()
    {
      Main.buttonsType = 11;
      Main.pageNumber = 0;
    }

    public static void PlayerMods()
    {
      Main.buttonsType = 12;
      Main.pageNumber = 0;
    }

    public static void WorldMods()
    {
      Main.buttonsType = 13;
      Main.pageNumber = 0;
    }

    public static void OverpoweredMods()
    {
      Main.buttonsType = 14;
      Main.pageNumber = 0;
    }

    public static void ProjectileMods()
    {
      Main.buttonsType = 15;
      Main.pageNumber = 0;
    }

    public static void ThemeMods()
    {
      Main.buttonsType = 16;
      Main.pageNumber = 0;
    }

    public static void GuardianMods()
    {
      Main.buttonsType = 17;
      Main.pageNumber = 0;
    }

    public static void PlaceholderMods()
    {
      Main.buttonsType = 18;
      Main.pageNumber = 0;
    }

    public static void Credits()
    {
      Main.buttonsType = 18;
      Main.pageNumber = 0;
    }

    public static void RightHand() => Settings.rightHanded = true;

    public static void LeftHand() => Settings.rightHanded = false;

    public static void EnableDisconnectButton() => Settings.disconnectButton = true;

    public static void DisableDisconnectButton() => Settings.disconnectButton = false;

    public static void EnableFPSCounter() => Settings.fpsCounter = true;

    public static void DisableFPSCounter() => Settings.fpsCounter = false;

    public static void EnableNotifications() => Settings.disableNotifications = false;

    public static void DisableNotifications() => Settings.disableNotifications = true;

    public static void EnableFPSBoost() => QualitySettings.globalTextureMipmapLimit = 99999;

    public static void DisableFPSBoost() => QualitySettings.globalTextureMipmapLimit = 1;

    public static void UncapFPS()
    {
      QualitySettings.vSyncCount = 0;
      Application.targetFrameRate = int.MaxValue;
    }

    public static void CapFPS() => Application.targetFrameRate = 144;

    public static void RoundMenuOn() => Main.shouldRound = true;

    public static void RoundMenuOff() => Main.shouldRound = false;

    public static void OutlineMenuOn() => Main.shouldOutline = true;

    public static void OutlineMenuOff() => Main.shouldOutline = false;

    public static void ShinyMenu() => Main.shinymenu = true;

    public static void NoShinyMenu() => Main.shinymenu = false;

    public static void LongMenuOn() => Main.longmenu = true;

    public static void LongMenuOff() => Main.longmenu = false;

    public static void DropMenu() => Main.dropOnRemove = false;

    public static void DropMenuOff() => Main.dropOnRemove = true;

    public static void FlipMenu() => Main.flipMenu = true;

    public static void NonFlippedMenu() => Main.flipMenu = false;

    public static void Disconnect() => Global.Disconnect();
  }
}
