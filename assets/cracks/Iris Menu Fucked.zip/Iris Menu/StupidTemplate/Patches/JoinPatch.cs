﻿// Decompiled with JetBrains decompiler
// Type: StupidTemplate.Patches.JoinPatch
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using HarmonyLib;
using Photon.Pun;
using Photon.Realtime;
using StupidTemplate.Notifications;
using UnityEngine;

#nullable disable
namespace StupidTemplate.Patches
{
  [HarmonyPatch(typeof (MonoBehaviourPunCallbacks), "OnPlayerEnteredRoom")]
  internal class JoinPatch : MonoBehaviour
  {
    private static Player oldnewplayer;

    private static void Prefix(Player newPlayer)
    {
      if (newPlayer == JoinPatch.oldnewplayer)
        return;
      NotifiLib.SendNotification("<color=grey>[</color><color=green>JOIN</color><color=grey>] </color><color=white>Name: " + newPlayer.NickName + "</color>");
      JoinPatch.oldnewplayer = newPlayer;
    }
  }
}
