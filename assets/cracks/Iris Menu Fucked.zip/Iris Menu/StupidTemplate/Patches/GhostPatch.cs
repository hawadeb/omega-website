﻿// Decompiled with JetBrains decompiler
// Type: StupidTemplate.Patches.GhostPatch
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using HarmonyLib;
using UnityEngine;

#nullable disable
namespace StupidTemplate.Patches
{
  [HarmonyPatch(typeof (VRRig), "OnDisable")]
  internal class GhostPatch : MonoBehaviour
  {
    public static bool Prefix(VRRig __instance)
    {
      return !Object.op_Equality((Object) __instance, (Object) GorillaTagger.Instance.offlineVRRig);
    }
  }
}
