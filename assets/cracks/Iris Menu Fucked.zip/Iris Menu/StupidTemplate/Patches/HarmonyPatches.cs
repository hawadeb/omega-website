﻿// Decompiled with JetBrains decompiler
// Type: StupidTemplate.Patches.HarmonyPatches
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using BepInEx;
using System.ComponentModel;

#nullable disable
namespace StupidTemplate.Patches
{
  [Description("Created by @ftsyxcal with hate <3")]
  [BepInPlugin("org.ftsyxcal.gorillatag.menutemplate", "FTSyxcal Template", "1.0.0")]
  public class HarmonyPatches : BaseUnityPlugin
  {
    private void OnEnable() => Menu.ApplyHarmonyPatches();

    private void OnDisable() => Menu.RemoveHarmonyPatches();
  }
}
