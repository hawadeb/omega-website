﻿// Decompiled with JetBrains decompiler
// Type: StupidTemplate.Patches.NoLogErrorCount
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using HarmonyLib;
using UnityEngine;

#nullable disable
namespace StupidTemplate.Patches
{
  [HarmonyPatch(typeof (GorillaNot), "LogErrorCount")]
  public class NoLogErrorCount : MonoBehaviour
  {
    private static bool Prefix(string logString, string stackTrace, LogType type) => false;
  }
}
