﻿// Decompiled with JetBrains decompiler
// Type: StupidTemplate.Settings
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using IrisTemplate;
using StupidTemplate.Classes;
using StupidTemplate.Menu;
using UnityEngine;

#nullable disable
namespace StupidTemplate
{
  internal class Settings
  {
    public static ExtGradient backgroundColor = new ExtGradient()
    {
      isRainbow = false
    };
    public static ExtGradient[] buttonColors = new ExtGradient[2]
    {
      new ExtGradient()
      {
        colors = Main.GetSolidGradient(Color.black)
      },
      new ExtGradient() { isRainbow = false }
    };
    public static Color[] textColors = new Color[2]
    {
      Color.white,
      SigmaColors123.darkpurple
    };
    public static Font currentFont = Resources.GetBuiltinResource(typeof (Font), "Arial.ttf") as Font;
    public static bool fpsCounter = true;
    public static bool disconnectButton = true;
    public static bool rightHanded = false;
    public static bool disableNotifications = false;
    public static bool outsline = true;
    public static KeyCode keyboardButton = (KeyCode) 113;
    public static Color32 btnencolor = Color32.op_Implicit(SigmaColors123.darkpurple);
    public static Color32 OutlineColor = Color32.op_Implicit(SigmaColors123.darkpurple);
    public static Color32 btndiscolor = new Color32((byte) 34, (byte) 34, (byte) 34, (byte) 34);
    public static Vector3 nextbtnpos = new Vector3(0.56f, -0.23f, -0.395f);
    public static Vector3 prevbtnpos = new Vector3(0.56f, 0.23f, -0.395f);
    public static Vector3 prevbtntext = new Vector3(0.064f, 0.07f, -0.15f);
    public static Vector3 nextbtntext = new Vector3(0.064f, -0.07f, -0.15f);
    public static Vector3 BtnHeight = new Vector3(0.08f, 0.4f, 0.1f);
    public static Vector3 DisBtnHeight = new Vector3(0.56f, 0.0f, 0.58f);
    public static Vector3 DisBtntext = new Vector3(0.064f, 0.0f, 0.22f);
    public static Color32 nextnprvcolor = new Color32((byte) 34, (byte) 34, (byte) 34, (byte) 34);
    public static Color32 disconnectbuttoncolor = new Color32((byte) 34, (byte) 34, (byte) 34, (byte) 34);
    public static Color32 ButtonTextColor = Color32.op_Implicit(new Color(1f, 1f, 1f));
    private static int NnPev;
    public static Vector3 menuSize = new Vector3(0.1f, 1f, 1f);
    public static int buttonsPerPage = 6;

    public static void NextNPrevPos()
    {
      ++Settings.NnPev;
      switch (Settings.NnPev)
      {
        case 0:
          Settings.BtnHeight = new Vector3(0.08f, 0.4f, 0.13f);
          Settings.nextbtnpos = new Vector3(0.56f, -0.23f, 0.595f);
          Settings.prevbtnpos = new Vector3(0.56f, 0.23f, 0.595f);
          Settings.prevbtntext = new Vector3(0.064f, 0.07f, 0.225f);
          Settings.nextbtntext = new Vector3(0.064f, -0.07f, 0.225f);
          break;
        case 1:
          Settings.BtnHeight = new Vector3(0.08f, 0.4f, 0.13f);
          Settings.nextbtnpos = new Vector3(0.56f, -0.23f, -0.595f);
          Settings.prevbtnpos = new Vector3(0.56f, 0.23f, -0.595f);
          Settings.prevbtntext = new Vector3(0.064f, 0.07f, -0.225f);
          Settings.nextbtntext = new Vector3(0.064f, -0.07f, -0.225f);
          break;
        case 2:
          Settings.BtnHeight = new Vector3(0.09f, 0.25f, 0.9f);
          Settings.nextbtnpos = new Vector3(0.56f, -0.65f, 0.0f);
          Settings.prevbtnpos = new Vector3(0.56f, 0.65f, 0.0f);
          Settings.prevbtntext = new Vector3(0.064f, 0.195f, 0.0f);
          Settings.nextbtntext = new Vector3(0.064f, -0.195f, 0.0f);
          break;
        default:
          Settings.NnPev = 0;
          Settings.BtnHeight = new Vector3(0.08f, 0.4f, 0.13f);
          Settings.nextbtnpos = new Vector3(0.56f, -0.23f, 0.595f);
          Settings.prevbtnpos = new Vector3(0.56f, 0.23f, 0.595f);
          Settings.prevbtntext = new Vector3(0.064f, 0.07f, 0.225f);
          Settings.nextbtntext = new Vector3(0.064f, -0.07f, 0.225f);
          break;
      }
      string[] strArray = new string[4]
      {
        "Top",
        "Bottom",
        "Side",
        "Top"
      };
      Main.GetIndex("Change Next n Prev Btn Pos:").overlapText = "Change Next n Prev Btn Pos: <color=white>[</color><color=white>" + strArray[Settings.NnPev] + "</color><color=white>]</color>";
    }
  }
}
