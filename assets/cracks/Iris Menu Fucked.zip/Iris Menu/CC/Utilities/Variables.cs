﻿// Decompiled with JetBrains decompiler
// Type: CC.Utilities.Variables
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using HarmonyLib;
using Photon.Pun;
using Photon.Realtime;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

#nullable enable
namespace CC.Utilities
{
  public class Variables : MonoBehaviourPunCallbacks
  {
    public static GameObject menuObj = (GameObject) null;
    public static GameObject background = (GameObject) null;
    public static GameObject canvasObj = (GameObject) null;
    public static GameObject clickerObj = (GameObject) null;
    public static GameObject disconnectButton = (GameObject) null;
    public static GameObject cirple = (GameObject) null;
    public bool copyRigColors = false;
    public static Text title;
    public static int currentCategoryPage = 0;
    public static int ButtonsPerPage = 7;
    public static bool toggledisconnectButton = false;
    public static bool toggledtitleBackground = false;
    public static bool togglemenuOutline = false;
    public static bool rightHandedMenu = false;
    public static bool toggleNotifications = true;
    public static bool PCMenuOpen = false;
    public static KeyCode PCMenuKey = (KeyCode) 308;
    public static bool openMenu;
    public static bool menuOpen = false;
    public static bool InMenuCondition;
    public static bool InPcCondition;
    public static bool isOn = false;
    public static bool wasButtonPressed = false;
    public static Vector3 OldMouse;
    public static readonly Vector3[] lastRight = new Vector3[10];
    public static readonly Vector3[] lastLeft = new Vector3[10];
    public static GorillaTagger taggerInstance;
    public static ControllerInputPoller pollerInstance;
    public static bool rightPrimary = false;
    public static bool rightSecondary = false;
    public static bool leftPrimary = false;
    public static bool leftSecondary = false;
    public static bool leftGrab = false;
    public static bool rightGrab = false;
    public static float leftTrigger = 0.0f;
    public static float rightTrigger = 0.0f;
    public static VRRig vrrig;
    public static Material vrrigMaterial = (Material) null;
    public static int[] bones = new int[38]
    {
      4,
      3,
      5,
      4,
      19,
      18,
      20,
      19,
      3,
      18,
      21,
      20,
      22,
      21,
      25,
      21,
      29,
      21,
      31,
      29,
      27,
      25,
      24,
      22,
      6,
      5,
      7,
      6,
      10,
      6,
      14,
      6,
      16,
      14,
      12,
      10,
      9,
      7
    };
    public static Vector3 wallContactPoint;
    public static Vector3 wallContactNormal;
    public static GameObject thirdPersonCamera;
    public static GameObject shoulderCamera;
    public static GameObject TransformCam = (GameObject) null;
    public static bool didThirdPerson = false;
    public static GameObject cm;
    public static Rigidbody currentMenuRigidbody = (Rigidbody) null;
    public static Vector3 previousVelocity = Vector3.zero;
    public const float velocityThreshold = 0.05f;
    public static MeshCollider[] tpStumpColliders;
    public static GameObject leftPlatform;
    public static GameObject leftPlatform2;
    public static GameObject leftPlatform3;
    public static GameObject leftPlatform4;
    public static GameObject rightPlatform;
    public static GameObject rightPlatform2;
    public static GameObject rightPlatform3;
    public static GameObject rightPlatform4;
    public static bool leftPlatformEnabled;
    public static bool rightPlatformEnabled;
    public static bool pressedPrimary;
    public static readonly Dictionary<string, string> gameModePaths = new Dictionary<string, string>()
    {
      {
        "forest",
        "Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Forest, Tree Exit"
      },
      {
        "city",
        "Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - City Front"
      },
      {
        "canyons",
        "Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Canyon"
      },
      {
        "mountains",
        "Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Mountain For Computer"
      },
      {
        "beach",
        "Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Beach from Forest"
      },
      {
        "sky",
        "Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Clouds"
      },
      {
        "basement",
        "Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Basement For Computer"
      },
      {
        "metro",
        "Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Metropolis from Computer"
      },
      {
        "arcade",
        "Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - City frm Arcade"
      },
      {
        "rotating",
        "Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Rotating Map"
      },
      {
        "bayou",
        "Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - BayouComputer2"
      },
      {
        "caves",
        "Environment Objects/TriggerZones_Prefab/JoinRoomTriggers_Prefab/JoinPublicRoom - Cave"
      }
    };

    public static bool IsLeftButtonPressed() => Mouse.current.leftButton.isPressed;

    public static bool IsRightButtonPressed() => Mouse.current.rightButton.isPressed;

    public static bool IsBackButtonPressed() => Mouse.current.backButton.isPressed;

    public static string GetPathForGameMode(string gameMode)
    {
      string pathForGameMode;
      Variables.gameModePaths.TryGetValue(gameMode.ToLower(), out pathForGameMode);
      return pathForGameMode;
    }

    public static string GetHTMode()
    {
      return PhotonNetwork.CurrentRoom == null || !((Dictionary<object, object>) ((RoomInfo) PhotonNetwork.CurrentRoom).CustomProperties).ContainsKey((object) "gameMode") ? "ERROR" : ((RoomInfo) PhotonNetwork.CurrentRoom).CustomProperties[(object) "gameMode"].ToString();
    }

    public static NetPlayer GetNetPlayerFromRig(VRRig vrrig) => vrrig.Creator;

    public static VRRig GetRigFromNetPlayer(NetPlayer netPlayer)
    {
      return GorillaGameManager.instance.FindPlayerVRRig(netPlayer);
    }

    public static PhotonView GetPhotonViewFromRig(VRRig vrrig)
    {
      return (PhotonView) Traverse.Create((object) vrrig).Field("photonView").GetValue();
    }

    public static PhotonView GetPhotonViewFromNetPlayer(NetPlayer netPlayer)
    {
      return Variables.GetPhotonViewFromRig(GorillaGameManager.instance.FindPlayerVRRig(netPlayer));
    }

    public static bool GetGamemode(string gamemodeName)
    {
      return GorillaGameManager.instance.GameModeName().ToLower().Contains(gamemodeName.ToLower());
    }

    public static bool IAmInfected
    {
      get => Variables.RigIsInfected(Variables.taggerInstance.offlineVRRig);
    }

    public static bool RigIsInfected(VRRig vrrig)
    {
      return ((Component) GorillaGameManager.instance).GetComponent<GorillaTagManager>().currentInfected.Contains(vrrig.OwningNetPlayer);
    }

    public static bool InLobby() => PhotonNetwork.InLobby;

    public static bool IsMaster() => PhotonNetwork.IsMasterClient;
  }
}
