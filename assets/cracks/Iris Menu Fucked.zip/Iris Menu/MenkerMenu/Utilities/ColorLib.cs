﻿// Decompiled with JetBrains decompiler
// Type: MenkerMenu.Utilities.ColorLib
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using UnityEngine;

#nullable disable
namespace MenkerMenu.Utilities
{
  public class ColorLib
  {
    public static Color32 Red = new Color32(byte.MaxValue, (byte) 0, (byte) 0, byte.MaxValue);
    public static Color32 DarkRed = new Color32((byte) 180, (byte) 0, (byte) 0, byte.MaxValue);
    public static Color32 Salmon = new Color32((byte) 250, (byte) 128, (byte) 114, byte.MaxValue);
    public static Color32 WineRed = new Color32((byte) 123, (byte) 0, (byte) 0, byte.MaxValue);
    public static Color32 IndianRed = new Color32((byte) 205, (byte) 92, (byte) 92, byte.MaxValue);
    public static Color32 Crimson = new Color32((byte) 220, (byte) 20, (byte) 60, byte.MaxValue);
    public static Color32 FireBrick = new Color32((byte) 178, (byte) 34, (byte) 34, byte.MaxValue);
    public static Color32 Coral = new Color32(byte.MaxValue, (byte) 127, (byte) 80, byte.MaxValue);
    public static Color32 Tomato = new Color32(byte.MaxValue, (byte) 99, (byte) 71, byte.MaxValue);
    public static Color32 Maroon = new Color32((byte) 128, (byte) 0, (byte) 0, byte.MaxValue);
    public static Color32 Green = new Color32((byte) 0, byte.MaxValue, (byte) 0, byte.MaxValue);
    public static Color32 Lime = new Color32((byte) 0, (byte) 128, (byte) 0, byte.MaxValue);
    public static Color32 DarkGreen = new Color32((byte) 0, (byte) 100, (byte) 0, byte.MaxValue);
    public static Color32 Olive = new Color32((byte) 128, (byte) 128, (byte) 0, byte.MaxValue);
    public static Color32 ForestGreen = new Color32((byte) 34, (byte) 139, (byte) 34, byte.MaxValue);
    public static Color32 SeaGreen = new Color32((byte) 46, (byte) 139, (byte) 87, byte.MaxValue);
    public static Color32 MediumSeaGreen = new Color32((byte) 60, (byte) 179, (byte) 113, byte.MaxValue);
    public static Color32 Aquamarine = new Color32((byte) 127, byte.MaxValue, (byte) 212, byte.MaxValue);
    public static Color32 MediumAquamarine = new Color32((byte) 102, (byte) 205, (byte) 170, byte.MaxValue);
    public static Color32 DarkSeaGreen = new Color32((byte) 143, (byte) 188, (byte) 143, byte.MaxValue);
    public static Color32 Blue = new Color32((byte) 0, (byte) 0, byte.MaxValue, byte.MaxValue);
    public static Color32 Navy = new Color32((byte) 0, (byte) 0, (byte) 128, byte.MaxValue);
    public static Color32 DarkBlue = new Color32((byte) 0, (byte) 0, (byte) 160, byte.MaxValue);
    public static Color32 RoyalBlue = new Color32((byte) 65, (byte) 105, (byte) 225, byte.MaxValue);
    public static Color32 DodgerBlue = new Color32((byte) 30, (byte) 144, byte.MaxValue, byte.MaxValue);
    public static Color32 DarkDodgerBlue = new Color32((byte) 8, (byte) 90, (byte) 177, byte.MaxValue);
    public static Color32 DeepSkyBlue = new Color32((byte) 0, (byte) 191, byte.MaxValue, byte.MaxValue);
    public static Color32 SkyBlue = new Color32((byte) 135, (byte) 206, (byte) 235, byte.MaxValue);
    public static Color32 SteelBlue = new Color32((byte) 70, (byte) 130, (byte) 180, byte.MaxValue);
    public static Color32 Cyan = new Color32((byte) 0, byte.MaxValue, byte.MaxValue, byte.MaxValue);
    public static Color32 Yellow = new Color32(byte.MaxValue, byte.MaxValue, (byte) 0, byte.MaxValue);
    public static Color32 Gold = new Color32(byte.MaxValue, (byte) 215, (byte) 0, byte.MaxValue);
    public static Color32 LightYellow = new Color32(byte.MaxValue, byte.MaxValue, (byte) 224, byte.MaxValue);
    public static Color32 LemonChiffon = new Color32(byte.MaxValue, (byte) 250, (byte) 205, byte.MaxValue);
    public static Color32 Khaki = new Color32((byte) 240, (byte) 230, (byte) 140, byte.MaxValue);
    public static Color32 PaleGoldenrod = new Color32((byte) 238, (byte) 232, (byte) 170, byte.MaxValue);
    public static Color32 LightGoldenrodYellow = new Color32((byte) 250, (byte) 250, (byte) 210, byte.MaxValue);
    public static Color32 Orange = new Color32(byte.MaxValue, (byte) 165, (byte) 0, byte.MaxValue);
    public static Color32 DarkOrange = new Color32(byte.MaxValue, (byte) 140, (byte) 0, byte.MaxValue);
    public static Color32 RedOrange = new Color32(byte.MaxValue, (byte) 69, (byte) 0, byte.MaxValue);
    public static Color32 PeachPuff = new Color32(byte.MaxValue, (byte) 218, (byte) 185, byte.MaxValue);
    public static Color32 DarkGoldenrod = new Color32((byte) 184, (byte) 134, (byte) 11, byte.MaxValue);
    public static Color32 Peru = new Color32((byte) 205, (byte) 133, (byte) 63, byte.MaxValue);
    public static Color32 OrangeRed = new Color32(byte.MaxValue, (byte) 69, (byte) 0, byte.MaxValue);
    public static Color32 Magenta = new Color32(byte.MaxValue, (byte) 0, byte.MaxValue, byte.MaxValue);
    public static Color32 Purple = new Color32((byte) 123, (byte) 3, (byte) 252, byte.MaxValue);
    public static Color32 Lavender = new Color32((byte) 230, (byte) 230, (byte) 250, byte.MaxValue);
    public static Color32 Plum = new Color32((byte) 221, (byte) 160, (byte) 221, byte.MaxValue);
    public static Color32 Indigo = new Color32((byte) 75, (byte) 0, (byte) 130, byte.MaxValue);
    public static Color32 MediumOrchid = new Color32((byte) 186, (byte) 85, (byte) 211, byte.MaxValue);
    public static Color32 SlateBlue = new Color32((byte) 106, (byte) 90, (byte) 205, byte.MaxValue);
    public static Color32 DarkSlateBlue = new Color32((byte) 72, (byte) 61, (byte) 139, byte.MaxValue);
    public static Color32 Pink = new Color32(byte.MaxValue, (byte) 192, (byte) 203, byte.MaxValue);
    public static Color32 LightSalmon = new Color32(byte.MaxValue, (byte) 160, (byte) 122, byte.MaxValue);
    public static Color32 DarkSalmon = new Color32((byte) 233, (byte) 150, (byte) 122, byte.MaxValue);
    public static Color32 LightCoral = new Color32((byte) 240, (byte) 128, (byte) 128, byte.MaxValue);
    public static Color32 MistyRose = new Color32(byte.MaxValue, (byte) 228, (byte) 225, byte.MaxValue);
    public static Color32 HotPink = new Color32(byte.MaxValue, (byte) 105, (byte) 180, byte.MaxValue);
    public static Color32 DeepPink = new Color32(byte.MaxValue, (byte) 20, (byte) 147, byte.MaxValue);
    public static Color32 Brown = new Color32((byte) 139, (byte) 69, (byte) 19, byte.MaxValue);
    public static Color32 RosyBrown = new Color32((byte) 188, (byte) 143, (byte) 143, byte.MaxValue);
    public static Color32 SaddleBrown = new Color32((byte) 139, (byte) 69, (byte) 19, byte.MaxValue);
    public static Color32 Sienna = new Color32((byte) 160, (byte) 82, (byte) 45, byte.MaxValue);
    public static Color32 Chocolate = new Color32((byte) 210, (byte) 105, (byte) 30, byte.MaxValue);
    public static Color32 SandyBrown = new Color32((byte) 244, (byte) 164, (byte) 96, byte.MaxValue);
    public static Color32 BurlyWood = new Color32((byte) 222, (byte) 184, (byte) 135, byte.MaxValue);
    public static Color32 Tan = new Color32((byte) 210, (byte) 180, (byte) 140, byte.MaxValue);
    public static Color32 White = new Color32(byte.MaxValue, byte.MaxValue, byte.MaxValue, byte.MaxValue);
    public static Color32 Linen = new Color32((byte) 250, (byte) 240, (byte) 230, byte.MaxValue);
    public static Color32 OldLace = new Color32((byte) 253, (byte) 245, (byte) 230, byte.MaxValue);
    public static Color32 SeaShell = new Color32(byte.MaxValue, (byte) 245, (byte) 238, byte.MaxValue);
    public static Color32 MintCream = new Color32((byte) 245, byte.MaxValue, (byte) 250, byte.MaxValue);
    public static Color32 Black = new Color32((byte) 0, (byte) 0, (byte) 0, byte.MaxValue);
    public static Color32 Grey = new Color32((byte) 128, (byte) 128, (byte) 128, byte.MaxValue);
    public static Color32 LightGrey = new Color32((byte) 192, (byte) 192, (byte) 192, byte.MaxValue);
    public static Color32 DarkGrey = new Color32((byte) 80, (byte) 80, (byte) 80, byte.MaxValue);
    public static Color32 back = new Color32((byte) 18, (byte) 18, (byte) 18, byte.MaxValue);
    public static Color32 DarkerGrey = new Color32((byte) 40, (byte) 40, (byte) 40, byte.MaxValue);
    public static Color32 RedTransparent = new Color32(byte.MaxValue, (byte) 0, (byte) 0, (byte) 80);
    public static Color32 DarkRedTransparent = new Color32((byte) 180, (byte) 0, (byte) 0, (byte) 80);
    public static Color32 SalmonTransparent = new Color32((byte) 250, (byte) 128, (byte) 114, (byte) 80);
    public static Color32 IndianRedTransparent = new Color32((byte) 205, (byte) 92, (byte) 92, (byte) 80);
    public static Color32 CrimsonTransparent = new Color32((byte) 220, (byte) 20, (byte) 60, (byte) 80);
    public static Color32 WineRedTransparent = new Color32((byte) 123, (byte) 0, (byte) 0, (byte) 80);
    public static Color32 FireBrickTransparent = new Color32((byte) 178, (byte) 34, (byte) 34, (byte) 80);
    public static Color32 CoralTransparent = new Color32(byte.MaxValue, (byte) 127, (byte) 80, (byte) 80);
    public static Color32 TomatoTransparent = new Color32(byte.MaxValue, (byte) 99, (byte) 71, (byte) 80);
    public static Color32 MaroonTransparent = new Color32((byte) 128, (byte) 0, (byte) 0, (byte) 80);
    public static Color32 GreenTransparent = new Color32((byte) 0, byte.MaxValue, (byte) 0, (byte) 80);
    public static Color32 LimeTransparent = new Color32((byte) 0, (byte) 128, (byte) 0, (byte) 80);
    public static Color32 DarkGreenTransparent = new Color32((byte) 0, (byte) 100, (byte) 0, (byte) 80);
    public static Color32 OliveTransparent = new Color32((byte) 128, (byte) 128, (byte) 0, (byte) 80);
    public static Color32 ForestGreenTransparent = new Color32((byte) 34, (byte) 139, (byte) 34, (byte) 80);
    public static Color32 SeaGreenTransparent = new Color32((byte) 46, (byte) 139, (byte) 87, (byte) 80);
    public static Color32 MediumSeaGreenTransparent = new Color32((byte) 60, (byte) 179, (byte) 113, (byte) 80);
    public static Color32 AquamarineTransparent = new Color32((byte) 127, byte.MaxValue, (byte) 212, (byte) 80);
    public static Color32 MediumAquamarineTransparent = new Color32((byte) 102, (byte) 205, (byte) 170, (byte) 80);
    public static Color32 DarkSeaGreenTransparent = new Color32((byte) 143, (byte) 188, (byte) 143, (byte) 80);
    public static Color32 BlueTransparent = new Color32((byte) 0, (byte) 0, byte.MaxValue, (byte) 80);
    public static Color32 NavyTransparent = new Color32((byte) 0, (byte) 0, (byte) 128, (byte) 80);
    public static Color32 DarkBlueTransparent = new Color32((byte) 0, (byte) 0, (byte) 139, (byte) 80);
    public static Color32 RoyalBlueTransparent = new Color32((byte) 65, (byte) 105, (byte) 225, (byte) 80);
    public static Color32 DodgerBlueTransparent = new Color32((byte) 30, (byte) 144, byte.MaxValue, (byte) 80);
    public static Color32 DarkDodgerBlueTransparent = new Color32((byte) 8, (byte) 90, (byte) 177, (byte) 80);
    public static Color32 DeepSkyBlueTransparent = new Color32((byte) 0, (byte) 191, byte.MaxValue, (byte) 80);
    public static Color32 SkyBlueTransparent = new Color32((byte) 135, (byte) 206, (byte) 235, (byte) 80);
    public static Color32 SteelBlueTransparent = new Color32((byte) 70, (byte) 130, (byte) 180, (byte) 80);
    public static Color32 CyanTransparent = new Color32((byte) 0, byte.MaxValue, byte.MaxValue, (byte) 80);
    public static Color32 YellowTransparent = new Color32(byte.MaxValue, byte.MaxValue, (byte) 0, (byte) 80);
    public static Color32 GoldTransparent = new Color32(byte.MaxValue, (byte) 215, (byte) 0, (byte) 80);
    public static Color32 LightYellowTransparent = new Color32(byte.MaxValue, byte.MaxValue, (byte) 224, (byte) 80);
    public static Color32 LemonChiffonTransparent = new Color32(byte.MaxValue, (byte) 250, (byte) 205, (byte) 80);
    public static Color32 KhakiTransparent = new Color32((byte) 240, (byte) 230, (byte) 140, (byte) 80);
    public static Color32 PaleGoldenrodTransparent = new Color32((byte) 238, (byte) 232, (byte) 170, (byte) 80);
    public static Color32 LightGoldenrodYellowTransparent = new Color32((byte) 250, (byte) 250, (byte) 210, (byte) 80);
    public static Color32 OrangeTransparent = new Color32(byte.MaxValue, (byte) 165, (byte) 0, (byte) 80);
    public static Color32 DarkOrangeTransparent = new Color32(byte.MaxValue, (byte) 140, (byte) 0, (byte) 80);
    public static Color32 RedOrangeTransparent = new Color32(byte.MaxValue, (byte) 69, (byte) 0, (byte) 80);
    public static Color32 PeachPuffTransparent = new Color32(byte.MaxValue, (byte) 218, (byte) 185, (byte) 80);
    public static Color32 DarkGoldenrodTransparent = new Color32((byte) 184, (byte) 134, (byte) 11, (byte) 80);
    public static Color32 PeruTransparent = new Color32((byte) 205, (byte) 133, (byte) 63, (byte) 80);
    public static Color32 OrangeRedTransparent = new Color32(byte.MaxValue, (byte) 69, (byte) 0, (byte) 80);
    public static Color32 MagentaTransparent = new Color32(byte.MaxValue, (byte) 0, byte.MaxValue, (byte) 80);
    public static Color32 PurpleTransparent = new Color32((byte) 123, (byte) 3, (byte) 252, (byte) 80);
    public static Color32 LavenderTransparent = new Color32((byte) 230, (byte) 230, (byte) 250, (byte) 80);
    public static Color32 PlumTransparent = new Color32((byte) 221, (byte) 160, (byte) 221, (byte) 80);
    public static Color32 IndigoTransparent = new Color32((byte) 75, (byte) 0, (byte) 130, (byte) 80);
    public static Color32 MediumOrchidTransparent = new Color32((byte) 186, (byte) 85, (byte) 211, (byte) 80);
    public static Color32 SlateBlueTransparent = new Color32((byte) 106, (byte) 90, (byte) 205, (byte) 80);
    public static Color32 DarkSlateBlueTransparent = new Color32((byte) 72, (byte) 61, (byte) 139, (byte) 80);
    public static Color32 PinkTransparent = new Color32(byte.MaxValue, (byte) 192, (byte) 203, (byte) 80);
    public static Color32 LightSalmonTransparent = new Color32(byte.MaxValue, (byte) 160, (byte) 122, (byte) 80);
    public static Color32 DarkSalmonTransparent = new Color32((byte) 233, (byte) 150, (byte) 122, (byte) 80);
    public static Color32 LightCoralTransparent = new Color32((byte) 240, (byte) 128, (byte) 128, (byte) 80);
    public static Color32 MistyRoseTransparent = new Color32(byte.MaxValue, (byte) 228, (byte) 225, (byte) 80);
    public static Color32 HotPinkTransparent = new Color32(byte.MaxValue, (byte) 105, (byte) 180, (byte) 80);
    public static Color32 DeepPinkTransparent = new Color32(byte.MaxValue, (byte) 20, (byte) 147, (byte) 80);
    public static Color32 BrownTransparent = new Color32((byte) 165, (byte) 42, (byte) 42, (byte) 80);
    public static Color32 RosyBrownTransparent = new Color32((byte) 188, (byte) 143, (byte) 143, (byte) 80);
    public static Color32 SaddleBrownTransparent = new Color32((byte) 139, (byte) 69, (byte) 19, (byte) 80);
    public static Color32 SiennaTransparent = new Color32((byte) 160, (byte) 82, (byte) 45, (byte) 80);
    public static Color32 ChocolateTransparent = new Color32((byte) 210, (byte) 105, (byte) 30, (byte) 80);
    public static Color32 SandyBrownTransparent = new Color32((byte) 244, (byte) 164, (byte) 96, (byte) 80);
    public static Color32 BurlyWoodTransparent = new Color32((byte) 222, (byte) 184, (byte) 135, (byte) 80);
    public static Color32 TanTransparent = new Color32((byte) 210, (byte) 180, (byte) 140, (byte) 80);
    public static Color32 WhiteTransparent = new Color32(byte.MaxValue, byte.MaxValue, byte.MaxValue, (byte) 80);
    public static Color32 LightWhiteTransparent = new Color32(byte.MaxValue, byte.MaxValue, byte.MaxValue, (byte) 10);
    public static Color32 LinenTransparent = new Color32((byte) 250, (byte) 240, (byte) 230, (byte) 80);
    public static Color32 OldLaceTransparent = new Color32((byte) 253, (byte) 245, (byte) 230, (byte) 80);
    public static Color32 SeaShellTransparent = new Color32(byte.MaxValue, (byte) 245, (byte) 238, (byte) 80);
    public static Color32 MintCreamTransparent = new Color32((byte) 245, byte.MaxValue, (byte) 250, (byte) 80);
    public static Color32 BlackTransparent = new Color32((byte) 0, (byte) 0, (byte) 0, (byte) 80);
    public static Color32 GreyTransparent = new Color32((byte) 80, (byte) 80, (byte) 80, (byte) 80);
    public static Color32 LightGreyTransparent = new Color32((byte) 192, (byte) 192, (byte) 192, (byte) 80);
    public static Color32 DarkGreyTransparent = new Color32((byte) 40, (byte) 40, (byte) 40, (byte) 80);
    public static Color32 DarkerGreyTransparent = new Color32((byte) 40, (byte) 40, (byte) 40, (byte) 80);
    public static Shader guiShader = Shader.Find("GUI/Text Shader");
    public static Shader uberShader = Shader.Find("GorillaTag/UberShader");
    public static int CurrentTheme = 0;
    public static Color32[] ThemeArraya = new Color32[6]
    {
      new Color32((byte) 0, (byte) 0, (byte) 200, byte.MaxValue),
      new Color32((byte) 0, (byte) 0, (byte) 0, byte.MaxValue),
      new Color32((byte) 123, (byte) 3, (byte) 200, byte.MaxValue),
      new Color32((byte) 0, (byte) 100, (byte) 0, byte.MaxValue),
      new Color32((byte) 200, (byte) 0, (byte) 0, byte.MaxValue),
      new Color32((byte) 200, (byte) 60, (byte) 0, byte.MaxValue)
    };
  }
}
