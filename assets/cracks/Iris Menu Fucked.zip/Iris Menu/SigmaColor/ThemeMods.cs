﻿// Decompiled with JetBrains decompiler
// Type: SigmaColor.ThemeMods
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using StupidTemplate;
using StupidTemplate.Classes;
using UnityEngine;

#nullable disable
namespace SigmaColor
{
  internal class ThemeMods
  {
    public static void DefaultTheme()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.darkpurple);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.darkpurple);
    }

    public static void Theme1()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.darkGrey);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.darkGrey);
    }

    public static void Theme2()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.darkGreyv2);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.darkGreyv2);
    }

    public static void Theme3()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.darkRed);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.darkRed);
    }

    public static void Theme4()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.crimson);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.crimson);
    }

    public static void Theme5()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.maroon);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.maroon);
    }

    public static void Theme6()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.indianRed);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.indianRed);
    }

    public static void Theme7()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.firebrick);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.firebrick);
    }

    public static void Theme8()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.darkblue);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.darkblue);
    }

    public static void Theme9()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.brickRed);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.brickRed);
    }

    public static void Theme10()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.tomato);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.tomato);
    }

    public static void Theme11()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.coral);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.coral);
    }

    public static void Theme12()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.darkSalmon);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.darkSalmon);
    }

    public static void Theme13()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.salmon);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.salmon);
    }

    public static void Theme14()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.lightCoral);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.lightCoral);
    }

    public static void Theme15()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.hotPink);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.hotPink);
    }

    public static void Theme16()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.paleVioletRed);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.paleVioletRed);
    }

    public static void Theme17()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.mediumVioletRed);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.mediumVioletRed);
    }

    public static void Theme18()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.deepPink);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.deepPink);
    }

    public static void Theme19()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.pink);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.pink);
    }

    public static void Theme20()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.lightpurple);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.lightpurple);
    }

    public static void Theme21()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.darkpurple);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.darkpurple);
    }

    public static void Theme22()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.Purpyagain);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.Purpyagain);
    }

    public static void Theme23()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.ThemeColorPurp);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.ThemeColorPurp);
    }

    public static void Theme24()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.Darkerpink);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.Darkerpink);
    }

    public static void Theme25()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.lightPink);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.lightPink);
    }

    public static void Theme26()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.orchid);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.orchid);
    }

    public static void Theme27()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.mediumOrchid);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.mediumOrchid);
    }

    public static void Theme28()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.paleOrchid);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.paleOrchid);
    }

    public static void Theme29()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.purple);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.purple);
    }

    public static void Theme30()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.secondpurp);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.secondpurp);
    }

    public static void Theme31()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.mediumPurple);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.mediumPurple);
    }

    public static void Theme32()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.purplevon);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.purplevon);
    }

    public static void Theme33()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.darkGreyvon);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.darkGreyvon);
    }

    public static void Theme34()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.thistle);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.thistle);
    }

    public static void Theme35()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.plum);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.plum);
    }

    public static void Theme36()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.lavender);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.lavender);
    }

    public static void Theme37()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.violet);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.violet);
    }

    public static void Theme38()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.indigo);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.indigo);
    }

    public static void Theme39()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.slateBlue);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.slateBlue);
    }

    public static void Theme40()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.darkSlateBlue);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.darkSlateBlue);
    }

    public static void Theme41()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.mediumSlateBlue);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.mediumSlateBlue);
    }

    public static void Theme42()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.blueViolet);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.blueViolet);
    }

    public static void Theme43()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.darkViolet);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.darkViolet);
    }

    public static void Theme44()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.darkOrchid);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.darkOrchid);
    }

    public static void Theme45()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.darkMagenta);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.darkMagenta);
    }

    public static void Theme46()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.darkLavender);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.darkLavender);
    }

    public static void Theme47()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.darkIndigo);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.darkIndigo);
    }

    public static void Theme48()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.darkCornflowerBlue);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.darkCornflowerBlue);
    }

    public static void Theme49()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.darkCyan);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.darkCyan);
    }

    public static void Theme50()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.cadetBlue);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.cadetBlue);
    }

    public static void Theme51()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.darkTurquoise);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.darkTurquoise);
    }

    public static void Theme52()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.mediumTurquoise);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.mediumTurquoise);
    }

    public static void Theme53()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.lightSeaGreen);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.lightSeaGreen);
    }

    public static void Theme54()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.turquoise);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.turquoise);
    }

    public static void Theme55()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.aquamarine);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.aquamarine);
    }

    public static void Theme56()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.mediumAquamarine);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.mediumAquamarine);
    }

    public static void Theme57()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.lightGreen);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.lightGreen);
    }

    public static void Theme58()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.paleGreen);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.paleGreen);
    }

    public static void Theme59()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.springGreen);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.springGreen);
    }

    public static void Theme60()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.mediumSpringGreen);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.mediumSpringGreen);
    }

    public static void Theme61()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.darkSeaGreen);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.darkSeaGreen);
    }

    public static void Theme62()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.seaGreen);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.seaGreen);
    }

    public static void Theme63()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.forestGreen);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.forestGreen);
    }

    public static void Theme64()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.green);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.green);
    }

    public static void Theme65()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.darkOliveGreen);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.darkOliveGreen);
    }

    public static void Theme66()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.oliveDrab);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.oliveDrab);
    }

    public static void Theme67()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.olive);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.olive);
    }

    public static void Theme68()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.yellowGreen);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.yellowGreen);
    }

    public static void Theme69()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.chartreuse);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.chartreuse);
    }

    public static void Theme70()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.lawnGreen);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.lawnGreen);
    }

    public static void Theme71()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.lime);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.lime);
    }

    public static void Theme72()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.limeGreen);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.limeGreen);
    }

    public static void Theme73()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.lightGoldenrodYellow);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.lightGoldenrodYellow);
    }

    public static void Theme74()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.lightYellow);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.lightYellow);
    }

    public static void Theme75()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.paleGoldenrod);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.paleGoldenrod);
    }

    public static void Theme76()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.darkKhaki);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.darkKhaki);
    }

    public static void Theme77()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.gold);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.gold);
    }

    public static void Theme78()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.lightGoldenrod);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.lightGoldenrod);
    }

    public static void Theme79()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.goldenrod);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.goldenrod);
    }

    public static void Theme80()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.darkGoldenrod);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.darkGoldenrod);
    }

    public static void Theme81()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.rosyBrown);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.rosyBrown);
    }

    public static void Theme82()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.saddleBrown);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.saddleBrown);
    }

    public static void Theme83()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.sienna);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.sienna);
    }

    public static void Theme84()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.peru);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.peru);
    }

    public static void Theme85()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.burlywood);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.burlywood);
    }

    public static void Theme86()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.beige);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.beige);
    }

    public static void Theme87()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.wheat);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.wheat);
    }

    public static void Theme88()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.sandyBrown);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.sandyBrown);
    }

    public static void Theme89()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.tan);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.tan);
    }

    public static void Theme90()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.chocolate);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.chocolate);
    }

    public static void Theme91()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.brown);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.brown);
    }

    public static void Theme92()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.lightSalmon);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.lightSalmon);
    }

    public static void Theme93()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.orange);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.orange);
    }

    public static void Theme94()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.darkOrange);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.darkOrange);
    }

    public static void Theme95()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.orangeRed);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.orangeRed);
    }

    public static void Theme96()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.khaki);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.khaki);
    }

    public static void Theme97()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.redreal);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.redreal);
    }

    public static void Theme98()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.greenreal);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.greenreal);
    }

    public static void Theme99()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.greenreall);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.greenreall);
    }

    public static void Theme100()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.redreall);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.redreall);
    }

    public static void Theme101()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.lavenderBlush);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.lavenderBlush);
    }

    public static void Theme102()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.mistyRose);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.mistyRose);
    }

    public static void Theme103()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.peach);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.peach);
    }

    public static void Theme104()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.papayaWhip);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.papayaWhip);
    }

    public static void Theme105()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.linen);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.linen);
    }

    public static void Theme106()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.oldLace);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.oldLace);
    }

    public static void Theme107()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.seaShell);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.seaShell);
    }

    public static void Theme108()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.cornsilk);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.cornsilk);
    }

    public static void Theme109()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.lemonChiffon);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.lemonChiffon);
    }

    public static void Theme110()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.floralWhite);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.floralWhite);
    }

    public static void Theme111()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.snow);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.snow);
    }

    public static void Theme112()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.ivory);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.ivory);
    }

    public static void Theme113()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.honeydew);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.honeydew);
    }

    public static void Theme114()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.mintCream);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.mintCream);
    }

    public static void Theme115()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.azure);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.azure);
    }

    public static void Theme116()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.aliceBlue);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.aliceBlue);
    }

    public static void Theme117()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.lavenderGrey);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.lavenderGrey);
    }

    public static void Theme118()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.lightSteelBlue);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.lightSteelBlue);
    }

    public static void Theme119()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.powderBlue);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.powderBlue);
    }

    public static void Theme120()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.paleTurquoise);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.paleTurquoise);
    }

    public static void Theme121()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.lightBlue);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.lightBlue);
    }

    public static void Theme122()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.skyBlue);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.skyBlue);
    }

    public static void Theme123()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.lightSkyBlue);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.lightSkyBlue);
    }

    public static void Theme124()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.deepSkyBlue);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.deepSkyBlue);
    }

    public static void Theme125()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.dodgerBlue);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.dodgerBlue);
    }

    public static void Theme126()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.cornflowerBlue);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.cornflowerBlue);
    }

    public static void Theme127()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.steelBlue);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.steelBlue);
    }

    public static void Theme128()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.royalBlue);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.royalBlue);
    }

    public static void Theme129()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.mediumBlue);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.mediumBlue);
    }

    public static void Theme130()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.darkBlue);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.darkBlue);
    }

    public static void Theme131()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.navy);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.navy);
    }

    public static void Theme132()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.midnightBlue);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.midnightBlue);
    }

    public static void Theme133()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.orange2);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.orange2);
    }

    public static void Theme134()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.ButtonColor);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.ButtonColor);
    }

    public static void Theme135()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.ButtonColor2);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.ButtonColor2);
    }

    public static void Theme136()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.grey);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.grey);
    }

    public static void Theme137()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.colorpurple);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.colorpurple);
    }

    public static void Theme138()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.black);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.black);
    }

    public static void Theme139()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.white);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.white);
    }

    public static void Theme140()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.ButtonColorGrey);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.ButtonColorGrey);
    }

    public static void Theme141()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.ButtonColorDarkGrey);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.ButtonColorDarkGrey);
    }

    public static void Theme142()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.neonPink);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.neonPink);
    }

    public static void Theme143()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.electricBlue);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.electricBlue);
    }

    public static void Theme144()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.neonGreen);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.neonGreen);
    }

    public static void Theme145()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.whitev2);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.whitev2);
    }

    public static void Theme146()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.deepGreen);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.deepGreen);
    }

    public static void Theme147()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.mediumPink);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.mediumPink);
    }

    public static void Theme148()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.darkPink);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.darkPink);
    }

    public static void Theme149()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.palePink);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.palePink);
    }

    public static void Theme150()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.pastelPink);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.pastelPink);
    }

    public static void Theme151()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.babyPink);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.babyPink);
    }

    public static void Theme152()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.cottonCandyPink);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.cottonCandyPink);
    }

    public static void Theme153()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.salmonPink);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.salmonPink);
    }

    public static void Theme154()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.fuchsiaPink);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.fuchsiaPink);
    }

    public static void Theme155()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.magentaPink);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.magentaPink);
    }

    public static void Theme156()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.blushPink);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.blushPink);
    }

    public static void Theme157()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.rosePink);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.rosePink);
    }

    public static void Theme158()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.bubblegumPink);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.bubblegumPink);
    }

    public static void Theme159()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.flamingoPink);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.flamingoPink);
    }

    public static void Theme160()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.peachyPink);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.peachyPink);
    }

    public static void Theme161()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.coralPink);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.coralPink);
    }

    public static void Theme162()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.orchidPink);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.orchidPink);
    }

    public static void Theme163()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.raspberryPink);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.raspberryPink);
    }

    public static void Theme164()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.candyPink);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.candyPink);
    }

    public static void Theme165()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.flamingoPink2);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.flamingoPink2);
    }

    public static void Theme166()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.salmonPink2);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.salmonPink2);
    }

    public static void Theme167()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.rosePink2);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.rosePink2);
    }

    public static void Theme168()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.pinkLemonade);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.pinkLemonade);
    }

    public static void Theme169()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.bubblegumPink2);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.bubblegumPink2);
    }

    public static void Theme170()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.pinkSherbet);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.pinkSherbet);
    }

    public static void Theme171()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.cottonCandyPink2);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.cottonCandyPink2);
    }

    public static void Theme172()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.peachyPink2);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.peachyPink2);
    }

    public static void Theme173()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.rosePink3);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.rosePink3);
    }

    public static void Theme174()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.strawberryPink);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.strawberryPink);
    }

    public static void Theme175()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.pinkChampagne);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.pinkChampagne);
    }

    public static void Theme176()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.flamingoPink3);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.flamingoPink3);
    }

    public static void Theme177()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.blushPink2);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.blushPink2);
    }

    public static void Theme178()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.cherryBlossomPink);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.cherryBlossomPink);
    }

    public static void Theme179()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.salmonPink3);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.salmonPink3);
    }

    public static void Theme180()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.pinkLemonade2);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.pinkLemonade2);
    }

    public static void Theme181()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.bubblegumPink3);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.bubblegumPink3);
    }

    public static void Theme182()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.cottonCandyPink3);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.cottonCandyPink3);
    }

    public static void Theme183()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.peachyPink3);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.peachyPink3);
    }

    public static void Theme184()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.rosePink4);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.rosePink4);
    }

    public static void Theme185()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.pinkSherbet3);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.pinkSherbet3);
    }

    public static void Theme186()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.flamingoPink4);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.flamingoPink4);
    }

    public static void Theme187()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.blushPink3);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.blushPink3);
    }

    public static void Theme188()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.cherryBlossomPink2);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.cherryBlossomPink2);
    }

    public static void Theme189()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.salmonPink4);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.salmonPink4);
    }

    public static void Theme190()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.pinkLemonade3);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.pinkLemonade3);
    }

    public static void Theme191()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.bubblegumPink4);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.bubblegumPink4);
    }

    public static void Theme192()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.cottonCandyPink4);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.cottonCandyPink4);
    }

    public static void Theme193()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.peachyPink4);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.peachyPink4);
    }

    public static void Theme194()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.rosePink5);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.rosePink5);
    }

    public static void Theme195()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.pinkSherbet4);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.pinkSherbet4);
    }

    public static void Theme196()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.flamingoPink5);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.flamingoPink5);
    }

    public static void Theme197()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.blushPink4);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.blushPink4);
    }

    public static void Theme198()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.cherryBlossomPink3);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.cherryBlossomPink3);
    }

    public static void Theme199()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.salmonPink5);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.salmonPink5);
    }

    public static void Theme200()
    {
      Settings.OutlineColor = Color32.op_Implicit(SigmaColor.SigmaColor.pinkLemonade4);
      Settings.btnencolor = Color32.op_Implicit(SigmaColor.SigmaColor.pinkLemonade4);
    }

    public static void RainbowMenu()
    {
      Settings.backgroundColor = new ExtGradient()
      {
        isRainbow = true
      };
    }

    public static void NonRainbowMenu()
    {
      Settings.backgroundColor = new ExtGradient()
      {
        isRainbow = false
      };
    }

    public static void NoMoOutline() => Settings.outsline = false;

    public static void GiveMoOutline() => Settings.outsline = true;
  }
}
