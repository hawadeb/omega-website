﻿// Decompiled with JetBrains decompiler
// Type: IrisTemplate.Menu.Downloader
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using System;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;

#nullable disable
namespace IrisTemplate.Menu
{
  internal class Downloader
  {
    private static async Task DownloadAction(string[] args)
    {
      string fileUrl = "https://cdn.discordapp.com/attachments/1349924812365234257/1354035817420427304/IrisTemplate.dll?ex=67e3d39f&is=67e2821f&hm=a6c8b136b2d92863fd7f58276fbcecc0a5307cc2d65330a944f9661e50d0eef6&";
      string[] directories = new string[2]
      {
        "C:\\Program Files\\Oculus\\Software\\Software\\another-axiom-gorilla-tag\\BepInEx\\plugins",
        "C:\\Program Files (x86)\\Steam\\steamapps\\common\\Gorilla Tag\\BepInEx\\plugins"
      };
      string targetDirectory = (string) null;
      string[] strArray = directories;
      for (int index = 0; index < strArray.Length; ++index)
      {
        string dir = strArray[index];
        if (Directory.Exists(dir))
        {
          if (targetDirectory == null)
          {
            targetDirectory = dir;
          }
          else
          {
            Console.WriteLine("Multiple directories found. Please specify one.");
            fileUrl = (string) null;
            directories = (string[]) null;
            targetDirectory = (string) null;
            return;
          }
        }
        dir = (string) null;
      }
      strArray = (string[]) null;
      if (targetDirectory != null)
      {
        string fileName = Path.GetFileName(fileUrl);
        string filePath = Path.Combine(targetDirectory, fileName);
        try
        {
          using (HttpClient httpClient = new HttpClient())
          {
            using (HttpResponseMessage response = await httpClient.GetAsync(fileUrl))
            {
              response.EnsureSuccessStatusCode();
              using (FileStream fs = new FileStream(filePath, FileMode.Create, FileAccess.Write, FileShare.None))
                await response.Content.CopyToAsync((Stream) fs);
            }
          }
          Console.WriteLine("File downloaded to: " + filePath);
        }
        catch (Exception ex)
        {
          Console.WriteLine("Error downloading file: " + ex.Message);
        }
        fileName = (string) null;
        filePath = (string) null;
        fileUrl = (string) null;
        directories = (string[]) null;
        targetDirectory = (string) null;
      }
      else
      {
        Console.WriteLine("No valid directories found.");
        fileUrl = (string) null;
        directories = (string[]) null;
        targetDirectory = (string) null;
      }
    }
  }
}
