﻿// Decompiled with JetBrains decompiler
// Type: Loading.Loader
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using UnityEngine;

#nullable disable
namespace Loading
{
  public class Loader : MonoBehaviour
  {
    private static GameObject gameobject;
    public static bool loaded;

    public static void Load()
    {
      Loader.gameobject = new GameObject();
      Object.DontDestroyOnLoad((Object) Loader.gameobject);
    }
  }
}
