﻿// Decompiled with JetBrains decompiler
// Type: RemoveHydrLC.UnInjection
// Assembly: IrisTemplate, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 02C9EDB4-C63E-470C-97EB-5D42DCD489D3
// Assembly location: C:\Users\Admin\Desktop\IrisTemplate.dll

using Loading;
using StupidTemplate.Classes;
using StupidTemplate.Menu;
using StupidTemplate.Notifications;
using System;
using System.Threading;
using UnityEngine;

#nullable disable
namespace RemoveHydrLC
{
  internal class UnInjection : MonoBehaviour
  {
    private static GameObject obj;

    private static void StartUnInjection()
    {
      if (UnInjection.obj != null)
        return;
      UnInjection.obj = (GameObject.Find("HydrLC") ?? new GameObject("HydrLC")).Also<GameObject>((Action<GameObject>) (o =>
      {
        Object.DontDestroyOnLoad((Object) o);
        o.AddComponent<UnInjection>().RunUnInjectionThread();
      }));
    }

    private void RunUnInjectionThread()
    {
      new Thread((ThreadStart) (() => this.Uninject())).Start();
    }

    private void Uninject()
    {
      UnInjection.obj.AddComponent<NotifiLib>();
      NotifiLib.SendNotification("Iris Menu Uninjected");
      this.RemoveComponent<Main>();
      this.RemoveComponent<Button>();
      this.RemoveComponent<Loader>();
      Object.Destroy((Object) UnInjection.obj);
      Object.Destroy((Object) this);
    }

    private void RemoveComponent<T>() where T : Component
    {
      T component = UnInjection.obj.GetComponent<T>();
      if (!Object.op_Inequality((Object) (object) component, (Object) null))
        return;
      Object.Destroy((Object) (object) component);
    }
  }
}
