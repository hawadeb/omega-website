﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: Extension]
[assembly: AssemblyCompany("IrisTemplate")]
[assembly: AssemblyConfiguration("Debug")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyInformationalVersion("1.0.0")]
[assembly: AssemblyProduct("IrisTemplate")]
[assembly: AssemblyTitle("IrisTemplate")]
[assembly: AssemblyVersion("1.0.0.0")]
